import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll() },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  const { data: { user } } = await supabase.auth.getUser()
  const { pathname } = request.nextUrl

  // Always-public routes
  const publicPaths = [
    '/',
    '/auth/login', '/auth/signup', '/auth/reset-password',
    '/auth/callback', '/auth/verify',
    '/api/stripe/webhook',
  ]
  const isPublic =
    publicPaths.includes(pathname) ||
    pathname.startsWith('/auth/') ||
    pathname.startsWith('/join/') ||   // invite links — public
    pathname.startsWith('/share/') ||  // shareable content — public
    pathname.startsWith('/api/stripe/webhook')

  if (isPublic) return supabaseResponse

  // Unauthenticated → login
  if (!user) {
    const url = request.nextUrl.clone()
    url.pathname = '/auth/login'
    url.searchParams.set('redirect', pathname)
    return NextResponse.redirect(url)
  }

  // Fetch role (cached via cookie ideally; fast single-column query)
  const { data: profile } = await supabase
    .from('users')
    .select('role')
    .eq('id', user.id)
    .single()

  const role = profile?.role ?? 'parent'

  // Protect school portal — teachers and admins only
  if (pathname.startsWith('/dashboard/school') && !['teacher', 'admin'].includes(role)) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  // Protect admin routes
  if (
    (pathname.startsWith('/dashboard/users') ||
     pathname.startsWith('/dashboard/analytics') ||
     pathname.startsWith('/dashboard/audit') ||
     pathname.startsWith('/dashboard/subscriptions')) &&
    role !== 'admin'
  ) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  return supabaseResponse
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
}
