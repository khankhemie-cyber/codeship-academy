# CODEship Academy 🚀

> **DREAM. CODE. ACHIEVE.** — AI-powered personalized coding education for Grades K–8.

![Next.js 14](https://img.shields.io/badge/Next.js-14-black) ![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green) ![Stripe](https://img.shields.io/badge/Stripe-Billing-purple) ![Claude AI](https://img.shields.io/badge/Claude-AI%20Powered-orange) ![Bilingual](https://img.shields.io/badge/Language-EN%20%2F%20FR-blue)

---

## What Is CODEship Academy?

A complete K–8 coding education platform serving both families and Ontario schools.

| Level | Grades | Ages | Languages |
|-------|--------|------|-----------|
| 🌱 **Explorers** | K–1 | 6–7 | Scratch Jr, block coding |
| 🏗️ **Builders** | 2–3 | 8–9 | HTML, CSS, Scratch |
| 💻 **Developers** | 4–6 | 10–12 | JavaScript, DOM, APIs |
| ⚙️ **Engineers** | 7–8 | 13–16 | Python, Flask, SQL, Git, ML |

**Curriculum:** 400 lessons · 400 projects · 200 quizzes × 10 questions · 4 levels (Explorers + Builders + Developers complete, Engineers upcoming)

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14 App Router, TypeScript, Tailwind CSS |
| Backend | Supabase (PostgreSQL + Auth + RLS) |
| AI | Anthropic Claude — planner, assessment, tutor, quiz feedback |
| Billing | Stripe — subscriptions, session packs, school licensing, webhooks |
| Email | Resend — weekly parent digest, milestone alerts |
| i18n | next-intl — English + French (bilingual Ontario-ready) |
| Font | Nunito (Google Fonts) |

---

## Quick Start

### 1. Clone and install

```bash
git clone https://github.com/yourname/codeship-academy.git
cd codeship-academy
npm install
```

### 2. Set up environment variables

```bash
cp .env.example .env.local
# Fill in all values — see .env.example for details
```

### 3. Set up Supabase database

Go to [supabase.com](https://supabase.com) → New project → SQL Editor.  
**Run these files in order — do not skip steps:**

```
1. supabase/schema.sql         — 23 tables, RLS, triggers, achievements
2. supabase/curriculum.sql     — 100 lessons, 100+ projects, 40 quizzes
3. supabase/school-portal.sql  — schools, sessions, attendance, certificates
4. supabase/classes.sql        — class codes, invite links, memberships
5. supabase/patch.sql          — visibility, locale, xp_multiplier, topic_mastery
```

Copy your **Project URL**, **anon key**, and **service_role key** into `.env.local`.

### 4. Set up Stripe

1. Go to [dashboard.stripe.com](https://dashboard.stripe.com) → Developers → API keys
2. Copy publishable key and secret key into `.env.local`
3. Create 9 products in Stripe Dashboard:

| Product | Price | Stripe ID env var |
|---------|-------|-------------------|
| Monthly | $19/month | `STRIPE_PRICE_MONTHLY` |
| Annual | $149/year | `STRIPE_PRICE_ANNUAL` |
| Family | $29/month | `STRIPE_PRICE_FAMILY` |
| Classroom | $49/month | `STRIPE_PRICE_TEACHER` |
| 5 Sessions | $495 one-time | `STRIPE_PRICE_SESSIONS_5` |
| 10 Sessions | $890 one-time | `STRIPE_PRICE_SESSIONS_10` |
| 20 Sessions | $1,580 one-time | `STRIPE_PRICE_SESSIONS_20` |
| School Monthly | $299/month | `STRIPE_PRICE_SCHOOL_MONTHLY` |
| School Annual | $2,499/year | `STRIPE_PRICE_SCHOOL_ANNUAL` |

4. Set up webhook: `stripe listen --forward-to localhost:3000/api/stripe/webhook`
5. Copy **webhook signing secret** into `.env.local` as `STRIPE_WEBHOOK_SECRET`

### 5. Set up Anthropic

1. Go to [console.anthropic.com](https://console.anthropic.com) → API keys
2. Add `ANTHROPIC_API_KEY` to `.env.local`

### 6. Set up Resend (email)

1. Go to [resend.com](https://resend.com) → API Keys
2. Add `RESEND_API_KEY` and `EMAIL_FROM` to `.env.local`
3. Verify your sending domain in Resend dashboard

### 7. Run development server

```bash
npm run dev
# Visit http://localhost:3000
```

---

## Deployment (Vercel + Supabase)

```bash
npm install -g vercel
vercel
```

1. Connect your GitHub repo in Vercel dashboard
2. Add **all** environment variables in Vercel → Settings → Environment Variables
3. Set `NEXT_PUBLIC_APP_URL` to your production URL (e.g. `https://app.codeshipacademy.com`)
4. Every push to `main` auto-deploys

### Production Stripe webhook

In Stripe Dashboard → Webhooks → Add endpoint:
- **URL:** `https://your-domain.com/api/stripe/webhook`
- **Events to listen for:**
  - `checkout.session.completed`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`
  - `invoice.payment_succeeded`
  - `invoice.payment_failed`

### Cron job (weekly parent emails)

`vercel.json` already configures this. It fires every Monday at 8am UTC.  
Add `CRON_SECRET` (any random hex string) to Vercel env vars.

---

## User Roles

| Role | What they can do |
|------|-----------------|
| **parent** | Add children, run assessments, use AI planner, view/share progress |
| **teacher** | Create classes, share codes/invite links, collective quiz reports, school portal |
| **student** | Today's tasks, lessons, quizzes, projects, code lab, achievements, leaderboard |
| **admin** | Full CMS, all users, analytics, audit logs, subscription management |

---

## Features

### Learning Platform
- 100 curriculum-aligned lessons across 4 levels
- 100+ coding projects with submission tracking
- 40 quizzes with 160+ questions, instant AI feedback
- ❤️ Lives/hearts system (Duolingo-style engagement)
- XP system with streak multipliers (7d=1.25×, 14d=1.5×, 30d=2×)
- Achievements and badges with PDF certificates on level completion
- Leaderboard (XP + streak rankings)
- Mastery tracking per topic per level

### AI Features
- **AI Lesson Planner** — generates dated weekly plans with XP estimates
- **AI Assessment** — 4-step questionnaire → personalized learning profile
- **AI Tutor** — floating chat on every lesson, context-aware, age-appropriate
- **AI Quiz Feedback** — warm, encouraging post-quiz analysis

### Code Lab
- **CODEship Blocks** — Scratch-like drag-and-drop environment for K–3
- **CODEship Editor** — live HTML/CSS/JS + Python editor with preview pane
  - Python runs in-browser via Skulpt (no server needed)

### Class Management
- Teachers create classes with auto-generated 6-digit codes
- Students join via code at signup or anytime from dashboard
- Invite links with expiry dates and use limits
- `/join/[token]` public landing page (works before login)

### School Portal
- Book and manage 90-minute in-school workshop sessions
- Attendance tracking with per-student engagement scores (1–5)
- **Impact Report Dashboard** — students reached, hours delivered, level breakdown, monthly trend, success proof statements
- CSV export for board/grant reporting
- School license management

### Billing
- 3-tab subscription page: Personal Plans · Session Packs · School Plans
- 14-day free trial (no card required)
- Stripe Billing Portal for self-serve upgrades/cancellations
- Payment history with invoice download

### Bilingual
- Full English + French UI via next-intl
- 267-key translation files for both languages
- Language switcher in dashboard header, persists to user profile

---

## Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── ai/              tutor, planner, assessment, quiz-feedback
│   │   ├── stripe/          checkout, portal, webhook
│   │   ├── emails/          weekly-digest (Vercel cron)
│   │   ├── certificates/    PDF certificate generator
│   │   ├── classes/join/    class code + invite token join
│   │   ├── progress/        progress tracking
│   │   ├── notifications/   in-app notifications
│   │   └── share/           shareable link creation
│   ├── auth/                login, signup, reset-password, verify, callback
│   ├── dashboard/
│   │   ├── (parent)         page, children, assessment, planner, schedule
│   │   ├── (student)        today, curriculum, quizzes, projects, achievements, leaderboard, code-lab
│   │   ├── (teacher)        students, classes, reports, reports/quiz, school/*
│   │   ├── (admin)          users, analytics, audit, subscriptions
│   │   └── (shared)         progress, subscription, settings
│   ├── join/[token]/        public class invite landing page
│   ├── share/[token]/       public progress/certificate sharing
│   └── not-found.tsx
├── components/
│   ├── layout/              DashboardShell, LanguageSwitcher
│   ├── code-lab/            BlocksEnvironment, CodeEditor
│   ├── learning/            AITutorChat, Hearts, MasteryPanel
│   └── classes/             JoinClassWidget
├── lib/                     anthropic, stripe, email, supabase, utils
└── types/index.ts
messages/
├── en.json                  English translations (267 keys)
└── fr.json                  French translations (267 keys)
supabase/
├── schema.sql               23 tables, RLS, triggers, achievements seed
├── curriculum.sql           100 lessons, 100+ projects, 40 quizzes
├── school-portal.sql        schools, sessions, attendance, certificates, share tokens
├── classes.sql              classes, memberships, invite links, join functions
└── patch.sql                visibility, locale, xp_multiplier, topic_mastery, streak multiplier
```

---

## Brand

| Element | Value |
|---------|-------|
| Primary | `#1E2140` (navy), `#2B2D42` (dark), `#3A3D5C` (mid) |
| Accent | `#F5C518` (gold) |
| Font | Nunito (Google Fonts) |
| Tagline EN | DREAM. CODE. ACHIEVE. |
| Tagline FR | RÊVER. CODER. RÉUSSIR. |
| Contact | admin@codeshipacademy.com |
| Website | codeshipacademy.com |
| Address | 21 Simcoe St S, Oshawa ON |

---

## License

© 2026 CODEship Academy. All rights reserved.
