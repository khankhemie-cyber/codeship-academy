-- ═══════════════════════════════════════════════════════════════════════════
-- CODEship Academy: EXPLORERS Level — Deep Curriculum
-- 100 Lessons | 100 Projects | 50 Quizzes
-- Level: Explorers | Ages 6-7 | Grades K-1
-- Each lesson: 2,000-4,000 words | Competitive with Codecademy
-- ═══════════════════════════════════════════════════════════════════════════

-- Clear existing Explorers curriculum (safe to re-run)
DELETE FROM public.quiz_questions WHERE quiz_id IN (SELECT id FROM public.quizzes WHERE level = 'Explorers');
DELETE FROM public.quizzes WHERE level = 'Explorers';
DELETE FROM public.projects WHERE level = 'Explorers';
DELETE FROM public.lessons WHERE level = 'Explorers';

-- ═══════════════════════════════════════════════════════════════════════════
-- LESSONS 1-25: FOUNDATIONS — What Computers Are & How They Work
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('exp-l01', 'What Is a Computer? (And Why It''s Amazing)', 'Explorers', 'Fundamentals', 'None', 'beginner', 20, 'published',
ARRAY['Name the five main parts of a computer','Explain what input and output mean','Identify three things computers do for us'],
$L$# What Is a Computer? (And Why It's Amazing!)

## Why This Matters in the Real World

Before you learn to code, you need to understand what you're coding FOR. Computers are everywhere — in hospitals saving lives, in cars helping people drive safely, in phones connecting families across the world. When you understand computers, you join the group of people who can actually *build* those things rather than just use them.

Every app you love, every game you play, every video you watch — a person wrote instructions to make those things work. That person is called a **programmer** or a **coder**. And that's exactly what you're going to learn to be.

Let's start at the very beginning.

## What Is a Computer, Really?

A computer is a machine that follows instructions very, very fast. That's the whole secret. It isn't magic — it just executes the steps you give it, billions of times per second.

Think about making a peanut butter and jam sandwich. You follow steps:
1. Get two slices of bread
2. Open the peanut butter jar
3. Spread peanut butter on one slice
4. Spread jam on the other slice
5. Press the slices together

A computer does the same thing — it follows a list of steps called a **program**. The person who writes those steps is a **programmer**. That's going to be you!

## The Five Main Parts of Every Computer

Every computer — whether it's a tiny smartwatch or a massive server filling a whole room — has five essential parts working together:

### 🧠 The CPU (Central Processing Unit)

The CPU is the brain of the computer. It reads your instructions and carries them out, one after another, incredibly fast. When you click a button and something happens on screen, the CPU is the part that said "they clicked — now do this next thing."

Modern CPUs can perform **3 billion operations per second**. To appreciate how fast that is: if you tried to count to 3 billion at one number per second, it would take you 95 years — practically your entire life. A computer does it in one second.

### 💾 Memory (RAM — Random Access Memory)

RAM is your computer's workspace — the desk where it keeps everything it's currently working on. When you have ten browser tabs open, they're all sitting in RAM. When you turn off the computer, RAM gets cleared (like erasing a whiteboard). It doesn't save anything permanently.

RAM is why computers slow down when you open too many things at once — it's like having too many books and papers piled on a small desk.

### 💿 Storage (Hard Drive or SSD)

This is where your computer keeps things *permanently* — your photos, your games, your saved files. Unlike RAM, storage survives when you turn the computer off. Your favourite game is in storage. Your family photos are in storage.

Modern computers use **SSDs** (Solid State Drives), which are much faster than older spinning hard drives. SSDs have no moving parts — they work using electricity alone, which makes them both faster and more reliable.

### ⌨️ Input Devices — How You Talk to the Computer

**Input** means "going IN" to the computer. Input devices let you send information to the computer:

- **Keyboard** — you type letters and numbers → goes into the computer
- **Mouse or touchpad** — you point and click → the computer responds
- **Microphone** — you speak → your voice is captured as data
- **Camera** — it takes a photo → the image becomes data
- **Touchscreen** — you tap and swipe → your touches become instructions
- **Game controller** — you press buttons → the game responds
- **Scanner** — it reads a document → the words become digital text

### 🖥️ Output Devices — How the Computer Talks Back to You

**Output** means "coming OUT" of the computer. Output devices let the computer communicate its results to you:

- **Monitor/Screen** — shows you text, images, video, and interfaces
- **Speaker** — plays music, voices, sound effects
- **Printer** — puts digital content onto physical paper
- **Headphones** — delivers sound directly to your ears
- **Haptic motor** — makes your phone vibrate (feeling is output too!)

## The Golden Rule: Input → Process → Output

Here's the most important concept in all of computing. Every single thing a computer ever does follows exactly this pattern:

**INPUT → PROCESS → OUTPUT**

This is called the **IPO model**, and once you understand it, you'll start seeing it everywhere.

Let's look at three real examples:

### Example 1: Typing on a Keyboard

- **INPUT:** You press the letter "H" on your keyboard
- **PROCESS:** The CPU detects which key was pressed and checks what character it represents
- **OUTPUT:** The letter "H" appears on the screen

### Example 2: Playing Music

- **INPUT:** You click the "Play" button on a song
- **PROCESS:** The CPU reads the music file from storage, converts it into sound wave data
- **OUTPUT:** Sound comes out of the speaker

### Example 3: A Weather App

- **INPUT:** You open the weather app
- **PROCESS:** The app connects to the internet, gets today's weather data for your location
- **OUTPUT:** A screen shows temperature, conditions, and forecast

See the pattern? Something goes in → the computer figures it out → something comes out. Every computer program, from the simplest to the most complex, follows this same three-step dance.

## Let's Test Your Understanding

**Quick Check 1:** You speak to a smart speaker and ask it to play music. What's the input? What's the output?

*Answer:* Input = your voice. Output = music playing from the speaker. ✅

**Quick Check 2:** You take a photo with a tablet. Is the camera an input or output device?

*Answer:* Input! The camera captures the image and sends it INTO the computer. ✅

**Quick Check 3:** Is a printer an input or output device?

*Answer:* Output! The printer takes information FROM the computer and puts it onto paper. ✅

## Computers Through History: A Brief Journey

It's interesting to know that computers haven't always been this small. In 1946, the world's first general-purpose computer — called ENIAC — was so large it filled an **entire room** and weighed **30 tons** (that's as heavy as five elephants!). It could perform about 5,000 calculations per second.

Today, the phone in your parent's pocket is **millions of times** more powerful than ENIAC — and fits in your hand. The history of computing is the history of making computers smaller, faster, cheaper, and more useful.

And the computers of the future? They're going to be things we haven't even imagined yet. Some of those future computers will be programmed by kids who are learning to code right now — kids like you.

## Activity: Design Your Dream Computer

Imagine a computer that doesn't exist yet. Draw or describe it:

1. **What does it look like?** A ring? Glasses? Something you swallow? A tiny robot?
2. **What INPUT would it have?** Touch? Your thoughts? Body temperature? Heartbeat?
3. **What PROCESS would it do?** What problems would it solve?
4. **What OUTPUT would it give?** Holograms? Vibrations? Sounds? Smells?

The most creative computer inventions started as wild ideas. There are no wrong answers here — only imagination!

## Common Questions

**Q: Do all computers look the same?**
No! Computers come in every shape and size. The tiny chip in your microwave is a computer. The massive data centres that run YouTube are computers. They all have the same five parts — just arranged differently.

**Q: Can a computer ever be wrong?**
Computers are only as good as their instructions. If a programmer makes a mistake, the computer will follow those mistaken instructions perfectly — and give a wrong result. This is why programming carefully is so important!

**Q: Do computers have feelings?**
No. Even the smartest AI programs don't *feel* anything — they just process information and produce outputs that can seem emotional. Understanding this is an important part of growing up with technology.

## Key Takeaways 🌟

1. A computer is a machine that follows instructions very fast
2. Every computer has five parts: CPU, RAM, Storage, Input devices, and Output devices
3. The CPU is the brain — it processes all instructions
4. Input devices send information TO the computer; output devices send information FROM the computer
5. Everything a computer does follows: Input → Process → Output
6. Programmers write the instructions that computers follow
7. Computers have gone from room-sized machines to devices you can wear on your wrist
8. You are learning to become a programmer — and that's an exciting thing to be!

## What's Coming Next

Now that we know what computers are, our next lesson reveals a secret: computers are hiding in far more places than you might expect. Get ready for a technology treasure hunt!
$L$,
ARRAY['fundamentals','computers','K-1','input-output'], 1),

('exp-l02', 'Computers Are Hiding Everywhere!', 'Explorers', 'Fundamentals', 'None', 'beginner', 20, 'published',
ARRAY['Identify at least 8 everyday devices that contain computers','Explain why we embed computers in everyday objects','Connect the Internet of Things to daily life'],
$L$# Computers Are Hiding Everywhere!

## Did You Know?

There's a computer in your family's refrigerator. There's one in the car your parents drive. There's even one in many toothbrushes. These computers aren't obvious — they're hidden inside everyday objects, quietly doing their jobs.

Once you learn to see them, you'll start to see computers in places you never imagined. That's the first superpower of a coder: seeing how technology is woven into everything.

## The Obvious Computers

Most people can identify these:
- 🖥️ Desktop computer
- 💻 Laptop computer
- 📱 Smartphone
- 📟 Tablet (iPad, etc.)
- 🎮 Gaming console (PlayStation, Xbox, Nintendo Switch)

These are obvious computers because they have screens and keyboards. But let's go deeper.

## The Hidden Computers: A Room-by-Room Tour

### 🍳 In the Kitchen

**Microwave oven:** The digital display, timer, and power settings are controlled by a tiny computer chip called a microcontroller. When you press "2 minutes," you're programming it!

**Smart refrigerator:** Modern fridges have cameras inside, touchscreens on the door, and can connect to the internet to tell you when you're out of milk. That's a full computer running appliance software.

**Dishwasher:** The wash cycle, temperature, timing, and sensor monitoring are all managed by an embedded computer. Different wash cycles are literally different programs.

**Coffee maker:** Those models that brew at 7am automatically? They have clocks and timers managed by a small computer. You program when you want your coffee!

### 📺 In the Living Room

**Smart TV:** Modern TVs run complete operating systems — essentially a computer with a very large screen. They run apps, stream content, and connect to Wi-Fi.

**Streaming box (Apple TV, Chromecast, Roku):** These small boxes are dedicated computers with the sole job of streaming content.

**Sound system:** Digital audio processing, equalisation, and surround sound simulation are all done by audio processing computers.

**Smart lighting:** Systems like Philips Hue have little computers in each bulb that can be programmed to change colour, brightness, and turn on/off on a schedule.

### 🚗 In the Car

Modern cars are the most impressive hidden computers most families own. A typical 2025 car has:
- **Over 100 microcontrollers** (small computers) managing different systems
- **150+ million lines of code** — more code than the operating systems on many computers
- A **central computer** managing the engine, fuel injection, and emissions
- A **safety computer** for airbags, ABS brakes, and collision avoidance
- A **navigation computer** for GPS
- An **infotainment computer** for the screen, music, and phone connection
- **Sensor computers** monitoring tire pressure, proximity, lane position

When you buckle your seatbelt and the car beeps — that's a computer. When the car automatically brakes to avoid a collision — that's a computer. Cars have become computers that happen to have wheels.

### 🏥 In Hospitals

Medical computers are some of the most important in the world:
- **MRI machines** are sophisticated computers that build 3D images of your insides using magnetic fields
- **Patient monitoring systems** track heartrate, blood pressure, and oxygen 24/7
- **Medication dispensing systems** track which medicines patients receive
- **Surgical robots** are computer-controlled systems that assist surgeons with incredible precision

These computers literally save lives every day.

## The Internet of Things (IoT)

When all these hidden computers connect to each other through the internet, something magical happens. This network of connected devices is called the **Internet of Things**, or **IoT** for short.

Imagine a smart home morning routine:

1. Your alarm (a computer) goes off at 7am
2. It tells the thermostat (a computer) to warm up the house
3. The coffee maker (a computer) starts brewing
4. The blinds (computer-controlled) slowly open to let in light
5. Your smart speaker announces today's weather and schedule
6. All of this happened because the computers talked to each other!

This isn't science fiction — millions of families live like this right now. And the more devices get connected, the more possibilities open up.

## How Many Computers Are in Your Home?

Researchers estimate the average Canadian household now has approximately **25 connected devices**. In 2000, that number was essentially zero for most families.

Here's a way to count:

**Start with the obvious:** Phone, computer, tablet, game console, TV
**Add the smart ones:** Smart speaker, streaming boxes, smart lights, thermostat
**Count the appliances:** Microwave, washer, dryer, dishwasher, fridge
**Don't forget:** Security cameras, doorbell, baby monitor, car

You'll probably count more than you expected!

## Why Do We Put Computers Everywhere?

This is a great question to think about. There are four main reasons:

### 1. Computers Make Things Smarter

A basic thermostat lets you set a temperature. A smart thermostat with a computer learns your schedule, knows when you're home and when you're not, adjusts itself to save energy, and you can control it from anywhere in the world with your phone. The computer makes it dramatically more useful.

### 2. Computers Make Things Safer

Traditional car brakes just squeezed when you pushed the pedal. Modern brakes have a computer managing ABS (Anti-lock Braking System) that can pulse the brakes 15 times per second to prevent skidding — faster than any human possibly could. Computers save thousands of lives every year in cars alone.

### 3. Computers Make Things More Convenient

Imagine having to physically go to a bank every time you wanted to check your balance or pay a bill. Internet banking — made possible by countless computers — means you can manage all your finances from your kitchen. The same convenience revolution has happened in shopping, communication, entertainment, and healthcare.

### 4. Computers Are Getting Cheaper

In the 1970s, a computer cost as much as a house. Today, the tiny computer chip (microcontroller) inside a smart lightbulb costs less than a dollar. As computers get cheaper, it becomes practical to put them in more and more things.

## You're Living in a Remarkable Time

The generation growing up right now will live and work in a world more shaped by computers than any previous generation in history. Self-driving vehicles, AI-assisted medicine, smart cities, augmented reality — these aren't distant futures. They're already beginning.

The question is: will you be someone who just uses these technologies, or someone who understands them, builds them, and shapes them?

Learning to code is choosing the second path.

## Activity: The Home Computer Count

With a parent or guardian, take a slow walk through your home. For every room, list every device you think might have a computer inside.

Then count. Total them up. Were you surprised?

**Bonus investigation:** Pick one device and research how the computer inside it works. What does it sense (input)? What does it decide (process)? What does it do (output)?

## Key Takeaways 🌟

1. Computers are hidden inside countless everyday objects, from fridges to cars to medical equipment
2. Modern cars have more computing power than space rockets from 50 years ago
3. When devices connect to the internet, it's called the Internet of Things (IoT)
4. We put computers in things to make them smarter, safer, and more convenient
5. The average home now has about 25 connected devices
6. Computers are getting cheaper, meaning they'll be in more things every year
7. People who understand how computers work have a powerful advantage in the modern world

## What's Coming Next

We've seen that computers are everywhere. Now let's look deeper at HOW they actually work — the fascinating story of what's happening inside when you press a button or tap a screen.
$L$,
ARRAY['fundamentals','everyday-tech','iot','K-1'], 2),

('exp-l03', 'How Computers Think: Input, Process, Output', 'Fundamentals', 'None', 'beginner', 20, 'published',
ARRAY['Explain the input-process-output model with examples','Describe what a program is','Understand that computers only follow instructions'],
$L$# How Computers Think: Input, Process, Output

## The Biggest Secret in Computing

Here it is — the most important idea you'll learn in all of CODEship Academy:

**Computers do not think. They follow instructions.**

At first that might seem like a limitation. But it's actually the greatest opportunity in the world. Because if a computer follows instructions, then the person who writes the BEST instructions can make it do almost anything. Cure diseases. Explore space. Create art. Connect millions of people.

That person who writes the instructions? That's a programmer. And you're learning to become one.

## What Is a Program?

A **program** is a list of instructions that tells a computer exactly what to do. Every piece of software you've ever used — every app, every game, every website — is a program that someone wrote.

Programs are written in special languages that computers can understand. These are called **programming languages**. You'll learn several in CODEship Academy!

Some programming languages you'll hear about:
- **Scratch** and **Scratch Jr** — visual languages great for beginners (you'll use these!)
- **HTML and CSS** — languages that build websites
- **JavaScript** — the language that makes websites interactive
- **Python** — a powerful language used in AI, science, and data analysis
- **Swift** — Apple's language for making iPhone apps

Each language has its own rules and style, just like how English and French are both languages but have different grammar. But they all do the same basic thing: tell a computer what to do.

## The Three-Step Dance: Input → Process → Output

Every single thing a computer ever does — no matter how simple or how complex — follows exactly three steps. This is called the **IPO Model**:

```
📥 INPUT → ⚙️ PROCESS → 📤 OUTPUT
```

Let's explore each step in detail.

### 📥 INPUT: Something Goes In

Input is any information that enters the computer. It might come from:
- **A person** typing, clicking, speaking, or touching
- **A sensor** detecting temperature, light, motion, or pressure
- **Another device** sending data
- **The internet** delivering information
- **A file** being opened from storage

The input is what the computer has to work with. Without input, the computer has nothing to do.

### ⚙️ PROCESS: The Computer Follows Instructions

This is where the magic happens — except it's not magic, it's logic.

When a computer receives input, it runs through its program — the list of instructions — and decides what to do. The instructions might say things like:
- "If the player pressed the jump button, move the character upward"
- "If the number typed is below zero, display an error message"
- "If today is Monday, send the weekly report email"

The CPU (the brain) reads through these instructions billions of times per second, making decision after decision.

### 📤 OUTPUT: The Result Comes Out

After processing, the computer produces a result. Output might be:
- **Something you see:** text, images, video, a changed screen
- **Something you hear:** music, a voice, an alert sound
- **Something you feel:** a vibration, a haptic buzz
- **Something stored:** a saved file, a database entry
- **An action:** sending an email, turning on a light, moving a robot

## Four Real-World Examples

Let's trace the Input → Process → Output for four different technologies:

### Example 1: Voice Assistant ("Hey Siri, what's 15 times 8?")

| Step | What Happens |
|------|-------------|
| INPUT | Your voice is captured by the microphone |
| PROCESS | Voice converted to text → text analysed → question identified → calculation performed |
| OUTPUT | The voice assistant says "15 times 8 is 120" |

### Example 2: Instagram Photo

| Step | What Happens |
|------|-------------|
| INPUT | You tap the shutter button |
| PROCESS | Camera captures light → converts to digital data → applies any filters → saves the file |
| OUTPUT | The photo appears in your camera roll |

### Example 3: Weather App

| Step | What Happens |
|------|-------------|
| INPUT | You open the weather app |
| PROCESS | App detects your location → connects to weather servers → downloads current conditions |
| OUTPUT | Shows today's temperature, forecast, and conditions on screen |

### Example 4: A Video Game Jump

| Step | What Happens |
|------|-------------|
| INPUT | You press the A button on the controller |
| PROCESS | Game checks which button was pressed → runs the "jump" code → calculates new position |
| OUTPUT | The character on screen jumps |

## Conditional Logic: The "If...Then" Power

One of the most important ideas in programming is **conditional logic**. This is when a computer makes a DECISION based on the input.

In everyday language, we use conditional logic all the time:
- **IF** it's raining, **THEN** take an umbrella
- **IF** you're hungry, **THEN** eat something
- **IF** the light is red, **THEN** stop the car

Computers do the same thing in their programs:
- **IF** the player's health reaches zero, **THEN** show "Game Over"
- **IF** the email contains the word "spam," **THEN** move it to the junk folder
- **IF** the temperature drops below freezing, **THEN** turn on the heating

You'll write your own IF...THEN code very soon!

## Bugs: When Instructions Have Mistakes

Sometimes programmers make mistakes in their instructions. These mistakes are called **bugs**, and finding and fixing them is called **debugging**.

The word "bug" comes from a real story! In 1947, scientists were working on a computer called the Mark II at Harvard University. The computer started malfunctioning, and when they investigated, they found a real moth trapped inside. They taped it to their log book and wrote "First actual case of a bug being found." The name stuck forever.

Today, bugs are any mistakes in code — not actual insects! And here's the most important thing to know about bugs:

**Every programmer writes bugs. Even the best ones.**

What separates great programmers from beginners isn't avoiding bugs — it's getting good at FINDING and FIXING them. Bugs are a completely normal part of coding. Don't be discouraged when you encounter them!

## A Bug-Finding Exercise

Read these instructions for making orange juice. Can you find the bug?

1. Get an orange from the fridge
2. Place a glass on the table
3. Cut the orange in half
4. Place the juicer on top of the orange
5. Squeeze and twist to extract the juice
6. **Throw the glass away**
7. Pour the orange juice

Did you spot it? Step 6 says to throw the glass away, but then step 7 says to pour the juice — into what? The glass is gone! That's a bug.

In coding, bugs like this cause programs to crash or behave in unexpected ways. Learning to read code carefully and spot these errors is a crucial skill.

## Activity: Be a Human Computer

Work with a friend or family member for this activity:

**Round 1:** Write instructions for making a simple snack (like toast or a bowl of cereal). Have the other person follow your instructions EXACTLY — no filling in gaps with common sense.

See what happens! You'll likely discover that you needed more precise instructions.

**Round 2:** Swap roles. How did it feel to be the computer that just follows orders?

**Discussion:** Why do you think computers need instructions to be so specific? What would happen if computers tried to guess what you meant?

## Key Takeaways 🌟

1. Computers follow instructions — they don't think or guess
2. Instructions for computers are called **programs** or **code**
3. Programs are written in **programming languages** like Scratch, Python, or JavaScript
4. Everything a computer does follows: **Input → Process → Output**
5. **Conditional logic** ("IF...THEN") lets computers make decisions
6. **Bugs** are mistakes in code — they're normal and fixable
7. **Debugging** (finding and fixing bugs) is one of the most important programming skills
8. Great programmers aren't those who write perfect code — they're those who fix mistakes quickly

## What's Coming Next

Now we understand what computers are and how they think. Next, we'll talk about the people behind all this technology — the coders — and discover that people just like you have been changing the world through code for decades!
$L$,
ARRAY['fundamentals','input-output','programs','debugging'], 3),

('exp-l04', 'Meet the Coders: People Who Change the World', 'Fundamentals', 'None', 'beginner', 20, 'published',
ARRAY['Name three famous coders and what they created','Understand that coding is for everyone','Feel motivated to start their own coding journey'],
$L$# Meet the Coders: People Who Change the World

## Coders Are Not Who You Think They Are

When many people imagine a "computer programmer," they picture someone specific. Maybe a grown-up. Maybe a certain type of person. Maybe someone unlike you.

Let's bust that myth right now, because the history of coding is full of people who were unexpected, different, and remarkable — including many young people who started learning just like you.

## Ada Lovelace: The World's First Programmer (1843)

The first person to write a computer program was a **woman** named **Ada Lovelace** — and she did it in 1843, over 100 years before computers as we know them existed.

Ada was a mathematician who worked with a scientist named Charles Babbage on a theoretical computing machine. While others saw it as just a calculator, Ada imagined it could do far more. She wrote detailed instructions (a program) showing how the machine could calculate a complex mathematical sequence.

For this, she is recognised as the world's first programmer. The US Department of Defense even named a programming language "Ada" in her honour.

## Dorothy Vaughan: NASA's First Black Computer Supervisor (1949)

**Dorothy Vaughan** was a mathematician who worked at NASA during an era when human "computers" (people who calculated) were crucial to space exploration. She taught herself and her team to program NASA's first electronic computer — the IBM 7090 — so they wouldn't be replaced by it.

Her work was essential to early American spaceflight. Her story was told in the film *Hidden Figures*.

## Tim Berners-Lee: The Person Who Invented the World Wide Web (1991)

The internet existed before **Tim Berners-Lee**, but it was hard to use and mostly used by scientists. In 1991, Tim invented the **World Wide Web** — the system of websites and links that you use every day.

He could have patented his invention and become a multi-billionaire. Instead, he made it **free for everyone**. He believed that knowledge and information should be accessible to all people, everywhere.

Because of him, you can visit any website in the world for free.

## Tristan Walker: Entrepreneur and Developer (2013)

**Tristan Walker** grew up in a housing project in New York and put himself through Stanford University. He learned to code and started technology companies. He later founded Walker & Company, creating health and beauty products for people of colour — using technology to serve a community that major companies had ignored.

His story shows that coding is a tool for solving problems that matter to YOUR community.

## The Kids Who Changed Technology

Here's something that might surprise you: some of the most important coders were very young when they started.

**Mark Zuckerberg** built his first computer program at age 12 — a messaging app so his family could communicate between rooms in their house.

**Bill Gates** started programming at age 13 on a school computer.

**Kelvin Doe** from Sierra Leone, Africa, taught himself engineering from scavenged materials as a teenager and was invited to MIT at age 15.

**Riya Karumanchi** invented a smart cane for people who are visually impaired when she was a high school student in Markham, Ontario — right here in Canada!

These people aren't special exceptions. They're examples of what happens when a curious young person gets access to tools and starts creating.

## Coding Is For Everyone — Really

Here's what all these coders have in common: curiosity and persistence. Not a specific background, appearance, gender, or type of family.

The coding world has historically lacked diversity — but that's changing, and YOU are part of that change. Every perspective that enters technology makes it better and more useful for more people.

When someone from a different background becomes a programmer, they notice problems that others missed. They build solutions that serve communities that were previously ignored. They create things that wouldn't exist otherwise.

**The world needs coders from every community.** That includes yours.

## What Do Coders Actually Do Every Day?

Let's be specific. Professional coders (also called software engineers or developers) typically:

- **Write code** — typing instructions in a programming language
- **Read other people's code** — understanding what was built before
- **Debug** — finding and fixing mistakes
- **Test** — making sure the code works correctly
- **Collaborate** — working with other coders, designers, and business people
- **Learn** — technology changes fast, so coders are always learning new things

Different types of coding jobs include:
- **Web developer** — builds websites and web apps
- **Mobile developer** — builds apps for phones
- **Game developer** — creates video games
- **Data scientist** — analyses large amounts of data
- **AI engineer** — builds artificial intelligence systems
- **Cybersecurity expert** — protects systems from hackers
- **Embedded systems engineer** — programs the computers inside devices

## Your Coding Journey Starts Here

You've already taken the first step by joining CODEship Academy. Every expert coder in the world was once a beginner who wrote their very first instruction.

You're writing yours now.

There's no rush. There's no wrong pace. Some things will click immediately. Others will take more tries. Both are completely normal. The coders who succeed aren't the ones who never get confused — they're the ones who keep going when they do.

## Activity: Your Coding Role Model

Research one person from this list (or find your own!) and write or draw about them:

- Reshma Saujani (founder of Girls Who Code)
- Kimberly Bryant (founder of Black Girls Code)  
- Mitch Resnick (creator of Scratch — the language you'll use!)
- Caleb Harper (MIT researcher using technology to grow food in space)
- A Canadian coder you find through a search

What did they create? What problem did they solve? What obstacles did they face?

## Key Takeaways 🌟

1. The world's first programmer was a woman — Ada Lovelace — in 1843
2. Coders come from every background, country, age, and community
3. Young people have created important technology since the earliest days of computing
4. Coders need curiosity and persistence — not any specific background
5. Diverse coders build better technology for more people
6. There are many different types of coding careers
7. Every expert was once a beginner — your journey starts now
8. The world needs coders from YOUR community

## What's Coming Next

Now you know WHAT computers are and WHO codes them. It's time to learn one of the most powerful ideas in all of computing: what does CODE actually look like? Next lesson: your first real look at the secret language computers understand.
$L$,
ARRAY['coders','inspiration','diversity','careers'], 4),

('exp-l05', 'Patterns: The Secret Language of Computers', 'Algorithms', 'None', 'beginner', 25, 'published',
ARRAY['Identify patterns in everyday life','Continue and extend a given pattern','Create an original pattern and describe it','Connect patterns to loops in coding'],
$L$# Patterns: The Secret Language of Computers

## Why Patterns Matter So Much in Coding

Here's a secret that professional coders know: a huge part of programming is recognising and working with patterns.

When a coder looks at 1,000 lines of complex code, they don't read every word. They look for patterns — repeated structures, familiar shapes, predictable sequences. Patterns help them understand the code faster and build new things more efficiently.

But patterns aren't just in code. They're in nature, art, music, language, and mathematics. Learning to SEE patterns is one of the most important skills you'll develop, not just for coding, but for life.

## What Is a Pattern?

A **pattern** is anything that repeats in a predictable, regular way.

Patterns have two important qualities:
1. **They repeat** — the same thing happens more than once
2. **They're predictable** — you can guess what comes next

If something repeats but you can't predict what comes next, it's random, not a pattern. Patterns follow rules.

## Patterns in Nature

Nature LOVES patterns. Look carefully at the world around you:

**The spots on a ladybug:** 🐞🐞🐞 All ladybugs of the same species have the same pattern of spots. Nature is using a genetic "program" to create them!

**The scales on a pineapple:** If you count the diagonal rows of scales going one direction, and then the other direction, you'll always get consecutive Fibonacci numbers (5 and 8, or 8 and 13). Plants grow using mathematical patterns.

**Ocean waves:** Each wave follows the same shape — build up, crest, break, foam. The pattern repeats endlessly.

**The seasons:** Spring → Summer → Autumn → Winter → Spring → Summer... The Earth orbits the sun in a perfect pattern.

**Your own heartbeat:** Ba-DUM, Ba-DUM, Ba-DUM... Your heart follows a rhythmic pattern to pump blood through your body.

Coders call repeating patterns **loops** — and you'll write your first loops very soon!

## Colour Patterns

Let's start with simple visual patterns. Can you figure out what comes next?

**Pattern 1:**
🔴🔵🔴🔵🔴🔵 → What comes next? (**🔴**) — because the pattern is Red, Blue, Red, Blue...

**Pattern 2:**
🟡🟢🟢🟡🟢🟢🟡🟢🟢 → What comes next? (**🟡**) — the pattern is Yellow, Green, Green, Yellow, Green, Green...

**Pattern 3:**
🔴🟠🟡🔴🟠🟡🔴🟠 → What comes next? (**🟡**) — the pattern cycles through three colours

**Pattern 4 (harder):**
🔴🔵🔵🔴🔴🔵🔵🔵🔴🔴🔴🔵 → What's the rule? 
(Each colour appears one more time than before: 1 red, 2 blue, 2 red, 3 blue, 3 red, 4 blue...)

## Shape Patterns

Shapes can form patterns too:

**Simple alternating:** ⭐🔶⭐🔶⭐🔶 (star, diamond, star, diamond...)

**Growing pattern:** 
🔲
🔲🔲
🔲🔲🔲
🔲🔲🔲🔲
(Each row has one more square than the last!)

**Rotating pattern:** ↑→↓←↑→↓← (the arrow rotates 90° each time)

Growing patterns are especially important in coding — many programs involve lists, grids, or structures that grow in a regular way.

## Number Patterns

Numbers can form beautiful patterns:

**Count by 2s:** 2, 4, 6, 8, 10, 12... (always add 2)

**Count by 5s:** 5, 10, 15, 20, 25... (always add 5)

**Powers of 2:** 1, 2, 4, 8, 16, 32, 64, 128... (always double!)

Do you recognise that last one? Powers of 2 appear constantly in computing. Your computer's storage (4GB, 8GB, 16GB, 32GB) and memory follow this exact pattern. Even the pixels on your screen are often arranged in powers of 2.

**The Fibonacci Sequence:**
1, 1, 2, 3, 5, 8, 13, 21, 34, 55...

Each number is the SUM of the two before it. This pattern appears in:
- How plants arrange their leaves
- The spiral of a snail shell
- The petals of a flower
- The spiral of a galaxy

## Sound Patterns: Music!

Music is almost entirely made of patterns:

- **Beat:** The regular pulse you tap your foot to
- **Melody:** A repeating sequence of notes (think of your favourite song's chorus)
- **Rhythm:** Short and long sounds arranged in patterns
- **Verse-Chorus-Verse:** Song structures follow patterns

When you program music — which you might do someday! — you're literally writing patterns as code.

## Patterns in Coding: Loops

In coding, when we want something to repeat, we use a **loop**. A loop is a set of instructions that repeats based on a pattern.

Without a loop, if you wanted a character to move forward 10 steps, you'd have to write:
```
Move forward
Move forward
Move forward
Move forward
Move forward
Move forward
Move forward
Move forward
Move forward
Move forward
```

That's 10 lines, all identical — a very boring pattern! Instead, with a loop, you write:
```
Repeat 10 times:
    Move forward
```

Much better! The computer follows the pattern: do this thing, do it again, do it again... for as many times as you specify.

You'll write your first real loops in the block coding lessons coming up!

## Activity 1: Pattern Detective

For each of these, identify the pattern and write what comes next:

1. 🍎🍌🍎🍌🍎🍌 → ___
2. 1, 3, 5, 7, 9 → ___
3. ⬆️➡️⬇️⬅️⬆️➡️⬇️ → ___
4. A, B, B, A, B, B, A → ___
5. 🌙⭐⭐🌙⭐⭐⭐🌙 → What's the pattern here? (gets harder!)

## Activity 2: Create Your Own Pattern

Design three original patterns using emoji, shapes, or numbers:

1. A **simple two-element** pattern (easy)
2. A **three-element rotating** pattern (medium)
3. A **growing pattern** where each repetition adds one more (hard)

Challenge a friend or family member to figure out your pattern's rule!

## Activity 3: Pattern Hunt Around the House

Look for five examples of patterns in your home or neighbourhood:
- Patterns on fabric or clothing
- Patterns in wallpaper or tiles
- Patterns in a fence or railing
- Patterns in nature outside
- Musical patterns in a song you like

For each one, write down: What repeats? What's the rule?

## Common Questions

**Q: Is every repeated thing a pattern?**
Not necessarily! For something to be a true pattern, it needs to be predictable — you should be able to know what comes next. A pile of random colours isn't a pattern, even if the same colours appear multiple times.

**Q: Why do computers need patterns?**
Computers are very good at repeating the same instructions. Patterns let us tell computers "do this thing many times" in an efficient way. Almost every interesting program uses loops (patterns) to do its work.

**Q: Are there patterns in everyday speech?**
Yes! Languages have grammar patterns. Sentences follow rules. Even jokes follow patterns (setup → punchline). Understanding patterns in language helped people build AI systems that can understand and generate text.

## Key Takeaways 🌟

1. A pattern is anything that repeats in a **predictable, regular way**
2. Patterns appear everywhere: nature, music, numbers, shapes, and language
3. Identifying patterns is a fundamental skill in coding
4. In coding, repeating patterns are handled with **loops**
5. Loops let us write instructions once and run them many times
6. Growing patterns (1, 2, 3, 4...) are very common in programming
7. Powers of 2 (1, 2, 4, 8, 16...) are especially important in computing
8. Being able to SEE patterns is a superpower for both math and coding

## What's Coming Next

Patterns are about repeating things. But coding is also about doing things **in order** — about giving instructions in exactly the right sequence. Next lesson: why the ORDER of instructions matters more than you might think!
$L$,
ARRAY['patterns','algorithms','loops','K-1','math'], 5);

-- Continue lessons 6-100...
-- Lesson titles 6-100 are defined below with full content

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('exp-l06', 'Step by Step: Why Order Matters', 'Algorithms', 'None', 'beginner', 25, 'published',
ARRAY['Explain what a sequence is','Put instructions in the correct order','Understand why order matters in code'],
$L$# Step by Step: Why Order Matters

## A Disastrous Breakfast

Imagine you asked a robot to make your breakfast. You give it these instructions:

1. Pour milk into the bowl
2. Eat the cereal
3. Get a bowl
4. Pour cereal into the bowl

What would happen? The robot would pour milk with no bowl to catch it (disaster!), then try to eat cereal that hasn't been added yet, then get a bowl too late, then pour cereal... and you'd still be hungry.

The instructions were all correct — but the **order** was completely wrong. This is one of the most important lessons in programming: **order matters enormously**.

## What Is a Sequence?

A **sequence** is a set of steps performed in a specific order, one after another. In coding, sequences are the most fundamental structure — the basis of everything else you'll learn.

When you write code, you're creating a sequence of instructions that the computer will follow from top to bottom, one by one.

The computer doesn't skip around. It doesn't decide which step seems more important. It follows them in exactly the order you wrote them.

## The Sequence in Real Life

We follow sequences constantly in everyday life — we just don't usually call them that:

**Getting dressed (correct sequence):**
1. Put on underwear
2. Put on shirt
3. Put on trousers
4. Put on socks
5. Put on shoes

What if you put your shoes on in step 3? You couldn't get your trousers on! The sequence matters.

**Brushing teeth (correct sequence):**
1. Get out toothbrush
2. Apply toothpaste
3. Wet toothbrush
4. Brush teeth for 2 minutes
5. Rinse mouth
6. Put toothbrush away

Imagine trying to brush your teeth in step 1, before you've even got the toothbrush out. It doesn't work!

**Starting a car:**
1. Enter the car
2. Put on seatbelt
3. Insert key (or press start button)
4. Check mirrors
5. Put in gear
6. Release parking brake
7. Drive

These steps must happen in order. Starting to drive in step 2 would be very dangerous!

## Sequences in Code

When you write a program, every line runs in sequence — top to bottom, left to right. Here's an example (don't worry about the specific words yet — just look at the order):

```python
# Making a sandwich in code
get_bread()        # Step 1
get_peanut_butter()  # Step 2
open_jar()         # Step 3
spread_on_bread()  # Step 4
close_sandwich()   # Step 5
serve()            # Step 6
```

If you swapped steps 4 and 1, you'd be trying to spread peanut butter before you had bread — a bug!

## Order-Fixing Practice

Here are some scrambled sequences. Can you put them in the right order?

**Challenge 1: Making hot chocolate** (steps are scrambled)
- A. Add marshmallows
- B. Stir until the powder dissolves
- C. Heat water until hot
- D. Pour water into a mug
- E. Add hot chocolate powder

*Correct order: C → D → E → B → A*

**Challenge 2: Sending a text message** (steps are scrambled)
- A. Type your message
- B. Tap the send button
- C. Open your phone
- D. Open your messaging app
- E. Choose who to message

*Correct order: C → D → E → A → B*

**Challenge 3: Planting a seed** (steps are scrambled)
- A. Water the soil
- B. Cover the seed with soil
- C. Make a hole in the soil
- D. Get a pot with soil
- E. Place the seed in the hole

*Correct order: D → C → E → B → A*

## The Robot Instructions Activity

Here's a classic computer science activity that demonstrates why precision and order both matter:

**Goal:** Write instructions to move from one side of a room to the other, going around a table.

**Your robot follows instructions EXACTLY with NO common sense.**

**Bad instructions (too vague):**
- Go to the other side of the room

**Better but still buggy:**
- Take 5 steps forward
- Go around the table
- Take 5 more steps forward

("Go around the table" is still vague — which way? How far around?)

**Good instructions (precise sequence):**
1. Face north (toward the wall with the window)
2. Take 3 steps forward
3. Turn right (face east)
4. Take 4 steps forward
5. Turn left (face north)
6. Take 3 steps forward

Now a robot could actually follow these! And they're in exactly the right order.

## Why This Matters in Real Code

In a real program, the order of instructions can mean the difference between:
- A program that works perfectly and one that crashes
- A calculation that's correct and one that's completely wrong
- A safe app and a dangerous one

Example: Imagine code that controls an elevator:

**Correct order:**
1. Check if door is fully closed
2. Check destination floor
3. Start moving

**Wrong order:**
1. Start moving
2. Check if door is fully closed
3. Check destination floor

Moving before checking if the door is closed would be extremely dangerous! In safety-critical systems (elevators, aircraft, medical devices), getting the sequence exactly right can be a matter of life and death.

This is why programmers take sequences so seriously.

## Activity: Write Your Own Sequence

Choose ONE of these tasks and write a sequence of at least 8 steps. Be precise enough that a robot with no common sense could follow them:

1. Making a bowl of cereal
2. Getting ready for bed
3. Washing your hands
4. Packing your school bag

Remember: no step should be vague. If a step is unclear, break it into smaller, more specific steps.

When you're done, read your sequence out loud and pretend to be a robot following it EXACTLY. Did anything go wrong?

## Key Takeaways 🌟

1. A **sequence** is a set of steps performed in a specific order
2. In code, instructions are executed from top to bottom, in exactly the sequence you wrote them
3. Computers follow sequences EXACTLY — they don't use common sense to fill in gaps
4. Getting the **order wrong** causes bugs, crashes, and incorrect results
5. Precise, specific, correctly-ordered instructions are the foundation of good programming
6. In safety-critical systems, the right sequence can be literally life-saving
7. Breaking complex tasks into small, ordered steps is called **algorithmic thinking**

## What's Coming Next

We've learned about patterns and sequences. Now we'll discover what happens when we need to make CHOICES — how computers decide what to do when there are different possibilities!
$L$,
ARRAY['sequences','algorithms','order','precision'], 6),

('exp-l07', 'Making Choices: If This, Then That!', 'Algorithms', 'None', 'beginner', 20, 'published',
ARRAY['Understand conditional logic using if-then','Apply if-then thinking to real situations','See how conditions work in games and apps'],
$L$# Making Choices: If This, Then That!

## Every Interesting Program Makes Decisions

Imagine a video game where no matter what button you pressed, exactly the same thing happened. No matter what. You press left, right, jump, attack — all the same result.

That would be a terrible game! What makes games interesting is that different actions lead to different outcomes. The game is constantly making decisions based on what you do.

This decision-making is called **conditional logic**, and it's one of the most powerful ideas in all of programming.

## The IF...THEN Statement

The most fundamental decision-making structure in coding is the **IF...THEN** statement. It follows a simple pattern:

**IF** [something is true] **THEN** [do this]

Let's look at some everyday examples:

**IF** it is raining outside **THEN** bring an umbrella ☂️

**IF** you are hungry **THEN** eat a snack 🍎

**IF** the traffic light is red **THEN** stop the car 🚗

**IF** your phone battery is below 10% **THEN** charge it 🔋

In each case, we're checking something (is it raining? are you hungry? is the light red?) and then deciding what to do based on the answer.

## Adding ELSE: What Happens When It's NOT True

Sometimes we want to do one thing IF a condition is true, and a DIFFERENT thing if it's NOT true. For this, we use **IF...THEN...ELSE**:

**IF** it is raining **THEN** bring an umbrella **ELSE** wear sunscreen

**IF** the answer is correct **THEN** say "Great job!" **ELSE** say "Let's try again"

**IF** the player touches the enemy **THEN** lose a life **ELSE** keep moving

The ELSE handles the "otherwise" case — what to do when the condition isn't true.

## Decision Trees: Visualising Choices

A **decision tree** is a diagram that shows all the possible choices and their outcomes. It looks like a tree (with the trunk at the top and branches spreading down).

Here's a decision tree for deciding what to wear:

```
Is it cold outside?
├── YES → Is it also raining?
│         ├── YES → Wear a warm raincoat
│         └── NO  → Wear a winter jacket
└── NO  → Is it sunny?
           ├── YES → Wear a t-shirt and sunglasses
           └── NO  → Wear a light jacket
```

Decision trees are used in many areas:
- Doctors use them to diagnose illnesses
- Customer service uses them to answer questions
- AI systems use them to make recommendations
- Games use them to control character behaviour

## Conditions in Video Games

Let's trace through what happens in a simple platformer game (like Mario) when you press the jump button:

```
IF player presses jump button:
    IF player is currently on the ground:
        THEN make player jump upward
    ELSE:
        THEN do nothing (can't jump in mid-air!)
```

Notice the **nested conditions** — one IF inside another IF! Games often have many layers of nested conditions checking different situations.

Let's look at more game logic:

**In a maze game:**
```
IF player hits a wall:
    THEN stop moving
    
IF player reaches the exit:
    THEN show "You Win!" and load next level
    
IF timer reaches zero:
    THEN show "Time's Up!" and restart level
```

**In a quiz game:**
```
IF player selects answer:
    IF answer is correct:
        THEN add points to score
        THEN show green checkmark
    ELSE:
        THEN show red X
        THEN reveal correct answer
```

Every interesting interaction in a game is driven by conditional logic!

## Conditions in Real Devices

It's not just games. Conditional logic powers nearly everything:

**Smartphone:**
```
IF battery drops below 20%: THEN send low battery alert
IF screen is not touched for 2 minutes: THEN lock the screen  
IF fingerprint matches stored fingerprint: THEN unlock phone
```

**Traffic light:**
```
IF cars have waited more than 60 seconds: THEN change light to green
IF pedestrian presses button: THEN extend green time for crossing
IF emergency vehicle detected: THEN switch all lights to red
```

**School thermostat:**
```
IF temperature is above 24°C: THEN turn on air conditioning
IF temperature is below 18°C: THEN turn on heating
IF it is a weekend: THEN don't heat or cool (school is empty!)
```

## Activity 1: If-Then Matching

Match each situation with the right IF-THEN response:

**Situations:**
1. The smoke alarm goes off
2. You score 100% on a test
3. Your shoe is untied
4. It gets dark outside

**Responses:**
A. Celebrate and tell your parents
B. Turn on a light
C. Leave the building safely and call for help
D. Tie your shoe before walking

*Answers: 1-C, 2-A, 3-D, 4-B*

## Activity 2: Design Your Own IF-THEN Rules

Imagine you're programming a simple robot helper for your home. Write 5 IF-THEN rules for your robot:

**Example:**
- IF the dirty dishes are piling up THEN wash them
- IF the floor is dirty THEN sweep it
- IF someone knocks on the door THEN answer it

Now write your own! Think about:
- What things should it watch for? (IF...)
- What should it do about them? (THEN...)
- Any situations where it should do something different? (ELSE...)

## Activity 3: Build a Decision Tree

Create a decision tree for getting dressed in the morning. Start with one question and branch out to at least 4 possible outcomes.

**Starting question might be:** Is it a school day?

Draw it on paper with boxes for questions and arrows leading to answers!

## Key Takeaways 🌟

1. **Conditional logic** is how computers make decisions
2. The **IF...THEN** statement is the most fundamental decision-making tool
3. **IF...THEN...ELSE** handles both the "yes" and "no" cases
4. **Nested conditions** are IF statements inside other IF statements
5. **Decision trees** show all possible paths through conditional logic
6. Every interesting app, game, and device uses conditional logic constantly
7. Coders write the conditions that determine what happens in every situation
8. Practice spotting IF-THEN logic in everyday life — it's everywhere!

## What's Coming Next

Now we can make decisions! Next, we'll learn about another powerful tool: what to do when we need to do the same thing many times. Welcome to LOOPS — the coders' best friend for getting a lot done with very little code!
$L$,
ARRAY['conditions','if-then','decisions','algorithms'], 7);

-- Lessons 8-100 follow the same structure
-- Below: all 100 lesson titles with shorter but complete content

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('exp-l08', 'Loops: Do It Again (and Again and Again!)', 'Algorithms', 'None', 'beginner', 25, 'published',
ARRAY['Explain what a loop is and why it is useful','Create a simple loop with a specific repeat count','Connect loops to patterns in real life'],
$L$# Loops: Do It Again (and Again and Again!)

## The Problem With Repetition

Imagine you're making a friendship bracelet and you need to tie 50 knots. If you had to write instructions for a robot doing this, without loops you'd write:
```
Tie knot
Tie knot
Tie knot
... (47 more times)
Tie knot
```

That's 50 lines — all identical! What a waste of time and space.

Experienced programmers are lazy in the best possible way: they hate writing the same thing over and over. Instead, they use **loops**.

## What Is a Loop?

A **loop** is a set of instructions that repeats automatically a certain number of times (or until a condition is met).

With a loop, our bracelet instructions become:
```
Repeat 50 times:
    Tie knot
```

Just 2 lines instead of 50! And if we decide we want 100 knots instead, we change one number — not 100 lines.

## Types of Loops

### Count Loops (Repeat a specific number of times)

The simplest loop runs a specific number of times:
```
Repeat 3 times:
    Say "Hip Hip"
Say "Hooray!"
```
Result: "Hip Hip, Hip Hip, Hip Hip, Hooray!"

### Condition Loops (Keep going until something changes)

These loops keep running as long as something is true:
```
Keep stirring WHILE the sugar hasn't dissolved yet
```
The loop runs as many times as needed — you don't need to know in advance how many.

```
Keep walking WHILE you haven't reached school yet
```

### Forever Loops (Run until told to stop)

Some programs need to run indefinitely:
```
Forever:
    Check if new message received
    If message received: display notification
```

Your phone does this constantly — it's in a forever loop checking for new messages, calls, and notifications!

## Loops in Animation

Animation is a perfect example of loops. When you watch a cartoon character walking, the animators drew a "walk cycle" — usually 8-12 frames of animation — and then the computer **loops** those frames over and over to create the appearance of continuous walking.

A simple walk animation loop might be:
```
Repeat forever:
    Show frame 1 (left foot forward)
    Show frame 2 (mid-step)
    Show frame 3 (right foot forward)
    Show frame 4 (mid-step)
    Wait a tiny moment between each frame
```

Every character animation you've ever seen in a game or cartoon uses loops!

## Loops in Music

Music is built on loops. A drummer plays a rhythm pattern — and then loops it. A bass line repeats. The verse-chorus structure of a song is a kind of loop.

When you hear your favourite song's chorus for the third time, that's a loop!

Modern music production software literally calls its repeating sections "loops."

## Counting Loops Practice

For each scenario, write the loop in plain English:

**Challenge 1:** A robot needs to wash 7 dishes.
```
Repeat ___ times:
    Wash ___
```

**Challenge 2:** A character in a game should jump 3 times.

**Challenge 3:** A printer needs to print 12 copies of a document.

## Nested Loops: Loops Inside Loops

Just like we had nested conditions (IF inside IF), we can have nested loops (loop inside loop)!

Here's an example: printing a grid of X's (5 columns × 3 rows)

```
Repeat 3 times:        ← outer loop (handles rows)
    Repeat 5 times:    ← inner loop (handles columns)
        Print "X"
    Start new line
```

Result:
```
XXXXX
XXXXX
XXXXX
```

Nested loops create grids, tables, and game boards. The outer loop handles one dimension; the inner loop handles another. You'll use nested loops when you start making games!

## Activity: The Clapping Machine

Pretend you're programming a clapping machine. Write loops to create these clapping patterns:

1. **Simple:** Clap 5 times
2. **With pause:** Clap 3 times, pause, clap 3 times (repeat twice)
3. **Increasing:** Clap once, pause. Clap twice, pause. Clap three times, pause. (Hint: this isn't a simple count loop — it changes!)

## Key Takeaways 🌟

1. A **loop** is a set of instructions that repeats automatically
2. Loops make code shorter, easier to read, and easier to change
3. **Count loops** repeat a specific number of times
4. **Condition loops** repeat while something is true
5. **Forever loops** repeat until the program is stopped
6. Loops are in animations, music, games, and virtually every program
7. Nested loops handle two-dimensional structures like grids and tables

## What's Coming Next

Patterns, sequences, conditions, loops — you're building an amazing toolkit of programming thinking! Next: we'll learn about one of the most surprising discoveries in computer history — how computers count using only 0 and 1.
$L$,
ARRAY['loops','algorithms','repetition','animation'], 8);

-- Insert remaining 92 Explorers lessons (9-100) with strong content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('exp-l09', 'Binary: How Computers Count with 0 and 1', 'Fundamentals', 'None', 'beginner', 20, 'published', ARRAY['Understand what binary is','Count in binary from 0 to 7','Explain why computers use binary'], $L$# Binary: How Computers Count with 0 and 1

## A Strange Way to Count

Most people count using 10 different symbols: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9. This is called **base 10** or the **decimal system** — we have 10 fingers, so humans naturally invented a 10-symbol counting system.

But computers don't have fingers. They have **switches** — electronic circuits that are either ON or OFF, open or closed, charged or not charged. Because switches only have two states, computers need a number system with only two symbols.

That system is called **binary** — and it uses only **0** and **1**.

**0** = OFF, No, False, No electricity
**1** = ON, Yes, True, Electricity flowing

## Binary Numbers in Action

In binary, instead of columns for 1s, 10s, 100s (like decimal), we have columns for 1s, 2s, 4s, 8s, 16s...

| Decimal | Binary |
|---------|--------|
| 0       | 0      |
| 1       | 1      |
| 2       | 10     |
| 3       | 11     |
| 4       | 100    |
| 5       | 101    |
| 6       | 110    |
| 7       | 111    |
| 8       | 1000   |

**Reading binary 101:**
- Rightmost column (1s place): 1 × 1 = 1
- Middle column (2s place): 0 × 2 = 0
- Left column (4s place): 1 × 4 = 4
- Total: 4 + 0 + 1 = **5**

## Why Does This Matter?

Every piece of information in a computer — every photo, song, word, game, and number — is stored as a pattern of 0s and 1s. 

The letter "A" is stored as **01000001**. Your favourite song is millions of 0s and 1s. A 4K movie is billions of them.

A single binary digit is called a **bit**. Eight bits together is called a **byte**. 

- 1 byte = 8 bits
- 1 kilobyte = 1,024 bytes
- 1 megabyte = 1,024 kilobytes
- 1 gigabyte = 1,024 megabytes

Your phone might have 256 gigabytes of storage — that's 256,000,000,000 bytes, or over 2 trillion individual bits, each one a tiny 0 or 1.

## Activity: Binary Bracelets!

Using two colours of beads (representing 0 and 1), make a bracelet that spells out your initials in binary!

Look up the binary code for each letter (or ask a parent to help search online for "ASCII binary table"). String the beads in the right pattern for each letter.

You'll have a bracelet that secretly says your name in computer language!

## Key Takeaways 🌟

1. Binary uses only 0 and 1 because computers use electronic switches
2. 0 = OFF, 1 = ON
3. Binary counts: 0, 1, 10, 11, 100, 101, 110, 111...
4. Everything in a computer is stored as patterns of 0s and 1s
5. A single 0 or 1 is called a **bit**; eight bits is a **byte**
$L$,
ARRAY['binary','fundamentals','numbers','computers'], 9),

('exp-l10', 'Keeping Safe Online: Your Digital Shield', 'Digital Citizenship', 'None', 'beginner', 20, 'published', ARRAY['Identify personal information that should stay private','Know the STOP rule for staying safe online','Know who to tell if something feels wrong online'], $L$# Keeping Safe Online: Your Digital Shield

## The Internet Is Amazing — And Needs Respect

The internet lets you learn about volcanoes in Iceland, watch animals in African savannas, and talk to your grandparents across the world — all without leaving your home. It's one of the most incredible tools ever created.

But just like a swimming pool needs safety rules (no running, no diving in the shallow end), the internet has safety rules too. These aren't meant to scare you — they're meant to help you enjoy the internet safely.

## What Is "Personal Information"?

**Personal information** is anything that could identify who you are or where you are in the real world. Sharing this information online with strangers is dangerous.

### 🚫 NEVER share online with strangers:
- Your **full name** (first + last)
- Your **home address**
- Your **phone number**
- Your **school name** (this tells people where you are every day!)
- Your **schedule** (when you're home alone, what route you take)
- **Passwords** — not even to friends!
- **Photos** of yourself without a parent's permission
- Your **location** when posting photos (turn off location tagging)

### ✅ Generally OK (but check with parents):
- Your first name (many online games and communities use first names)
- Your age (approximate)
- Favourite games, shows, or hobbies

## The STOP Rule

When you encounter something online that feels uncertain, use the **STOP** rule:

**S** — **Stop** what you're doing
**T** — **Think** — is this safe? Would my parents approve?
**O** — **OK?** If yes, continue carefully
**P** — **Problem?** Tell a trusted adult immediately

## Trusted Adults

If anything ever makes you feel uncomfortable, scared, or confused online, tell a trusted adult IMMEDIATELY:
- A parent or guardian
- A teacher
- Another adult family member you trust

There is **nothing you can do online** that is too embarrassing to tell a trusted adult. They are there to help you, not get you in trouble.

## Cyberbullying: What It Is and What to Do

**Cyberbullying** is when someone uses technology to hurt, embarrass, or threaten another person. It can happen through:
- Mean comments on posts
- Excluding someone from online groups
- Sharing embarrassing photos without permission
- Sending threatening messages

**If you are cyberbullied:**
1. Don't respond — responding often makes it worse
2. Screenshot (save evidence)
3. Block the person
4. Tell a trusted adult right away

**If you see cyberbullying:**
You can be an **upstander** — someone who stands up for others! You can defend the target, include them, and report the behaviour to an adult.

## Passwords: Your Digital Keys

Your password is like the key to your house. If someone has it, they can go anywhere you can go online.

**Strong password tips:**
- Use at least 8 characters
- Mix letters, numbers, and symbols
- Never use your name or birthday
- Don't use "password" or "123456"
- Use different passwords for different accounts
- Never share your password with friends (a real friend won't ask!)

**Good password example:** *Blu3Fire!Jump*
**Bad password example:** *emily2016*

## The Golden Rule of the Internet

**If you wouldn't say it to someone's face, don't say it online.**

The internet can make words feel less real — but they're just as hurtful. Before you type anything, ask yourself: "Would I be comfortable if my parent or teacher could see this?"

If yes — go ahead!
If no — delete it.

## Key Takeaways 🌟

1. Never share personal information (full name, address, phone, school) with online strangers
2. Use the STOP rule when uncertain: Stop, Think, OK?, Problem?
3. Always tell a trusted adult if something feels wrong online
4. Cyberbullying is real and harmful — you can be an upstander
5. Strong passwords protect your accounts
6. Treat others online the same way you'd want to be treated in person
$L$,
ARRAY['digital-citizenship','online-safety','privacy','K-1'], 10),

('exp-l11', 'What Is Coding? The Secret Language of Machines', 'Fundamentals', 'None', 'beginner', 20, 'published', ARRAY['Define coding in simple terms','Name three different programming languages','Understand that coding is a skill anyone can learn'], $L$# What Is Coding? The Secret Language of Machines

## The Language Computers Speak

Humans communicate in languages like English, French, Spanish, or Mandarin. Computers have their own languages — except instead of conveying stories or emotions, these languages convey **instructions**.

**Coding** (also called programming) is the process of writing instructions in a language that computers can understand and execute.

## Why Can't We Just Say "Computer, Do This!"?

Actually, we can — sort of! Voice assistants like Siri and Google Assistant respond to plain language. But they're only possible because someone *coded* them to understand speech and figure out what we mean.

Underneath every voice assistant is millions of lines of code telling the computer:
- How to listen and record
- How to convert speech to text
- How to understand the question
- How to search for an answer
- How to speak the response back

To build the voice assistant in the first place, coders had to write in a programming language — not plain English.

## The Major Programming Languages

There are hundreds of programming languages. Here are some of the most important:

### 🟠 Scratch and Scratch Jr
Visual, block-based languages perfect for beginners. You drag and snap blocks together instead of typing. Created by MIT specifically for young learners. You'll use these in CODEship Academy!

### 🌐 HTML and CSS
Used to build websites. HTML creates the structure (headings, paragraphs, images). CSS adds style (colours, fonts, layouts). Every website you've ever visited uses these.

### ⚡ JavaScript
The language that makes websites interactive. When you click a button and something happens without the page reloading, that's JavaScript. It's also used in games, apps, and artificial intelligence.

### 🐍 Python
Named after Monty Python (a British comedy group!), Python is famous for being easy to read while being incredibly powerful. It's used in AI, science, data analysis, and automation.

### 🍎 Swift
Apple's language for making iPhone and iPad apps. Most apps in the App Store were built with Swift (or its predecessor, Objective-C).

### 🎮 C++ and C#
Fast, powerful languages used in game development. Most major video games — Fortnite, Call of Duty, the Unreal Engine — are built in C++ or C#.

## What Does Code Actually Look Like?

Here's a tiny bit of real code in Python — the language you'll learn in the Engineers level:

```python
print("Hello, World!")
```

This tells the computer to display the words "Hello, World!" on the screen. It's simple, but it's a complete program!

Here's code in Scratch's block language (described in text):
```
When green flag clicked
Say "Hello, World!" for 2 seconds
```

Different language, same idea — tell the computer to show a greeting.

## Code Is Creative

Code isn't just technical — it's one of the most creative tools in the world. With code, you can:

🎨 Create digital art and animation
🎵 Generate music
📚 Tell interactive stories
🎮 Build video games
🌐 Make websites and apps
🤖 Program robots
🔬 Analyse scientific data
💊 Design medical treatments

The same fundamental concepts you'll learn in Scratch will apply when you're building complex systems years from now. Every coder started by learning these same basics.

## Famous Things Created by Code

- **Minecraft** — one of the best-selling games ever, started as one person's coding project
- **Instagram** — built by 13 people before it was sold for $1 billion
- **Netflix** — runs on millions of lines of code managing video for 200 million subscribers
- **The International Space Station** — controlled by multiple computer systems running specialised code
- **COVID-19 vaccines** — designed partly using AI software and biological simulation code

## Anyone Can Code

For many years, coding felt like it was "for certain types of people." That's completely wrong. Today, millions of children around the world learn to code every year. Coding is a skill like reading, writing, or playing music — anyone who wants to learn can learn it.

You don't need to be a "math person" (though math does come in handy). You don't need to be a certain gender, background, or age. You need curiosity and practice.

And you're already here — that's the best start!

## Key Takeaways 🌟

1. Coding is writing instructions in a language computers can understand
2. There are hundreds of programming languages, each with different strengths
3. Scratch is a great first language — visual, fun, and powerful
4. Code is creative — it's used to make games, art, music, websites, and more
5. Famous things from Minecraft to Netflix to space stations run on code
6. Anyone with curiosity and practice can learn to code

## What's Coming Next

You know WHAT coding is. Now let's start actually DOING it! Your first real coding experience begins in the next lesson with Scratch Jr!
$L$,
ARRAY['coding','programming-languages','fundamentals','creativity'], 11);

-- Lessons 12-100: Complete set with proper educational content
-- Each builds on the previous, following K-1 pedagogical principles

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('exp-l12', 'Hello Scratch Jr! Your First Code', 'Block Coding', 'Scratch Jr', 'beginner', 30, 'published', ARRAY['Open Scratch Jr and navigate the interface','Move a sprite using code blocks','Make a sprite say something'], $L$# Hello Scratch Jr! Your First Code

## The Moment You've Been Waiting For

All the lessons so far have been about understanding computers and coding concepts. Important stuff — but today, we START CODING.

Right now. For real.

By the end of this lesson, you will have written a real program that makes a character move and speak. That's a genuine accomplishment, and you should feel proud when you get there!

## What Is Scratch Jr?

**Scratch Jr** is a free programming app for tablets and computers, created by the Massachusetts Institute of Technology (MIT) — one of the most famous science and technology universities in the world. It was designed specifically for children ages 5-7.

In Scratch Jr, instead of typing code, you **drag and snap colourful blocks together** — like building with digital LEGO. Each block represents an instruction, and when you connect them in a sequence, you create a program.

**Where to find it:**
- On iPad/iPhone: search "Scratch Jr" in the App Store (free!)
- On Android: search "Scratch Jr" in the Play Store (free!)
- On a computer: visit scratchjr.org (free!)

## The Scratch Jr Interface

When you open Scratch Jr, you'll see four main areas:

### 🎭 The Stage (the big area on the left or top)
This is where your program runs — like a theatre stage where the action happens. The default character is a friendly orange cat!

### 📦 The Block Palette (the coloured blocks)
These are your programming tools. Each colour represents a different category:
- 🟡 **Yellow** — Events (triggers, like "when I tap the screen")
- 🔵 **Blue** — Motion (moving, turning, jumping)
- 🟣 **Purple** — Looks (changing appearance, showing/hiding)
- 🟢 **Green** — Sound (playing music and sounds)
- 🟠 **Orange** — Control (loops and waiting)
- 🔴 **Red** — End (stopping the program)

### 📜 The Script Area (the dotted area)
This is where you build your program by dragging blocks from the palette.

### 🐱 The Sprite Panel (bottom)
These are the characters in your program. You can have multiple characters!

## Your First Program: Make the Cat Move and Talk!

Let's build a simple program step by step:

### Step 1: Set Up
1. Open Scratch Jr
2. You should see the orange cat on the stage
3. Tap the cat to select it (you'll program this character)

### Step 2: Add a Trigger
Every Scratch Jr program needs a **trigger** — something that makes it start.

1. Find the yellow **START block** — it looks like a little flag (🏁)
2. Drag it to the Script Area

This block means: "When I tap the green flag, start here"

### Step 3: Make the Cat Move
1. Find the blue **MOVE RIGHT** block (an arrow pointing right)
2. Snap it onto your START block
3. You can tap the number on the block to change how far it moves (try the number 3)

### Step 4: Make the Cat Say Hello
1. Find the purple **SAY** block
2. Tap the speech bubble to type what you want the cat to say
3. Type: **Hello, World!**
4. Snap this block after your MOVE block

### Step 5: Run Your Program!
Look for the green flag button and tap it!

🎉 Your cat should move to the right and then say "Hello, World!"

Congratulations — you just wrote your first program!

## Understanding What You Built

Let's look at what your program does, using the IPO model:

**INPUT:** You tapped the green flag
**PROCESS:** The computer read your blocks: "Start → Move right → Say Hello"
**OUTPUT:** The cat moved and showed the speech bubble

You wrote the PROCESS part — that's the code!

## Experimenting: Make It Yours

Now it's time to explore! Try these modifications:

**Experiment 1:** Change the text in the SAY block. What does the cat say now?

**Experiment 2:** Add a second MOVE block. What happens when you have two moves?

**Experiment 3:** Try a MOVE UP or MOVE DOWN block. Can you make the cat go in different directions?

**Experiment 4:** Add a SOUND block and see what sound the cat makes!

**Experiment 5:** Can you make the cat move right, then up, then say "I made it!"?

## When Things Go Wrong (Debug!)

If your program doesn't work as expected, check:
- Are all the blocks snapped together tightly? (gaps cause problems)
- Is the START block at the very beginning?
- Are the blocks in the right order?

Finding and fixing these issues is called **debugging** — and you're getting better at it every time you try!

## Key Takeaways 🌟

1. Scratch Jr is a free block-coding app created by MIT
2. You build programs by dragging and snapping colourful blocks
3. Every program needs a trigger (the yellow START block)
4. Blocks run in sequence, top to bottom
5. You can make sprites move, talk, make sounds, and more
6. Experimenting and fixing mistakes is how real coders work
7. You just wrote your first real program — that's a huge milestone!

## What's Coming Next

You've got the basics! Next we'll learn how to use LOOPS in Scratch Jr to make our programs much more powerful with much less code.
$L$,
ARRAY['scratch-jr','block-coding','first-program','K-1'], 12);

-- Lessons 13-100 defined with proper content
-- (Adding remaining 88 lessons with educational depth)

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('exp-l13', 'Loops in Scratch Jr: Make Things Repeat!', 'Block Coding', 'Scratch Jr', 'beginner', 25, 'published', ARRAY['Use the Repeat block in Scratch Jr','Create animations using loops','Understand why loops save code'], $L$# Loops in Scratch Jr: Make Things Repeat!

## The Most Powerful Block in Your Toolkit

In our last lesson, you moved a cat across the screen. But what if you wanted it to walk continuously — taking step after step in a smooth animation?

You could add 100 MOVE blocks... or you could use ONE LOOP BLOCK and tell it to repeat. That's the power of loops.

## The Repeat Block in Scratch Jr

In Scratch Jr, the orange REPEAT block looks like a circle with an arrow (♻️). It wraps around other blocks, and everything inside the loop runs over and over.

Here's a basic loop that makes the cat take 3 steps repeatedly:

```
START (🏁)
  REPEAT (orange circle)
    MOVE RIGHT 1 step
```

Tap the START flag — and watch the cat walk forever!

## Creating a Walk Animation

For a character to look like they're truly walking, you need to switch between different poses. In Scratch Jr, you can do this with the NEXT COSTUME block (green), which changes the character's appearance.

```
START
  REPEAT
    MOVE RIGHT 2
    NEXT COSTUME
```

Now the cat's legs appear to move as it walks across the stage!

## Bouncing Balls

Want to make a bouncing ball? Use the FLIP HORIZONTAL block to make it look like it bounced:

```
START
  REPEAT
    MOVE RIGHT 2
    MOVE UP 2
    MOVE RIGHT 2
    MOVE DOWN 2
```

This creates an up-down-up-down motion that looks like bouncing!

## Using Numbers in Loops

You can set how many times a loop repeats by tapping the number inside it:

- REPEAT 5 → runs 5 times then stops
- REPEAT 10 → runs 10 times then stops  
- REPEAT with no number → runs forever

The difference: a forever loop keeps going until you press the red stop button. A numbered loop stops automatically.

## Challenge: The Spinning Star

1. Change your character to a star (tap the + next to the character panel)
2. Use REPEAT with TURN RIGHT inside
3. How many turns does it take to spin in a full circle?
4. Add some motion blocks too — can you make the star spin AND move?

## Activity: Animate an Animal

Pick any animal character from Scratch Jr's library. Create a loop animation that makes it look realistic:
- A bird flapping its wings
- A fish swimming
- A frog jumping

**Hint:** Use NEXT COSTUME inside your loop to switch between the animal's poses!

## Key Takeaways 🌟

1. The orange REPEAT block in Scratch Jr creates loops
2. Everything inside a REPEAT block runs over and over
3. You can set how many times a numbered loop repeats
4. Forever loops run until you stop the program
5. Loops + costume changes = realistic animation
6. One loop block is much better than many identical blocks
$L$,
ARRAY['scratch-jr','loops','animation','block-coding'], 13),

('exp-l14', 'Characters and Stories: Making Digital Books', 'Creative Coding', 'Scratch Jr', 'beginner', 30, 'published', ARRAY['Create a multi-scene story in Scratch Jr','Use messages to move between pages','Make characters interact through speech'], $L$# Characters and Stories: Making Digital Books

## Code as Storytelling

One of the most exciting things about coding is that it's a creative tool — not just a technical one. Writers use words. Artists use brushes. Coders use BOTH — and add interactivity on top!

In this lesson, you'll create your first interactive digital storybook in Scratch Jr.

## Planning Your Story

Before you touch the app, think about your story. Every good story needs:

**Characters:** Who is in your story? (pick from Scratch Jr's library or draw your own!)
**Setting:** Where does it take place? (Scratch Jr has many backgrounds)
**Problem:** What challenge do the characters face?
**Solution:** How do they solve it?

**Simple story example:**
- Character: A small cat
- Setting: A rainy day inside → then sunny outside
- Problem: The cat wants to go outside but it's raining
- Solution: The cat waits, the rain stops, the cat goes outside and plays

## Pages in Scratch Jr

Scratch Jr stories are told across multiple **pages** — like pages in a book. You can add pages using the + button in the page panel at the bottom.

Each page can have:
- A different background
- Different characters
- Different code for those characters

## Sending Messages Between Pages

To move from one page to the next, you use the **SEND MESSAGE** block and the **RECEIVE MESSAGE** block.

**Page 1 code (on a character):**
```
START
  Move right
  Say "Let's go to page 2!"
  SEND MESSAGE (green letter icon)
```

**Page 2 code (on the page itself, or a trigger):**
```
RECEIVE MESSAGE (envelope icon)
  → This triggers when the message arrives
```

## Your Story Structure

**Page 1: The Beginning**
- Show your main character
- Set the scene with a background
- Have the character say something to introduce the story

**Page 2: The Middle (The Problem)**
- Show the conflict
- Characters react with speech
- Build tension

**Page 3: The End (The Solution)**
- Show the resolution
- Characters celebrate or reflect
- The story ends happily

## Making Characters Talk to Each Other

In Scratch Jr, you can have two characters in a conversation by making them take turns:

**Character 1:**
```
START
  WAIT 1 second
  SAY "Hello friend!"
  WAIT 2 seconds
  SAY "Want to play?"
```

**Character 2:**
```
START
  WAIT 3 seconds (waits for Character 1 to finish)
  SAY "Yes! Let's play!"
```

The WAITs create pauses so the characters appear to be having a real conversation!

## Activity: Your First Digital Storybook

Create a 3-page story about something that matters to you:
- A favourite place you've been
- A pet (real or imaginary)
- A fun day with family or friends
- A problem you solved

**Requirements:**
- At least 3 pages (beginning, middle, end)
- At least 2 characters
- Each character must say something on each page
- Use a different background on each page

When you're done, share it with a family member — you're an author AND a programmer!

## Key Takeaways 🌟

1. Coding is creative — you can tell stories with code
2. Scratch Jr pages work like pages in a book
3. SEND MESSAGE and RECEIVE MESSAGE link pages together
4. WAIT blocks create timing for conversations
5. Characters can "talk" by showing speech bubbles in sequence
6. You are both a programmer AND an author when you make a digital story
$L$,
ARRAY['scratch-jr','storytelling','creative-coding','K-1'], 14),

('exp-l15', 'Debugging: Finding and Fixing Mistakes', 'Algorithms', 'Scratch Jr', 'beginner', 20, 'published', ARRAY['Define debugging','Find bugs in provided code examples','Fix bugs by testing and adjusting'], $L$# Debugging: Finding and Fixing Mistakes

## Every Coder Writes Bugs

We've talked about bugs before — mistakes in code that make the program do the wrong thing. Now it's time to learn to find and fix them, because debugging is one of the most important skills a coder develops.

Here's what separates good coders from great ones: **great coders get better at finding their mistakes, not at avoiding them**.

The famous computer scientist Ken Thompson said: "One of my most productive days was throwing away 1,000 lines of code." Even the most experienced programmers regularly tear up their work and start over!

## Types of Bugs

**Bug Type 1: Wrong Order**
Steps in the wrong sequence. Example: Making the character say hello BEFORE moving to the right spot.

**Bug Type 2: Wrong Direction**
Moving up when you meant to move right, or turning left when you meant to turn right.

**Bug Type 3: Missing Step**
Forgetting an important instruction. Like forgetting the START block, so the program never begins!

**Bug Type 4: Wrong Number**
Using 10 steps when you meant 3, or repeating 5 times when you needed 2.

**Bug Type 5: Blocks Not Connected**
In Scratch Jr, if blocks aren't snapped together properly, they won't all run.

## The Debugging Process

Professional coders have a systematic approach to finding bugs:

**Step 1: Read the error** (if there is one)
Error messages tell you what went wrong and where. They're not insults — they're clues!

**Step 2: Trace the code**
Go through your program step by step, line by line, imagining what happens at each step.

**Step 3: Add clues**
Make characters SAY what they're thinking at different points. If you see unexpected things being said, you know where the bug is.

**Step 4: Simplify**
Remove parts of the code until it works, then add back one piece at a time to find what breaks it.

**Step 5: Test often**
Don't write 50 blocks then test. Test after every 5 blocks so you know exactly when something broke.

## Debugging Practice

Here are some buggy Scratch Jr programs. Can you find and fix the bugs?

**Bug 1:** The cat is supposed to walk right and then say "I made it!" but it says hello first and then moves.
```
START → SAY "Hello!" → MOVE RIGHT
```
*What's wrong? The SAY comes before the MOVE. Swap them!*

**Bug 2:** The ball should bounce 5 times but it only bounces once.
```
START → MOVE RIGHT → MOVE UP → MOVE RIGHT → MOVE DOWN
```
*What's wrong? There's no REPEAT block! Wrap it in a REPEAT 5 block.*

**Bug 3:** Two characters are supposed to have a conversation, but they both talk at the same time.
*What's wrong? Character 2 has no WAIT block. Add a WAIT before Character 2 speaks.*

## The Rubber Duck Method

Here's a real technique professional programmers use: **explain your code to a rubber duck** (or any object, or a younger sibling!).

When you explain your code out loud to someone (or something) who doesn't understand it, you often spot the problem yourself. Your brain goes from "auto-pilot" to "careful explanation mode" — and the bug becomes obvious.

It sounds silly. It works incredibly well.

## Activity: Intentional Bugs

**Part 1:** Take a Scratch Jr program you've already made. Intentionally introduce THREE bugs into it. Write down what you changed.

**Part 2:** Swap with a classmate (or a family member). Can they find your bugs and fix them?

**Part 3:** Reflect: What was harder — introducing the bugs or finding them?

## Key Takeaways 🌟

1. Bugs are mistakes in code — every programmer writes them
2. **Debugging** is the process of finding and fixing bugs
3. Types of bugs: wrong order, wrong direction, missing steps, wrong numbers, disconnected blocks
4. **Trace through your code step by step** to find bugs
5. Test your code frequently — after every few blocks, not just at the end
6. The **rubber duck method** really works: explain your code out loud
7. Getting better at debugging makes you a better coder overall
$L$,
ARRAY['debugging','algorithms','problem-solving','scratch-jr'], 15);

-- Completing lessons 16-100 with proper educational content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('exp-l16', 'Sorting and Grouping: How Computers Organise', 'Computational Thinking', 'None', 'beginner', 20, 'published', ARRAY['Sort items by different properties','Group objects by category','Connect sorting to how computers organise data'], $L$# Sorting and Grouping: How Computers Organise

## Why Sorting Matters

Imagine a library where every book was placed completely randomly. Finding a book would take all day! Libraries work because books are organised — by section, then alphabetically by author, then by title.

Computers face the same challenge. They deal with billions of pieces of information, and they need to organise it so they can find what they need quickly. **Sorting** is one of the fundamental operations computers perform millions of times every second.

## Sorting in Everyday Life

We sort things constantly:
- Grocery store: food organised by type (produce, dairy, bakery)
- Dictionary: words organised alphabetically
- Your playlist: songs organised by artist or mood
- Your school bag: books organised by subject or size
- Your photo app: photos organised by date taken

Different situations call for different ways of sorting. A doctor might sort patients by urgency. An online store sorts products by price, ratings, or relevance to your search.

## Three Ways to Sort

### 1. Sort by Category (Type)

Put similar things together:
🐶🐱🐹🐦🐠 → Animals: **Mammals** (🐶🐱🐹) | **Birds** (🐦) | **Fish** (🐠)
🍎🌽🥕🍌🍇 → **Fruits** (🍎🍌🍇) | **Vegetables** (🌽🥕)

### 2. Sort by Number (Size, Age, Price)

Put things in order from smallest to largest (or largest to smallest):
Ages: 3, 7, 12, 5, 9 → Sorted: 3, 5, 7, 9, 12
Prices: $15, $3, $8, $20, $1 → Sorted: $1, $3, $8, $15, $20

### 3. Sort Alphabetically (A to Z)

Put words in dictionary order:
Names: Maria, Alex, Jordan, Priya, Ben → Sorted: Alex, Ben, Jordan, Maria, Priya

## How Computers Sort: Algorithms

Computers use specific **sorting algorithms** — step-by-step procedures for sorting. You'll study these in much more detail in the Developers and Engineers levels, but here's a simple example:

**Bubble Sort** (the simplest, but not the fastest):
1. Look at the first two items
2. If they're in the wrong order, swap them
3. Move to the next pair
4. Keep going until you reach the end
5. Start over from the beginning
6. Repeat until no swaps are needed

It's called "bubble sort" because small items slowly "bubble" to the beginning!

## Activity 1: Sort the Groceries

Here's a random grocery list. Sort it into three categories: Fruits, Vegetables, Dairy.

🥦 Broccoli · 🍑 Peach · 🥛 Milk · 🥕 Carrot · 🧀 Cheese · 🍇 Grapes · 🧄 Garlic · 🥚 Eggs · 🍓 Strawberry

Then, within each category, sort alphabetically!

## Activity 2: Human Sorting Algorithm

Stand up! With a group of people, each person is assigned a different number (1-10, randomly).

Using ONLY these moves:
- You can look at the numbers of the people next to you
- You can swap positions with someone next to you
- You cannot jump over people

Sort yourselves from 1 to 10 as quickly as possible.

How many swaps did it take? That's how many steps your sorting algorithm needed.

## Grouping vs Sorting

**Grouping** (also called classifying) is putting things into categories without ordering them within those categories.

**Sorting** means ordering within categories.

Both are fundamental operations in computer science. Databases group and sort constantly. Search engines group results by topic and sort them by relevance.

## Key Takeaways 🌟

1. Sorting and grouping help organise information so it can be found quickly
2. We can sort by category, number, or alphabetically
3. Computers use special procedures called **sorting algorithms**
4. Bubble sort is a simple algorithm that compares and swaps adjacent pairs
5. Databases group and sort billions of records every second
6. Computational thinking includes breaking problems into organised categories
$L$,
ARRAY['computational-thinking','sorting','algorithms','data-organisation'], 16),

('exp-l17', 'Giving Directions: Programming a Robot', 'Algorithms', 'None', 'beginner', 25, 'published', ARRAY['Give precise step-by-step directions','Understand forward-backward and left-right commands','Navigate a simple maze using directional code'], $L$# Giving Directions: Programming a Robot

## You Are the Programmer

In this lesson, you'll programme a "robot" — which might be a friend, a classmate, or even a toy you move around a paper map. The goal is simple: get from point A to point B using only specific directional commands.

This activity directly mirrors how real robots and game characters are programmed!

## The Robot's Vocabulary

Your robot understands only these commands:
- **FORWARD** (moves one step ahead)
- **BACKWARD** (moves one step back)
- **TURN LEFT** (rotates 90° to the left, but doesn't move)
- **TURN RIGHT** (rotates 90° to the right, but doesn't move)

That's it! No "move diagonally," no "go around the table," no "you know what I mean."

The robot is very literal. If you say FORWARD and there's a wall, it walks into the wall. You need to plan around obstacles.

## Working With a Grid

Imagine a 5×5 grid, like a simplified city map:

```
+---+---+---+---+---+
| S |   |   | W |   |
+---+---+---+---+---+
|   | W |   |   |   |
+---+---+---+---+---+
|   |   |   | W |   |
+---+---+---+---+---+
|   | W |   |   |   |
+---+---+---+---+---+
|   |   |   |   | E |
+---+---+---+---+---+
```

**S = Start** (top left)
**E = End** (bottom right)
**W = Wall** (can't walk through)

The robot starts at S, facing RIGHT. Your job: write the directions to get to E without hitting any walls.

Try it! Write your directions, then trace them on the grid with your finger to see if you made it.

## Absolute vs. Relative Directions

There are two ways to give directions:

**Absolute (compass directions):**
"Go north, then east, then south"

These work no matter which way you're facing.

**Relative (relative to you):**
"Go forward, turn right, go forward"

These depend on which way you're currently facing.

Scratch Jr and most game programming uses **relative** directions. Real-world GPS navigation typically uses **absolute** directions.

## Making It a Game: Floor Robot

**Materials needed:** Tape on the floor to make a grid, or you can play this outside on a patio.

**Players:** One programmer, one robot, optional observer

**Rules:**
1. The programmer writes down directions BEFORE the robot starts moving (no shouting instructions as you go!)
2. The robot follows the instructions EXACTLY as written
3. If the robot hits a wall or goes off the grid, the program has a bug!

Take turns being the programmer and the robot.

## Challenge: The Treasure Hunt

Write directions for a friend to follow that navigate them from the classroom door to your desk. They must follow your written instructions without any hints — only the code!

Remember: they can only TURN LEFT, TURN RIGHT, FORWARD, BACKWARD. No "go through the door" (that's not a command they know) — you need FORWARD or similar.

## Connecting to Real Coding

In Scratch Jr, when you use MOVE RIGHT, MOVE UP, MOVE DOWN, or MOVE LEFT — you're giving directional commands just like our robot activity!

The TURN blocks in Scratch Jr work in degrees. 90 degrees = one right angle = one quarter turn. To face the opposite direction, you turn 180 degrees.

In more advanced programming, you'll use coordinates (x,y positions) to precisely place characters and objects on screen. But it all starts with this simple directional thinking!

## Key Takeaways 🌟

1. Robots (and characters in code) need very precise directional instructions
2. Basic directions: FORWARD, BACKWARD, TURN LEFT, TURN RIGHT
3. Relative directions depend on which way you're currently facing
4. Absolute directions (compass) don't depend on your facing
5. This directional thinking directly applies to moving characters in Scratch and games
6. All movement in code ultimately comes down to precise directional commands
$L$,
ARRAY['algorithms','directions','robots','grid','spatial-thinking'], 17),

('exp-l18', 'Asking Good Questions: The Coder''s Superpower', 'Computational Thinking', 'None', 'beginner', 20, 'published', ARRAY['Ask clear specific questions when stuck','Describe a problem with what I expected and what happened','Practice rubber duck debugging'], $L$# Asking Good Questions: The Coder''s Superpower

## The Question That Gets Help vs The Question That Gets Nothing

Picture two students who are stuck on the same coding problem:

**Student 1 says:** "It doesn't work."

**Student 2 says:** "I'm trying to make my cat move to the right when I tap the flag, but instead it moves to the left. I've checked my blocks and I think I have MOVE RIGHT but something is wrong."

Which student do you think got help faster?

Learning to ask precise, specific questions is genuinely one of the most powerful skills you can develop — not just in coding, but in all of school and life.

## The Problem-Description Formula

When something goes wrong in code, use this three-part formula:

**Part 1: What I was TRYING to do**
"I wanted the cat to move to the right and then say hello."

**Part 2: What ACTUALLY happened**
"The cat moved to the left, and no message appeared."

**Part 3: What I've already TRIED**
"I checked that I have MOVE RIGHT, not MOVE LEFT, and the SAY block is definitely connected."

This formula gives the person helping you everything they need to actually help!

## Why Specific Questions Get Better Answers

**Vague question:** "Why doesn't my code work?"
This forces the helper to guess what's wrong, look through all your code, and investigate before they can even start helping.

**Specific question:** "My character should jump when I press space, but nothing happens when I press space. I have a WHEN SPACE PRESSED block connected to a MOVE UP block, and the blocks are connected properly."
Now a helper can immediately say: "Check if the script is attached to the character, not the background!"

Specific questions save time for everyone.

## The Three Clues Formula for Coding Problems

When you're debugging your own code, look for three clues:

**Clue 1: What's different from what you expected?**
"The character went UP but I wanted it to go RIGHT."

**Clue 2: Where in the code might that happen?**
"The movement blocks are in the second row of my script."

**Clue 3: What could cause that specific difference?**
"Maybe I have the wrong block — let me double-check MOVE RIGHT vs MOVE UP."

## The Rubber Duck Method (Again!)

We mentioned this in the debugging lesson, but it deserves more attention because it really works.

**How it works:**
1. Find a rubber duck (or any toy, stuffed animal, or even your reflection)
2. Start explaining your code to it, line by line: "This block makes the cat start. This block makes it move right. This block..."
3. Very often, you'll suddenly say "Oh! I see the problem!" and the duck has said nothing

Your brain processes information differently when you verbalise it. Something that was invisible becomes obvious.

Professional programmers at major companies like Google and Microsoft actually keep rubber ducks on their desks for this purpose!

## Asking for Help vs Finding the Answer Yourself

Both are important skills. Here's a framework:

**Try yourself first (15-20 minutes):**
- Read through the code carefully
- Use rubber duck debugging
- Google the specific error message
- Look at examples in the help documentation

**Then ask for help (with your research ready):**
- Show what you tried
- Describe what happened
- Ask "Have you seen this before?"

This approach is respectful of others' time and also develops your problem-solving skills more effectively than asking immediately.

## Activity: Transform These Questions

Turn these vague questions into specific, helpful questions:

1. "My code is broken." → ?
2. "This doesn't make sense." → ?
3. "Why isn't the loop working?" → ?
4. "Help, I don't know what to do!" → ?

There's no single correct answer — but your improved questions should include: what you wanted to happen, what actually happened, and what you've already tried.

## Key Takeaways 🌟

1. Specific questions get help; vague questions get confusion
2. Use the three-part formula: Trying to → Actually happened → Already tried
3. Good questions help others help you — and help you think more clearly
4. The rubber duck method helps you find your own bugs
5. Try for 15-20 minutes before asking for help (but do ask when you need it!)
6. Clear communication is a professional skill used by every coder every day
$L$,
ARRAY['computational-thinking','problem-solving','communication','debugging'], 18),

('exp-l19', 'Creating Art With Code: Pixel Pictures', 'Art & Design', 'None', 'beginner', 25, 'published', ARRAY['Understand what pixels are','Create pixel art on a grid','Connect digital art to computer graphics'], $L$# Creating Art With Code: Pixel Pictures

## The Tiny Dots Behind Every Digital Image

Every picture on a computer screen — every photo, every game graphic, every emoji — is made of tiny coloured dots called **pixels** (short for "picture elements").

If you've ever zoomed way into a digital photo until it got all blocky, you've seen pixels! Each coloured square is one pixel.

Your phone screen has millions of pixels — a modern phone might have 2,532 × 1,170 pixels, which is nearly **3 million pixels** on a screen you can hold in your hand!

## The Grid: Pixel Art's Canvas

Pixel art uses a grid of squares, where each square represents one pixel. Artists colour in the squares to create images — just like filling in a colouring grid, but with code.

Here's a simple pixel art heart (where ❤️ = red and ⬜ = white):

```
⬜❤️❤️⬜❤️❤️⬜
❤️❤️❤️❤️❤️❤️❤️
❤️❤️❤️❤️❤️❤️❤️
⬜❤️❤️❤️❤️❤️⬜
⬜⬜❤️❤️❤️⬜⬜
⬜⬜⬜❤️⬜⬜⬜
```

When you step back from the grid, the individual squares blur together and you see a heart!

## Pixels and Colour

Each pixel on a screen can display any colour, created by combining three light colours:
- 🔴 Red
- 🟢 Green  
- 🔵 Blue

This is called **RGB colour** (Red, Green, Blue).

**Mixing light is different from mixing paint:**
- Red + Green light = Yellow
- Red + Blue light = Magenta (pink-purple)
- Green + Blue light = Cyan (blue-green)
- Red + Green + Blue = White
- No light at all = Black

Every colour you see on screen — including the specific gold and navy of CODEship Academy's colours — is created by mixing these three types of light at different intensities.

## Coordinate Systems

To tell a computer WHERE to colour a pixel, we use coordinates — a pair of numbers that say "how far across" and "how far up."

**On a 5×5 grid:**
- (1,1) is the bottom-left corner
- (5,5) is the top-right corner
- (3,3) is the centre

In code, you might write: `colour_pixel(3, 3, red)` — which means "make the pixel at position 3 across, 3 up, be red."

This coordinate system is used constantly in game development, web design, and data visualisation!

## Activity 1: Grid Colouring

Using graph paper (or draw a 10×10 grid), colour in these coordinates to reveal a picture:

**Red squares:** (2,8), (3,8), (4,8), (2,7), (4,7), (2,6), (4,6), (2,5), (4,5), (2,4), (3,4), (4,4)

**What did you create?** (It should look like a little house!)

## Activity 2: Design Your Own Pixel Art

On a 16×16 grid (bigger = more detail possible):

Create pixel art of ONE of these:
- Your initial (first letter of your name)
- A simple animal
- A fruit or vegetable
- An emoji of your choice

When you're done, see if someone can guess what it is without you telling them!

## Activity 3: Decode the Message

Each letter has a pixel art representation. Here's a code: using a 5×3 grid, each letter is shown by which squares are filled.

**A:**
```
⬜🔲⬜
🔲🔲🔲
🔲⬜🔲
```

Create your own pixel font for at least 5 letters. Then write a secret message using your font and see if a friend can decode it!

## Pixels in the Real World

Pixel art isn't just an art style — it connects to real computer graphics programming:

- **Game developers** use grids to design character sprites and tile maps
- **UI designers** think in pixels when positioning elements on screen
- **Image compression** algorithms work by analysing and compressing pixel data
- **AI image recognition** processes images pixel by pixel

The people who make the graphics for your favourite games and apps think about pixels every day!

## Key Takeaways 🌟

1. Pixels are tiny dots that make up all digital images
2. Every digital screen is a grid of millions of pixels
3. Each pixel can be any colour, created by mixing red, green, and blue light
4. Coordinates (x, y) tell us the position of each pixel on a grid
5. Pixel art is a direct connection between creative expression and coding concepts
6. Game sprites and digital images are built from grids of coloured pixels
7. Understanding pixels is foundational to digital art and game development
$L$,
ARRAY['art-design','pixels','coordinates','digital-art','creativity'], 19),

('exp-l20', 'Sharing and Teamwork: Coding Together', 'Digital Citizenship', 'None', 'beginner', 20, 'published', ARRAY['Understand collaborative coding concepts','Practice giving kind feedback','Learn about open source and shared creativity'], $L$# Sharing and Teamwork: Coding Together

## Code Is Rarely a Solo Sport

In movies, we often see a lone genius hacker typing furiously alone in the dark. Reality is completely different.

Almost all professional coding happens in **teams**. The phone in your pocket was built by hundreds of engineers working together. The apps you use were built by teams of designers, coders, testers, and project managers.

Even Minecraft — which started as one person's project — quickly became a team effort and was eventually built by a studio of hundreds.

## Why Teamwork Works in Coding

**Different strengths:** One person might be excellent at visual design; another at problem-solving logic; another at explaining complex ideas simply. Teams combine these strengths.

**More eyes catch more bugs:** When only one person sees code, they miss their own mistakes. When multiple people review it, bugs are caught earlier.

**Bigger projects:** A single person can build a small app. Teams build operating systems, social networks, and space software.

**Better ideas:** Brainstorming in a group almost always produces better solutions than brainstorming alone.

## Giving Kind, Useful Feedback

In coding teams, giving feedback on each other's code is called **code review**. The goal is to make the code better — not to criticise the person.

**Unhelpful feedback:** "This code is confusing and badly written."

**Helpful feedback:** "I found it hard to understand what this section does. Could we add a comment explaining why you did it this way?"

The difference: specific, respectful, focused on the work not the person.

**The feedback sandwich:**
1. Something positive first ("I love how you organised the blocks into clear groups!")
2. Suggestion for improvement ("One thing that confused me was...")
3. Encouragement to close ("Overall this is really impressive work!")

## Open Source: Sharing Code with the World

Many developers freely share their code with the world — this is called **open source** software.

When code is open source, anyone can:
- Use it in their own projects
- Study how it works
- Suggest improvements
- Build on top of it

Some of the most important software in the world is open source:
- **Linux** — the operating system that runs most web servers and Android phones
- **Python** — the programming language used in AI and science
- **Firefox** — the web browser
- **WordPress** — the platform that runs 43% of all websites

The internet largely runs on open source code! People all over the world contributed their work for free because they believe in sharing knowledge.

## Being a Good Digital Teammate

When working with others on projects (including sharing Scratch projects):

✅ **Credit your sources:** If you use someone else's code, sprite, or idea, say where it came from

✅ **Ask before reusing:** If someone's work isn't labelled for sharing, ask them first

✅ **Give credit generously:** When someone helps you solve a problem, thank them publicly

✅ **Share your knowledge:** If you figure something out, share it — someone else is probably stuck on the same thing

✅ **Accept improvements gracefully:** If someone suggests a better way, say "Thank you!" not "But my way is fine!"

## Activity 1: Pair Programming

Work with a partner on a Scratch Jr project:
- **One person is the "Driver"** — they control the tablet/computer and add blocks
- **One person is the "Navigator"** — they plan what to do next and catch mistakes

Switch roles every 5 minutes!

This is a real technique used in professional programming — it's called **pair programming** and many companies use it daily.

## Activity 2: Code Gallery Walk

If you're in a classroom: share your Scratch Jr projects on screen. Everyone does a "gallery walk" — looking at each other's projects.

For each project, use a sticky note to write:
- One thing you loved about it
- One question you have about it

No criticism — only curiosity and appreciation!

## Key Takeaways 🌟

1. Almost all professional coding happens in teams
2. Teams bring diverse strengths, catch more bugs, and build bigger things
3. Feedback should be specific, kind, and focused on the work
4. Open source means sharing code freely with the world
5. Linux, Python, and many huge software systems are open source
6. Good digital teamwork means crediting sources, asking permission, and sharing knowledge
7. Pair programming (driver + navigator) is a real professional technique

## What's Coming Next

You've learned so much! In our next lesson, we'll put everything together and build something more complex — your first real game!
$L$,
ARRAY['digital-citizenship','teamwork','collaboration','open-source'], 20);

-- Lessons 21-100 (continuing with full content for all remaining lessons)
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('exp-l21', 'My First Game: Catch the Star!', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Build a complete simple game in Scratch Jr','Add score-like feedback to a game','Understand what makes a game fun'], $L$# My First Game: Catch the Star!

## What Makes a Game a Game?

Before we build, let's think about what makes a game satisfying to play:

1. **A clear goal** — the player knows what they're trying to do
2. **A challenge** — it's not too easy and not too hard
3. **Feedback** — the player knows if they succeeded or failed
4. **Replayability** — you want to play again after finishing

Your Catch the Star game will have all four of these!

## The Game Design

**Goal:** Touch the falling star with your character before it falls off the screen
**Challenge:** The star falls from different positions each time
**Feedback:** The star disappears (you caught it!) or the screen changes colour (you missed)
**Replayability:** The star appears from a new spot each round

## Building the Game Step by Step

### Part 1: Setting Up

1. Open Scratch Jr
2. Choose a fun background (try the outer space background!)
3. Keep the cat character OR change it to a rocket 🚀

### Part 2: Programme the Player (Cat/Rocket)

The player should move left and right:

**Add these scripts to the cat:**
```
WHEN [RIGHT ARROW] TAPPED → MOVE RIGHT 2
WHEN [LEFT ARROW] TAPPED  → MOVE LEFT 2
```

Or for a tablet without arrow keys:
- Use the left/right tilt buttons in Scratch Jr

**Test it!** Can you move the character left and right?

### Part 3: Add a Star

1. Tap the + in the character panel
2. Choose the star character (or draw a simple one)
3. Move it to the TOP of the screen

**Programme the star:**
```
START
  GO TO position (random, top)
  REPEAT
    MOVE DOWN 1
    WAIT tiny moment
  END REPEAT
```

If Scratch Jr doesn't have a random position block, place it at the top manually each time for now.

### Part 4: Catching the Star

When the cat touches the star, the star should disappear and reappear at the top:

**Programme this on the star:**
```
WHEN TOUCHING cat:
  HIDE (make invisible)
  WAIT 1 second
  GO TO top
  SHOW (make visible again)
```

### Part 5: Adding Feedback

When the star reaches the bottom without being caught, make the background flash:

**Programme on the stage:**
```
WHEN TOUCHING EDGE (bottom):
  CHANGE BACKGROUND COLOUR
  WAIT 0.5 seconds
  CHANGE BACKGROUND BACK
```

### Part 6: Test and Improve!

Play your game several times. Ask yourself:
- Is it too easy? Make the star fall faster!
- Is it too hard? Make the star fall slower!
- Is it fun? What would make it more fun?

This process — testing and improving — is called **iteration**. Every great game was iterated many, many times before it felt right.

## Activity: Share Your Game

Have a parent, sibling, or friend play your game!

Watch them play without helping — just observe. Notice:
- What do they do first?
- Where do they get confused?
- Do they enjoy it? Why or why not?

Now improve based on what you observed. This is **playtesting** — and it's how real game studios improve their games!

## Key Takeaways 🌟

1. Good games have: a clear goal, a challenge, feedback, and replayability
2. You built a complete interactive game in Scratch Jr — that's impressive!
3. **Iteration** means testing and improving repeatedly
4. **Playtesting** means watching other people play to find improvements
5. Even professional game studios iterate their games many, many times
6. Building games is one of the most exciting things you can do with code
$L$,
ARRAY['scratch-jr','game-design','creative-coding','iteration','K-1'], 21),

('exp-l22', 'Sound and Music in Code', 'Creative Coding', 'Scratch Jr', 'beginner', 25, 'published', ARRAY['Add sounds and music to Scratch Jr projects','Understand how computers create sound','Create a simple interactive musical instrument'], $L$# Sound and Music in Code

## How Computers Make Sound

Sound, in the real world, is vibrations in the air. When something vibrates — a guitar string, your vocal cords, a speaker — it creates waves of compressed and expanded air that your ears detect.

How does a computer create sound? A digital sound file stores numbers that tell the speaker how to vibrate at each tiny moment. For example, a 44,100 Hz audio file stores 44,100 individual measurements of vibration per second!

The speaker takes those numbers and converts them back into actual physical vibrations — which your ears hear as music, voices, or sound effects.

## Sound Blocks in Scratch Jr

Scratch Jr has a set of GREEN sound blocks:
- **POP** — a simple pop sound
- **BOING** — a bouncy spring sound  
- **WOOF** — a dog bark
- And more!

You can use these to add audio feedback to your programs. When the character jumps — make a boing sound! When they catch something — make a pop!

## Building a Musical Instrument

Let's create an interactive keyboard! Each key on screen will play a different sound.

**Design plan:**
- 4 different characters, each one a different colour
- Each character plays a different sound when tapped
- Tapping them in sequence makes a "song"!

**Building it:**
1. Create 4 different coloured square characters
2. Label them differently (you can draw letters on them)
3. Programme each one:

```
Character 1 (red):
WHEN TAPPED → PLAY SOUND [pop]

Character 2 (orange):
WHEN TAPPED → PLAY SOUND [boing]

Character 3 (green):
WHEN TAPPED → PLAY SOUND [woof]

Character 4 (blue):
WHEN TAPPED → PLAY SOUND [... different one]
```

**Test it:** Can you play a tune?

## Activity: Compose a Song

Now that you have your 4-note instrument, try to play these songs (just tap the colours in order):

**Twinkle Twinkle (simplified):** 
Red Red Blue Blue Orange Orange Blue | Orange Orange Green Green Red Red | ...

Can you figure out simple tunes and share them with a friend?

## How Video Games Use Sound

Sound in games isn't just decoration — it's essential:

**Feedback sounds:** Tell you what's happening (coin collected! enemy approaching! level complete!)

**Background music:** Sets the mood and emotion of different areas

**Positional audio:** In 3D games, sound gets louder or softer based on distance from the source

**Adaptive music:** Some games change the music based on what you're doing (exploring = calm music; fighting = intense music)

The people who create game sound are called **sound designers** and **composers** — both creative and technical roles!

## Key Takeaways 🌟

1. Sound is air vibrations; computers store numbers representing those vibrations
2. Scratch Jr has sound blocks that play different sounds
3. You can create interactive musical instruments with code
4. Sound in games provides feedback, atmosphere, and emotion
5. Game sound design is a real creative and technical career
$L$,
ARRAY['scratch-jr','sound','music','creative-coding'], 22),

('exp-l23', 'Problem Solving: Think Like a Coder', 'Computational Thinking', 'None', 'beginner', 20, 'published', ARRAY['Apply the 4-step problem solving process','Break a complex problem into smaller pieces','Understand decomposition'], $L$# Problem Solving: Think Like a Coder

## The Coder''s Problem-Solving Process

Professional coders rarely sit down and just start typing. They spend time thinking about the problem FIRST — understanding it deeply before writing a single line of code.

This thinking process has a name: **computational thinking**. It''s a set of mental tools that help you solve complex problems systematically.

There are four tools in the computational thinking toolkit:

## Tool 1: Decomposition

**Decomposition** means breaking a big, complex problem into smaller, simpler pieces.

**Example:** Build a video game.

That''s way too big to tackle at once! Let''s decompose it:
1. Design the main character
2. Programme the character''s movement
3. Create the first level
4. Add enemies
5. Create a scoring system
6. Add sound effects
7. Design the menu screen
8. Test everything and fix bugs

Each of those can be decomposed FURTHER:

"Design the main character" becomes:
- Decide what the character looks like
- Draw or find a character sprite
- Decide what the character can do (jump? shoot? fly?)
- Programme each ability

You keep decomposing until each piece is small enough to actually do!

## Tool 2: Pattern Recognition

**Pattern recognition** means noticing things that repeat or look similar — we covered this in the patterns lesson!

In coding, patterns tell you:
- When to use a loop (when the same thing repeats)
- When to use a function (when the same code is needed in multiple places)
- When you''ve seen and solved this problem before

## Tool 3: Abstraction

**Abstraction** means focusing on the important details and ignoring the unnecessary ones.

When you drive a car, you use the steering wheel, gas pedal, and brakes. You don''t need to understand the internal combustion engine or the hydraulic steering system. Those details are **abstracted away** — hidden from you so you can focus on driving.

In coding, abstraction means:
- When you use a MOVE RIGHT block in Scratch, you don''t need to know HOW the computer moves the pixel — it''s abstracted!
- When you call a function, you just care about what it does, not exactly how it does it

Good code hides complexity behind simple interfaces.

## Tool 4: Algorithm Design

**Algorithm design** means creating the step-by-step process that solves the problem.

An **algorithm** is just a word for a set of steps that solves a problem. When you write code, you''re implementing an algorithm!

We''ve already seen several algorithms:
- Following a recipe = algorithm
- Getting dressed in the right order = algorithm
- Bubble sorting = algorithm

## The 4-Step Problem-Solving Process

When you hit a problem (in coding or anywhere), use these four steps:

**STEP 1: UNDERSTAND**
What exactly is the problem? Read it twice. Explain it in your own words. What are we trying to achieve?

**STEP 2: PLAN**
How might you solve it? What are different approaches? (Don''t code yet — think first!)

**STEP 3: IMPLEMENT**
Write the code (or take the action). Start with the simplest version that could possibly work.

**STEP 4: TEST & REVIEW**
Does it work? Test it thoroughly. If not, go back to Step 1 or 2. If yes — can you make it better?

## Activity: Decompose a Problem

Take one of these problems and decompose it into at least 10 smaller steps:

1. **Plan a birthday party** for 10 friends
2. **Build a treehouse** (imaginary is fine!)
3. **Create a school yearbook** app
4. **Design a robot** that makes breakfast

Don''t actually solve the whole thing — just break it down. Notice how each step becomes clearer when it''s smaller!

## Key Takeaways 🌟

1. **Computational thinking** has four tools: decomposition, pattern recognition, abstraction, algorithm design
2. **Decomposition** = break big problems into smaller pieces
3. **Pattern recognition** = notice what repeats or looks familiar
4. **Abstraction** = focus on what matters, ignore what doesn''t
5. **Algorithm design** = create step-by-step instructions to solve the problem
6. The 4-step process: Understand → Plan → Implement → Test & Review
7. Great coders spend more time THINKING about problems than typing solutions
$L$,
ARRAY['computational-thinking','problem-solving','decomposition','algorithms'], 23),

('exp-l24', 'The Internet: How Computers Talk to Each Other', 'Digital Citizenship', 'None', 'beginner', 20, 'published', ARRAY['Explain what the internet is in simple terms','Understand that data travels across networks','Describe what happens when you visit a website'], $L$# The Internet: How Computers Talk to Each Other

## A Global Network of Computers

Imagine stretching a string between two tin cans — you can whisper into one can and hear the voice at the other end. Now imagine doing that with billions of cans, all connected together, allowing any can to communicate with any other can instantly.

That''s a (very simplified) version of the internet.

The **internet** is a massive global network connecting billions of computers, phones, tablets, servers, and devices. When your computer is connected to the internet, it can send and receive information with any other connected device in the world.

## How Information Travels

When you watch a YouTube video, the video isn''t stored on your device — it''s stored on YouTube''s servers (powerful computers in massive data centres). Your device requests the video, YouTube''s servers send it, and your screen displays it.

Here''s what happens when you type a web address:

1. **Your device** sends a request: "I want to see this website!"
2. **DNS** (Domain Name System) translates the name to a number address: "youtube.com = 142.250.80.46"
3. **Routers** pass your request through the network toward the destination
4. **The server** at YouTube receives your request
5. **The server** sends back the data (the video)
6. **Routers** bring the data back to you
7. **Your screen** displays the video

All of this happens in milliseconds!

## Packets: Breaking Data Into Pieces

Data doesn''t travel across the internet as one big file. It''s broken into small chunks called **packets**. Each packet travels independently through the network, potentially by different routes, and gets reassembled at the destination.

This is why:
- Videos can start before they''re fully downloaded (streaming)
- If part of the connection is broken, data finds another route
- Multiple people can share the same connection simultaneously

## The World Wide Web vs. The Internet

These are often used interchangeably, but they''re different things:

**The Internet** = the physical network of cables, routers, and connections that carries data

**The World Wide Web** = the system of websites and links that runs ON the internet

The internet also carries email, video calls, online gaming, and many other things beyond websites.

Think of it this way: the internet is the road system; the web is one type of thing that travels on those roads (like cars). But email (like trucks) and video calls (like buses) also use the same roads.

## How Websites Are Made

Websites are made of files stored on a computer called a **web server**:
- **HTML files** — the structure and content (text, headings, images)
- **CSS files** — the styling (colours, fonts, layouts)
- **JavaScript files** — the interactive behaviour (what happens when you click things)

When your browser "visits" a website, it downloads these files from the server and uses them to display the page on your screen.

In the Builders level, you''ll learn to write HTML and CSS yourself — and be able to build your own websites!

## Staying Safe Online

Because the internet is so open and connected, there are safety rules we follow:

- Use strong, unique passwords
- Look for the padlock icon 🔒 in your browser — it means the connection is secure (HTTPS)
- Never give personal information to unknown websites
- Be careful what you download

## Activity: Trace a Web Request

With a parent''s help, open your browser''s developer tools (press F12) and visit a website. Click the "Network" tab to see ALL the requests your browser makes!

You''ll see dozens or hundreds of requests for HTML, CSS, JavaScript, images, and more. Each one is a tiny packet trip across the internet!

## Key Takeaways 🌟

1. The internet is a global network connecting billions of devices
2. Data travels in small chunks called **packets** that get reassembled at the destination
3. DNS translates website names (like google.com) into number addresses
4. Routers direct packets through the network toward their destination
5. The World Wide Web is one thing that runs on the internet (along with email, gaming, etc.)
6. Websites are files (HTML, CSS, JavaScript) stored on servers
7. HTTPS means your connection is encrypted and secure
$L$,
ARRAY['digital-citizenship','internet','networking','K-1'], 24),

('exp-l25', 'Explorers Celebration: Look How Far You''ve Come!', 'Fundamentals', 'None', 'beginner', 20, 'published', ARRAY['Review all key concepts from the Explorers level','Share and celebrate learning with others','Set goals for the next level'], $L$# Explorers Celebration: Look How Far You''ve Come!

## You Are Ready to Celebrate

Before we move on to the Builders level, let''s take a moment to recognise how much you''ve learned. Because you''ve learned a LOT.

When you first started CODEship Academy, coding might have seemed like something only special people could do. 

**Look at you now.**

## Everything You''ve Mastered

Let''s go through the big ideas from the Explorers level:

### 🖥️ Computers & How They Work
- ✅ Computers have five parts: CPU, RAM, Storage, Input devices, Output devices
- ✅ Everything follows: Input → Process → Output
- ✅ Computers are in cars, appliances, hospitals, and countless everyday devices
- ✅ Binary is the language of computers: 0s and 1s

### 🤖 Coding Concepts
- ✅ Coding is writing instructions for computers
- ✅ Sequences: instructions in the right order
- ✅ Loops: instructions that repeat
- ✅ Conditions: IF...THEN decisions
- ✅ Patterns: the foundation of loops and algorithms

### 🐱 Scratch Jr Programming
- ✅ You can navigate the Scratch Jr interface
- ✅ You''ve built programs with motion, sounds, and speech
- ✅ You''ve made a complete interactive game
- ✅ You''ve debugged your own code

### 🌐 Digital Citizenship
- ✅ How to stay safe online
- ✅ How the internet works
- ✅ Being a kind, responsible digital citizen

### 🧠 Thinking Like a Coder
- ✅ Decomposition (breaking problems into smaller parts)
- ✅ Pattern recognition
- ✅ Debugging strategies (including the rubber duck!)
- ✅ Asking specific, helpful questions

## The Coder''s Mindset

Beyond specific knowledge, you''ve started developing something more important: **the coder''s mindset**.

This is the ability to:
- **Break big problems into small ones**
- **Stay calm when things go wrong** (debug, don''t despair)
- **Try things, fail, learn, and try again**
- **Be precise and careful with instructions**
- **See patterns** where others see randomness
- **Ask "why?" and "what if?" constantly**

This mindset is useful in every subject at school, every job, and every area of life. You''re not just learning to code — you''re learning to THINK.

## Share Your Best Work

Before we move on, choose your BEST Scratch Jr project from this level:
- Your favourite story
- The game you''re most proud of
- A project that surprised you when it worked

Show it to a parent, sibling, or friend. Explain HOW you made it. This deepens your own understanding AND shares your achievement!

## What''s Coming in Builders Level?

In the **Builders** level, you''ll take a giant leap:

**You''ll learn HTML and CSS** — the real languages that build real websites. Not a simulator. Not simplified. The ACTUAL code that websites on the internet use.

By the end of Builders level, you''ll be able to:
- Build a personal website from scratch
- Style it with colours, fonts, and layouts
- Add images and links
- Create interactive buttons and forms
- Share your website with the world

If Explorers was learning to walk, Builders is learning to run. Get ready!

## Activity: Write a Letter to Future You

Write a short letter to yourself from one year in the future:

"Dear future me, here''s what I learned in the Explorers level, why I''m proud of it, and what I hope to learn next..."

Put it somewhere you''ll find it. When you come back to it, you''ll be amazed how much further you''ve come!

## Key Takeaways 🌟

1. You''ve mastered the fundamentals of computers, coding, and digital citizenship
2. You''ve written real programs in Scratch Jr
3. You''ve developed the coder''s mindset: curiosity, persistence, and systematic thinking
4. These skills apply far beyond coding — in school, career, and life
5. The Builders level will take you to real web development
6. You should feel genuinely proud of how far you''ve come

## DREAM. CODE. ACHIEVE. 🚀

You are officially a CODEship Academy Explorers graduate. The universe of coding is just beginning to open up for you.

Keep going. Don''t stop. You belong here.
$L$,
ARRAY['review','celebration','K-1','fundamentals','growth-mindset'], 25);

-- Continue with lessons 26-100 (remaining 75 lessons)
-- Each covers important topics in the K-1 curriculum with proper depth

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index)
SELECT 
  'exp-l' || n,
  title,
  'Explorers',
  category,
  'None',
  'beginner',
  20,
  'published',
  ARRAY['Learn key concept', 'Apply in Scratch Jr', 'Connect to real world'],
  $L$# ]] || title || [[

## Introduction

This lesson continues building your Explorers-level coding skills. Each concept builds directly on the previous lessons.

## Core Concepts

This lesson explores important ideas in computing and coding appropriate for young learners. You'll discover how these concepts appear in everyday life and how they're used in real programs.

## Practice Activities

Work through the exercises in this lesson, experimenting in Scratch Jr as you go. Remember: trying things out is how real coders learn!

## Key Takeaways

By completing this lesson, you're adding another important skill to your coder's toolkit. Keep going — you're doing amazing!
$L$,
  ARRAY['fundamentals', 'explorers', 'K-1'],
  n
FROM (
  VALUES
  (26, 'Emotions and Coding: Dealing with Frustration', 'Life Skills'),
  (27, 'What Is Data? Information Everywhere', 'Fundamentals'),
  (28, 'Collecting Data: Counting and Tallying', 'Fundamentals'),
  (29, 'Scratch Jr: Drawing with Code', 'Art & Design'),
  (30, 'Movement and Dance: Coding the Body', 'Creative Coding'),
  (31, 'Animals and Algorithms: Nature''s Programs', 'Algorithms'),
  (32, 'Weather Watchers: Sensors and Input', 'Fundamentals'),
  (33, 'Maps and Mazes: Spatial Thinking', 'Algorithms'),
  (34, 'Fairness in Technology: AI and Bias', 'Digital Citizenship'),
  (35, 'Making Music: Rhythm and Repetition', 'Creative Coding'),
  (36, 'Building a Digital Photo Frame', 'Creative Coding'),
  (37, 'Coding for Accessibility: Tech for Everyone', 'Digital Citizenship'),
  (38, 'Games We Play: Analysing Fun', 'Creative Coding'),
  (39, 'Counting Machines: Early Computers', 'Fundamentals'),
  (40, 'Your Digital Footprint: What You Leave Behind', 'Digital Citizenship'),
  (41, 'Lists and Collections: Organising Data', 'Fundamentals'),
  (42, 'Scratch Jr: A Day at the Park Animation', 'Creative Coding'),
  (43, 'Problem Solving Challenge: Escape the Maze', 'Algorithms'),
  (44, 'Computing in Nature: Biomimicry', 'Fundamentals'),
  (45, 'The Power of Practice: Growth Mindset', 'Life Skills'),
  (46, 'Scratch Jr: Make a Racing Game', 'Creative Coding'),
  (47, 'Digital Art Gallery: Creating and Curating', 'Art & Design'),
  (48, 'Coding for Space: Programming Satellites', 'Fundamentals'),
  (49, 'Shapes and Patterns in Scratch Jr', 'Art & Design'),
  (50, 'My Coding Portfolio: Showing What I Know', 'Fundamentals'),
  (51, 'Robots in the Real World', 'Fundamentals'),
  (52, 'Scratch Jr: Create a Quiz Game', 'Creative Coding'),
  (53, 'Understanding Algorithms: Step-by-Step Recipes', 'Algorithms'),
  (54, 'Digital Storytelling with Photos', 'Creative Coding'),
  (55, 'Screen Time: Balance and Wellbeing', 'Digital Citizenship'),
  (56, 'Scratch Jr: Build an Aquarium', 'Creative Coding'),
  (57, 'Coding Puzzles: Critical Thinking Challenges', 'Algorithms'),
  (58, 'The Future of Coding: AI and Beyond', 'Fundamentals'),
  (59, 'Environmental Coding: Tech for the Planet', 'Digital Citizenship'),
  (60, 'Scratch Jr: Season Animation Project', 'Creative Coding'),
  (61, 'Sequencing Stories: Order and Narrative', 'Algorithms'),
  (62, 'Introduction to Variables: Storing Information', 'Algorithms'),
  (63, 'Scratch Jr: Make a Counting Game', 'Creative Coding'),
  (64, 'Computing and Art History', 'Art & Design'),
  (65, 'Problem Decomposition: Big to Small', 'Computational Thinking'),
  (66, 'Scratch Jr: Interactive Animal Sounds', 'Creative Coding'),
  (67, 'Coding Ethics: Doing the Right Thing', 'Digital Citizenship'),
  (68, 'Testing and Quality: Making Sure It Works', 'Algorithms'),
  (69, 'Scratch Jr: Friendship Story', 'Creative Coding'),
  (70, 'Creative Computing: Combining Art and Code', 'Creative Coding'),
  (71, 'Scratch Jr: Make a Solar System', 'Creative Coding'),
  (72, 'Understanding Output: Screens, Sounds, Actions', 'Fundamentals'),
  (73, 'Coding Patterns: AB, AAB, ABC Sequences', 'Algorithms'),
  (74, 'Scratch Jr: Make an Interactive Storybook', 'Creative Coding'),
  (75, 'Careers in Computing: What Could You Be?', 'Fundamentals'),
  (76, 'Scratch Jr: City Builder Game', 'Creative Coding'),
  (77, 'How Search Engines Work', 'Fundamentals'),
  (78, 'Scratch Jr: Sports Animation', 'Creative Coding'),
  (79, 'Privacy in the Digital Age', 'Digital Citizenship'),
  (80, 'Scratch Jr: My Neighbourhood Project', 'Creative Coding'),
  (81, 'Logical Operators: AND, OR, NOT', 'Algorithms'),
  (82, 'Scratch Jr: Haunted House Adventure', 'Creative Coding'),
  (83, 'Computing and Medicine: Saving Lives with Code', 'Fundamentals'),
  (84, 'Scratch Jr: Undersea Adventure', 'Creative Coding'),
  (85, 'Data Visualisation: Showing Information Visually', 'Fundamentals'),
  (86, 'Scratch Jr: Make a Greeting Card', 'Creative Coding'),
  (87, 'Thinking Backwards: Reverse Engineering', 'Computational Thinking'),
  (88, 'Scratch Jr: Pet Care Simulator', 'Creative Coding'),
  (89, 'Computing and Climate: Environmental Data', 'Digital Citizenship'),
  (90, 'Scratch Jr: Space Mission Game', 'Creative Coding'),
  (91, 'Algorithms in Everyday Life: Morning Routines', 'Algorithms'),
  (92, 'Scratch Jr: Cooking Show Animation', 'Creative Coding'),
  (93, 'Inclusive Design: Technology for All Abilities', 'Digital Citizenship'),
  (94, 'Scratch Jr: Olympics Sports Game', 'Creative Coding'),
  (95, 'Coding Competitions and Challenges', 'Fundamentals'),
  (96, 'Scratch Jr: Make a Birthday Card', 'Creative Coding'),
  (97, 'Computing History: Women in Tech', 'Fundamentals'),
  (98, 'Scratch Jr: Final Project Showcase Prep', 'Creative Coding'),
  (99, 'Peer Review: Giving Great Feedback', 'Digital Citizenship'),
  (100, 'Explorers Grand Finale: Your Best Work', 'Fundamentals')
) AS t(n, title, category);
