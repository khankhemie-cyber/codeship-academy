-- ─────────────────────────────────────────────────────────────────────────────
-- CODEship Academy — Classes & Invite System
-- Run AFTER school-portal.sql
-- ─────────────────────────────────────────────────────────────────────────────

-- Classes (teacher-created groups of students)
create table if not exists public.classes (
  id              uuid primary key default gen_random_uuid(),
  teacher_id      uuid references public.users(id) on delete cascade not null,
  school_id       uuid references public.schools(id) on delete set null,
  name            text not null,                        -- e.g. "Grade 4 Coding Club"
  description     text,
  level           text,                                 -- Explorers / Builders / Developers / Engineers
  grade_range     text,                                 -- e.g. "Grades 3–4"
  class_code      text unique not null default upper(substring(encode(gen_random_bytes(4), 'hex'), 1, 6)),
  max_students    integer default 35,
  status          text default 'active' check (status in ('active','archived','draft')),
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- Class memberships (students joined via code or invite)
create table if not exists public.class_memberships (
  id              uuid primary key default gen_random_uuid(),
  class_id        uuid references public.classes(id) on delete cascade not null,
  student_id      uuid references public.student_profiles(id) on delete cascade,
  user_id         uuid references public.users(id) on delete cascade,  -- direct user join (before profile created)
  joined_via      text default 'code' check (joined_via in ('code','invite_link','manual')),
  status          text default 'active' check (status in ('active','removed')),
  joined_at       timestamptz default now(),
  unique (class_id, user_id)
);

-- Invite links (teacher sends a link; anyone who clicks it joins the class)
create table if not exists public.class_invites (
  id              uuid primary key default gen_random_uuid(),
  class_id        uuid references public.classes(id) on delete cascade not null,
  token           text unique not null default encode(gen_random_bytes(16), 'hex'),
  created_by      uuid references public.users(id),
  label           text,                                 -- e.g. "Email to parents Mar 2026"
  uses            integer default 0,
  max_uses        integer,                              -- null = unlimited
  expires_at      timestamptz,
  created_at      timestamptz default now()
);

-- ─── RLS ─────────────────────────────────────────────────────────────────────

alter table public.classes enable row level security;
alter table public.class_memberships enable row level security;
alter table public.class_invites enable row level security;

-- Classes: teachers manage their own; students see classes they belong to
create policy "classes_teacher_all" on public.classes for all
  using (teacher_id = auth.uid() or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "classes_student_select" on public.classes for select
  using (
    id in (
      select class_id from public.class_memberships
      where user_id = auth.uid() and status = 'active'
    )
  );

-- Memberships: teachers see all in their classes; students see own
create policy "memberships_teacher_select" on public.class_memberships for select
  using (
    class_id in (select id from public.classes where teacher_id = auth.uid())
    or user_id = auth.uid()
    or exists (select 1 from public.users where id = auth.uid() and role = 'admin')
  );

create policy "memberships_insert" on public.class_memberships for insert
  with check (auth.role() = 'authenticated');

create policy "memberships_teacher_update" on public.class_memberships for update
  using (
    class_id in (select id from public.classes where teacher_id = auth.uid())
    or exists (select 1 from public.users where id = auth.uid() and role = 'admin')
  );

-- Invites: teachers manage their own
create policy "invites_teacher_all" on public.class_invites for all
  using (created_by = auth.uid() or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "invites_public_select" on public.class_invites for select
  using (true); -- anyone can look up an invite token (to validate it before joining)

-- ─── Helper function: join class by code ─────────────────────────────────────

create or replace function public.join_class_by_code(
  p_user_id uuid,
  p_code    text
) returns jsonb language plpgsql security definer as $$
declare
  v_class  public.classes%rowtype;
  v_count  integer;
begin
  -- Find class
  select * into v_class from public.classes
  where class_code = upper(trim(p_code)) and status = 'active';

  if not found then
    return jsonb_build_object('success', false, 'error', 'Class code not found. Please check and try again.');
  end if;

  -- Check capacity
  select count(*) into v_count from public.class_memberships
  where class_id = v_class.id and status = 'active';

  if v_class.max_students is not null and v_count >= v_class.max_students then
    return jsonb_build_object('success', false, 'error', 'This class is full. Ask your teacher for help.');
  end if;

  -- Already a member?
  if exists (select 1 from public.class_memberships where class_id = v_class.id and user_id = p_user_id) then
    return jsonb_build_object('success', false, 'error', 'You are already in this class!');
  end if;

  -- Join
  insert into public.class_memberships (class_id, user_id, joined_via)
  values (v_class.id, p_user_id, 'code');

  return jsonb_build_object(
    'success', true,
    'class_id', v_class.id,
    'class_name', v_class.name,
    'teacher_message', 'Welcome to ' || v_class.name || '! 🎉'
  );
end;
$$;

-- ─── Helper function: join class by invite token ──────────────────────────────

create or replace function public.join_class_by_invite(
  p_user_id uuid,
  p_token   text
) returns jsonb language plpgsql security definer as $$
declare
  v_invite public.class_invites%rowtype;
  v_class  public.classes%rowtype;
begin
  -- Find invite
  select * into v_invite from public.class_invites where token = p_token;

  if not found then
    return jsonb_build_object('success', false, 'error', 'Invite link not found or expired.');
  end if;

  -- Check expiry
  if v_invite.expires_at is not null and v_invite.expires_at < now() then
    return jsonb_build_object('success', false, 'error', 'This invite link has expired. Ask your teacher for a new one.');
  end if;

  -- Check max uses
  if v_invite.max_uses is not null and v_invite.uses >= v_invite.max_uses then
    return jsonb_build_object('success', false, 'error', 'This invite link has reached its maximum uses.');
  end if;

  -- Get class
  select * into v_class from public.classes where id = v_invite.class_id and status = 'active';
  if not found then
    return jsonb_build_object('success', false, 'error', 'Class not found or no longer active.');
  end if;

  -- Already a member?
  if exists (select 1 from public.class_memberships where class_id = v_class.id and user_id = p_user_id) then
    return jsonb_build_object('success', false, 'error', 'You are already in this class!');
  end if;

  -- Join + increment uses
  insert into public.class_memberships (class_id, user_id, joined_via)
  values (v_class.id, p_user_id, 'invite_link');

  update public.class_invites set uses = uses + 1 where id = v_invite.id;

  return jsonb_build_object(
    'success', true,
    'class_id', v_class.id,
    'class_name', v_class.name,
    'teacher_message', 'Welcome to ' || v_class.name || '! 🎉'
  );
end;
$$;

select '✅ Classes & invite system created' as status;
