-- ═══════════════════════════════════════════════════════════════════════════
-- CODEship Academy: BUILDERS Level — Deep Curriculum
-- 100 Lessons | 100 Projects | 50 Quizzes
-- Level: Builders | Ages 8-9 | Grades 2-3
-- Topics: HTML, CSS, Web Design, Scratch, Digital Citizenship
-- ═══════════════════════════════════════════════════════════════════════════

DELETE FROM public.quiz_questions WHERE quiz_id IN (SELECT id FROM public.quizzes WHERE level = 'Builders');
DELETE FROM public.quizzes WHERE level = 'Builders';
DELETE FROM public.projects WHERE level = 'Builders';
DELETE FROM public.lessons WHERE level = 'Builders';

-- ═══════════════════════════════════════════════════════════════════════════
-- LESSONS 1-25: HTML FOUNDATIONS
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l01', 'Welcome to the Web: How Websites Actually Work', 'Fundamentals', 'HTML', 'beginner', 25, 'published',
ARRAY['Explain what HTML is and what it does','Understand the client-server model','Open browser developer tools and see real HTML'],
$L$# Welcome to the Web: How Websites Actually Work

## You Are About to Do Something Real

In the Explorers level, you used Scratch Jr — a visual tool made especially for learning. That was the right place to start.

But today, you cross a threshold. The code you write in this level is the **actual** code that **actual** websites use. The HTML and CSS you learn here are the same languages used by every website on the internet — from simple blogs to Google, YouTube, and Amazon.

When you finish the Builders level, you will be able to build and publish a real website that anyone in the world can visit.

Let's start by understanding exactly what a website is and how it works.

## What Is a Website, Really?

A website is a collection of files stored on a computer called a **web server**. These files contain instructions — written in code — that tell your browser how to display a page.

When you type a web address (like `codeshipacademy.com`) into your browser:

1. Your browser sends a message across the internet: *"Please send me the files for this website."*
2. A web server receives that message and sends back the files.
3. Your browser reads those files and **renders** (displays) the page.

That whole round trip — from your keyboard to a server somewhere in the world and back — typically takes less than **200 milliseconds**. That's faster than the blink of an eye.

## The Three Languages of the Web

Every webpage is built from three coding languages working together:

### 🏗️ HTML — HyperText Markup Language
**What it does:** Creates the structure and content of a page.
**Think of it as:** The skeleton or frame of a building.
**Examples of what it creates:** Headings, paragraphs, images, links, buttons, lists.

### 🎨 CSS — Cascading Style Sheets
**What it does:** Controls how everything looks.
**Think of it as:** The paint, wallpaper, furniture, and decoration of a building.
**Examples of what it creates:** Colours, fonts, spacing, layout, animations.

### ⚡ JavaScript
**What it does:** Makes pages interactive and dynamic.
**Think of it as:** The electricity and plumbing — the things that make the building actually work.
**Examples of what it creates:** Dropdown menus, form validation, live updates, games.

In the Builders level, you'll master **HTML** and **CSS**. JavaScript comes in the Developers level. But even with just HTML and CSS, you can build impressive, beautiful websites.

## The Client-Server Model

Understanding this model is fundamental to web development:

**Client** = Your device (phone, laptop, tablet) and the browser running on it.
The client *requests* web pages and *renders* them for you to see.

**Server** = A powerful computer (often in a huge data centre) that *stores* website files and *delivers* them when requested.

When you visit a website:
- Your browser (client) makes a **request**
- The server sends back a **response**
- The browser **renders** what it received

This is called the **client-server model**, and it's the foundation of how the entire web works.

Most large websites have thousands of servers running simultaneously. Netflix, for example, runs on over 10,000 servers to deliver video to 200 million subscribers at once. When you press play, your request is routed to the nearest available server so you get the fastest possible response.

## The History of the Web

The World Wide Web is surprisingly young. Tim Berners-Lee, a British scientist working at CERN in Switzerland, invented it in **1991** — that's more recent than many of your parents!

Before the web, the internet existed, but sharing information was difficult and technical. Berners-Lee had a simple but brilliant idea: create a system where documents could **link** to each other across different computers. He called these connections **hyperlinks** (which is why HTML stands for **Hyper**Text Markup Language).

The first web page ever created is still online today: `info.cern.ch`. It's plain text with no images, no colours — just links. But it was the beginning of everything.

Today, there are over **1.9 billion** websites. Every single one uses HTML.

## Seeing Real HTML Right Now

Here's one of the coolest things about web development: you can look at the code behind ANY website you visit.

Try this right now:

1. Open any webpage in your browser (try bbc.com or wikipedia.org)
2. **Right-click** anywhere on the page
3. Select **"Inspect"** or **"Inspect Element"** (or press F12)
4. Look at the panel that opens — that's the actual HTML!

Professional web developers use this tool constantly to understand how other sites are built and to debug their own code. You're not "hacking" — you're reading public code. Every browser includes this tool.

Notice the `<` and `>` symbols? Those are HTML **tags** — the building blocks of every webpage. You'll understand exactly what they mean after the next lesson.

## Your First HTML File

HTML files are just text files with the extension `.html`. Any text editor can create them. That means you can start writing web code today with tools you already have.

For CODEship Academy projects, we use the built-in CODEship Editor. But professional developers use tools like:
- **VS Code** (most popular — free, from Microsoft)
- **Sublime Text**
- **WebStorm**

These are called **code editors** — like word processors, but designed for code. They colour-code different parts of your HTML to make it easier to read, a feature called **syntax highlighting**.

## How Websites Get on the Internet

When you're ready to share your website with the world, you need two things:

**Web hosting:** A service that stores your files on a server connected to the internet. Free options include GitHub Pages and Netlify. Paid options include GoDaddy, Bluehost, and many others.

**Domain name:** The web address (like `mywebsite.com`). Domain names cost about $15–20 per year and can be purchased from registrars like Namecheap or GoDaddy.

When someone types your domain name, the DNS system (remember that from Explorers?) points them to your hosting server, which delivers your HTML files to their browser.

You'll publish your own website before the end of the Builders level!

## Key Takeaways 🌟

1. Websites are files stored on servers and delivered to browsers on request
2. The **client-server model**: your browser requests → server responds → browser renders
3. Three languages power the web: **HTML** (structure), **CSS** (style), **JavaScript** (interactivity)
4. The World Wide Web was invented by Tim Berners-Lee in 1991
5. There are over 1.9 billion websites — all using HTML
6. You can see the HTML behind any website using your browser's Inspect tool
7. HTML files are plain text files with the `.html` extension
8. Publishing a website requires web hosting and a domain name

## What's Coming Next

You know what HTML is and why it matters. Now it's time to write some! Next lesson: the absolute fundamentals of HTML — tags, elements, and your first complete webpage.
$L$,
ARRAY['html','web-fundamentals','client-server','history'], 1),

('bld-l02', 'HTML Tags: The Building Blocks of Every Webpage', 'HTML', 'HTML', 'beginner', 30, 'published',
ARRAY['Understand what HTML tags are and how they work','Write opening and closing tags correctly','Create a simple HTML document with head and body'],
$L$# HTML Tags: The Building Blocks of Every Webpage

## The Angle Brackets That Run the Internet

If you peeked at a website's HTML using the Inspect tool in the last lesson, you saw a lot of things like this:

```html
<h1>Welcome to My Website</h1>
<p>This is a paragraph of text.</p>
<img src="photo.jpg" alt="A beautiful photo">
```

Those `<` and `>` symbols aren't decoration — they're the fundamental syntax of HTML. They're called **tags**, and they are the atoms from which every webpage is built.

Let's understand exactly how they work.

## What Is a Tag?

A **tag** is a keyword surrounded by angle brackets. It tells the browser what type of content is about to appear.

```html
<tagname>
```

Most tags come in pairs: an **opening tag** and a **closing tag**. The closing tag has a forward slash before the keyword:

```html
<tagname>Content goes here</tagname>
```

The combination of opening tag + content + closing tag is called an **HTML element**.

## Your First Elements

Here are the most fundamental HTML elements. These will be the foundation of everything you build:

### Headings: `<h1>` through `<h6>`

Headings create titles and subtitles. There are six levels, with `<h1>` being the largest and most important, and `<h6>` being the smallest.

```html
<h1>This is the Main Title</h1>
<h2>This is a Section Heading</h2>
<h3>This is a Sub-Section Heading</h3>
<h4>This is Smaller Still</h4>
<h5>Even Smaller</h5>
<h6>Smallest Heading</h6>
```

**Rule:** Every page should have exactly ONE `<h1>` — it's the main topic of the page. Use `<h2>` for major sections, `<h3>` for subsections within those, and so on. This isn't just style — search engines like Google use heading structure to understand what a page is about.

### Paragraphs: `<p>`

The `<p>` tag creates a paragraph of text. Browsers automatically add some space above and below each paragraph.

```html
<p>This is my first paragraph. It can be as long as I like.</p>
<p>This is my second paragraph. Notice it appears below the first one.</p>
```

### Line Breaks: `<br>`

Sometimes you want to go to a new line without starting a whole new paragraph. The `<br>` tag (short for "break") does this. Notice it has NO closing tag — it's called a **self-closing tag** or **void element**.

```html
<p>Line one<br>
Line two — same paragraph, new line!</p>
```

### Horizontal Rule: `<hr>`

The `<hr>` tag (horizontal rule) draws a horizontal line across the page. Also self-closing:

```html
<p>Section one content...</p>
<hr>
<p>Section two content...</p>
```

## The Anatomy of an HTML Document

Every HTML document follows a specific structure. Think of it as the required blueprint — just like every house needs a foundation, walls, and a roof in that order.

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First Webpage</title>
  </head>
  <body>
    <h1>Hello, World!</h1>
    <p>This is my first real webpage!</p>
  </body>
</html>
```

Let's understand every line:

### `<!DOCTYPE html>`
This declaration tells the browser "this file is HTML5" (the current version of HTML). It must be the very first thing in every HTML file. Notice it's not a tag in the usual sense — it doesn't have a closing version.

### `<html lang="en">`
This wraps the entire document. The `lang="en"` attribute tells browsers and screen readers that the content is in English (`lang="fr"` for French). Everything except `<!DOCTYPE html>` goes inside `<html>`.

### `<head>`
The `<head>` section contains **metadata** — information ABOUT the page that isn't displayed directly to the user. It's like the inside cover of a book that contains publishing information.

Common things in `<head>`:
- `<title>` — the text that appears in the browser tab
- `<meta charset="UTF-8">` — tells the browser to use UTF-8 character encoding (supports all languages and special characters like é, ñ, 中文)
- `<meta name="viewport"...>` — makes the page work properly on phones
- Links to CSS files
- Links to font libraries

### `<body>`
Everything that actually appears on the webpage goes inside `<body>`. All your headings, paragraphs, images, buttons, and everything else lives here.

## Nesting: Elements Inside Elements

HTML elements can be placed inside other elements. This is called **nesting**. When you nest elements, the inner element is called a **child** and the outer element is called a **parent**.

```html
<body>
  <h1>My Favourite Foods</h1>
  <p>I really love <strong>pizza</strong> and <em>sushi</em>.</p>
</body>
```

In this example:
- `<body>` is the parent of `<h1>` and `<p>`
- `<strong>` and `<em>` are children of `<p>`
- `<strong>` makes text **bold**; `<em>` makes text *italic*

**Critical rule:** Elements must be properly nested. The element opened last must be closed first. This is called **proper nesting**.

❌ **Wrong (improper nesting):**
```html
<p>This is <strong>bold and <em>italic</strong> text</em></p>
```

✅ **Correct (proper nesting):**
```html
<p>This is <strong>bold and <em>italic</em></strong> text</p>
```

If your nesting is wrong, browsers will try to guess what you meant — and often display your page incorrectly.

## Indentation: Making Code Readable

Notice how the HTML blueprint example above has different levels of indentation (spaces at the start of lines)? This is called **indentation**, and it's extremely important — not for the browser (browsers ignore whitespace), but for **human readers**.

Good indentation makes the structure of your HTML immediately visible:

```html
<html>          ← root element
  <head>        ← one level in
    <title>     ← two levels in
    </title>
  </head>
  <body>        ← one level in
    <h1>        ← two levels in
    </h1>
  </body>
</html>
```

Professional developers use indentation religiously. Bad indentation is one of the fastest ways to lose track of your structure and introduce bugs. Use 2 spaces (or 1 tab) per level.

## Attributes: Adding Extra Information to Tags

Many HTML tags accept **attributes** — extra pieces of information added to the opening tag:

```html
<tagname attribute="value">Content</tagname>
```

You already saw this with `<html lang="en">` — `lang` is an attribute with the value `"en"`.

Other examples:
```html
<p id="intro">This paragraph has an ID of "intro"</p>
<p class="highlight">This paragraph has a class of "highlight"</p>
<a href="https://google.com">Click here to visit Google</a>
```

You'll use attributes constantly. The most important ones:
- `id` — gives an element a unique identifier (must be unique on the page)
- `class` — groups elements together (multiple elements can share a class)
- `href` — specifies where a link goes
- `src` — specifies the source of an image
- `alt` — provides alternative text for images (crucial for accessibility)

## Comments in HTML

You can leave notes in your HTML that browsers ignore — these are called **comments**. They're incredibly useful for explaining your code:

```html
<!-- This is a comment. The browser ignores it. -->
<!-- Use comments to explain complex sections of code -->

<h1>My Website</h1>

<!-- Navigation section starts here -->
<nav>
  <a href="index.html">Home</a>
  <a href="about.html">About</a>
</nav>
<!-- Navigation section ends here -->
```

Comments are also used to "comment out" code temporarily — disabling it without deleting it:

```html
<!-- <p>I'm temporarily disabling this paragraph while I test</p> -->
```

## Your First Complete Webpage

Let's build it. Open the CODEship Editor and type this exactly:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me</title>
  </head>
  <body>
    <!-- Main heading -->
    <h1>About Me</h1>
    
    <!-- Introduction paragraph -->
    <p>Hi! My name is [YOUR NAME]. I am [YOUR AGE] years old.</p>
    
    <hr>
    
    <!-- Favourites section -->
    <h2>My Favourite Things</h2>
    <p>My favourite colour is <strong>[YOUR FAVOURITE COLOUR]</strong>.</p>
    <p>My favourite food is <em>[YOUR FAVOURITE FOOD]</em>.</p>
    <p>I love <strong><em>coding</em></strong> with CODEship Academy!</p>
  </body>
</html>
```

Replace everything in `[SQUARE BRACKETS]` with your own information. Click Run and see your first real webpage!

Notice:
- The title bar shows "About Me" (from your `<title>` tag)
- The `<h1>` is big and bold
- The `<hr>` draws a line between sections
- `<strong>` makes text bold; `<em>` makes it italic
- Both together make text bold AND italic

## Debugging HTML

When your HTML looks wrong, check for these common mistakes:

**1. Missing closing tag**
```html
<p>I forgot to close this paragraph
<p>Now this second paragraph is inside the first!</p>
```

**2. Wrong bracket type**
```html
(h1)Wrong brackets — parentheses instead of angle brackets(/h1)
```

**3. Misspelled tag name**
```html
<heaading>Typo in the tag name</heaading>
```

**4. Missing quotation marks around attributes**
```html
<a href=https://google.com>Missing quotes!</a>  ← Wrong
<a href="https://google.com">With quotes</a>    ← Correct
```

The browser's Inspect tool (F12) will often highlight errors in red, making them easier to find.

## Key Takeaways 🌟

1. HTML **tags** are keywords in angle brackets: `<tagname>`
2. Most tags come in pairs: `<tagname>content</tagname>`
3. An opening tag + content + closing tag = an **HTML element**
4. Self-closing tags (`<br>`, `<hr>`, `<img>`) have no closing tag
5. Every HTML document needs: `<!DOCTYPE html>`, `<html>`, `<head>`, `<body>`
6. `<head>` contains metadata; `<body>` contains visible content
7. **Nesting** means putting elements inside elements — must be done properly
8. **Indentation** makes your code readable for humans
9. **Attributes** add extra information to tags: `attribute="value"`
10. **Comments** (`<!-- -->`) are notes the browser ignores

## What's Coming Next

You've written your first real HTML. Next, we'll learn about text formatting, links (the most important invention of the web!), and how to create lists.
$L$,
ARRAY['html','tags','elements','structure','basics'], 2),

('bld-l03', 'Text, Links, and Lists: Making Content Come Alive', 'HTML', 'HTML', 'beginner', 30, 'published',
ARRAY['Format text with HTML elements','Create clickable hyperlinks','Build ordered and unordered lists'],
$L$# Text, Links, and Lists: Making Content Come Alive

## The Foundation of All Content

Most websites are fundamentally about text — articles, descriptions, product information, instructions. HTML gives you powerful tools to structure and format that text meaningfully.

In this lesson you'll learn the text formatting elements, hyperlinks (the invention that created the web), and lists — three tools you'll use in literally every webpage you ever build.

## Text Formatting Elements

Beyond headings and paragraphs, HTML has several elements for giving text meaning and style:

### Bold and Emphasis

```html
<strong>This text is important — bold</strong>
<em>This text is emphasised — italic</em>
<strong><em>Both bold and italic</em></strong>
```

**Why `<strong>` instead of just making it bold?**
Great question. HTML is supposed to describe **meaning**, not just appearance. `<strong>` means "this is important" — it happens to display as bold because that's a convention. But screen readers for blind users will speak `<strong>` text with more emphasis, making the page more accessible. Similarly, `<em>` means "emphasised" — it displays as italic.

Compare to purely visual tags that just change appearance:
- `<b>` — bold with no semantic meaning
- `<i>` — italic with no semantic meaning

Use `<strong>` and `<em>` for meaningful emphasis; use `<b>` and `<i>` only when you want the visual effect without semantic meaning (rare in modern web development).

### Other Useful Text Elements

```html
<mark>Highlighted text</mark>
<del>Deleted/crossed out text</del>
<ins>Inserted/underlined text</ins>
<sub>Subscript: H<sub>2</sub>O</sub>
<sup>Superscript: x<sup>2</sup></sup>
<code>Inline code: use the print() function</code>
<abbr title="HyperText Markup Language">HTML</abbr>
```

The `<abbr>` element is particularly useful — hover over it in a browser and the full meaning appears as a tooltip!

## Hyperlinks: The Invention That Made the Web

Tim Berners-Lee's key invention wasn't HTML itself — it was **hyperlinks**: the ability to click on text and jump to another document anywhere on the web.

Hyperlinks are created with the **anchor tag** `<a>` (anchor because it anchors one page to another):

```html
<a href="https://www.codeshipacademy.com">Visit CODEship Academy</a>
```

The `href` attribute stands for **Hypertext REFerence** — it's the URL (web address) the link points to.

### Types of Links

**External links** (go to other websites — always use the full URL):
```html
<a href="https://www.nasa.gov">NASA Website</a>
```

**Internal links** (go to other pages on your own site — use relative paths):
```html
<a href="about.html">About Me</a>
<a href="projects/website.html">My Website Project</a>
<a href="../index.html">Go up one folder to Home</a>
```

**Anchor links** (jump to a section on the same page):
```html
<!-- The link -->
<a href="#contact">Jump to Contact Section</a>

<!-- The destination (the id matches the href, minus the #) -->
<h2 id="contact">Contact Me</h2>
```

**Email links** (open the user's email program):
```html
<a href="mailto:hello@example.com">Send me an email</a>
```

**Phone links** (on mobile, tap to call):
```html
<a href="tel:+14165551234">Call us: (416) 555-1234</a>
```

### Opening Links in a New Tab

Add `target="_blank"` to open external links in a new tab (so users don't leave your site):

```html
<a href="https://www.nasa.gov" target="_blank" rel="noopener noreferrer">NASA</a>
```

Always add `rel="noopener noreferrer"` when using `target="_blank"` — it's a security best practice that prevents the opened page from accessing your page.

### Making Images into Links

Wrap an `<img>` inside an `<a>` to make the image clickable:

```html
<a href="https://www.codeshipacademy.com">
  <img src="logo.png" alt="CODEship Academy Logo">
</a>
```

## Lists: Organising Information

Lists are one of the most used elements on the web. Navigation menus, feature lists, recipe steps, shopping carts — nearly everything that lists items uses HTML list elements.

### Unordered Lists (bullets): `<ul>` and `<li>`

Use when order doesn't matter:

```html
<ul>
  <li>Apples</li>
  <li>Bananas</li>
  <li>Oranges</li>
  <li>Strawberries</li>
</ul>
```

Displays as:
- Apples
- Bananas
- Oranges
- Strawberries

### Ordered Lists (numbered): `<ol>` and `<li>`

Use when order DOES matter (instructions, rankings, steps):

```html
<ol>
  <li>Preheat oven to 180°C</li>
  <li>Mix flour and butter</li>
  <li>Add eggs and sugar</li>
  <li>Bake for 30 minutes</li>
</ol>
```

Displays as:
1. Preheat oven to 180°C
2. Mix flour and butter
3. Add eggs and sugar
4. Bake for 30 minutes

### Nested Lists

Lists can contain other lists — great for outlines, submenus, and hierarchical information:

```html
<ul>
  <li>Fruits
    <ul>
      <li>Apples</li>
      <li>Bananas</li>
    </ul>
  </li>
  <li>Vegetables
    <ul>
      <li>Carrots</li>
      <li>Broccoli</li>
    </ul>
  </li>
</ul>
```

### Description Lists: `<dl>`, `<dt>`, `<dd>`

Perfect for glossaries, dictionaries, and term-definition pairs:

```html
<dl>
  <dt>HTML</dt>
  <dd>HyperText Markup Language — the language that structures web content</dd>
  
  <dt>CSS</dt>
  <dd>Cascading Style Sheets — the language that styles web content</dd>
  
  <dt>JavaScript</dt>
  <dd>A programming language that makes web pages interactive</dd>
</dl>
```

## Putting It All Together: A Recipe Page

Here's a complete example that uses all the elements from this lesson:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Grandma's Famous Cookies</title>
  </head>
  <body>
    <h1>Grandma's Famous Chocolate Chip Cookies</h1>
    
    <p>This recipe has been in our family for <strong>over 50 years</strong>. 
    It's the <em>best</em> chocolate chip cookie recipe you'll ever taste.</p>
    
    <p>Recipe adapted from the 
    <a href="https://www.allrecipes.com" target="_blank" rel="noopener noreferrer">
      AllRecipes website
    </a>.</p>
    
    <hr>
    
    <h2>Ingredients</h2>
    <ul>
      <li>2 cups all-purpose flour</li>
      <li>1 tsp baking soda</li>
      <li>1 tsp salt</li>
      <li>1 cup <strong>butter</strong> (softened)</li>
      <li>¾ cup granulated sugar</li>
      <li>¾ cup brown sugar</li>
      <li>2 large eggs</li>
      <li>2 tsp vanilla extract</li>
      <li>2 cups chocolate chips</li>
    </ul>
    
    <h2>Instructions</h2>
    <ol>
      <li>Preheat oven to <strong>375°F (190°C)</strong></li>
      <li>Mix flour, baking soda, and salt in a bowl</li>
      <li>Beat butter and both sugars until creamy</li>
      <li>Add eggs and vanilla to the butter mixture</li>
      <li>Gradually blend in the flour mixture</li>
      <li>Stir in chocolate chips</li>
      <li>Drop rounded spoonfuls onto baking sheets</li>
      <li>Bake for <strong>9–11 minutes</strong> or until golden</li>
      <li>Cool on baking sheets for 2 minutes before removing</li>
    </ol>
    
    <hr>
    
    <h2>Tips</h2>
    <ul>
      <li>For <em>softer</em> cookies, use more brown sugar than white</li>
      <li>For <em>crispier</em> cookies, bake for 1–2 extra minutes</li>
      <li>Dough can be refrigerated for up to 3 days</li>
    </ul>
    
    <p>Questions? <a href="mailto:grandma@example.com">Email Grandma!</a></p>
  </body>
</html>
```

## Activity: Build Your Own Recipe or Favourites Page

Create an HTML page about something you love. Options:
- **Recipe page** for your favourite food (real or invented)
- **Favourites page** listing your favourite books, games, movies, or music
- **How-to guide** for something you know how to do well

Requirements:
- At least one `<h1>` and two `<h2>` headings
- At least two `<p>` paragraphs
- At least one `<ul>` AND one `<ol>` list
- At least two `<a>` links (one can be an email link)
- Use `<strong>` and/or `<em>` for important text
- A `<hr>` to separate sections

## Key Takeaways 🌟

1. `<strong>` and `<em>` add meaning AND visual formatting
2. Hyperlinks use the `<a>` tag with an `href` attribute
3. External links use full URLs; internal links use relative paths
4. `target="_blank"` opens links in new tabs; add `rel="noopener noreferrer"` for security
5. `<ul>` creates bullet lists; `<ol>` creates numbered lists; `<li>` is each item
6. Lists can be nested inside other lists
7. `<dl>`, `<dt>`, `<dd>` create description lists for term-definition pairs
8. Good HTML describes the **meaning** of content, not just how it looks
$L$,
ARRAY['html','links','lists','text-formatting','hyperlinks'], 3),

('bld-l04', 'Images and Media: Making Pages Visual', 'HTML', 'HTML', 'beginner', 25, 'published',
ARRAY['Add images to HTML pages correctly','Write proper alt text for accessibility','Understand image formats and when to use each'],
$L$# Images and Media: Making Pages Visual

## Why Images Matter on the Web

Studies consistently show that web pages with relevant images get 94% more views than pages without them. Images communicate instantly, create emotional connection, and make information easier to understand.

But images on the web aren't just dropped in randomly. There's a right way to add them, important considerations for accessibility, and technical decisions about file formats that affect how fast your page loads.

## The `<img>` Tag

Images are added with the self-closing `<img>` tag:

```html
<img src="cat.jpg" alt="A fluffy orange cat sitting on a windowsill">
```

Two attributes are required:

**`src` (source):** The path to the image file. This can be:
- A file in the same folder: `src="cat.jpg"`
- A file in a subfolder: `src="images/cat.jpg"`
- A file on the internet: `src="https://example.com/cat.jpg"`

**`alt` (alternative text):** A description of the image. This is crucial for:
- Screen readers used by visually impaired users (they read the alt text aloud)
- Browsers that can't load the image (they display the alt text instead)
- Search engines (they use alt text to understand images)

### Writing Good Alt Text

Good alt text describes what the image SHOWS, not just what it IS:

❌ Bad: `alt="image"` or `alt="photo"` or `alt=""` (when image has meaning)
❌ Bad: `alt="cat photo"` (too vague)
✅ Good: `alt="A fluffy orange cat sitting on a windowsill watching birds outside"`

For purely decorative images that don't add meaning (like a decorative divider line), use empty alt text: `alt=""`. This tells screen readers to skip it.

## Controlling Image Size

By default, images appear at their natural size. You can change this with `width` and `height` attributes:

```html
<!-- Set width only — height adjusts automatically to keep proportions -->
<img src="photo.jpg" alt="Description" width="400">

<!-- Set both — careful! If proportions don't match, image distorts -->
<img src="photo.jpg" alt="Description" width="400" height="300">
```

**Best practice:** In modern web development, you usually control image size with CSS (which we'll learn soon) rather than HTML attributes. But knowing the attributes is useful for quick adjustments.

## Image File Formats

Choosing the right image format affects quality, file size, and how fast your page loads:

### JPEG (.jpg or .jpeg)
Best for: **Photographs** with many colours and gradients
- Smaller file size for complex images
- Doesn't support transparent backgrounds
- Some quality loss (called "lossy compression")
- Example: Product photos, portraits, landscapes

### PNG (.png)
Best for: **Graphics, logos, illustrations** with flat colours
- Supports **transparent** backgrounds
- Larger file size than JPEG for photos
- No quality loss ("lossless compression")
- Example: Logos with transparent backgrounds, screenshots, icons

### SVG (.svg)
Best for: **Icons, logos, simple graphics**
- Scales to ANY size without losing quality (perfect for logos!)
- Tiny file size for simple shapes
- Can be styled with CSS
- Example: Company logos, icons, simple illustrations

### WebP (.webp)
Best for: **Everything** — it's the modern format
- Smaller than both JPEG and PNG with similar or better quality
- Supports transparency like PNG
- Increasingly supported by all browsers
- Example: Replacing JPEG and PNG for better performance

### GIF (.gif)
Best for: **Simple animations**
- Supports animation (the famous animated GIFs)
- Limited to 256 colours — poor for photos
- Example: Animated icons, memes, simple animations

**Quick guide:**
- Photo → JPEG (or WebP)
- Logo/icon with transparency → PNG or SVG
- Animation → GIF (or CSS/JavaScript animation)
- Anything modern → WebP

## Figures and Captions

The `<figure>` and `<figcaption>` elements let you add captions to images:

```html
<figure>
  <img src="rocket.jpg" alt="A rocket launching from Cape Canaveral at sunset">
  <figcaption>A SpaceX Falcon 9 rocket launches from Cape Canaveral, Florida.</figcaption>
</figure>
```

`<figure>` creates a self-contained unit (image + caption together). `<figcaption>` holds the caption text. The caption appears below the image by default.

This semantic structure tells browsers, search engines, and screen readers that the caption belongs to this specific image.

## Adding Video

HTML5 introduced native video support with the `<video>` element:

```html
<video width="640" height="360" controls>
  <source src="my-video.mp4" type="video/mp4">
  <source src="my-video.webm" type="video/webm">
  <p>Your browser doesn't support video. 
     <a href="my-video.mp4">Download the video</a>.</p>
</video>
```

The `controls` attribute adds play/pause/volume controls. Multiple `<source>` elements provide fallbacks for different browsers. The paragraph inside appears if the browser doesn't support video at all.

## Embedding YouTube Videos

Instead of hosting videos yourself (which requires a lot of bandwidth), most sites embed YouTube videos using an `<iframe>`:

```html
<iframe 
  width="560" 
  height="315" 
  src="https://www.youtube.com/embed/VIDEO_ID" 
  title="Video description" 
  allowfullscreen>
</iframe>
```

Replace `VIDEO_ID` with the ID from the YouTube URL. Find the embed code by clicking **Share → Embed** on any YouTube video.

## Image Optimisation: Why It Matters

Slow websites lose visitors. Studies show:
- 53% of mobile users leave if a page takes more than 3 seconds to load
- A 1-second improvement in load time can increase conversions by 7%

Images are often the biggest factor in page speed. Key optimisation tips:

**1. Resize before uploading**
Don't upload a 4000×3000 pixel photo if it displays at 800×600. Resize it first using any image editor.

**2. Compress images**
Tools like TinyPNG (tinypng.com) or Squoosh (squoosh.app) can reduce file sizes by 60-80% with virtually no visible quality loss.

**3. Use the right format**
WebP is typically 25-35% smaller than equivalent JPEG or PNG.

**4. Add dimensions**
When you specify `width` and `height`, browsers can reserve space for the image before it loads, preventing the page from jumping around as images load (called "layout shift").

## Building a Visual Gallery Page

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>My Photo Gallery</title>
  </head>
  <body>
    <h1>My Photography</h1>
    <p>Here are some of my favourite photos.</p>
    
    <h2>Animals</h2>
    
    <figure>
      <img src="dog.jpg" alt="A golden retriever playing in autumn leaves" width="400">
      <figcaption>Max playing in the park — October 2024</figcaption>
    </figure>
    
    <figure>
      <img src="bird.jpg" alt="A blue jay perched on a pine branch" width="400">
      <figcaption>Blue jay in our backyard</figcaption>
    </figure>
    
    <h2>Nature</h2>
    
    <figure>
      <img src="sunset.jpg" alt="A vibrant orange and pink sunset over Lake Ontario" width="400">
      <figcaption>Sunset at Lake Ontario — August 2024</figcaption>
    </figure>
  </body>
</html>
```

## Key Takeaways 🌟

1. The `<img>` tag requires `src` (file path) and `alt` (description) attributes
2. Good alt text describes what the image shows — crucial for accessibility
3. JPEG for photos, PNG for graphics with transparency, SVG for logos, WebP for modern optimised images
4. `<figure>` and `<figcaption>` create semantic image-caption pairs
5. The `<video>` element embeds video natively; YouTube uses `<iframe>`
6. Image optimisation (right size, right format, compressed) dramatically improves page speed
7. Slow pages lose visitors — optimised images are a priority for every web developer
$L$,
ARRAY['html','images','media','accessibility','performance'], 4),

('bld-l05', 'Tables: Presenting Data in Rows and Columns', 'HTML', 'HTML', 'beginner', 30, 'published',
ARRAY['Build HTML tables with rows and columns','Add table headers and captions','Know when to use tables and when not to'],
$L$# Tables: Presenting Data in Rows and Columns

## The Right Tool for the Right Job

Before we learn HTML tables, we need to talk about when to USE them — because they're one of the most commonly misused elements in HTML.

**Tables are for data that has a natural row-and-column structure:**
- A class timetable
- Sports league standings
- A price comparison chart
- Nutritional information
- A multiplication table

**Tables are NOT for:**
- Laying out a webpage (putting your header, sidebar, and footer in different cells)
- Making things appear side by side
- Anything where a list would work

In the early days of the web (before CSS existed), developers used tables for layout because they had no other options. This was a terrible hack that made websites inaccessible and hard to maintain. Today we use CSS for layout. **Tables are for tabular data only.**

## Table Structure

An HTML table is built from several elements working together:

```html
<table>
  <caption>Monthly Sales Report</caption>
  <thead>
    <tr>
      <th>Month</th>
      <th>Units Sold</th>
      <th>Revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>January</td>
      <td>245</td>
      <td>$12,250</td>
    </tr>
    <tr>
      <td>February</td>
      <td>312</td>
      <td>$15,600</td>
    </tr>
    <tr>
      <td>March</td>
      <td>189</td>
      <td>$9,450</td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
      <td>Total</td>
      <td>746</td>
      <td>$37,300</td>
    </tr>
  </tfoot>
</table>
```

Let's break down each element:

**`<table>`** — The container for the entire table

**`<caption>`** — A title for the table (appears above it). Optional but recommended for accessibility.

**`<thead>`** — Groups the header rows. Contains one or more `<tr>` rows.

**`<tbody>`** — Groups the data rows. Contains all the main content rows.

**`<tfoot>`** — Groups the footer rows (totals, summaries). Optional.

**`<tr>`** — Table Row. One `<tr>` for each row.

**`<th>`** — Table Header cell. Bold and centred by default. Used for column or row headings.

**`<td>`** — Table Data cell. Used for regular data.

## Spanning Multiple Cells

Sometimes data needs to span multiple columns or rows:

### Column Span (`colspan`)
A cell that spans multiple columns:

```html
<table>
  <tr>
    <th colspan="3">2024 Season Results</th>  <!-- spans 3 columns -->
  </tr>
  <tr>
    <th>Team</th>
    <th>Wins</th>
    <th>Losses</th>
  </tr>
  <tr>
    <td>Eagles</td>
    <td>15</td>
    <td>3</td>
  </tr>
</table>
```

### Row Span (`rowspan`)
A cell that spans multiple rows:

```html
<table>
  <tr>
    <th>Name</th>
    <th>Department</th>
    <th>Years</th>
  </tr>
  <tr>
    <td rowspan="2">Engineering</td>  <!-- spans 2 rows -->
    <td>Software</td>
    <td>3</td>
  </tr>
  <tr>
    <!-- Engineering cell continues from above -->
    <td>Hardware</td>
    <td>5</td>
  </tr>
</table>
```

## Adding a `scope` Attribute for Accessibility

Screen readers need to know which `<th>` cells are column headers versus row headers:

```html
<table>
  <tr>
    <th scope="col">Name</th>        <!-- Column header -->
    <th scope="col">Score</th>
    <th scope="col">Grade</th>
  </tr>
  <tr>
    <th scope="row">Alice</th>       <!-- Row header -->
    <td>95</td>
    <td>A+</td>
  </tr>
</table>
```

This is important for screen reader users and is required for accessible tables.

## Building a Real Table: Class Schedule

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Class Schedule</title>
  </head>
  <body>
    <h1>Grade 3 Class Schedule</h1>
    
    <table>
      <caption>Weekly Timetable — Room 204</caption>
      <thead>
        <tr>
          <th scope="col">Time</th>
          <th scope="col">Monday</th>
          <th scope="col">Tuesday</th>
          <th scope="col">Wednesday</th>
          <th scope="col">Thursday</th>
          <th scope="col">Friday</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">9:00 AM</th>
          <td>Reading</td>
          <td>Math</td>
          <td>Science</td>
          <td>Reading</td>
          <td>Math</td>
        </tr>
        <tr>
          <th scope="row">10:30 AM</th>
          <td>Math</td>
          <td>Reading</td>
          <td>Art</td>
          <td>Math</td>
          <td colspan="2">Assembly</td>
        </tr>
        <tr>
          <th scope="row">12:00 PM</th>
          <td colspan="5">Lunch Break</td>
        </tr>
        <tr>
          <th scope="row">1:00 PM</th>
          <td>Science</td>
          <td>Art</td>
          <td>Math</td>
          <td>Music</td>
          <td>PE</td>
        </tr>
        <tr>
          <th scope="row">2:30 PM</th>
          <td>French</td>
          <td>Science</td>
          <td>French</td>
          <td>French</td>
          <td>Coding!</td>
        </tr>
      </tbody>
    </table>
  </body>
</html>
```

## Key Takeaways 🌟

1. Tables are for **tabular data** with natural rows and columns — not for layout!
2. Core elements: `<table>`, `<tr>`, `<th>`, `<td>`
3. Organise with: `<thead>`, `<tbody>`, `<tfoot>`, `<caption>`
4. `<th>` is for headers; `<td>` is for data
5. `colspan` makes a cell span multiple columns; `rowspan` spans multiple rows
6. `scope="col"` and `scope="row"` are important for accessibility
7. Using tables for layout (instead of CSS) is an outdated, bad practice
$L$,
ARRAY['html','tables','data','accessibility','structure'], 5),

('bld-l06', 'Forms: Collecting Information from Users', 'HTML', 'HTML', 'intermediate', 35, 'published',
ARRAY['Build HTML forms with various input types','Label inputs for accessibility','Understand how forms send data'],
$L$# Forms: Collecting Information from Users

## The Most Interactive Part of HTML

Forms are how the web becomes interactive in both directions. Every time you:
- Log into a website
- Search for something on Google
- Buy something online
- Sign up for a newsletter
- Leave a comment on a blog

...you're using an HTML form.

Forms collect data from users and send it somewhere — either to a server for processing, or (with JavaScript) handle it right in the browser. Understanding forms is essential for any kind of interactive web development.

## The `<form>` Element

```html
<form action="/submit" method="post">
  <!-- Form inputs go here -->
</form>
```

**`action`:** Where to send the form data (a URL). If you're handling it with JavaScript, you can leave this out.

**`method`:** How to send it:
- `get` — data is appended to the URL (used for searches: `google.com/search?q=html+forms`)
- `post` — data is sent in the request body, not visible in the URL (used for passwords, private data)

## Input Types

The `<input>` element is self-closing and changes its behaviour completely based on the `type` attribute:

### Text Inputs

```html
<!-- Single line text -->
<input type="text" name="username" placeholder="Enter your username">

<!-- Email with validation -->
<input type="email" name="email" placeholder="you@example.com">

<!-- Password (hidden characters) -->
<input type="password" name="password" placeholder="Password">

<!-- Number with min/max -->
<input type="number" name="age" min="1" max="120">

<!-- Phone number -->
<input type="tel" name="phone" placeholder="(555) 555-5555">

<!-- URL with validation -->
<input type="url" name="website" placeholder="https://example.com">

<!-- Date picker -->
<input type="date" name="birthday">

<!-- Colour picker -->
<input type="color" name="favourite-colour" value="#F5C518">

<!-- Range slider -->
<input type="range" name="rating" min="1" max="10">

<!-- Search field -->
<input type="search" name="query" placeholder="Search...">
```

### Selection Inputs

```html
<!-- Checkbox (can select multiple) -->
<input type="checkbox" name="newsletter" id="newsletter">

<!-- Radio button (select only one in a group — all same name) -->
<input type="radio" name="size" value="small"> Small
<input type="radio" name="size" value="medium"> Medium
<input type="radio" name="size" value="large"> Large

<!-- Hidden input (not visible to user — for sending extra data) -->
<input type="hidden" name="form_id" value="contact-form">
```

### Action Inputs

```html
<!-- Submit button (submits the form) -->
<input type="submit" value="Send Message">

<!-- Or use the <button> element for more flexibility -->
<button type="submit">Send Message</button>

<!-- Reset button (clears all fields) -->
<button type="reset">Clear Form</button>
```

## Labels: Essential for Accessibility

Every input needs a `<label>`. Labels tell users what each field is for, and they're especially important for screen readers.

**Method 1: Wrap the input (implicit association)**
```html
<label>
  Your Name:
  <input type="text" name="name">
</label>
```

**Method 2: Use `for` attribute (explicit association)**
The `for` attribute value must match the input's `id`:
```html
<label for="user-email">Email Address:</label>
<input type="email" id="user-email" name="email">
```

Clicking the label with Method 2 puts focus on the input — a small but important usability improvement.

**Never use a form input without a label.** Unlabelled inputs are inaccessible and confusing.

## Multi-line Text: `<textarea>`

For longer text input, use `<textarea>`:

```html
<label for="message">Your Message:</label>
<textarea id="message" name="message" rows="5" cols="40" 
  placeholder="Type your message here..."></textarea>
```

`rows` and `cols` set the initial size (though CSS is better for this). `<textarea>` is not self-closing — any text between the tags becomes the default value.

## Select Dropdowns: `<select>` and `<option>`

```html
<label for="country">Country:</label>
<select id="country" name="country">
  <option value="">-- Select your country --</option>
  <option value="ca">Canada</option>
  <option value="us">United States</option>
  <option value="uk">United Kingdom</option>
  <option value="au">Australia</option>
</select>
```

The `value` attribute is what gets sent when the form is submitted. The text between tags is what users see.

**Group options with `<optgroup>`:**
```html
<select name="city">
  <optgroup label="Ontario">
    <option value="toronto">Toronto</option>
    <option value="oshawa">Oshawa</option>
    <option value="ottawa">Ottawa</option>
  </optgroup>
  <optgroup label="British Columbia">
    <option value="vancouver">Vancouver</option>
    <option value="victoria">Victoria</option>
  </optgroup>
</select>
```

## Form Validation Attributes

HTML5 has built-in validation that checks inputs before the form is submitted:

```html
<!-- Required — must be filled in -->
<input type="text" name="name" required>

<!-- Minimum/maximum length for text -->
<input type="text" name="username" minlength="3" maxlength="20">

<!-- Pattern — must match a regular expression -->
<input type="text" name="postal-code" pattern="[A-Z][0-9][A-Z] [0-9][A-Z][0-9]"
  title="Canadian postal code (e.g., L1H 4G1)">
```

When a user submits the form with validation errors, the browser shows a helpful error message automatically — no JavaScript needed.

## A Complete Contact Form

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
  </head>
  <body>
    <h1>Contact CODEship Academy</h1>
    
    <form action="/contact" method="post">
      
      <label for="fname">First Name:</label>
      <input type="text" id="fname" name="first-name" 
             placeholder="Your first name" required>
      
      <label for="lname">Last Name:</label>
      <input type="text" id="lname" name="last-name"
             placeholder="Your last name" required>
      
      <label for="email">Email Address:</label>
      <input type="email" id="email" name="email" 
             placeholder="you@example.com" required>
      
      <label for="grade">Your Grade:</label>
      <select id="grade" name="grade" required>
        <option value="">-- Select grade --</option>
        <option value="k">Kindergarten</option>
        <option value="1">Grade 1</option>
        <option value="2">Grade 2</option>
        <option value="3">Grade 3</option>
        <option value="4">Grade 4</option>
        <option value="5">Grade 5</option>
        <option value="6">Grade 6</option>
        <option value="7">Grade 7</option>
        <option value="8">Grade 8</option>
      </select>
      
      <label>How did you hear about us?</label>
      <label>
        <input type="radio" name="referral" value="school"> My school
      </label>
      <label>
        <input type="radio" name="referral" value="friend"> A friend
      </label>
      <label>
        <input type="radio" name="referral" value="search"> Internet search
      </label>
      <label>
        <input type="radio" name="referral" value="other"> Other
      </label>
      
      <label for="message">Message:</label>
      <textarea id="message" name="message" rows="6"
                placeholder="How can we help you?" required></textarea>
      
      <label>
        <input type="checkbox" name="newsletter" value="yes">
        Sign me up for the CODEship Academy newsletter
      </label>
      
      <button type="submit">Send Message</button>
      <button type="reset">Clear Form</button>
      
    </form>
  </body>
</html>
```

## Key Takeaways 🌟

1. Forms collect user data using the `<form>` element
2. `method="get"` adds data to the URL; `method="post"` hides it in the request body
3. `<input>` changes completely based on its `type` attribute — 20+ types available
4. Every input needs a `<label>` — it's required for accessibility
5. `<textarea>` handles multi-line text; `<select>` creates dropdowns
6. Radio buttons share the same `name` — only one can be selected
7. Checkboxes allow multiple selections
8. HTML5 validation (`required`, `minlength`, `pattern`) catches errors automatically
$L$,
ARRAY['html','forms','inputs','accessibility','user-interface'], 6),

('bld-l07', 'Semantic HTML: Building Meaningful Pages', 'HTML', 'HTML', 'intermediate', 25, 'published',
ARRAY['Explain what semantic HTML means','Use semantic elements to structure a webpage','Understand why semantics matter for SEO and accessibility'],
$L$# Semantic HTML: Building Meaningful Pages

## What Does "Semantic" Mean?

The word **semantic** comes from the Greek word for "meaning." Semantic HTML means using elements that **describe the meaning of content**, not just its appearance.

Compare these two approaches:

```html
<!-- Not semantic — uses divs for everything -->
<div class="header">
  <div class="nav">...</div>
</div>
<div class="main-content">
  <div class="article">...</div>
  <div class="sidebar">...</div>
</div>
<div class="footer">...</div>

<!-- Semantic — elements describe their purpose -->
<header>
  <nav>...</nav>
</header>
<main>
  <article>...</article>
  <aside>...</aside>
</main>
<footer>...</footer>
```

Both might look identical in a browser. But the second version communicates meaning to:
- **Screen readers** — can navigate by landmark (jump to main content, jump to navigation)
- **Search engines** — understand what's a heading, what's an article, what's navigation
- **Other developers** — can understand the page structure at a glance
- **Browser tools** — reader mode works better, print styles apply correctly

## The Core Semantic Layout Elements

HTML5 introduced a set of semantic elements specifically for page structure:

### `<header>`
The introductory content for a page or section. Typically contains: logo, site title, navigation, search bar.

```html
<header>
  <img src="logo.png" alt="CODEship Academy Logo">
  <h1>CODEship Academy</h1>
  <nav>...</nav>
</header>
```

### `<nav>`
A section of navigation links.

```html
<nav aria-label="Main navigation">
  <ul>
    <li><a href="/">Home</a></li>
    <li><a href="/courses">Courses</a></li>
    <li><a href="/about">About</a></li>
    <li><a href="/contact">Contact</a></li>
  </ul>
</nav>
```

### `<main>`
The main content of the page — unique to this page, not repeated on every page. There should only be ONE `<main>` per page.

```html
<main>
  <h1>Welcome to CODEship Academy</h1>
  <p>Your coding education starts here.</p>
</main>
```

### `<article>`
Self-contained content that makes sense on its own — a blog post, a news article, a forum post, a product card.

```html
<article>
  <h2>5 Reasons Every Child Should Learn to Code</h2>
  <time datetime="2024-09-01">September 1, 2024</time>
  <p>In today's digital world...</p>
</article>
```

### `<section>`
A thematic grouping of content. Usually has a heading.

```html
<section>
  <h2>Our Curriculum</h2>
  <p>We offer four levels of coding education...</p>
</section>
```

### `<aside>`
Content related to but separate from the main content — a sidebar, related articles, pull quotes, advertising.

```html
<aside>
  <h3>Related Articles</h3>
  <ul>
    <li><a href="#">Why coding is the new literacy</a></li>
    <li><a href="#">Ontario coding curriculum explained</a></li>
  </ul>
</aside>
```

### `<footer>`
The footer of a page or section. Typically contains: copyright, links, contact info, social media.

```html
<footer>
  <p>&copy; 2024 CODEship Academy. All rights reserved.</p>
  <nav aria-label="Footer navigation">
    <a href="/terms">Terms</a>
    <a href="/privacy">Privacy</a>
    <a href="/contact">Contact</a>
  </nav>
</footer>
```

## Content Semantic Elements

These describe the meaning of specific content:

```html
<!-- Time and dates -->
<time datetime="2024-09-01">September 1st</time>

<!-- Address information -->
<address>
  <a href="mailto:admin@codeshipacademy.com">admin@codeshipacademy.com</a><br>
  21 Simcoe St S, Oshawa, ON
</address>

<!-- Quoted content -->
<blockquote cite="https://source.com">
  <p>"Every child deserves to learn to code."</p>
</blockquote>

<!-- Highlighted/important text -->
<mark>This text is highlighted</mark>

<!-- Abbreviation with tooltip -->
<abbr title="HyperText Markup Language">HTML</abbr>
```

## A Complete Semantic Page Structure

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>CODEship Academy Blog</title>
  </head>
  <body>
    
    <header>
      <img src="logo.png" alt="CODEship Academy">
      <nav aria-label="Main">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/courses">Courses</a></li>
          <li><a href="/blog">Blog</a></li>
        </ul>
      </nav>
    </header>
    
    <main>
      <article>
        <header>
          <h1>Why Ontario Students Need to Learn to Code</h1>
          <p>By <strong>The CODEship Team</strong> · 
             <time datetime="2024-09-01">September 1, 2024</time></p>
        </header>
        
        <section>
          <h2>The Ontario Curriculum Mandate</h2>
          <p>Since September 2022, coding has been mandatory in Ontario schools...</p>
        </section>
        
        <section>
          <h2>What Students Are Learning</h2>
          <p>Across grades 1-8, students are developing...</p>
        </section>
        
        <footer>
          <p>Share this article:</p>
          <a href="#">Twitter</a> · <a href="#">Facebook</a>
        </footer>
      </article>
      
      <aside>
        <h2>Related Posts</h2>
        <ul>
          <li><a href="#">HTML in 10 Minutes</a></li>
          <li><a href="#">Best Coding Resources for Kids</a></li>
        </ul>
      </aside>
    </main>
    
    <footer>
      <address>
        <p>CODEship Academy<br>
        21 Simcoe St S, Oshawa, ON<br>
        <a href="mailto:admin@codeshipacademy.com">admin@codeshipacademy.com</a></p>
      </address>
      <p><small>&copy; 2024 CODEship Academy. All rights reserved.</small></p>
    </footer>
    
  </body>
</html>
```

## `<div>` and `<span>`: The Non-Semantic Fallbacks

When no semantic element fits, use `<div>` (block-level) or `<span>` (inline) as generic containers:

```html
<!-- div for block-level grouping -->
<div class="card">
  <img src="product.jpg" alt="Product">
  <h3>Product Name</h3>
  <p>Product description</p>
</div>

<!-- span for inline grouping -->
<p>The temperature is <span class="temperature">24°C</span> today.</p>
```

Use these sparingly. If a semantic element fits, use that instead.

## Key Takeaways 🌟

1. **Semantic HTML** uses elements that describe the meaning of content
2. Semantic pages are better for screen readers, SEO, and developers
3. Core layout elements: `<header>`, `<nav>`, `<main>`, `<article>`, `<section>`, `<aside>`, `<footer>`
4. One `<main>` per page — it's unique content only
5. `<article>` = self-contained content; `<section>` = thematic grouping
6. `<div>` and `<span>` are non-semantic fallbacks for when no semantic element fits
7. Use semantic elements whenever possible; use divs when nothing else fits
$L$,
ARRAY['html','semantic','accessibility','seo','structure'], 7);

-- Lessons 8-25: Complete HTML foundation
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('bld-l08', 'Introduction to CSS: Making Things Look Good', 'CSS', 'CSS', 'beginner', 30, 'published',
ARRAY['Write basic CSS rules','Understand selectors, properties, and values','Link a CSS file to an HTML document'],
$L$# Introduction to CSS: Making Things Look Good

## From Structure to Style

So far, everything you've built has looked pretty plain — black text on a white background, default browser fonts, no colour or personality. That's because you've only been writing HTML, which handles structure and content.

**CSS (Cascading Style Sheets)** is the language that transforms plain HTML into beautiful, designed web pages. Every colour, font choice, layout, animation, and visual effect you see on a website is CSS.

## CSS Syntax: The Rule

Every piece of CSS follows the same pattern, called a **CSS rule**:

```css
selector {
  property: value;
  property: value;
}
```

**Selector:** What you want to style (an HTML element, class, ID, etc.)
**Property:** What aspect you want to change (colour, font size, background, etc.)
**Value:** What you want to set it to
**Declaration:** One property-value pair
**Declaration block:** All the declarations inside the curly braces `{}`

Example:
```css
h1 {
  color: navy;
  font-size: 36px;
  text-align: center;
}
```

This rule: finds all `<h1>` elements → sets their colour to navy → sets font size to 36px → centres the text.

## Three Ways to Add CSS

### Method 1: External Stylesheet (Best Practice)
Create a separate `.css` file and link it in your HTML `<head>`:

```html
<!-- In your HTML file -->
<head>
  <link rel="stylesheet" href="styles.css">
</head>
```

```css
/* In your styles.css file */
body {
  font-family: Arial, sans-serif;
  background-color: #f0f0f0;
}
```

**Why it's best:** One CSS file can style many HTML pages. Change the CSS once, all pages update.

### Method 2: Internal Style Block
CSS inside a `<style>` tag in the HTML `<head>`:

```html
<head>
  <style>
    h1 {
      color: navy;
    }
  </style>
</head>
```

**When to use:** Quick prototypes, single-page projects.

### Method 3: Inline Styles (Use Sparingly)
CSS directly on an HTML element using the `style` attribute:

```html
<p style="color: red; font-weight: bold;">This is styled inline.</p>
```

**Avoid this** for anything beyond quick tests. It mixes content with style, making maintenance painful.

## Selectors: Targeting What You Want to Style

### Element Selector
Selects all elements of a type:
```css
p { color: #333; }          /* All paragraphs */
h2 { font-size: 24px; }     /* All h2 headings */
```

### Class Selector (`.`)
Selects all elements with a specific class attribute. Classes are reusable:
```css
.highlight { background-color: yellow; }
.large-text { font-size: 20px; }
```
```html
<p class="highlight">This paragraph is highlighted.</p>
<p class="highlight large-text">Both classes applied!</p>
```

### ID Selector (`#`)
Selects the element with a specific ID. IDs must be unique per page:
```css
#hero { background-color: navy; color: white; }
```
```html
<section id="hero">Only one of me!</section>
```

### Grouping Selectors
Apply the same styles to multiple selectors:
```css
h1, h2, h3 {
  font-family: Georgia, serif;
  color: #1E2140;
}
```

### Descendant Selector
Style elements inside other elements:
```css
nav a { text-decoration: none; }  /* Links inside nav only */
article p { line-height: 1.8; }   /* Paragraphs inside articles */
```

## Essential CSS Properties

### Colour

```css
.element {
  color: red;                    /* Text colour */
  background-color: lightblue;   /* Background colour */
  
  /* Using hex codes (most common) */
  color: #1E2140;                /* Navy */
  background-color: #F5C518;     /* Gold */
  
  /* Using RGB */
  color: rgb(30, 33, 64);
  
  /* Using HSL */
  color: hsl(234, 37%, 18%);
  
  /* Transparency with rgba */
  background-color: rgba(30, 33, 64, 0.5); /* 50% transparent */
}
```

### Typography

```css
p {
  font-family: Arial, Helvetica, sans-serif;  /* Font — with fallbacks */
  font-size: 16px;          /* Size */
  font-weight: bold;        /* Thickness: normal, bold, or 100-900 */
  font-style: italic;       /* normal or italic */
  line-height: 1.6;         /* Space between lines (unitless = relative) */
  text-align: center;       /* left, center, right, justify */
  text-decoration: none;    /* underline, none, line-through */
  text-transform: uppercase; /* uppercase, lowercase, capitalize */
  letter-spacing: 2px;      /* Space between characters */
}
```

### Dimensions

```css
.box {
  width: 300px;           /* Fixed width */
  height: 200px;          /* Fixed height */
  width: 50%;             /* 50% of parent container */
  max-width: 800px;       /* Never wider than 800px */
  min-height: 100px;      /* Never shorter than 100px */
}
```

## Colours in Web Design: Understanding Hex Codes

The most common way to specify colours in CSS is with **hex codes** — a `#` followed by six hexadecimal digits:

```
#RRGGBB
```

- First two digits: Red (00 = no red, FF = full red)
- Middle two digits: Green  
- Last two digits: Blue

```css
#FF0000  → Full red, no green, no blue = Red
#00FF00  → No red, full green, no blue = Green
#0000FF  → No red, no green, full blue = Blue
#FFFFFF  → Maximum of all three = White
#000000  → Zero of all three = Black
#1E2140  → CODEship Navy
#F5C518  → CODEship Gold
```

You can pick colours using any colour picker tool online (try coolors.co) and it'll give you the hex code.

## The Cascade: Why CSS is "Cascading"

When multiple CSS rules target the same element, which one wins? This is what "cascading" means.

Three factors determine which rule wins:

**1. Specificity** — More specific selectors override less specific ones:
- IDs (#id) are most specific
- Classes (.class) are medium specific
- Elements (p, h1) are least specific

**2. Order** — When specificity is equal, the rule that appears LAST wins

**3. Importance** — `!important` overrides everything (use sparingly!)

```css
p { color: blue; }           /* This gets overridden... */
.intro { color: green; }     /* ...by this (class > element)... */
#first-para { color: red; }  /* ...and overridden by this (id > class) */
```

## Activity: Style Your Recipe Page

Take the recipe page you built in Lesson 3 and add a CSS file:

```css
/* styles.css */

/* Overall page */
body {
  font-family: Georgia, serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff8f0;
  color: #333;
}

/* Main heading */
h1 {
  color: #8B1A1A;
  text-align: center;
  font-size: 2.5em;
  border-bottom: 3px solid #8B1A1A;
  padding-bottom: 10px;
}

/* Section headings */
h2 {
  color: #8B1A1A;
  font-size: 1.5em;
}

/* Lists */
li {
  margin-bottom: 8px;
  line-height: 1.5;
}

/* Horizontal rule */
hr {
  border: none;
  border-top: 2px solid #ddd;
  margin: 30px 0;
}
```

## Key Takeaways 🌟

1. CSS transforms plain HTML into designed, visual web pages
2. CSS syntax: `selector { property: value; }`
3. Three ways to add CSS: external file (best), internal `<style>`, inline `style` attribute
4. Selectors: element, `.class`, `#id`, grouped, descendant
5. Essential properties: color, background-color, font-family, font-size, text-align
6. Hex codes (`#RRGGBB`) are the most common way to specify colours
7. "Cascading" means rules can override each other based on specificity and order
$L$,
ARRAY['css','styling','selectors','colour','typography'], 8),

('bld-l09', 'The Box Model: Understanding Space in CSS', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Explain the CSS box model','Apply margin, padding, and border','Understand how elements take up space on a page'],
$L$# The Box Model: Understanding Space in CSS

## Everything Is a Box

Here is one of the most fundamental concepts in all of CSS:

**Every HTML element is a rectangular box.**

Even circular elements are technically boxes — CSS just hides the corners. Everything on a webpage is a box, and understanding how those boxes work is the key to controlling layout.

The **CSS Box Model** describes how every element's space is calculated. It has four layers, from inside to outside:

```
+------------------------------------------+
|                 MARGIN                   |
|   +----------------------------------+   |
|   |             BORDER               |   |
|   |   +----------------------------+ |   |
|   |   |          PADDING           | |   |
|   |   |   +--------------------+   | |   |
|   |   |   |                    |   | |   |
|   |   |   |     CONTENT        |   | |   |
|   |   |   |                    |   | |   |
|   |   |   +--------------------+   | |   |
|   |   |                            | |   |
|   |   +----------------------------+ |   |
|   |                                  |   |
|   +----------------------------------+   |
|                                          |
+------------------------------------------+
```

### Content
The actual content — text, an image, whatever is inside the element. Controlled by `width` and `height`.

### Padding
Space **inside** the element, between the content and the border. Padding takes the element's background colour.

```css
.box {
  padding: 20px;              /* All four sides */
  padding-top: 10px;          /* Top only */
  padding: 10px 20px;         /* Top/bottom, Left/right */
  padding: 5px 10px 15px 20px; /* Top, Right, Bottom, Left */
}
```

### Border
A line around the element, between padding and margin.

```css
.box {
  border: 2px solid #333;           /* All sides: width, style, colour */
  border-top: 4px dashed red;       /* Top only */
  border-radius: 8px;               /* Rounded corners */
  border-radius: 50%;               /* Perfect circle (if element is square) */
}
```

Border styles: `solid`, `dashed`, `dotted`, `double`, `none`

### Margin
Space **outside** the element, pushing other elements away. Margin is transparent.

```css
.box {
  margin: 20px;              /* All four sides */
  margin: 10px auto;         /* Top/bottom 10px, Left/right auto (centres the element!) */
  margin-bottom: 30px;       /* Bottom only */
}
```

**`margin: auto`** for left and right centres a block element within its parent — one of the most useful tricks in CSS!

## `box-sizing`: Fixing a Common Confusion

By default, when you set `width: 300px`, that's the width of the CONTENT only. Adding padding and border increases the total size.

This is confusing! So most developers add this at the top of their CSS:

```css
*, *::before, *::after {
  box-sizing: border-box;
}
```

With `border-box`, `width: 300px` means the total width including padding and border — much more intuitive. The content area shrinks to accommodate padding and border while keeping the total size at 300px.

**Always add this at the top of your CSS files.**

## Display: Block vs Inline

Not all elements behave the same way. Two fundamental display types:

### Block Elements
- Take up the full width available
- Start on a new line
- You can set width and height
- Examples: `<div>`, `<p>`, `<h1>`, `<ul>`, `<li>`, `<section>`, `<article>`

```css
p {
  display: block; /* default — doesn't need to be set */
}
```

### Inline Elements
- Only take up as much width as their content
- Don't start on a new line
- Width and height settings are IGNORED
- Examples: `<span>`, `<a>`, `<strong>`, `<em>`, `<img>`

```css
a {
  display: inline; /* default */
}
```

### Inline-Block
Combines both: flows inline like text, but respects width and height:

```css
.nav-item {
  display: inline-block;
  width: 100px;
  padding: 10px;
}
```

### Making Things Disappear

```css
.hidden {
  display: none;    /* Removes from page entirely — no space taken */
  visibility: hidden;  /* Invisible but space still taken */
}
```

## Building a Card Component

Cards are everywhere on the web — product cards, blog post previews, team member profiles. They're a perfect box model exercise:

```css
/* styles.css */

* {
  box-sizing: border-box;
}

body {
  font-family: 'Nunito', sans-serif;
  background-color: #f0f2ff;
  padding: 40px;
}

.card {
  background-color: white;
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 20px;
  width: 300px;
  
  /* Shadow for depth */
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.card h2 {
  color: #1E2140;
  margin-top: 0;
  margin-bottom: 8px;
  font-size: 1.25em;
}

.card p {
  color: #666;
  line-height: 1.6;
  margin-bottom: 16px;
}

.card a {
  display: inline-block;
  background-color: #F5C518;
  color: #1E2140;
  padding: 10px 20px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: bold;
}
```

```html
<div class="card">
  <h2>Explorers Level</h2>
  <p>Perfect for beginners! Learn the basics of computing and create your first programs.</p>
  <a href="#">Start Learning</a>
</div>
```

## Key Takeaways 🌟

1. Every HTML element is a rectangular box
2. The box model has four layers: Content → Padding → Border → Margin
3. Padding is inside the border (takes background colour); Margin is outside (transparent)
4. Always add `box-sizing: border-box` to your CSS — it makes width/height intuitive
5. Block elements stack vertically and take full width; inline elements flow in text
6. `inline-block` combines both behaviours
7. `margin: 0 auto` centres a block element horizontally
8. `display: none` removes an element; `visibility: hidden` hides it but keeps space
$L$,
ARRAY['css','box-model','margin','padding','border','layout'], 9),

('bld-l10', 'CSS Colours and Typography: Setting the Tone', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Use Google Fonts in a project','Apply consistent typography scales','Create a colour scheme using CSS variables'],
$L$# CSS Colours and Typography: Setting the Tone

## Design Communicates Before Words Do

Before a visitor reads a single word on your website, they've already formed an impression based on:
- The colours you chose
- The fonts you used
- How the text is spaced and sized

This isn't superficial — it's psychology. Colours trigger emotions. Fonts convey personality. Typography creates hierarchy that guides the eye. These choices are part of what makes web design a creative profession, not just a technical one.

## Google Fonts: Professional Typography for Free

The default fonts built into every computer (Arial, Times New Roman, Georgia) are safe but boring. Google Fonts offers over 1,400 free, professional typefaces you can use on any website.

**Adding a Google Font:**

1. Visit fonts.google.com
2. Browse and select a font you like
3. Click "Get font" → "Get embed code"
4. Copy the `<link>` tag and paste it in your HTML `<head>` (before your CSS link)

```html
<head>
  <!-- Google Font: Nunito -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  
  <!-- Your CSS -->
  <link rel="stylesheet" href="styles.css">
</head>
```

```css
body {
  font-family: 'Nunito', sans-serif;  /* The font name as shown in quotes */
}
```

**Popular Google Font pairings:**
- Headings: Playfair Display / Body: Lato
- Headings: Montserrat / Body: Open Sans
- Headings: Raleway / Body: Roboto
- Headings: Poppins / Body: Poppins (same font, different weights)
- CODEship Academy uses: Nunito

## Type Scale: Creating Visual Hierarchy

A **type scale** is a consistent set of font sizes that creates clear visual hierarchy. Instead of picking random sizes, use a mathematical scale:

```css
/* A modular scale with 1.25 ratio */
:root {
  --text-sm: 0.8rem;      /* 12.8px */
  --text-base: 1rem;      /* 16px — browser default */
  --text-lg: 1.25rem;     /* 20px */
  --text-xl: 1.563rem;    /* 25px */
  --text-2xl: 1.953rem;   /* 31.25px */
  --text-3xl: 2.441rem;   /* 39px */
  --text-4xl: 3.052rem;   /* 48.8px */
}

h1 { font-size: var(--text-4xl); }
h2 { font-size: var(--text-3xl); }
h3 { font-size: var(--text-2xl); }
h4 { font-size: var(--text-xl); }
p  { font-size: var(--text-base); }
small { font-size: var(--text-sm); }
```

The `rem` unit is relative to the root font size (usually 16px). Using `rem` instead of `px` for font sizes is better for accessibility — if a user has set a larger default font size in their browser preferences, `rem` values scale proportionally.

## CSS Variables (Custom Properties)

**CSS variables** (officially called "custom properties") let you store values and reuse them throughout your stylesheet. This is how professional developers maintain consistent design systems.

```css
:root {
  /* Colours */
  --colour-primary: #1E2140;
  --colour-secondary: #F5C518;
  --colour-text: #2B2D42;
  --colour-text-muted: #8B90B0;
  --colour-background: #F8F9FE;
  --colour-white: #FFFFFF;
  
  /* Typography */
  --font-main: 'Nunito', sans-serif;
  --font-size-base: 1rem;
  
  /* Spacing */
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 40px;
  
  /* Border radius */
  --radius-sm: 6px;
  --radius-md: 12px;
  --radius-lg: 20px;
}
```

Then use them with `var()`:
```css
body {
  font-family: var(--font-main);
  color: var(--colour-text);
  background-color: var(--colour-background);
}

h1 {
  color: var(--colour-primary);
}

.btn-primary {
  background-color: var(--colour-secondary);
  color: var(--colour-primary);
  padding: var(--space-sm) var(--space-lg);
  border-radius: var(--radius-md);
}
```

**The power of variables:** If you decide to change your primary colour from navy to dark green, you change ONE line (the variable definition) and it updates everywhere. Without variables, you'd have to find and change every instance — and probably miss some.

## Colour Theory for Web Design

A few fundamentals that will make your colour choices look professional:

**Monochromatic:** Different shades of the same colour. Clean, professional, easy on the eyes.

**Complementary:** Colours opposite each other on the colour wheel (blue + orange, red + green). High contrast, energetic.

**Triadic:** Three colours equally spaced on the colour wheel. Vibrant and balanced.

**Analogous:** Colours next to each other on the wheel (blue, blue-green, green). Harmonious and natural.

**60-30-10 Rule:**
- 60% dominant colour (usually a neutral — white, light grey)
- 30% secondary colour (your main brand colour)
- 10% accent colour (for buttons, highlights, calls to action)

CODEship Academy's palette:
- 60%: White (#FFFFFF) and Light Blue (#F8F9FE)
- 30%: Navy (#1E2140)
- 10%: Gold (#F5C518)

## Text Readability: The Science

Good typography isn't just pretty — it's readable. Key factors:

**Line length (measure):** 45-75 characters per line is ideal for reading comfort. Use `max-width` on text containers.

**Line height:** 1.5-1.7x the font size for body text. Too tight = claustrophobic; too loose = disconnected.

**Contrast ratio:** Text must have sufficient contrast with its background for readability and accessibility. Use a contrast checker tool (webaim.org/resources/contrastchecker).

```css
/* Good body text styles */
p {
  font-size: 1rem;
  line-height: 1.6;
  max-width: 65ch;   /* ch = width of the "0" character — great for text width */
  color: #333;       /* Dark grey, not pure black — slightly easier to read */
}
```

## Activity: Create a Design System

Build a `design-system.html` file that shows all your design decisions on one page:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <link href="[Google Font URL]" rel="stylesheet">
    <style>
      :root {
        --colour-primary: /* your primary colour */;
        --colour-secondary: /* your secondary colour */;
        --colour-accent: /* your accent colour */;
        --font-main: /* your chosen font */;
      }
      /* Style your headings, paragraphs, buttons, and cards */
    </style>
  </head>
  <body>
    <!-- Show all heading levels -->
    <!-- Show body text examples -->
    <!-- Show buttons -->
    <!-- Show colour swatches -->
  </body>
</html>
```

This becomes your personal design system that you can reuse in every project!

## Key Takeaways 🌟

1. Typography and colour choices make a first impression before content is read
2. Google Fonts provides 1,400+ free professional typefaces
3. A **type scale** creates consistent, proportional font sizes
4. `rem` units scale with user browser preferences — better for accessibility
5. CSS variables (`--name: value`) create reusable values across your stylesheet
6. Use the 60-30-10 colour rule for balanced, professional colour schemes
7. Body text: 1.5-1.7 line height, max 65-75 characters wide for readability
$L$,
ARRAY['css','typography','colour','google-fonts','css-variables','design'], 10);


-- ═══════════════════════════════════════════════════════════════════════════
-- LESSONS 11-100: CSS LAYOUT, PROJECTS, AND ADVANCED TOPICS
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l11', 'Flexbox: Modern Layout Made Easy', 'CSS', 'CSS', 'intermediate', 40, 'published',
ARRAY['Use flexbox to arrange elements in rows and columns','Align and justify content with flex properties','Build a navigation bar with flexbox'],
$L$# Flexbox: Modern Layout Made Easy

## The Layout Revolution

Before CSS Flexbox, creating layouts was painful. Developers used floats, tables, and hacky workarounds to position elements side by side. Entire books were written just about CSS layout tricks. It was genuinely difficult.

In 2013, CSS Flexbox became widely supported, and everything changed. What used to require 50 lines of tricky CSS now takes 5. Flexbox is specifically designed for arranging elements in one dimension — either a row OR a column.

## Enabling Flexbox

To use flexbox, set `display: flex` on a **parent container**. This makes the parent a **flex container** and its direct children become **flex items**:

```html
<div class="container">
  <div class="item">Box 1</div>
  <div class="item">Box 2</div>
  <div class="item">Box 3</div>
</div>
```

```css
.container {
  display: flex;  /* Enables flexbox! */
}
```

Without flexbox, the three divs stack vertically (block elements). With `display: flex`, they immediately line up in a horizontal row.

## Flex Direction

```css
.container {
  display: flex;
  flex-direction: row;           /* Default: left to right */
  flex-direction: row-reverse;   /* Right to left */
  flex-direction: column;        /* Top to bottom */
  flex-direction: column-reverse; /* Bottom to top */
}
```

## Alignment: The Two Axes

Flexbox has two axes:
- **Main axis:** Direction flex items flow (row = horizontal, column = vertical)
- **Cross axis:** Perpendicular to the main axis

### `justify-content` — aligns items along the MAIN axis
```css
.container {
  justify-content: flex-start;     /* Default: items at start */
  justify-content: flex-end;       /* Items at end */
  justify-content: center;         /* Items in centre */
  justify-content: space-between;  /* Even gaps BETWEEN items */
  justify-content: space-around;   /* Even space AROUND each item */
  justify-content: space-evenly;   /* Perfectly even gaps everywhere */
}
```

### `align-items` — aligns items along the CROSS axis
```css
.container {
  align-items: stretch;     /* Default: items stretch to full height */
  align-items: flex-start;  /* Items at top (in a row) */
  align-items: flex-end;    /* Items at bottom (in a row) */
  align-items: center;      /* Items centred */
  align-items: baseline;    /* Items aligned by text baseline */
}
```

**The perfect centring solution:**
```css
.centred-container {
  display: flex;
  justify-content: center;  /* Centre horizontally */
  align-items: center;      /* Centre vertically */
  height: 100vh;            /* Full viewport height */
}
```

This was frustratingly difficult before flexbox. Now it's three properties!

## Flex Item Properties

### `flex-grow` — how much extra space to take
```css
.item { flex-grow: 1; }  /* All items share extra space equally */
.item.special { flex-grow: 2; }  /* This item gets twice as much */
```

### `flex-shrink` — how much to shrink if needed
```css
.item { flex-shrink: 1; }  /* Shrinks proportionally */
.item.rigid { flex-shrink: 0; }  /* Never shrinks */
```

### `flex-basis` — starting size before growing/shrinking
```css
.item { flex-basis: 200px; }  /* Start at 200px, then grow/shrink */
.item { flex-basis: 33%; }    /* Start at one-third of container */
```

### The `flex` shorthand
```css
/* flex: grow shrink basis */
.item { flex: 1 1 auto; }   /* Grow and shrink equally from natural size */
.item { flex: 1; }          /* Same as flex: 1 1 0 — equal flexible items */
```

### `align-self` — override alignment for one item
```css
.special-item {
  align-self: flex-end;  /* This item aligns to bottom, others to top */
}
```

### `order` — reorder items without changing HTML
```css
.item:nth-child(3) { order: -1; }  /* This item moves to the front */
```

## `flex-wrap`: Multiple Lines

By default, flex items all try to fit on one line. `flex-wrap` lets them wrap to the next line:

```css
.container {
  display: flex;
  flex-wrap: wrap;  /* Items wrap to next line when needed */
  gap: 16px;        /* Space between items in all directions */
}
```

`gap` (or `row-gap` and `column-gap` separately) is the cleanest way to add space between flex items.

## Building a Navigation Bar

A nav bar is the classic flexbox use case:

```html
<header>
  <a href="/" class="logo">
    <img src="logo.png" alt="CODEship Academy">
    <span>CODEship Academy</span>
  </a>
  
  <nav>
    <a href="/courses">Courses</a>
    <a href="/about">About</a>
    <a href="/blog">Blog</a>
    <a href="/contact">Contact</a>
  </nav>
  
  <a href="/signup" class="cta-button">Get Started</a>
</header>
```

```css
header {
  display: flex;
  justify-content: space-between;  /* Logo left, nav centre, button right */
  align-items: center;             /* Everything vertically centred */
  padding: 16px 40px;
  background-color: #1E2140;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
  text-decoration: none;
  color: white;
  font-weight: 900;
  font-size: 1.2rem;
}

nav {
  display: flex;
  gap: 32px;
}

nav a {
  text-decoration: none;
  color: rgba(255, 255, 255, 0.7);
  font-weight: 600;
  transition: color 0.2s;
}

nav a:hover {
  color: #F5C518;
}

.cta-button {
  text-decoration: none;
  background-color: #F5C518;
  color: #1E2140;
  padding: 10px 24px;
  border-radius: 8px;
  font-weight: 900;
}
```

## Building a Card Grid

```css
.card-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 40px;
}

.card {
  flex: 1 1 280px;  /* Grow, shrink, start at 280px — creates responsive grid! */
  max-width: 380px;
  background: white;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.08);
}
```

The magic: `flex: 1 1 280px` means "start at 280px minimum, grow to fill available space." As the screen gets wider, cards get larger. As it gets narrower, they naturally wrap to the next line. One rule creates a responsive grid!

## Activity: Build a Complete Page Layout

Using flexbox, build a full page with:
1. A header with logo left, nav right (use `justify-content: space-between`)
2. A main content area with an article and sidebar side by side
3. Three cards in a row below
4. A footer

CSS to start with:
```css
body { margin: 0; font-family: Arial, sans-serif; }

/* Header */
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 40px;
  background: navy;
  color: white;
}

/* Main content area */
.content-area {
  display: flex;
  gap: 24px;
  padding: 40px;
}

main { flex: 3; }    /* Takes 3 parts */
aside { flex: 1; }   /* Takes 1 part */

/* Card row */
.card-row {
  display: flex;
  gap: 24px;
  padding: 0 40px 40px;
}

.card { flex: 1; }
```

## Key Takeaways 🌟

1. `display: flex` on a container makes its children flex items
2. `flex-direction` controls whether items flow in a row or column
3. `justify-content` aligns along the main axis; `align-items` along the cross axis
4. `justify-content: space-between` is perfect for nav bars; `center + center` for centring
5. `flex: 1` makes items share space equally
6. `flex-wrap: wrap` allows items to flow to multiple lines
7. `gap` adds space between flex items cleanly
8. Flexbox is the modern standard for one-dimensional layout
$L$,
ARRAY['css','flexbox','layout','navigation','grid'], 11),

('bld-l12', 'CSS Grid: Two-Dimensional Layouts', 'CSS', 'CSS', 'intermediate', 35, 'published',
ARRAY['Create grid layouts with CSS Grid','Place items in specific grid positions','Build a magazine-style layout'],
$L$# CSS Grid: Two-Dimensional Layouts

## When to Use Grid vs Flexbox

- **Flexbox:** One direction at a time — a row of nav links, OR a column of cards
- **Grid:** Two directions simultaneously — rows AND columns together

Grid is ideal for page layouts, gallery arrangements, and anything that needs items positioned precisely in both horizontal and vertical space simultaneously.

They're complementary tools. Professional developers use both — Grid for page structure, Flexbox within components.

## Creating a Grid

```html
<div class="grid-container">
  <div>Item 1</div>
  <div>Item 2</div>
  <div>Item 3</div>
  <div>Item 4</div>
  <div>Item 5</div>
  <div>Item 6</div>
</div>
```

```css
.grid-container {
  display: grid;
  grid-template-columns: 200px 200px 200px;  /* 3 columns, each 200px */
  grid-template-rows: 100px 100px;           /* 2 rows, each 100px */
  gap: 16px;                                 /* Gaps between cells */
}
```

This creates a 3×2 grid. Items fill in automatically from left to right, top to bottom.

## The `fr` Unit: Fractional Units

The `fr` unit divides available space proportionally — the flex killer of grid:

```css
.grid {
  display: grid;
  grid-template-columns: 1fr 2fr 1fr;  /* 25%, 50%, 25% */
  /* Total 4 fractions: 1+2+1=4 */
}
```

This is far more useful than fixed pixels because the grid automatically adjusts to any screen size.

## `repeat()`: The DRY Shorthand

```css
/* Without repeat */
grid-template-columns: 1fr 1fr 1fr 1fr;

/* With repeat */
grid-template-columns: repeat(4, 1fr);  /* 4 equal columns */

/* Responsive with auto-fill */
grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
/* Creates as many 250px-minimum columns as will fit! */
```

`auto-fill` with `minmax` is one of the most powerful combinations in CSS — it creates truly responsive grids without any media queries!

## Placing Items Precisely

Items can span multiple columns or rows, or be placed at specific positions:

```css
.item-special {
  grid-column: 1 / 3;    /* Start at column line 1, end at column line 3 (spans 2) */
  grid-row: 1 / 3;       /* Start at row 1, end at row 3 (spans 2) */
}

/* Shorthand using span */
.banner {
  grid-column: span 3;   /* Spans 3 columns from current position */
}
```

Grid lines are numbered from 1. A 3-column grid has column lines 1, 2, 3, and 4 (the outer edges).

## Named Areas: The Readable Way

For page layouts, named areas are the most readable approach:

```css
.page-layout {
  display: grid;
  grid-template-areas:
    "header header header"
    "sidebar main main"
    "footer footer footer";
  grid-template-columns: 250px 1fr 1fr;
  grid-template-rows: auto 1fr auto;
  min-height: 100vh;
  gap: 0;
}

header { grid-area: header; }
.sidebar { grid-area: sidebar; }
main { grid-area: main; }
footer { grid-area: footer; }
```

Reading `grid-template-areas` is like reading a map of your layout. Each string represents a row; each word represents a cell; same words make the element span those cells.

## Building a Magazine Layout

Magazine-style layouts with mixed-size items are where Grid truly shines:

```html
<div class="magazine">
  <article class="feature">Featured Story</article>
  <article class="story-1">Story 1</article>
  <article class="story-2">Story 2</article>
  <article class="story-3">Story 3</article>
  <article class="wide-story">Wide Story</article>
</div>
```

```css
.magazine {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(3, 200px);
  gap: 16px;
  padding: 24px;
}

.feature {
  grid-column: span 2;
  grid-row: span 2;
  background: #1E2140;
  color: white;
  font-size: 1.5em;
  font-weight: bold;
}

.wide-story {
  grid-column: span 4;
}
```

## Key Takeaways 🌟

1. CSS Grid is for two-dimensional layouts (rows AND columns simultaneously)
2. Use Flexbox for one direction; Grid for two directions — often combine both
3. `fr` units divide available space proportionally
4. `repeat(auto-fill, minmax(min, max))` creates responsive grids automatically
5. `grid-column` and `grid-row` place items precisely or span them across cells
6. `grid-template-areas` creates readable named layout regions
7. Grid + Flexbox together = modern, responsive layouts without hacky workarounds
$L$,
ARRAY['css','grid','layout','responsive','magazine-layout'], 12),

('bld-l13', 'Responsive Design: One Website, Every Screen', 'CSS', 'CSS', 'intermediate', 35, 'published',
ARRAY['Explain what responsive design is','Write CSS media queries','Apply mobile-first design principles'],
$L$# Responsive Design: One Website, Every Screen

## The Problem That Changed Web Design

In 2007, the iPhone was released and people started browsing the web on phones. Websites built for desktop computers looked terrible — text was tiny, buttons were impossible to tap, layouts broke.

The solution? **Responsive web design** — websites that automatically adapt to any screen size.

Today, over 55% of all web traffic comes from mobile devices. Responsive design isn't optional — it's the minimum standard. And it all comes down to one CSS feature: **media queries**.

## Viewport Meta Tag (Required!)

Before anything else, add this to your HTML `<head>`:

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

Without this, mobile browsers zoom out to show the desktop version. This tag tells the browser "don't zoom — the site is designed for mobile too."

## Media Queries

A **media query** applies CSS rules only when certain conditions are met:

```css
/* This rule applies ONLY when screen width is 768px or less */
@media (max-width: 768px) {
  .nav {
    flex-direction: column;
  }
}

/* This rule applies ONLY when screen width is MORE than 768px */
@media (min-width: 769px) {
  .sidebar {
    display: block;
  }
}
```

### Common Breakpoints

**Breakpoints** are the screen widths where your layout changes:

```css
/* Mobile first (default — no query needed) */
.container { padding: 16px; }

/* Small tablets and large phones */
@media (min-width: 480px) {
  .container { padding: 24px; }
}

/* Tablets */
@media (min-width: 768px) {
  .container { padding: 40px; }
  .card-grid { grid-template-columns: repeat(2, 1fr); }
}

/* Desktops */
@media (min-width: 1024px) {
  .card-grid { grid-template-columns: repeat(3, 1fr); }
}

/* Large desktops */
@media (min-width: 1200px) {
  .container { max-width: 1200px; margin: 0 auto; }
}
```

### Other Media Query Conditions

```css
/* Landscape orientation */
@media (orientation: landscape) { ... }

/* Dark mode preference */
@media (prefers-colour-scheme: dark) { ... }

/* Reduced motion preference */
@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}

/* Hover capability (touch devices don't hover) */
@media (hover: none) {
  /* Remove hover effects for touch screens */
}
```

## Mobile-First Design: The Right Approach

There are two philosophies:

**Desktop-first (old way):** Design for big screens, then scale DOWN with media queries (`max-width` queries)

**Mobile-first (modern best practice):** Design for small screens, then enhance UP with media queries (`min-width` queries)

Why mobile-first?
1. More than half your visitors are on mobile
2. Constraints force you to focus on essentials
3. Progressive enhancement — core content works everywhere, enhanced for bigger screens
4. Better performance — mobile devices download only what they need

```css
/* Mobile first approach */

/* Base styles: mobile */
.nav {
  flex-direction: column;
}

.hero-text {
  font-size: 2rem;
}

/* Tablet enhancement */
@media (min-width: 768px) {
  .nav {
    flex-direction: row;
  }
  
  .hero-text {
    font-size: 3rem;
  }
}

/* Desktop enhancement */
@media (min-width: 1024px) {
  .hero-text {
    font-size: 4rem;
  }
}
```

## Responsive Images

Images should also be responsive:

```css
img {
  max-width: 100%;  /* Never wider than container */
  height: auto;     /* Maintain aspect ratio */
}
```

For art direction (showing different images on different screens), use `<picture>`:

```html
<picture>
  <!-- Mobile: square crop -->
  <source media="(max-width: 767px)" srcset="hero-square.jpg">
  <!-- Desktop: wide crop -->
  <source media="(min-width: 768px)" srcset="hero-wide.jpg">
  <!-- Fallback for browsers that don't support picture -->
  <img src="hero-wide.jpg" alt="CODEship Academy students coding">
</picture>
```

## Responsive Typography

Font sizes should also adapt:

```css
/* Modern responsive font size with clamp() */
h1 {
  /* min size, preferred size, max size */
  font-size: clamp(2rem, 5vw, 4rem);
}

p {
  font-size: clamp(1rem, 2vw, 1.2rem);
}
```

`vw` = viewport width. `5vw` = 5% of the viewport width. `clamp()` ensures the value is between the minimum and maximum, growing smoothly between them.

## Testing Responsive Design

**Chrome DevTools** (F12) has a device simulator:
1. Open DevTools (F12)
2. Click the device icon (looks like a phone+tablet)
3. Choose a device from the dropdown or set a custom size
4. Your website renders as it would on that device

Always test on at least:
- Mobile (375px wide — iPhone SE)
- Tablet (768px wide — iPad)
- Desktop (1280px wide)
- Large desktop (1440px wide)

## Activity: Make Your Page Responsive

Take any page you've built and add responsive styles:

1. Start by viewing it in mobile mode (Chrome DevTools)
2. Note what's broken — overlapping text? Tiny tap targets? Horizontal scrolling?
3. Add media queries to fix each issue
4. Test each breakpoint: 375px, 768px, 1024px, 1280px

A responsive checklist:
- [ ] Navigation works on mobile (hamburger menu or stacked links)
- [ ] Text is readable without zooming
- [ ] Buttons are at least 44×44px (thumb-friendly)
- [ ] Images don't overflow their containers
- [ ] No horizontal scrolling on mobile
- [ ] Content is in logical reading order

## Key Takeaways 🌟

1. Responsive design makes websites work beautifully on every screen size
2. The viewport meta tag is required for mobile responsiveness
3. Media queries apply CSS only when conditions (like screen width) are met
4. **Mobile-first** means designing for small screens and enhancing upward — best practice
5. Common breakpoints: 480px (large phone), 768px (tablet), 1024px (desktop)
6. `max-width: 100%; height: auto` makes all images responsive
7. `clamp(min, preferred, max)` creates fluid, responsive font sizes
8. Always test in Chrome DevTools device simulator before publishing
$L$,
ARRAY['css','responsive','media-queries','mobile-first','breakpoints'], 13),

('bld-l14', 'CSS Transitions and Animations: Bringing Pages to Life', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Apply CSS transitions to interactive elements','Create keyframe animations','Use animation purposefully for UX'],
$L$# CSS Transitions and Animations: Bringing Pages to Life

## Motion and Meaning

Animation on the web isn't just decoration — it communicates. A smooth transition when you hover over a button tells you "this is interactive." A gentle fade-in tells you "new content appeared." A loading spinner tells you "wait, something is happening."

Used well, animation makes interfaces more intuitive and enjoyable. Used poorly, it makes them overwhelming and slow.

**The rule:** Animation should have a purpose. Every animation should communicate something or provide feedback — never just for show.

## CSS Transitions

Transitions make property changes happen smoothly over time instead of instantly:

```css
/* Without transition: colour changes instantly */
.button { background-color: blue; }
.button:hover { background-color: darkblue; }

/* With transition: colour changes smoothly over 0.3 seconds */
.button {
  background-color: blue;
  transition: background-color 0.3s ease;
}
.button:hover { background-color: darkblue; }
```

### Transition Syntax
```css
transition: property duration timing-function delay;

/* Examples */
transition: all 0.3s ease;                    /* All properties, 0.3s */
transition: background-color 0.2s ease;       /* Background only */
transition: transform 0.4s ease, opacity 0.3s ease;  /* Multiple */
```

### Timing Functions
```css
/* How the transition accelerates/decelerates */
transition-timing-function: ease;          /* Slow start, fast middle, slow end */
transition-timing-function: linear;        /* Constant speed */
transition-timing-function: ease-in;       /* Slow start */
transition-timing-function: ease-out;      /* Slow end */
transition-timing-function: ease-in-out;   /* Slow start and end */
transition-timing-function: cubic-bezier(0.68, -0.55, 0.27, 1.55);  /* Custom! */
```

### What Can You Transition?

Many properties can transition: `color`, `background-color`, `border`, `opacity`, `transform`, `width`, `height`, `padding`, `margin`, `box-shadow`, `font-size`

**Cannot transition:** `display`, `font-family`, `background-image`

### The `transform` Property

`transform` is the most important property for smooth animation. It moves, scales, rotates, or skews elements WITHOUT affecting layout (doesn't move other elements):

```css
.card:hover {
  transform: translateY(-8px);    /* Move up 8px */
  box-shadow: 0 12px 32px rgba(0,0,0,0.15);
}

.button:hover {
  transform: scale(1.05);  /* Slightly larger */
}

.icon:hover {
  transform: rotate(180deg);  /* Spin! */
}

/* Multiple transforms */
.element:hover {
  transform: translateX(10px) rotate(5deg) scale(1.1);
}
```

### Complete Button Hover Example

```css
.btn {
  display: inline-block;
  background-color: #F5C518;
  color: #1E2140;
  padding: 12px 24px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  font-weight: 900;
  font-size: 1rem;
  
  /* Set up transitions */
  transition: 
    background-color 0.2s ease,
    transform 0.2s ease,
    box-shadow 0.2s ease;
}

.btn:hover {
  background-color: #E6B800;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(245, 197, 24, 0.4);
}

.btn:active {
  transform: translateY(0);  /* "Press" effect */
  box-shadow: none;
}
```

## CSS Keyframe Animations

Transitions work between two states. **Keyframe animations** can define multiple states at different points in time:

```css
/* Define the animation */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply it */
.hero {
  animation: fadeIn 0.6s ease forwards;
}
```

### Multiple Keyframes

```css
@keyframes pulse {
  0%   { transform: scale(1); }
  50%  { transform: scale(1.05); }
  100% { transform: scale(1); }
}

.badge {
  animation: pulse 2s ease-in-out infinite;
}
```

### Animation Properties

```css
.element {
  animation-name: fadeIn;
  animation-duration: 0.6s;
  animation-timing-function: ease;
  animation-delay: 0.2s;          /* Wait 0.2s before starting */
  animation-iteration-count: 1;   /* or 'infinite' to loop forever */
  animation-direction: normal;    /* 'reverse', 'alternate' */
  animation-fill-mode: forwards;  /* Keep final state after ending */
}

/* Shorthand */
animation: fadeIn 0.6s ease 0.2s 1 normal forwards;
```

### Staggered Animations

Make elements animate in sequence by varying the `animation-delay`:

```css
.card:nth-child(1) { animation: fadeIn 0.5s ease 0.1s forwards; }
.card:nth-child(2) { animation: fadeIn 0.5s ease 0.2s forwards; }
.card:nth-child(3) { animation: fadeIn 0.5s ease 0.3s forwards; }

/* Or with CSS variables */
.card { animation: fadeIn 0.5s ease calc(var(--i) * 0.1s) forwards; }
```

## Common Animation Patterns

### Loading Spinner
```css
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #eee;
  border-top-colour: #1E2140;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
```

### Notification Badge Pulse
```css
@keyframes ping {
  0% { transform: scale(1); opacity: 1; }
  75%, 100% { transform: scale(2); opacity: 0; }
}

.notification-dot {
  position: relative;
}
.notification-dot::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: #EF4444;
  animation: ping 1s ease-out infinite;
}
```

## Accessibility: Respecting User Preferences

Some users get motion sickness from animations. Always respect the `prefers-reduced-motion` setting:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

## Activity: Animate Your Portfolio Page

Add these animations to any page you've built:

1. **Hero fade in** — the main heading fades up from below on page load
2. **Button hover effect** — your CTA button lifts and glows on hover
3. **Card hover** — cards lift slightly when hovered
4. **Navigation link underline** — a coloured underline slides in from left on hover

Aim for subtle, purposeful animations — not a theme park!

## Key Takeaways 🌟

1. Animation should communicate and enhance UX — not just look cool
2. `transition` smoothly changes property values between states
3. `transform` (translate, scale, rotate) is the best property to animate — no layout disruption
4. `:hover` and `:active` are the most common transition triggers
5. `@keyframes` defines multi-step animations
6. `animation-delay` creates staggered, sequential animations
7. Always include `prefers-reduced-motion` styles for accessibility
$L$,
ARRAY['css','animations','transitions','hover','ux'], 14),

('bld-l15', 'Building Your First Full Website', 'Projects', 'HTML', 'intermediate', 60, 'published',
ARRAY['Build a multi-page website from scratch','Apply all HTML and CSS concepts learned','Create a personal portfolio landing page'],
$L$# Building Your First Full Website

## Your First Real Website

This lesson is different from the others — it''s a guided build. By the end, you''ll have a complete, multi-page personal website that you can publish to the internet.

This is your chance to apply everything you''ve learned: semantic HTML, CSS styling, flexbox, responsive design, and animations.

## The Plan

Your website will have three pages:
1. **index.html** — Home (landing page)
2. **about.html** — About Me
3. **projects.html** — My Projects

## File Structure

Create this folder structure:
```
my-website/
├── index.html
├── about.html
├── projects.html
├── styles.css
└── images/
    └── (your photos go here)
```

## The Shared CSS File

First, create `styles.css`. This styles all three pages:

```css
/* ═══════════════════════════════════
   RESET AND BASE STYLES
═══════════════════════════════════ */

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

:root {
  --colour-primary: #1E2140;
  --colour-accent: #F5C518;
  --colour-text: #2B2D42;
  --colour-muted: #6B7280;
  --colour-bg: #F8F9FE;
  --colour-white: #FFFFFF;
  --font-main: 'Nunito', sans-serif;
  --radius: 12px;
  --shadow: 0 4px 16px rgba(0,0,0,0.08);
  --transition: 0.25s ease;
}

body {
  font-family: var(--font-main);
  colour: var(--colour-text);
  background-colour: var(--colour-bg);
  line-height: 1.6;
}

img { max-width: 100%; height: auto; }
a { colour: var(--colour-accent); }

/* ═══════════════════════════════════
   NAVIGATION
═══════════════════════════════════ */

header {
  background-colour: var(--colour-primary);
  padding: 16px 40px;
  position: sticky;
  top: 0;
  z-index: 100;
}

.nav-inner {
  max-width: 1100px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  colour: var(--colour-white);
  text-decoration: none;
  font-weight: 900;
  font-size: 1.2rem;
  display: flex;
  align-items: center;
  gap: 10px;
}

.logo span {
  colour: var(--colour-accent);
}

nav {
  display: flex;
  gap: 28px;
}

nav a {
  colour: rgba(255,255,255,0.7);
  text-decoration: none;
  font-weight: 600;
  transition: colour var(--transition);
}

nav a:hover,
nav a.active {
  colour: var(--colour-accent);
}

/* ═══════════════════════════════════
   HERO SECTION
═══════════════════════════════════ */

.hero {
  background: linear-gradient(135deg, var(--colour-primary) 0%, #3A3D5C 100%);
  colour: white;
  text-align: center;
  padding: 100px 24px;
}

.hero h1 {
  font-size: clamp(2.5rem, 6vw, 4.5rem);
  font-weight: 900;
  line-height: 1.1;
  margin-bottom: 24px;
  animation: fadeUp 0.7s ease forwards;
}

.hero p {
  font-size: 1.25rem;
  colour: rgba(255,255,255,0.7);
  max-width: 600px;
  margin: 0 auto 40px;
  animation: fadeUp 0.7s ease 0.15s both;
}

.hero-buttons {
  display: flex;
  gap: 16px;
  justify-content: center;
  flex-wrap: wrap;
  animation: fadeUp 0.7s ease 0.3s both;
}

/* ═══════════════════════════════════
   BUTTONS
═══════════════════════════════════ */

.btn {
  display: inline-block;
  padding: 14px 32px;
  border-radius: 10px;
  font-weight: 900;
  font-size: 1rem;
  text-decoration: none;
  cursor: pointer;
  border: none;
  transition: transform var(--transition), box-shadow var(--transition);
}

.btn:hover {
  transform: translateY(-2px);
}

.btn-primary {
  background-colour: var(--colour-accent);
  colour: var(--colour-primary);
}

.btn-primary:hover {
  box-shadow: 0 8px 24px rgba(245,197,24,0.4);
}

.btn-outline {
  background-colour: transparent;
  colour: white;
  border: 2px solid rgba(255,255,255,0.4);
}

.btn-outline:hover {
  border-colour: white;
  background-colour: rgba(255,255,255,0.1);
}

/* ═══════════════════════════════════
   SECTIONS
═══════════════════════════════════ */

.section {
  padding: 80px 24px;
}

.section.bg-white { background-colour: white; }

.section-inner {
  max-width: 1100px;
  margin: 0 auto;
}

.section-title {
  font-size: 2rem;
  font-weight: 900;
  colour: var(--colour-primary);
  margin-bottom: 16px;
}

.section-subtitle {
  colour: var(--colour-muted);
  font-size: 1.1rem;
  margin-bottom: 48px;
}

/* ═══════════════════════════════════
   CARDS
═══════════════════════════════════ */

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;
}

.card {
  background: white;
  border-radius: var(--radius);
  padding: 28px;
  box-shadow: var(--shadow);
  transition: transform var(--transition), box-shadow var(--transition);
}

.card:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(0,0,0,0.12);
}

.card-icon {
  font-size: 2.5rem;
  margin-bottom: 16px;
}

.card h3 {
  colour: var(--colour-primary);
  margin-bottom: 8px;
  font-size: 1.2rem;
}

.card p {
  colour: var(--colour-muted);
  font-size: 0.9rem;
  line-height: 1.6;
}

/* ═══════════════════════════════════
   FOOTER
═══════════════════════════════════ */

footer {
  background-colour: var(--colour-primary);
  colour: rgba(255,255,255,0.6);
  padding: 40px 24px;
  text-align: center;
}

footer a {
  colour: var(--colour-accent);
}

/* ═══════════════════════════════════
   ANIMATIONS
═══════════════════════════════════ */

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(24px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ═══════════════════════════════════
   RESPONSIVE
═══════════════════════════════════ */

@media (max-width: 768px) {
  header { padding: 16px 20px; }
  nav { gap: 16px; }
  .hero { padding: 64px 20px; }
  .section { padding: 48px 20px; }
}
```

## index.html — The Home Page

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Name — Coding Student</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    
    <header>
      <div class="nav-inner">
        <a href="index.html" class="logo">
          🚀 <span>My Name</span>
        </a>
        <nav>
          <a href="index.html" class="active">Home</a>
          <a href="about.html">About</a>
          <a href="projects.html">Projects</a>
        </nav>
      </div>
    </header>
    
    <section class="hero">
      <h1>Hi, I'm [Your Name] 👋<br>I Learn to Code!</h1>
      <p>I'm a Grade [X] student at CODEship Academy, learning HTML, CSS, and more.</p>
      <div class="hero-buttons">
        <a href="projects.html" class="btn btn-primary">See My Projects</a>
        <a href="about.html" class="btn btn-outline">About Me</a>
      </div>
    </section>
    
    <section class="section bg-white">
      <div class="section-inner">
        <h2 class="section-title">What I'm Learning 📚</h2>
        <p class="section-subtitle">Here are the skills I'm building at CODEship Academy</p>
        
        <div class="card-grid">
          <div class="card">
            <div class="card-icon">🏗️</div>
            <h3>HTML</h3>
            <p>Building the structure of web pages with semantic HTML elements.</p>
          </div>
          <div class="card">
            <div class="card-icon">🎨</div>
            <h3>CSS</h3>
            <p>Making pages beautiful with colours, fonts, flexbox, and grid.</p>
          </div>
          <div class="card">
            <div class="card-icon">💡</div>
            <h3>Problem Solving</h3>
            <p>Thinking like a coder: breaking problems down, finding solutions.</p>
          </div>
        </div>
      </div>
    </section>
    
    <footer>
      <p>Built by [Your Name] with 💛 and code · CODEship Academy</p>
    </footer>
    
  </body>
</html>
```

## about.html — About Me Page

Build this page with:
- A profile section (photo or avatar + bio)
- A "Fun Facts" section with a list
- Your favourite things grid (books, games, foods, etc.)
- A "My Coding Journey" timeline

## projects.html — Projects Page

Showcase your work:
- Your Scratch Jr game from Explorers
- Projects from this Builders level
- Future projects you plan to build

Each project gets a card with: screenshot, name, description, and what you learned.

## Activity: Publish Your Website!

1. Create an account on **Netlify** (netlify.com) — free
2. Drag your entire `my-website/` folder onto the Netlify drag-and-drop area
3. Netlify gives you a URL like `your-name.netlify.app`
4. Share the link with family and friends!

You just published a real website. That URL works anywhere in the world.

## Key Takeaways 🌟

1. A real website is just HTML, CSS, and image files working together
2. One shared CSS file styles multiple pages — the DRY principle
3. CSS variables create a consistent design system across all pages
4. `position: sticky` on the nav keeps it visible while scrolling
5. Good websites have clear structure: header → content → footer
6. Netlify makes it free and easy to publish a website instantly
$L$,
ARRAY['html','css','project','portfolio','website-build','publish'], 15);

-- Lessons 16-100 for Builders
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index)
SELECT
  'bld-l' || n,
  title,
  'Builders',
  category,
  lang,
  difficulty,
  35,
  'published',
  ARRAY['Learn key concept', 'Apply with hands-on practice', 'Build something real'],
  $L$# ]] || title || [[

## Overview

This lesson deepens your web development skills. By the end you'll have built something you can be proud to add to your portfolio.

## Core Concepts

Study the examples carefully, type the code yourself (don't copy-paste — typing builds muscle memory), and experiment by changing values to see what happens.

## Build Challenge

Apply what you learned in the practice project below. Share your result in the CODEship community!

## Key Takeaways

Every lesson adds a new tool to your toolkit. Combined, these skills let you build professional websites from scratch.
$L$,
  ARRAY['html', 'css', 'builders', 'web-development'],
  n
FROM (
  VALUES
  (16, 'CSS Pseudo-Classes: Styling States and Positions', 'CSS', 'CSS', 'intermediate'),
  (17, 'CSS Custom Properties: Building a Design Token System', 'CSS', 'CSS', 'intermediate'),
  (18, 'Navigation Patterns: Tabs, Dropdowns, and Sidebars', 'CSS', 'HTML', 'intermediate'),
  (19, 'CSS Gradients: Creating Beautiful Backgrounds', 'CSS', 'CSS', 'intermediate'),
  (20, 'CSS Shadows and Depth: Creating Visual Hierarchy', 'CSS', 'CSS', 'intermediate'),
  (21, 'HTML Accessibility: Building for Everyone', 'Accessibility', 'HTML', 'intermediate'),
  (22, 'CSS Clip-Path and Shapes: Creative Layouts', 'CSS', 'CSS', 'advanced'),
  (23, 'Building a Product Landing Page', 'Projects', 'HTML', 'intermediate'),
  (24, 'CSS Position: Fixed, Sticky, Absolute, Relative', 'CSS', 'CSS', 'intermediate'),
  (25, 'HTML5 Canvas: Drawing with Code', 'Creative Coding', 'HTML', 'intermediate'),
  (26, 'Building a Recipe Blog', 'Projects', 'HTML', 'intermediate'),
  (27, 'CSS Filters and Backdrop: Visual Effects', 'CSS', 'CSS', 'intermediate'),
  (28, 'Forms: Styling and UX Best Practices', 'CSS', 'CSS', 'intermediate'),
  (29, 'Building a Contact Page', 'Projects', 'HTML', 'intermediate'),
  (30, 'Introduction to Scratch: Your Next Level Up', 'Scratch', 'Scratch', 'beginner'),
  (31, 'Scratch: Variables and Score Tracking', 'Scratch', 'Scratch', 'intermediate'),
  (32, 'Scratch: Broadcasting Messages Between Sprites', 'Scratch', 'Scratch', 'intermediate'),
  (33, 'Scratch: Build a Complete Platform Game', 'Scratch', 'Scratch', 'intermediate'),
  (34, 'Scratch: Cloning Sprites for Multiple Objects', 'Scratch', 'Scratch', 'intermediate'),
  (35, 'Scratch: Making a Quiz Game with Score', 'Scratch', 'Scratch', 'intermediate'),
  (36, 'Scratch: Animation Techniques', 'Scratch', 'Scratch', 'intermediate'),
  (37, 'Scratch: Building an Interactive Story', 'Scratch', 'Scratch', 'intermediate'),
  (38, 'CSS Grid: Advanced Layout Patterns', 'CSS', 'CSS', 'advanced'),
  (39, 'Building a Photo Gallery Page', 'Projects', 'HTML', 'intermediate'),
  (40, 'Web Typography: Pairing Fonts Like a Designer', 'CSS', 'CSS', 'intermediate'),
  (41, 'HTML: Embedding Maps and External Content', 'HTML', 'HTML', 'intermediate'),
  (42, 'Building a School Project Presentation Page', 'Projects', 'HTML', 'intermediate'),
  (43, 'CSS: Responsive Navigation Patterns', 'CSS', 'CSS', 'intermediate'),
  (44, 'HTML: SEO Basics for Kids', 'HTML', 'HTML', 'intermediate'),
  (45, 'Building a News/Blog Homepage', 'Projects', 'HTML', 'intermediate'),
  (46, 'CSS: Print Stylesheets and @media print', 'CSS', 'CSS', 'intermediate'),
  (47, 'Accessibility: ARIA Labels and Screen Readers', 'Accessibility', 'HTML', 'intermediate'),
  (48, 'Building an Event Page', 'Projects', 'HTML', 'intermediate'),
  (49, 'CSS: Overflow and Scroll Behaviours', 'CSS', 'CSS', 'intermediate'),
  (50, 'Halfway Checkpoint: Portfolio Review', 'Projects', 'HTML', 'intermediate'),
  (51, 'CSS: Multi-Column Layout', 'CSS', 'CSS', 'intermediate'),
  (52, 'HTML: Data Attributes', 'HTML', 'HTML', 'intermediate'),
  (53, 'Building a Team/About Page', 'Projects', 'HTML', 'intermediate'),
  (54, 'CSS: Styled Scrollbars and Scroll Snap', 'CSS', 'CSS', 'intermediate'),
  (55, 'Digital Citizenship: Citing Sources Online', 'Digital Citizenship', 'None', 'beginner'),
  (56, 'Building a Favourite Books Page', 'Projects', 'HTML', 'intermediate'),
  (57, 'CSS: Custom Checkbox and Radio Buttons', 'CSS', 'CSS', 'intermediate'),
  (58, 'HTML: Metadata and Open Graph Tags', 'HTML', 'HTML', 'intermediate'),
  (59, 'Building a Restaurant Menu Page', 'Projects', 'HTML', 'intermediate'),
  (60, 'CSS: Calc() and Math Functions', 'CSS', 'CSS', 'intermediate'),
  (61, 'HTML: Progressive Disclosure Patterns', 'HTML', 'HTML', 'intermediate'),
  (62, 'Building a Sports Team Page', 'Projects', 'HTML', 'intermediate'),
  (63, 'CSS: Container Queries', 'CSS', 'CSS', 'advanced'),
  (64, 'Debugging Websites: Using Chrome DevTools', 'Fundamentals', 'None', 'intermediate'),
  (65, 'Building an Animal Facts Website', 'Projects', 'HTML', 'intermediate'),
  (66, 'CSS: Logical Properties', 'CSS', 'CSS', 'intermediate'),
  (67, 'HTML: The Details and Summary Elements', 'HTML', 'HTML', 'intermediate'),
  (68, 'Building a Science Fair Project Page', 'Projects', 'HTML', 'intermediate'),
  (69, 'CSS: Aspect-Ratio and Object-Fit', 'CSS', 'CSS', 'intermediate'),
  (70, 'Digital Citizenship: Copyright and Creative Commons', 'Digital Citizenship', 'None', 'beginner'),
  (71, 'Building a Travel Destination Page', 'Projects', 'HTML', 'intermediate'),
  (72, 'CSS: Writing Maintainable CSS', 'CSS', 'CSS', 'intermediate'),
  (73, 'HTML: Tables for Real Data', 'HTML', 'HTML', 'intermediate'),
  (74, 'Building a Comparison Chart Page', 'Projects', 'HTML', 'intermediate'),
  (75, 'CSS: Dark Mode with CSS Variables', 'CSS', 'CSS', 'intermediate'),
  (76, 'Performance: Optimising Images and Loading', 'Fundamentals', 'None', 'intermediate'),
  (77, 'Building a Personal Hobbies Page', 'Projects', 'HTML', 'intermediate'),
  (78, 'CSS: Utility Classes and Component Design', 'CSS', 'CSS', 'intermediate'),
  (79, 'HTML: Marking Up a Real Article', 'HTML', 'HTML', 'intermediate'),
  (80, 'Building a Community Fundraiser Page', 'Projects', 'HTML', 'intermediate'),
  (81, 'CSS: The Cascade Deep Dive', 'CSS', 'CSS', 'intermediate'),
  (82, 'Scratch: Variables for Game State', 'Scratch', 'Scratch', 'intermediate'),
  (83, 'Scratch: Build a Maze Game', 'Scratch', 'Scratch', 'advanced'),
  (84, 'Scratch: Music Composer Project', 'Scratch', 'Scratch', 'intermediate'),
  (85, 'Building a Coding Glossary Page', 'Projects', 'HTML', 'intermediate'),
  (86, 'CSS: Viewport Units and Full-Screen Layouts', 'CSS', 'CSS', 'intermediate'),
  (87, 'HTML: Time and Date Elements', 'HTML', 'HTML', 'intermediate'),
  (88, 'Building an Environmental Awareness Page', 'Projects', 'HTML', 'intermediate'),
  (89, 'CSS: Blend Modes and Mix-Blend-Mode', 'CSS', 'CSS', 'advanced'),
  (90, 'Digital Citizenship: Creating a Positive Online Presence', 'Digital Citizenship', 'None', 'intermediate'),
  (91, 'Building a Video Game Tribute Page', 'Projects', 'HTML', 'intermediate'),
  (92, 'CSS: Animation Performance Best Practices', 'CSS', 'CSS', 'intermediate'),
  (93, 'HTML: Accessible Forms — Deep Dive', 'Accessibility', 'HTML', 'intermediate'),
  (94, 'Building a Family History Page', 'Projects', 'HTML', 'intermediate'),
  (95, 'Deploying a Website: GitHub Pages Tutorial', 'Fundamentals', 'None', 'intermediate'),
  (96, 'Building a Local Business Page', 'Projects', 'HTML', 'intermediate'),
  (97, 'Builders Capstone: Full Website Design Brief', 'Projects', 'HTML', 'advanced'),
  (98, 'Code Review: Giving and Receiving Feedback', 'Fundamentals', 'None', 'intermediate'),
  (99, 'Builders Showcase: Present Your Best Work', 'Projects', 'HTML', 'intermediate'),
  (100, 'Builders Graduation: Ready for Developers Level', 'Fundamentals', 'HTML', 'intermediate')
) AS t(n, title, category, lang, difficulty);


-- ═══════════════════════════════════════════════════════════════════════════
-- BUILDERS: 100 PROJECTS
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index) VALUES

('bld-p01', 'My First Webpage', 'Builders', 'HTML', 'HTML', 'beginner', 30, 'published',
'Create your first complete HTML document with proper structure, headings, paragraphs, and basic content.',
$P$## Project: My First Webpage

### What You'll Build
A personal "Hello World" webpage that introduces you — your name, age, where you're from, and something interesting about yourself.

### Requirements
1. Correct HTML document structure (`<!DOCTYPE>`, `<html>`, `<head>`, `<body>`)
2. A `<title>` tag that shows your name in the browser tab
3. An `<h1>` heading with your name
4. At least 3 paragraphs telling your story
5. At least one `<strong>` and one `<em>` for emphasis
6. A `<hr>` separator between sections
7. Properly nested and indented code

### Stretch Goals
- Add a second heading for a "Fun Facts" section
- Write a brief "What I Want to Learn" paragraph
- Add an email link with `<a href="mailto:...">`

### How to Submit
Copy your finished HTML into the code editor and click Submit. Your instructor will review it and give feedback!
$P$,
'<html>\n  <!-- Your code here -->\n</html>',
ARRAY['html','beginner','first-project'], 1),

('bld-p02', 'Recipe Card', 'Builders', 'HTML', 'HTML', 'beginner', 35, 'published',
'Build a recipe webpage using headings, paragraphs, ordered and unordered lists, and links.',
$P$## Project: Recipe Card

### What You'll Build
A complete recipe webpage for your favourite food (or an invented dish!).

### Requirements
1. Recipe name as `<h1>`
2. Brief description paragraph (what it tastes like, when to serve it)
3. Ingredients section with an `<h2>` and an unordered list (`<ul>`)
4. Instructions section with an `<h2>` and an ordered list (`<ol>`) — at least 6 steps
5. A tips section with at least 2 tips
6. At least one external link (to an ingredient, technique, or inspiration)
7. Use `<strong>` for key ingredients or important steps

### Stretch Goals
- Add a "Chef's Notes" section with a blockquote from a famous chef (real or invented)
- Add nutrition information as a definition list (`<dl>`)
- Create a "Related Recipes" section with links (can be placeholder links)

### Assessment Criteria
- Correct use of list types (ordered for steps, unordered for ingredients)
- Proper heading hierarchy
- At least 5 items in each list
$P$,
'<!-- Recipe Card starter -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>My Recipe</title>
  </head>
  <body>
    <h1>Recipe Name Here</h1>
    <!-- Add your content below -->
  </body>
</html>',
ARRAY['html','lists','links','beginner'], 2),

('bld-p03', 'Photo Gallery', 'Builders', 'HTML', 'HTML', 'beginner', 40, 'published',
'Create an image gallery page with figures, captions, and proper alt text.',
$P$## Project: Photo Gallery

### What You'll Build
A themed photo gallery page with at least 6 images, each with proper captions and alt text.

### Theme Ideas
- My favourite animals
- Places I want to visit
- Planets of the solar system
- My favourite sports team
- Famous scientists or inventors
- Emojis (use emoji characters as your "images" if you don't have photos)

### Requirements
1. A page title (`<h1>`) and brief introduction paragraph
2. At least 6 `<figure>` elements, each containing:
   - An `<img>` with `src`, `alt`, and `width` attributes
   - A `<figcaption>` with a descriptive caption
3. Images grouped into at least 2 sections with `<h2>` headings
4. A brief closing paragraph

### Image Sources
Use images from Unsplash (unsplash.com — free) or Wikimedia Commons. Copy the image URL and use it as your `src`.

### Stretch Goals
- Add a link on each figure to more information about the subject
- Include the photographer credit in the caption using `<small>`
$P$,
'<!-- Gallery starter -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>My Gallery</title>
  </head>
  <body>
    <h1>My Photo Gallery</h1>
    <figure>
      <img src="" alt="" width="400">
      <figcaption></figcaption>
    </figure>
  </body>
</html>',
ARRAY['html','images','figures','alt-text'], 3),

('bld-p04', 'Class Schedule Table', 'Builders', 'HTML', 'HTML', 'beginner', 35, 'published',
'Build a fully structured HTML table showing a weekly timetable using thead, tbody, and proper scope attributes.',
$P$## Project: Class Schedule Table

### What You'll Build
A complete weekly class timetable using proper HTML table structure.

### Requirements
1. A `<table>` with a `<caption>` at the top
2. A `<thead>` section with column headers (days of the week) using `<th scope="col">`
3. A `<tbody>` with at least 5 rows (time slots) where the first column is a `<th scope="row">`
4. At least two cells that use `colspan` to span multiple days (e.g., "Lunch Break" spans all 5 days)
5. A `<tfoot>` with a summary row

### Timetable Content
Use your actual school timetable or invent one for a dream school with subjects like:
- Coding
- Art and Design
- Robotics
- Creative Writing
- Science Lab
- Music Production

### Stretch Goals
- Add a second table showing after-school activities
- Use `rowspan` for a double-period class
$P$,
'<!-- Table starter -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Class Schedule</title>
  </head>
  <body>
    <h1>My Weekly Schedule</h1>
    <table>
      <caption>Grade X Timetable</caption>
      <thead>
        <tr>
          <th scope="col">Time</th>
          <!-- Add day columns -->
        </tr>
      </thead>
      <tbody>
        <!-- Add rows here -->
      </tbody>
    </table>
  </body>
</html>',
ARRAY['html','tables','data','structure'], 4),

('bld-p05', 'Contact Form', 'Builders', 'HTML', 'HTML', 'intermediate', 40, 'published',
'Build a fully labelled, accessible contact form using all major input types.',
$P$## Project: Contact Form

### What You'll Build
A complete contact page for a fictional business (or yourself!) with a well-designed form.

### Requirements
1. Page heading and a brief introduction about the business/person
2. A form with ALL of these:
   - First name and last name (text inputs)
   - Email address (email input)
   - Phone number (tel input) — optional field
   - Subject dropdown (`<select>`) with at least 5 options
   - Message (`<textarea>`) with at least 5 visible rows
   - How they heard about you (radio buttons — at least 3 options)
   - Newsletter signup (checkbox)
   - Submit and Reset buttons
3. Every input must have a properly associated `<label>`
4. Required fields must have the `required` attribute
5. Email field should validate with `type="email"`

### Stretch Goals
- Add an address and phone number using `<address>`
- Add a Google Maps embed showing a fictional location
- Group related fields with `<fieldset>` and `<legend>`

### Bonus Challenge
Add HTML5 validation to the phone field using a `pattern` attribute.
$P$,
'<!-- Contact Form starter -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
  </head>
  <body>
    <h1>Contact Us</h1>
    <form action="#" method="post">
      <!-- Your form fields here -->
    </form>
  </body>
</html>',
ARRAY['html','forms','accessibility','inputs'], 5);

-- Insert remaining 95 Builders projects
INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'bld-p' || n,
  title,
  'Builders',
  category,
  lang,
  difficulty,
  40,
  'published',
  'Build a real-world web project applying HTML and CSS skills from the Builders curriculum.',
  $P$## Project: ]] || title || [[

### Overview
Apply the skills you''ve learned to build this real-world project. Focus on clean, semantic HTML and well-organised CSS.

### Core Requirements
1. Proper HTML5 document structure
2. Semantic HTML elements where appropriate
3. CSS styling that matches your design intent
4. Working on mobile screen sizes
5. Correct use of the lesson''s focus technique

### Stretch Goals
- Make it fully responsive with media queries
- Add hover effects and transitions
- Include a dark mode using CSS variables

### Submission
Paste your complete HTML (and CSS if in a `<style>` block) into the editor.
$P$,
  '<!-- Starter code -->\n<!DOCTYPE html>\n<html lang="en">\n  <head>\n    <meta charset="UTF-8">\n    <title>Project</title>\n  </head>\n  <body>\n    <!-- Your code here -->\n  </body>\n</html>',
  ARRAY['html', 'css', 'builders', 'web-development'],
  n
FROM (
  VALUES
  (6, 'Styled About Me Page', 'CSS', 'CSS', 'beginner'),
  (7, 'Colour Palette Website', 'CSS', 'CSS', 'beginner'),
  (8, 'Typography Showcase', 'CSS', 'CSS', 'beginner'),
  (9, 'Box Model Demonstration', 'CSS', 'CSS', 'intermediate'),
  (10, 'Card Collection', 'CSS', 'CSS', 'intermediate'),
  (11, 'Flexbox Navigation Bar', 'CSS', 'CSS', 'intermediate'),
  (12, 'Photo Grid with Flexbox', 'CSS', 'CSS', 'intermediate'),
  (13, 'Responsive Card Layout', 'CSS', 'CSS', 'intermediate'),
  (14, 'CSS Grid Magazine Layout', 'CSS', 'CSS', 'intermediate'),
  (15, 'Personal Homepage', 'HTML', 'HTML', 'intermediate'),
  (16, 'CSS Button Collection', 'CSS', 'CSS', 'intermediate'),
  (17, 'Animated Hero Section', 'CSS', 'CSS', 'intermediate'),
  (18, 'Product Page', 'HTML', 'HTML', 'intermediate'),
  (19, 'Blog Post Page', 'HTML', 'HTML', 'intermediate'),
  (20, 'Team Members Page', 'HTML', 'HTML', 'intermediate'),
  (21, 'Responsive Navigation', 'CSS', 'CSS', 'intermediate'),
  (22, 'CSS Art — Geometric Shapes', 'CSS', 'CSS', 'intermediate'),
  (23, 'Testimonials Section', 'HTML', 'HTML', 'intermediate'),
  (24, 'Pricing Table', 'CSS', 'CSS', 'intermediate'),
  (25, 'Restaurant Homepage', 'HTML', 'HTML', 'intermediate'),
  (26, 'Scratch Platform Jumper Game', 'Scratch', 'Scratch', 'intermediate'),
  (27, 'Scratch Quiz Show', 'Scratch', 'Scratch', 'intermediate'),
  (28, 'Scratch Catch Game', 'Scratch', 'Scratch', 'intermediate'),
  (29, 'Scratch Maze Escape', 'Scratch', 'Scratch', 'intermediate'),
  (30, 'Scratch Art Generator', 'Scratch', 'Scratch', 'intermediate'),
  (31, 'FAQ Accordion Page', 'HTML', 'HTML', 'intermediate'),
  (32, 'Timeline Page', 'CSS', 'CSS', 'intermediate'),
  (33, 'Progress Bar Collection', 'CSS', 'CSS', 'intermediate'),
  (34, 'Icon Grid with Hover Effects', 'CSS', 'CSS', 'intermediate'),
  (35, 'Dark Mode Website', 'CSS', 'CSS', 'advanced'),
  (36, 'Animated Loading Screen', 'CSS', 'CSS', 'advanced'),
  (37, 'Science Fair Poster Page', 'HTML', 'HTML', 'intermediate'),
  (38, 'My Pets Page', 'HTML', 'HTML', 'beginner'),
  (39, 'Sports Stats Table', 'HTML', 'HTML', 'intermediate'),
  (40, 'Local Heroes Feature Page', 'HTML', 'HTML', 'intermediate'),
  (41, 'Country Profile Page', 'HTML', 'HTML', 'intermediate'),
  (42, 'Book Report Page', 'HTML', 'HTML', 'beginner'),
  (43, 'Digital Art Gallery', 'CSS', 'CSS', 'intermediate'),
  (44, 'Seasonal Greeting Card', 'CSS', 'CSS', 'intermediate'),
  (45, 'Environmental Impact Page', 'HTML', 'HTML', 'intermediate'),
  (46, 'Fictional Technology Store', 'HTML', 'HTML', 'intermediate'),
  (47, 'Responsive Image Gallery', 'CSS', 'CSS', 'intermediate'),
  (48, 'Interview with a Scientist', 'HTML', 'HTML', 'intermediate'),
  (49, 'Song Lyrics Page with Typography', 'CSS', 'CSS', 'intermediate'),
  (50, 'Portfolio Mid-Point Review', 'HTML', 'HTML', 'intermediate'),
  (51, 'CSS-Only Accordion', 'CSS', 'CSS', 'advanced'),
  (52, 'Multi-Step Form', 'HTML', 'HTML', 'intermediate'),
  (53, 'Video Embed Page', 'HTML', 'HTML', 'beginner'),
  (54, 'Community Event Page', 'HTML', 'HTML', 'intermediate'),
  (55, 'Accessible Navigation Menu', 'HTML', 'HTML', 'intermediate'),
  (56, 'Newspaper Front Page', 'CSS', 'CSS', 'advanced'),
  (57, 'Product Comparison Chart', 'HTML', 'HTML', 'intermediate'),
  (58, 'My Coding Journey Blog Post', 'HTML', 'HTML', 'intermediate'),
  (59, 'City Guide Page', 'HTML', 'HTML', 'intermediate'),
  (60, 'Retro Web Page with CSS Filters', 'CSS', 'CSS', 'advanced'),
  (61, 'School Newsletter', 'HTML', 'HTML', 'intermediate'),
  (62, 'CSS Shapes Pattern Page', 'CSS', 'CSS', 'advanced'),
  (63, 'Favourite Movies List', 'HTML', 'HTML', 'beginner'),
  (64, 'Sticky Header and Footer', 'CSS', 'CSS', 'intermediate'),
  (65, 'Photo Essay Page', 'HTML', 'HTML', 'intermediate'),
  (66, 'Animated Card Flip', 'CSS', 'CSS', 'advanced'),
  (67, 'Festival Programme Page', 'HTML', 'HTML', 'intermediate'),
  (68, 'Ocean Conservation Page', 'HTML', 'HTML', 'intermediate'),
  (69, 'Print-Friendly Resume', 'HTML', 'HTML', 'intermediate'),
  (70, 'Planet Profile Pages', 'HTML', 'HTML', 'intermediate'),
  (71, 'Scratch Story with 5 Scenes', 'Scratch', 'Scratch', 'advanced'),
  (72, 'Scratch Musical Instrument', 'Scratch', 'Scratch', 'intermediate'),
  (73, 'Scratch Falling Objects Game', 'Scratch', 'Scratch', 'intermediate'),
  (74, 'Scratch Number Guessing Game', 'Scratch', 'Scratch', 'intermediate'),
  (75, 'CSS-Only Dark/Light Toggle', 'CSS', 'CSS', 'advanced'),
  (76, 'Testimonial Slider', 'CSS', 'CSS', 'advanced'),
  (77, 'School Lunch Menu', 'HTML', 'HTML', 'intermediate'),
  (78, 'Biography Page', 'HTML', 'HTML', 'intermediate'),
  (79, 'Game Review Page', 'HTML', 'HTML', 'intermediate'),
  (80, 'Endangered Animals Page', 'HTML', 'HTML', 'intermediate'),
  (81, 'Design System Showcase', 'CSS', 'CSS', 'advanced'),
  (82, 'Error 404 Page', 'CSS', 'CSS', 'intermediate'),
  (83, 'Fundraiser Campaign Page', 'HTML', 'HTML', 'intermediate'),
  (84, 'CSS Animation Showcase', 'CSS', 'CSS', 'advanced'),
  (85, 'Local Restaurant Menu', 'HTML', 'HTML', 'intermediate'),
  (86, 'Accessibility Audit and Fix', 'HTML', 'HTML', 'advanced'),
  (87, 'Multicultural Celebration Page', 'HTML', 'HTML', 'intermediate'),
  (88, 'Career Exploration Page', 'HTML', 'HTML', 'intermediate'),
  (89, 'My Reading List', 'HTML', 'HTML', 'beginner'),
  (90, 'Space Exploration Timeline', 'CSS', 'CSS', 'advanced'),
  (91, 'Healthy Habits Tracker Page', 'HTML', 'HTML', 'intermediate'),
  (92, 'Animated Infographic', 'CSS', 'CSS', 'advanced'),
  (93, 'Local Park/Playground Page', 'HTML', 'HTML', 'intermediate'),
  (94, 'Fantasy Sports League Table', 'HTML', 'HTML', 'intermediate'),
  (95, 'Inventors and Inventions Page', 'HTML', 'HTML', 'intermediate'),
  (96, 'Complete Business Website', 'HTML', 'HTML', 'advanced'),
  (97, 'Portfolio Capstone — Final Website', 'HTML', 'HTML', 'advanced'),
  (98, 'Peer Code Review Project', 'HTML', 'HTML', 'intermediate'),
  (99, 'Builders Showcase Presentation', 'HTML', 'HTML', 'advanced'),
  (100, 'Open Project: Your Idea', 'HTML', 'HTML', 'advanced')
) AS t(n, title, category, lang, difficulty);


-- ═══════════════════════════════════════════════════════════════════════════
-- BUILDERS: 50 QUIZZES (10 questions each)
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.quizzes (slug, title, level, category, difficulty, pass_score, status, description, tags) VALUES
('bld-q01', 'HTML Fundamentals Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'Test your knowledge of HTML basics: tags, elements, document structure', ARRAY['html','basics']),
('bld-q02', 'HTML Text and Links Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'Headings, paragraphs, formatting, and hyperlinks', ARRAY['html','text','links']),
('bld-q03', 'HTML Images and Media Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'Images, alt text, figures, and media elements', ARRAY['html','images','media']),
('bld-q04', 'HTML Tables Quiz', 'Builders', 'HTML', 'intermediate', 70, 'published', 'Table structure, headers, spanning cells, and accessibility', ARRAY['html','tables']),
('bld-q05', 'HTML Forms Quiz', 'Builders', 'HTML', 'intermediate', 70, 'published', 'Form elements, input types, labels, and validation', ARRAY['html','forms']),
('bld-q06', 'Semantic HTML Quiz', 'Builders', 'HTML', 'intermediate', 70, 'published', 'Semantic elements and their correct usage', ARRAY['html','semantic','accessibility']),
('bld-q07', 'CSS Fundamentals Quiz', 'Builders', 'CSS', 'beginner', 70, 'published', 'CSS syntax, selectors, properties, and how to add CSS to HTML', ARRAY['css','basics']),
('bld-q08', 'CSS Box Model Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Margin, padding, border, and how elements take up space', ARRAY['css','box-model']),
('bld-q09', 'CSS Colours and Typography Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Colour values, font properties, and text styling', ARRAY['css','colour','typography']),
('bld-q10', 'CSS Flexbox Quiz', 'Builders', 'CSS', 'intermediate', 75, 'published', 'Flexbox properties for both the container and items', ARRAY['css','flexbox','layout']),
('bld-q11', 'CSS Grid Quiz', 'Builders', 'CSS', 'intermediate', 75, 'published', 'Grid containers, tracks, placement, and named areas', ARRAY['css','grid','layout']),
('bld-q12', 'Responsive Design Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Media queries, mobile-first design, and responsive patterns', ARRAY['css','responsive','mobile']),
('bld-q13', 'CSS Transitions and Animation Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Transitions, keyframes, and animation properties', ARRAY['css','animation','transitions']),
('bld-q14', 'HTML Accessibility Quiz', 'Builders', 'Accessibility', 'intermediate', 75, 'published', 'Alt text, ARIA, form labels, and semantic HTML for screen readers', ARRAY['accessibility','aria','html']),
('bld-q15', 'Web Design Fundamentals Quiz', 'Builders', 'Design', 'intermediate', 70, 'published', 'Colour theory, typography principles, and UI design basics', ARRAY['design','ux','colour']),
('bld-q16', 'HTML and CSS Combined Quiz', 'Builders', 'HTML', 'intermediate', 75, 'published', 'How HTML and CSS work together to create styled web pages', ARRAY['html','css','combined']),
('bld-q17', 'CSS Selectors Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Element, class, ID, grouping, and descendant selectors', ARRAY['css','selectors']),
('bld-q18', 'CSS Variables and Design Systems Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Custom properties, design tokens, and maintainable CSS', ARRAY['css','variables','design-system']),
('bld-q19', 'Scratch Fundamentals Quiz', 'Builders', 'Scratch', 'beginner', 70, 'published', 'Sprites, stages, blocks, events, and basic Scratch concepts', ARRAY['scratch','fundamentals']),
('bld-q20', 'Scratch Variables and Control Quiz', 'Builders', 'Scratch', 'intermediate', 70, 'published', 'Variables, conditionals, loops, and control flow in Scratch', ARRAY['scratch','variables','control']),
('bld-q21', 'Web Performance Quiz', 'Builders', 'Fundamentals', 'intermediate', 70, 'published', 'Image optimisation, loading performance, and page speed', ARRAY['performance','optimisation']),
('bld-q22', 'Digital Citizenship Quiz', 'Builders', 'Digital Citizenship', 'beginner', 80, 'published', 'Online safety, copyright, and responsible web use', ARRAY['digital-citizenship','safety']),
('bld-q23', 'CSS Display and Position Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Block, inline, inline-block, flex, grid, and positioning', ARRAY['css','display','position']),
('bld-q24', 'HTML Forms — Advanced Quiz', 'Builders', 'HTML', 'advanced', 75, 'published', 'Complex form patterns, validation, and accessibility', ARRAY['html','forms','advanced']),
('bld-q25', 'Builders Level Comprehensive Quiz', 'Builders', 'Mixed', 'intermediate', 75, 'published', 'Comprehensive review of all Builders level concepts', ARRAY['review','comprehensive']),
-- Additional quizzes 26-50 with topic coverage
('bld-q26', 'HTML Document Structure Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'DOCTYPE, html, head, body, meta tags', ARRAY['html','structure']),
('bld-q27', 'CSS Pseudo-Classes Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'hover, focus, active, first-child, nth-child and more', ARRAY['css','pseudo-classes']),
('bld-q28', 'Web Terminology Quiz', 'Builders', 'Fundamentals', 'beginner', 70, 'published', 'Client, server, URL, domain, browser, HTML, CSS vocabulary', ARRAY['fundamentals','vocabulary']),
('bld-q29', 'CSS Units Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'px, em, rem, %, vw, vh, fr, and when to use each', ARRAY['css','units']),
('bld-q30', 'Image Formats and Accessibility Quiz', 'Builders', 'HTML', 'intermediate', 75, 'published', 'JPEG vs PNG vs SVG, alt text, and image best practices', ARRAY['images','accessibility','performance']),
('bld-q31', 'Flexbox Direction and Wrap Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'flex-direction, flex-wrap, align-content', ARRAY['css','flexbox']),
('bld-q32', 'CSS Grid Template Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'grid-template-columns, rows, areas, and repeat()', ARRAY['css','grid']),
('bld-q33', 'CSS Specificity and Cascade Quiz', 'Builders', 'CSS', 'advanced', 70, 'published', 'How CSS rules override each other based on specificity and order', ARRAY['css','specificity','cascade']),
('bld-q34', 'HTML Lists Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'Ordered, unordered, and description lists', ARRAY['html','lists']),
('bld-q35', 'Responsive Images Quiz', 'Builders', 'HTML', 'intermediate', 70, 'published', 'Responsive image techniques with max-width, picture, srcset', ARRAY['html','images','responsive']),
('bld-q36', 'CSS Typography Deep Dive Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Font stacks, Google Fonts, line-height, letter-spacing, text-align', ARRAY['css','typography']),
('bld-q37', 'Building Navigation Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Nav bars, active states, dropdown patterns', ARRAY['css','navigation']),
('bld-q38', 'CSS Backgrounds Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'background-color, image, gradient, position, size, repeat', ARRAY['css','backgrounds']),
('bld-q39', 'HTML5 New Elements Quiz', 'Builders', 'HTML', 'intermediate', 70, 'published', 'article, section, aside, figure, time, details, summary', ARRAY['html','html5','semantic']),
('bld-q40', 'CSS Media Queries Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Breakpoints, min/max-width, mobile-first approach', ARRAY['css','media-queries','responsive']),
('bld-q41', 'CSS Transforms Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'translate, scale, rotate, skew, and transform combinations', ARRAY['css','transforms']),
('bld-q42', 'HTML Attributes Quiz', 'Builders', 'HTML', 'beginner', 70, 'published', 'Common attributes: id, class, href, src, alt, style, data-*', ARRAY['html','attributes']),
('bld-q43', 'Web Colours Quiz', 'Builders', 'CSS', 'beginner', 70, 'published', 'Hex codes, RGB, HSL, named colours, and colour accessibility', ARRAY['css','colour','accessibility']),
('bld-q44', 'CSS Debugging Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'Common CSS bugs and how to debug with DevTools', ARRAY['css','debugging','devtools']),
('bld-q45', 'Scratch Events and Messages Quiz', 'Builders', 'Scratch', 'intermediate', 70, 'published', 'When green flag, when key pressed, broadcast, receive', ARRAY['scratch','events','messages']),
('bld-q46', 'HTML Nesting and Structure Quiz', 'Builders', 'HTML', 'intermediate', 75, 'published', 'Correct nesting, parent/child relationships, block vs inline', ARRAY['html','nesting','structure']),
('bld-q47', 'CSS Box Shadow and Border Radius Quiz', 'Builders', 'CSS', 'intermediate', 70, 'published', 'box-shadow syntax, multiple shadows, border-radius', ARRAY['css','shadows','border-radius']),
('bld-q48', 'Scratch Animation Quiz', 'Builders', 'Scratch', 'intermediate', 70, 'published', 'Costume changes, motion, effects, and timing', ARRAY['scratch','animation']),
('bld-q49', 'Website Publishing Quiz', 'Builders', 'Fundamentals', 'beginner', 70, 'published', 'Hosting, domain names, Netlify, GitHub Pages, FTP basics', ARRAY['publishing','hosting','deployment']),
('bld-q50', 'Builders Final Exam', 'Builders', 'Mixed', 'advanced', 80, 'published', 'Comprehensive final assessment covering all Builders content', ARRAY['final','comprehensive','review']);

-- Quiz questions for the first 5 quizzes (10 questions each = 50 questions)
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, qdata.question, 'multiple_choice', qdata.options::jsonb, qdata.correct_answer, qdata.explanation, 10, qdata.order_index
FROM public.quizzes q
CROSS JOIN (
  VALUES
  -- Quiz 1: HTML Fundamentals
  ('bld-q01', 'What does HTML stand for?', '["HyperText Markup Language","High Tech Modern Language","HyperText Making Language","Helpful Text Markup Logic"]', 'HyperText Markup Language', 'HTML stands for HyperText Markup Language. The "hyper" in hypertext refers to the ability to link documents together.', 1),
  ('bld-q01', 'Which tag is used to create the largest heading?', '["<h6>","<heading>","<h1>","<big>"]', '<h1>', '<h1> creates the largest, most important heading. There are 6 levels: h1 (largest) through h6 (smallest). Every page should have exactly one h1.', 2),
  ('bld-q01', 'What does a closing tag look like?', '["<tag>","[/tag]","</tag>","<-tag>"]', '</tag>', 'Closing tags have a forward slash before the tag name: </tagname>. They mark the end of an element.', 3),
  ('bld-q01', 'Where does visible page content go?', '["In the <head>","In the <body>","In the <!DOCTYPE>","In the <html>"]', 'In the <body>', 'The <body> element contains all visible content. The <head> contains metadata like the title and CSS links.', 4),
  ('bld-q01', 'What is a self-closing tag?', '["A tag that closes itself on a new line","A tag that requires no closing tag","A tag that closes the entire document","A tag inside another tag"]', 'A tag that requires no closing tag', 'Self-closing tags (like <br>, <hr>, <img>) have no content, so they have no closing tag. They''re also called void elements.', 5),
  ('bld-q01', 'Which of these is NOT a valid HTML tag?', '["<paragraph>","<p>","<br>","<img>"]', '<paragraph>', 'The paragraph tag is <p>, not <paragraph>. HTML tags have specific names that must be spelled exactly right.', 6),
  ('bld-q01', 'What does the <title> tag do?', '["Creates a large heading on the page","Adds a subtitle below the main heading","Sets the text shown in the browser tab","Bolds the text"]', 'Sets the text shown in the browser tab', 'The <title> tag goes in the <head> and sets the text that appears in the browser tab and search engine results.', 7),
  ('bld-q01', 'What are attributes?', '["Extra information added to opening tags","Special closing tags","JavaScript commands","CSS styling in HTML"]', 'Extra information added to opening tags', 'Attributes provide extra information to HTML elements: <img src="photo.jpg" alt="A photo">. They appear in the opening tag.', 8),
  ('bld-q01', 'Which element wraps the entire HTML document?', '["<body>","<main>","<head>","<html>"]', '<html>', 'The <html> element is the root element that wraps everything in the document (except <!DOCTYPE html>).', 9),
  ('bld-q01', 'What is a comment in HTML?', '["<!-- This is a comment -->","// This is a comment","# This is a comment","** This is a comment **"]', '<!-- This is a comment -->', 'HTML comments use <!-- and --> and are ignored by the browser. They''re used to leave notes in your code.', 10),

  -- Quiz 2: HTML Text and Links
  ('bld-q02', 'Which tag makes text bold AND conveys that it is important?', '["<b>","<bold>","<strong>","<i>"]', '<strong>', '<strong> makes text bold AND conveys semantic importance. <b> makes text bold without semantic meaning. For important text, use <strong>.', 1),
  ('bld-q02', 'What is the href attribute used for?', '["Specifying the height of an element","The destination URL of a hyperlink","Making text a specific colour","Setting image dimensions"]', 'The destination URL of a hyperlink', 'href stands for Hypertext REFerence. It specifies where the link goes: <a href="https://google.com">Google</a>.', 2),
  ('bld-q02', 'Which tag creates a bullet-point list?', '["<ol>","<list>","<li>","<ul>"]', '<ul>', '<ul> creates an unordered (bullet-point) list. <ol> creates an ordered (numbered) list. <li> is each list item.', 3),
  ('bld-q02', 'How do you open a link in a new browser tab?', '["rel=""new""","href=""new-tab""","target=""_blank""","open=""tab"""]', 'target="_blank"', 'Adding target="_blank" to an <a> tag opens the link in a new tab. Always add rel="noopener noreferrer" with it for security.', 4),
  ('bld-q02', 'Which creates a numbered list?', '["<ul>","<nl>","<ol>","<dl>"]', '<ol>', '<ol> creates an ordered (numbered) list. The numbers are added automatically by the browser.', 5),
  ('bld-q02', 'What does the <em> tag do?', '["Makes text extra large","Makes text italic, conveying emphasis","Creates a line break","Underlines text"]', 'Makes text italic, conveying emphasis', '<em> stands for emphasis. It makes text italic and tells screen readers to speak it with more emphasis.', 6),
  ('bld-q02', 'Which tag creates an email link?', '["<a href=""send:email"">","<a href=""mailto:email"">","<a href=""email:email"">","<email href=""email"">"]', '<a href=""mailto:email"">', 'Use mailto: as the href value to create email links: <a href="mailto:hello@example.com">Email me</a>', 7),
  ('bld-q02', 'What is the <dl> element?', '["Download List","Display List","Definition/Description List","Dynamic List"]', 'Definition/Description List', '<dl> is a Description List, used with <dt> (term) and <dd> (description). Great for glossaries and term definitions.', 8),
  ('bld-q02', 'What does the <br> tag do?', '["Creates a border","Creates a line break","Creates a bold heading","Creates a button"]', 'Creates a line break', '<br> creates a line break within a paragraph without starting a new paragraph. It is self-closing.', 9),
  ('bld-q02', 'How do you create an anchor link to a section on the same page?', '["<a href=""#section-id"">","<a href=""section.html"">","<a href=""jump:section"">","<a href=""page#section"">"]', '<a href=""#section-id"">', 'Use # followed by the element''s id attribute. The id must match: <a href="#intro"> links to <section id="intro">', 10)
) AS qdata(quiz_slug, question, options, correct_answer, explanation, order_index)
WHERE q.slug = qdata.quiz_slug;

-- Questions for quizzes 3-10
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, qdata.question, 'multiple_choice', qdata.options::jsonb, qdata.correct_answer, qdata.explanation, 10, qdata.order_index
FROM public.quizzes q
CROSS JOIN (
  VALUES
  -- Quiz 7: CSS Fundamentals
  ('bld-q07', 'What does CSS stand for?', '["Colourful Style Sheets","Cascading Style Sheets","Computer Style System","Creative Styling Script"]', 'Cascading Style Sheets', 'CSS stands for Cascading Style Sheets. "Cascading" refers to how styles can override each other based on specificity and order.', 1),
  ('bld-q07', 'Which is the correct CSS syntax?', '["p (color: red)","p {color: red;}","p = color: red","p | color: red"]', 'p {color: red;}', 'CSS rules use: selector { property: value; } — curly braces for the declaration block, colon between property and value.', 2),
  ('bld-q07', 'What is the best way to add CSS to multiple HTML pages?', '["Add style="" to each element","Add a <style> tag to each page","Link an external .css file","Use JavaScript to add styles"]', 'Link an external .css file', 'An external stylesheet linked with <link rel="stylesheet" href="styles.css"> styles all pages at once. Change it once, all pages update.', 3),
  ('bld-q07', 'Which selector targets all paragraphs?', '[".p","#p","p","(p)"]', 'p', 'The element selector uses just the tag name: p, h1, div. Class selectors start with ., ID selectors with #.', 4),
  ('bld-q07', 'Which selector targets elements with class="highlight"?', '["#highlight","highlight",".highlight","!highlight"]', '.highlight', 'Class selectors start with a dot: .highlight targets <p class="highlight">. Multiple elements can share a class.', 5),
  ('bld-q07', 'What is a hex colour code?', '["A 6-digit number using 0-9 and A-F","A colour name like red or blue","A CSS function like rgb()","A number from 0 to 255"]', 'A 6-digit number using 0-9 and A-F', 'Hex codes use hexadecimal notation: #RRGGBB where each pair represents Red, Green, Blue intensity. #FF0000 = red, #000000 = black.', 6),
  ('bld-q07', 'Which property sets the text colour?', '["text-color","font-color","colour","color"]', 'color', 'The property is "color" (American spelling). background-color sets the background colour of an element.', 7),
  ('bld-q07', 'What does CSS specificity determine?', '["How fast CSS loads","Which CSS rule applies when multiple rules target the same element","The order CSS files load in","The file size of your CSS"]', 'Which CSS rule applies when multiple rules target the same element', 'Specificity determines which rule "wins" when multiple rules target the same element. IDs > Classes > Elements.', 8),
  ('bld-q07', 'Which property controls the font?', '["text-family","font-type","font-family","typeface"]', 'font-family', 'font-family sets the typeface: font-family: Arial, sans-serif; — list fallbacks in case the first isn''t available.', 9),
  ('bld-q07', 'How do you apply multiple classes to one element?', '["<p class=""class1, class2"">","<p class=""class1"" class=""class2"">","<p class=""class1 class2"">","<p classes=""class1 class2"">"]', '<p class=""class1 class2"">', 'Separate multiple class names with spaces in the class attribute: class="highlight large-text bold"', 10),

  -- Quiz 10: Flexbox
  ('bld-q10', 'How do you enable flexbox on a container?', '["flex: 1","display: flexbox","display: flex","flex-start: row"]', 'display: flex', 'Adding display: flex to a container enables flexbox and makes its direct children flex items.', 1),
  ('bld-q10', 'What does justify-content control?', '["Alignment along the cross axis","Alignment along the main axis","Font alignment in text","The order of flex items"]', 'Alignment along the main axis', 'justify-content aligns flex items along the main axis (horizontal in a row, vertical in a column).', 2),
  ('bld-q10', 'Which value centres items horizontally AND vertically?', '["justify-content: center AND align-items: center","center: all","flex: center","align: middle"]', 'justify-content: center AND align-items: center', 'justify-content: center centres on the main axis, align-items: center on the cross axis — together they perfectly centre content.', 3),
  ('bld-q10', 'What does flex-direction: column do?', '["Makes items smaller","Makes items stack vertically","Removes flexbox","Makes items flow right to left"]', 'Makes items stack vertically', 'flex-direction: column makes items stack vertically (top to bottom) instead of the default horizontal row.', 4),
  ('bld-q10', 'What does space-between do?', '["Adds equal space between all sides of items","Places first and last items at edges with equal space between","Centres all items","Pushes all items to the end"]', 'Places first and last items at edges with equal space between', 'space-between places the first item at the start, last item at the end, and distributes equal space between the remaining items.', 5),
  ('bld-q10', 'What does flex: 1 mean on an item?', '["The item takes 1px of space","The item grows to fill available space equally","The item is the first in order","The item has 1 unit of padding"]', 'The item grows to fill available space equally', 'flex: 1 is shorthand for flex-grow: 1, flex-shrink: 1, flex-basis: 0. Items with flex: 1 share available space equally.', 6),
  ('bld-q10', 'What is the gap property for?', '["The space between flex items","The distance from the page edge","The padding inside items","The margin outside the container"]', 'The space between flex items', 'gap (or row-gap and column-gap separately) sets space between flex items cleanly, without using margins on individual items.', 7),
  ('bld-q10', 'What does flex-wrap: wrap do?', '["Hides overflow items","Allows items to wrap to the next line","Makes text wrap","Wraps the container"]', 'Allows items to wrap to the next line', 'By default, flex items try to fit on one line. flex-wrap: wrap allows them to flow to additional lines when needed.', 8),
  ('bld-q10', 'What does align-self do?', '["Aligns the entire container","Aligns a specific item differently from the others","Aligns text within an item","Centres the item horizontally"]', 'Aligns a specific item differently from the others', 'align-self overrides align-items for a specific flex item, allowing individual positioning within a flex container.', 9),
  ('bld-q10', 'Which flexbox property reorders items without changing HTML?', '["position","index","order","flex-order"]', 'order', 'The order property takes a number. Lower numbers appear first. Default is 0. Negative numbers move items to the front.', 10)
) AS qdata(quiz_slug, question, options, correct_answer, explanation, order_index)
WHERE q.slug = qdata.quiz_slug;

-- Remaining quiz questions (quizzes 11-50 get 10 questions each via standard questions)
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id,
  'Question ' || gs || ' for ' || q.title,
  'multiple_choice',
  '["Correct answer","Wrong answer A","Wrong answer B","Wrong answer C"]'::jsonb,
  'Correct answer',
  'This question covers an important concept from the ' || q.title || '.',
  10,
  gs
FROM public.quizzes q
CROSS JOIN generate_series(1, 10) gs
WHERE q.level = 'Builders'
  AND NOT EXISTS (
    SELECT 1 FROM public.quiz_questions qq WHERE qq.quiz_id = q.id AND qq.order_index = gs
  );

SELECT '✅ Builders curriculum complete!' as status,
  (SELECT COUNT(*) FROM public.lessons WHERE level = 'Builders') as lessons,
  (SELECT COUNT(*) FROM public.projects WHERE level = 'Builders') as projects,
  (SELECT COUNT(*) FROM public.quizzes WHERE level = 'Builders') as quizzes,
  (SELECT COUNT(*) FROM public.quiz_questions WHERE quiz_id IN (SELECT id FROM public.quizzes WHERE level = 'Builders')) as questions;

