-- ─────────────────────────────────────────────────────────────────────────────
-- CODEship Academy — Complete Database Schema
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ─────────────────────────────────────────────────────────────────────────────

-- Enable extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";

-- ─── ENUMS ───────────────────────────────────────────────────────────────────

create type user_role as enum ('parent', 'teacher', 'student', 'admin');
create type content_status as enum ('draft', 'published', 'archived');
create type content_type as enum ('lesson', 'project', 'quiz');
create type difficulty as enum ('beginner', 'intermediate', 'advanced');
create type level_name as enum ('Explorers', 'Builders', 'Developers', 'Engineers');
create type session_status as enum ('not_started', 'in_progress', 'completed', 'skipped', 'needs_review');
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'unpaid');
create type plan_name as enum ('trial', 'monthly', 'annual', 'family', 'teacher');

-- ─── USERS ───────────────────────────────────────────────────────────────────

-- Extends Supabase auth.users
create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  full_name text,
  avatar_url text,
  role user_role not null default 'parent',
  email_verified boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.parent_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  phone text,
  timezone text default 'America/Toronto',
  notification_prefs jsonb default '{"email": true, "in_app": true, "weekly_report": true}'::jsonb,
  created_at timestamptz default now()
);

create table public.teacher_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  school_name text,
  classroom_name text,
  grade_range text,
  certification text,
  created_at timestamptz default now()
);

create table public.student_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete set null,
  parent_id uuid references public.users(id) on delete cascade,
  teacher_id uuid references public.users(id) on delete set null,
  full_name text not null,
  avatar_emoji text default '🧒',
  age integer,
  grade text,
  level level_name default 'Explorers',
  xp_points integer default 0,
  streak_days integer default 0,
  last_active_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ─── ASSESSMENTS ─────────────────────────────────────────────────────────────

create table public.assessments (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  completed_by uuid not null references public.users(id),
  age integer,
  grade text,
  experience text,
  skills jsonb,           -- {reading:4, writing:3, math:4, logic:3, focus:2, coding:2}
  interests text[],
  challenges text[],
  challenge_notes text,
  goals text[],
  learning_style text,
  created_at timestamptz default now()
);

create table public.learning_profiles (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  assessment_id uuid references public.assessments(id),
  recommended_level level_name,
  strengths text[],
  challenges text[],
  goals text[],
  recommended_mix jsonb,   -- {lessons:50, projects:30, quizzes:20}
  engagement_tips text[],
  weekly_pace text,
  summary text,
  ai_generated boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ─── CURRICULUM ──────────────────────────────────────────────────────────────

create table public.lessons (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text unique,
  level level_name not null,
  category text not null,
  language text,
  difficulty difficulty not null default 'beginner',
  duration_minutes integer not null default 30,
  status content_status default 'draft',
  objectives text[],
  instructions text,       -- Rich text / markdown
  starter_code text,
  solution_code text,
  tags text[],
  prerequisites uuid[],   -- lesson ids
  thumbnail_url text,
  video_url text,
  order_index integer default 0,
  created_by uuid references public.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.projects (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text unique,
  level level_name not null,
  languages text[],
  difficulty difficulty not null default 'beginner',
  duration_minutes integer not null default 60,
  status content_status default 'draft',
  description text,
  instructions text,
  expected_output text,
  starter_code text,
  solution_code text,
  tags text[],
  related_lessons uuid[],
  thumbnail_url text,
  order_index integer default 0,
  created_by uuid references public.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.quizzes (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  level level_name not null,
  topic text not null,
  difficulty difficulty not null default 'beginner',
  duration_minutes integer default 15,
  status content_status default 'draft',
  description text,
  pass_score integer default 70,
  tags text[],
  related_lessons uuid[],
  created_by uuid references public.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.quiz_questions (
  id uuid primary key default uuid_generate_v4(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question text not null,
  question_type text default 'multiple_choice',  -- multiple_choice, true_false, short_answer, code
  options jsonb,          -- [{id:"a", text:"..."}, ...]
  correct_answer text,
  explanation text,
  code_snippet text,
  order_index integer default 0,
  points integer default 1
);

-- ─── LEARNING PLANS ──────────────────────────────────────────────────────────

create table public.learning_plans (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  created_by uuid not null references public.users(id),
  title text not null,
  weekly_goal text,
  start_date date not null,
  end_date date,
  sessions_per_week integer default 3,
  session_duration integer default 30,
  focus_preference text default 'balanced',
  is_active boolean default true,
  ai_generated boolean default true,
  ai_tips text[],
  estimated_xp integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.scheduled_sessions (
  id uuid primary key default uuid_generate_v4(),
  plan_id uuid not null references public.learning_plans(id) on delete cascade,
  student_id uuid not null references public.student_profiles(id),
  content_type content_type not null,
  content_id uuid not null,
  content_title text not null,
  scheduled_date date not null,
  scheduled_time time,
  duration_minutes integer default 30,
  status session_status default 'not_started',
  xp_reward integer default 50,
  notes text,
  completed_at timestamptz,
  created_at timestamptz default now()
);

-- ─── PROGRESS & SUBMISSIONS ──────────────────────────────────────────────────

create table public.progress_records (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  content_type content_type not null,
  content_id uuid not null,
  content_title text,
  status session_status default 'not_started',
  score integer,           -- for quizzes, 0-100
  time_spent integer,      -- seconds
  attempts integer default 0,
  feedback text,
  xp_earned integer default 0,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.project_submissions (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  project_id uuid not null references public.projects(id),
  submission_type text default 'draft',   -- draft, final
  code text,
  notes text,
  file_urls text[],
  feedback text,
  grade text,
  graded_by uuid references public.users(id),
  submitted_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.quiz_attempts (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  quiz_id uuid not null references public.quizzes(id),
  answers jsonb,           -- {questionId: selectedAnswer}
  score integer,
  passed boolean,
  time_spent integer,
  completed_at timestamptz default now()
);

-- ─── ACHIEVEMENTS ────────────────────────────────────────────────────────────

create table public.achievements (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  description text,
  emoji text,
  xp_reward integer default 0,
  condition_type text,    -- streak, completions, score, first_time
  condition_value integer
);

create table public.student_achievements (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.student_profiles(id) on delete cascade,
  achievement_id uuid not null references public.achievements(id),
  earned_at timestamptz default now(),
  unique(student_id, achievement_id)
);

-- ─── SUBSCRIPTIONS & BILLING ─────────────────────────────────────────────────

create table public.subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  stripe_subscription_id text unique,
  stripe_customer_id text,
  plan plan_name not null default 'trial',
  status subscription_status not null default 'trialing',
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean default false,
  trial_end timestamptz,
  max_children integer default 1,
  max_students integer default 30,
  features jsonb default '{"ai_planner": false, "calendar_sync": false, "reports": false}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id),
  subscription_id uuid references public.subscriptions(id),
  stripe_payment_intent_id text,
  stripe_invoice_id text,
  amount integer,          -- in cents
  currency text default 'cad',
  status text,
  description text,
  invoice_url text,
  created_at timestamptz default now()
);

-- ─── NOTIFICATIONS ───────────────────────────────────────────────────────────

create table public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  type text not null,
  title text not null,
  message text,
  data jsonb,
  read boolean default false,
  created_at timestamptz default now()
);

-- ─── CALENDAR ────────────────────────────────────────────────────────────────

create table public.calendar_connections (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  provider text not null,   -- google, apple, ics
  access_token text,
  refresh_token text,
  calendar_id text,
  synced_at timestamptz,
  created_at timestamptz default now()
);

-- ─── ADMIN AUDIT LOGS ────────────────────────────────────────────────────────

create table public.admin_audit_logs (
  id uuid primary key default uuid_generate_v4(),
  actor_id uuid references public.users(id),
  actor_email text,
  action text not null,
  resource_type text,
  resource_id text,
  metadata jsonb,
  ip_address inet,
  created_at timestamptz default now()
);

-- ─── SEED: ACHIEVEMENTS ──────────────────────────────────────────────────────

insert into public.achievements (name, description, emoji, xp_reward, condition_type, condition_value) values
  ('First Code', 'Completed your very first lesson!', '🚀', 50, 'first_time', 1),
  ('Quiz Star', 'Scored 90%+ on a quiz', '⭐', 75, 'score', 90),
  ('Builder', 'Submitted your first project', '🔧', 100, 'first_time', 1),
  ('3-Day Streak', 'Learned 3 days in a row', '🔥', 50, 'streak', 3),
  ('10-Day Streak', 'Learning hero — 10 days straight!', '💪', 150, 'streak', 10),
  ('Speed Coder', 'Completed a lesson in under 20 minutes', '⚡', 60, 'first_time', 1),
  ('Perfect Score', 'Got 100% on a quiz', '🎯', 100, 'score', 100),
  ('Project Pro', 'Submitted 5 projects', '💻', 200, 'completions', 5),
  ('Lesson Legend', 'Completed 25 lessons', '📚', 250, 'completions', 25),
  ('Champion', 'Earned 500 XP', '🏆', 100, 'xp', 500);

-- ─── SEED: CURRICULUM (Lessons) ──────────────────────────────────────────────

insert into public.lessons (title, slug, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) values
  -- Explorers
  ('What is a Computer?', 'what-is-a-computer', 'Explorers', 'Fundamentals', 'None', 'beginner', 20, 'published',
    ARRAY['Understand what a computer is', 'Name the main parts of a computer', 'Explain what computers can do'],
    '# What is a Computer?\n\nA computer is a machine that can follow instructions to do many things...\n\n## Parts of a Computer\n- **Monitor** – the screen you look at\n- **Keyboard** – what you type on\n- **Mouse** – what you click with\n- **CPU** – the brain of the computer\n\n## What Can Computers Do?\nComputers can play games, help with homework, draw pictures, and talk to people far away!',
    ARRAY['fundamentals', 'no-code', 'beginner'], 1),

  ('Patterns and Sequences', 'patterns-and-sequences', 'Explorers', 'Algorithms', 'None', 'beginner', 25, 'published',
    ARRAY['Recognize patterns', 'Create simple sequences', 'Understand loops through patterns'],
    '# Patterns and Sequences\n\nPatterns are things that repeat in a predictable way...\n\n## Finding Patterns\nLook at this: 🔴🔵🔴🔵🔴🔵\nWhat comes next?\n\n## Why Patterns Matter in Coding\nComputers use patterns all the time! When we tell a computer to do something over and over, that''s called a **loop**.',
    ARRAY['algorithms', 'patterns', 'no-code'], 2),

  ('Introduction to Scratch', 'intro-to-scratch', 'Explorers', 'Block Coding', 'Scratch', 'beginner', 30, 'published',
    ARRAY['Open Scratch', 'Move a sprite', 'Make a sprite speak'],
    '# Introduction to Scratch\n\nScratch is a fun coding tool that uses **blocks** instead of typing!\n\n## Your First Program\n1. Go to scratch.mit.edu\n2. Click "Create"\n3. Find the "Motion" blocks (blue)\n4. Drag "move 10 steps" to the middle area\n5. Click the green flag!\n\nCongratulations — you just wrote code! 🎉',
    ARRAY['scratch', 'block-coding', 'beginner'], 3),

  -- Builders
  ('My First HTML Page', 'my-first-html-page', 'Builders', 'HTML', 'HTML', 'beginner', 30, 'published',
    ARRAY['Understand what HTML is', 'Write your first HTML tags', 'Create a heading and paragraph'],
    '# My First HTML Page\n\nHTML stands for **HyperText Markup Language**. It is the language of web pages!\n\n## Basic Structure\n```html\n<!DOCTYPE html>\n<html>\n  <head>\n    <title>My Page</title>\n  </head>\n  <body>\n    <h1>Hello World!</h1>\n    <p>This is my first webpage.</p>\n  </body>\n</html>\n```\n\n## Try It!\nType the code above and save it as `index.html`. Open it in your browser!',
    ARRAY['html', 'web', 'beginner'], 1),

  ('Styling with CSS', 'styling-with-css', 'Builders', 'CSS', 'CSS', 'beginner', 35, 'published',
    ARRAY['Add CSS to an HTML page', 'Change colors and fonts', 'Style elements'],
    '# Styling with CSS\n\nCSS stands for **Cascading Style Sheets**. It makes your pages look beautiful!\n\n## Adding CSS\n```css\nh1 {\n  color: blue;\n  font-size: 32px;\n}\n\np {\n  color: gray;\n  font-family: Arial;\n}\n```\n\n## Colors in CSS\nYou can use color names (`red`, `blue`), hex codes (`#FF0000`), or RGB values!',
    ARRAY['css', 'styling', 'web'], 2),

  ('HTML Links and Images', 'html-links-images', 'Builders', 'HTML', 'HTML', 'beginner', 30, 'published',
    ARRAY['Add links to pages', 'Insert images', 'Use the img and a tags'],
    '# Links and Images\n\n## Adding a Link\n```html\n<a href="https://google.com">Click here!</a>\n```\n\n## Adding an Image\n```html\n<img src="cat.jpg" alt="A cute cat" width="300">\n```\n\nThe `alt` text describes the image for people who cannot see it.',
    ARRAY['html', 'links', 'images'], 3),

  -- Developers
  ('JavaScript Variables', 'javascript-variables', 'Developers', 'JavaScript', 'JavaScript', 'intermediate', 40, 'published',
    ARRAY['Declare variables with let and const', 'Understand data types', 'Use variables in expressions'],
    '# JavaScript Variables\n\nVariables store information in your program.\n\n## Declaring Variables\n```javascript\nlet name = "Zara";\nlet age = 9;\nconst SCHOOL = "CODEship";\n\nconsole.log("Hello, " + name + "!");\n```\n\n## Data Types\n- **String** – text in quotes: `"hello"`\n- **Number** – numbers: `42`, `3.14`\n- **Boolean** – true or false: `true`\n- **Array** – a list: `["apple", "banana"]`',
    ARRAY['javascript', 'variables', 'beginner'], 1),

  ('JavaScript Functions', 'javascript-functions', 'Developers', 'JavaScript', 'JavaScript', 'intermediate', 45, 'published',
    ARRAY['Write a function', 'Call a function with arguments', 'Return values from functions'],
    '# JavaScript Functions\n\nFunctions are reusable blocks of code.\n\n## Creating a Function\n```javascript\nfunction greet(name) {\n  return "Hello, " + name + "!";\n}\n\nlet message = greet("Zara");\nconsole.log(message); // Hello, Zara!\n```\n\n## Why Use Functions?\n- Write code once, use it many times\n- Keep your code organized\n- Easier to fix problems',
    ARRAY['javascript', 'functions', 'intermediate'], 2),

  ('JavaScript Loops', 'javascript-loops', 'Developers', 'JavaScript', 'JavaScript', 'intermediate', 45, 'published',
    ARRAY['Use for loops', 'Use while loops', 'Loop through arrays'],
    '# JavaScript Loops\n\n## For Loop\n```javascript\nfor (let i = 0; i < 5; i++) {\n  console.log("Count: " + i);\n}\n```\n\n## Looping Through an Array\n```javascript\nlet fruits = ["apple", "banana", "cherry"];\nfor (let fruit of fruits) {\n  console.log(fruit);\n}\n```',
    ARRAY['javascript', 'loops', 'intermediate'], 3),

  ('CSS Flexbox', 'css-flexbox', 'Developers', 'CSS', 'CSS', 'intermediate', 40, 'published',
    ARRAY['Use display: flex', 'Align items with flexbox', 'Build a row and column layout'],
    '# CSS Flexbox\n\nFlexbox makes it easy to arrange items in a row or column.\n\n## Basic Flexbox\n```css\n.container {\n  display: flex;\n  gap: 16px;\n  align-items: center;\n  justify-content: space-between;\n}\n```\n\n## Common Properties\n- `flex-direction: row | column`\n- `justify-content: center | space-between | flex-start`\n- `align-items: center | flex-start | flex-end`',
    ARRAY['css', 'flexbox', 'layout'], 4),

  -- Engineers
  ('Python Introduction', 'python-introduction', 'Engineers', 'Python', 'Python', 'intermediate', 45, 'published',
    ARRAY['Write your first Python program', 'Use print and input', 'Understand Python syntax'],
    '# Python Introduction\n\nPython is one of the most popular programming languages in the world!\n\n## Hello World\n```python\nprint("Hello, World!")\n```\n\n## Getting User Input\n```python\nname = input("What is your name? ")\nprint("Hello, " + name + "!")\n```\n\n## Python is Clean!\nPython uses indentation (spaces) instead of curly braces {}.',
    ARRAY['python', 'beginner', 'fundamentals'], 1),

  ('Python Lists and Loops', 'python-lists-loops', 'Engineers', 'Python', 'Python', 'intermediate', 50, 'published',
    ARRAY['Create and modify lists', 'Use for loops with lists', 'Use list methods'],
    '# Python Lists and Loops\n\n## Creating a List\n```python\nfruits = ["apple", "banana", "cherry"]\nprint(fruits[0])  # apple\n```\n\n## Looping Through a List\n```python\nfor fruit in fruits:\n    print(fruit)\n```\n\n## Useful List Methods\n```python\nfruits.append("mango")   # add to end\nfruits.remove("banana")  # remove item\nprint(len(fruits))       # count items\n```',
    ARRAY['python', 'lists', 'loops', 'intermediate'], 2),

  ('Introduction to JSON', 'introduction-to-json', 'Engineers', 'JSON', 'JSON', 'intermediate', 35, 'published',
    ARRAY['Understand JSON format', 'Read JSON data', 'Parse JSON in JavaScript'],
    '# Introduction to JSON\n\nJSON (JavaScript Object Notation) is a way to store and share data.\n\n## JSON Structure\n```json\n{\n  "name": "Zara",\n  "age": 9,\n  "level": "Builders",\n  "interests": ["games", "art", "coding"]\n}\n```\n\n## Reading JSON in JavaScript\n```javascript\nconst data = JSON.parse(jsonString);\nconsole.log(data.name); // Zara\n```',
    ARRAY['json', 'data', 'intermediate'], 3);

-- ─── SEED: PROJECTS ──────────────────────────────────────────────────────────

insert into public.projects (title, slug, level, languages, difficulty, duration_minutes, status, description, instructions, tags, order_index) values
  ('Draw a Robot', 'draw-a-robot', 'Explorers', ARRAY['HTML', 'CSS'], 'beginner', 30, 'published',
    'Use CSS shapes to draw a cute robot!',
    '# Draw a Robot with CSS!\n\n## What You''ll Build\nA fun robot made entirely with HTML and CSS shapes.\n\n## Getting Started\n```html\n<div class="robot">\n  <div class="head"></div>\n  <div class="body"></div>\n  <div class="legs"></div>\n</div>\n```\n\n```css\n.robot { display: flex; flex-direction: column; align-items: center; }\n.head { width: 80px; height: 80px; background: #silver; border-radius: 10px; }\n```\n\nGet creative — give your robot eyes, a mouth, and colors!',
    ARRAY['html', 'css', 'creative', 'art'], 1),

  ('Personal Webpage', 'personal-webpage', 'Builders', ARRAY['HTML', 'CSS'], 'intermediate', 60, 'published',
    'Build a webpage all about YOU!',
    '# Build Your Personal Webpage\n\n## What You''ll Create\nA webpage with your name, a photo, your interests, and a fun fact!\n\n## Structure to Follow\n1. A big heading with your name\n2. A short "About Me" paragraph\n3. A list of your hobbies\n4. Your favourite colour as the background\n5. At least one image\n\n## Challenge\nAdd a navigation menu at the top with links to different sections!',
    ARRAY['html', 'css', 'personal', 'web'], 1),

  ('JavaScript Calculator', 'javascript-calculator', 'Developers', ARRAY['HTML', 'CSS', 'JavaScript'], 'intermediate', 90, 'published',
    'Build a working calculator with JavaScript!',
    '# Build a Calculator\n\n## Features to Build\n1. Number buttons (0-9)\n2. Operation buttons (+, -, ×, ÷)\n3. A display screen\n4. Clear button\n5. Equals button\n\n## Start Here\n```html\n<div id="calculator">\n  <div id="display">0</div>\n  <div id="buttons">\n    <!-- Add buttons here -->\n  </div>\n</div>\n```\n\n## JavaScript Logic\nUse `eval()` to calculate the result, or implement your own math logic!',
    ARRAY['javascript', 'html', 'css', 'calculator', 'interactive'], 1),

  ('Python Quiz Game', 'python-quiz-game', 'Engineers', ARRAY['Python'], 'advanced', 90, 'published',
    'Build a multiple-choice quiz game in Python!',
    '# Python Quiz Game\n\n## What You''ll Build\nA terminal-based quiz game with questions, scoring, and a final result!\n\n## Starter Structure\n```python\nquestions = [\n    {\n        "question": "What does HTML stand for?",\n        "options": ["A) Hyper Text Makeup Language", "B) Hyper Text Markup Language"],\n        "answer": "B"\n    }\n]\n\nscore = 0\nfor q in questions:\n    print(q["question"])\n    # Add your answer logic here\n```\n\n## Challenge: Add a timer for each question!',
    ARRAY['python', 'game', 'advanced', 'terminal'], 1);

-- ─── SEED: QUIZZES ───────────────────────────────────────────────────────────

insert into public.quizzes (title, level, topic, difficulty, duration_minutes, status, description, pass_score, tags) values
  ('HTML Basics Quiz', 'Builders', 'HTML', 'beginner', 10, 'published', 'Test your knowledge of basic HTML tags and structure!', 70, ARRAY['html', 'beginner']),
  ('CSS Styling Quiz', 'Builders', 'CSS', 'beginner', 12, 'published', 'How well do you know CSS properties and values?', 70, ARRAY['css', 'styling']),
  ('JavaScript Variables Quiz', 'Developers', 'JavaScript', 'intermediate', 15, 'published', 'Test your understanding of variables and data types in JavaScript.', 75, ARRAY['javascript', 'variables']),
  ('Python Fundamentals Quiz', 'Engineers', 'Python', 'intermediate', 20, 'published', 'Assess your Python basics including syntax, lists, and functions.', 75, ARRAY['python', 'fundamentals']),
  ('Logic and Algorithms Quiz', 'Builders', 'Algorithms', 'beginner', 10, 'published', 'Think like a programmer! Test your logical thinking.', 70, ARRAY['logic', 'algorithms']);

-- ─── SEED: QUIZ QUESTIONS ────────────────────────────────────────────────────

-- Get quiz IDs and insert questions
do $$
declare
  html_quiz_id uuid;
  js_quiz_id uuid;
begin
  select id into html_quiz_id from public.quizzes where title = 'HTML Basics Quiz';
  select id into js_quiz_id from public.quizzes where title = 'JavaScript Variables Quiz';

  insert into public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, order_index) values
    (html_quiz_id, 'What does HTML stand for?', 'multiple_choice',
      '[{"id":"a","text":"Hyper Text Makeup Language"},{"id":"b","text":"Hyper Text Markup Language"},{"id":"c","text":"High Text Markup Language"},{"id":"d","text":"Hyper Tool Markup Language"}]'::jsonb,
      'b', 'HTML stands for Hyper Text Markup Language. It is the standard language for creating web pages.', 1),
    (html_quiz_id, 'Which tag creates the biggest heading?', 'multiple_choice',
      '[{"id":"a","text":"<h6>"},{"id":"b","text":"<heading>"},{"id":"c","text":"<h1>"},{"id":"d","text":"<big>"}]'::jsonb,
      'c', 'The <h1> tag creates the largest heading. Headings go from h1 (largest) to h6 (smallest).', 2),
    (html_quiz_id, 'What tag is used to create a paragraph?', 'multiple_choice',
      '[{"id":"a","text":"<paragraph>"},{"id":"b","text":"<p>"},{"id":"c","text":"<para>"},{"id":"d","text":"<text>"}]'::jsonb,
      'b', 'The <p> tag is used to define a paragraph in HTML.', 3),
    (html_quiz_id, 'Which HTML tag is used to add a link?', 'multiple_choice',
      '[{"id":"a","text":"<link>"},{"id":"b","text":"<href>"},{"id":"c","text":"<a>"},{"id":"d","text":"<url>"}]'::jsonb,
      'c', 'The <a> (anchor) tag is used to create hyperlinks. The href attribute specifies the URL.', 4),
    (html_quiz_id, 'HTML tags are usually written in _____ pairs.', 'multiple_choice',
      '[{"id":"a","text":"single"},{"id":"b","text":"opening and closing"},{"id":"c","text":"double"},{"id":"d","text":"triple"}]'::jsonb,
      'b', 'Most HTML tags come in pairs: an opening tag like <p> and a closing tag like </p>.', 5),

    (js_quiz_id, 'Which keyword declares a variable that cannot be reassigned?', 'multiple_choice',
      '[{"id":"a","text":"let"},{"id":"b","text":"var"},{"id":"c","text":"const"},{"id":"d","text":"set"}]'::jsonb,
      'c', 'const declares a constant — a variable whose value cannot be reassigned after it is set.', 1),
    (js_quiz_id, 'What is the output of: console.log(typeof "hello")?', 'multiple_choice',
      '[{"id":"a","text":"text"},{"id":"b","text":"string"},{"id":"c","text":"word"},{"id":"d","text":"char"}]'::jsonb,
      'b', 'The typeof operator returns "string" for text values in JavaScript.', 2),
    (js_quiz_id, 'Which of these is a valid variable name?', 'multiple_choice',
      '[{"id":"a","text":"2fast"},{"id":"b","text":"my-var"},{"id":"c","text":"myVar"},{"id":"d","text":"let"}]'::jsonb,
      'c', 'myVar is valid. Variable names cannot start with numbers, contain hyphens, or be reserved words like "let".', 3);
end $$;

-- ─── ROW LEVEL SECURITY ──────────────────────────────────────────────────────

alter table public.users enable row level security;
alter table public.parent_profiles enable row level security;
alter table public.teacher_profiles enable row level security;
alter table public.student_profiles enable row level security;
alter table public.assessments enable row level security;
alter table public.learning_profiles enable row level security;
alter table public.lessons enable row level security;
alter table public.projects enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.learning_plans enable row level security;
alter table public.scheduled_sessions enable row level security;
alter table public.progress_records enable row level security;
alter table public.project_submissions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.achievements enable row level security;
alter table public.student_achievements enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
alter table public.notifications enable row level security;
alter table public.admin_audit_logs enable row level security;

-- Users: can only read/update own profile
create policy "users_own" on public.users for all using (auth.uid() = id);

-- Students: parents can manage their children, teachers can see assigned students
create policy "students_parent" on public.student_profiles for all
  using (auth.uid() = parent_id);
create policy "students_teacher" on public.student_profiles for select
  using (auth.uid() = teacher_id);
create policy "students_self" on public.student_profiles for select
  using (auth.uid() = user_id);

-- Published curriculum is readable by all authenticated users
create policy "lessons_read_published" on public.lessons for select
  using (auth.role() = 'authenticated' and status = 'published');
create policy "lessons_admin" on public.lessons for all
  using (exists(select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "projects_read_published" on public.projects for select
  using (auth.role() = 'authenticated' and status = 'published');
create policy "projects_admin" on public.projects for all
  using (exists(select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "quizzes_read_published" on public.quizzes for select
  using (auth.role() = 'authenticated' and status = 'published');
create policy "quizzes_admin" on public.quizzes for all
  using (exists(select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "quiz_questions_read" on public.quiz_questions for select
  using (exists(select 1 from public.quizzes q where q.id = quiz_id and q.status = 'published'));

-- Progress: own records only (or parent/teacher)
create policy "progress_own" on public.progress_records for all
  using (exists(select 1 from public.student_profiles s where s.id = student_id and (s.user_id = auth.uid() or s.parent_id = auth.uid() or s.teacher_id = auth.uid())));

-- Subscriptions: own only
create policy "subscriptions_own" on public.subscriptions for all using (auth.uid() = user_id);

-- Notifications: own only
create policy "notifications_own" on public.notifications for all using (auth.uid() = user_id);

-- Achievements: readable by all
create policy "achievements_read" on public.achievements for select using (auth.role() = 'authenticated');
create policy "student_achievements_own" on public.student_achievements for all
  using (exists(select 1 from public.student_profiles s where s.id = student_id and (s.user_id = auth.uid() or s.parent_id = auth.uid())));

-- Admin audit: admin only
create policy "audit_admin" on public.admin_audit_logs for all
  using (exists(select 1 from public.users where id = auth.uid() and role = 'admin'));

-- ─── FUNCTIONS ───────────────────────────────────────────────────────────────

-- Auto-create user profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.users (id, email, full_name, avatar_url, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url',
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'parent')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Auto-create free trial subscription on signup
create or replace function public.handle_new_subscription()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.subscriptions (user_id, plan, status, trial_end, max_children, features)
  values (
    new.id, 'trial', 'trialing',
    now() + interval '14 days', 1,
    '{"ai_planner": false, "calendar_sync": false, "reports": false}'::jsonb
  );
  return new;
end;
$$;

create trigger on_user_created_subscription
  after insert on public.users
  for each row execute procedure public.handle_new_subscription();

-- Award XP to student
create or replace function public.award_xp(p_student_id uuid, p_xp integer)
returns void language plpgsql security definer as $$
begin
  update public.student_profiles
  set xp_points = xp_points + p_xp, updated_at = now()
  where id = p_student_id;
end;
$$;

-- Update streak
create or replace function public.update_streak(p_student_id uuid)
returns void language plpgsql security definer as $$
declare
  v_last_active date;
begin
  select last_active_at::date into v_last_active
  from public.student_profiles where id = p_student_id;

  if v_last_active = current_date - 1 then
    update public.student_profiles
    set streak_days = streak_days + 1, last_active_at = now(), updated_at = now()
    where id = p_student_id;
  elsif v_last_active < current_date - 1 then
    update public.student_profiles
    set streak_days = 1, last_active_at = now(), updated_at = now()
    where id = p_student_id;
  else
    update public.student_profiles
    set last_active_at = now(), updated_at = now()
    where id = p_student_id;
  end if;
end;
$$;

-- ─── INDEXES ─────────────────────────────────────────────────────────────────

create index lessons_level_idx on public.lessons(level);
create index lessons_status_idx on public.lessons(status);
create index lessons_search_idx on public.lessons using gin(to_tsvector('english', title || ' ' || coalesce(instructions, '')));
create index projects_level_idx on public.projects(level);
create index quizzes_level_idx on public.quizzes(level);
create index progress_student_idx on public.progress_records(student_id);
create index sessions_student_idx on public.scheduled_sessions(student_id);
create index sessions_date_idx on public.scheduled_sessions(scheduled_date);
create index notifications_user_idx on public.notifications(user_id, read);
create index audit_created_idx on public.admin_audit_logs(created_at desc);
