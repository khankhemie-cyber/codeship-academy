-- ═══════════════════════════════════════════════════════════════════════════
-- CODEship Academy: BUILDERS Projects — Full Content (Projects 6–100)
-- Run AFTER curriculum-builders.sql
-- ═══════════════════════════════════════════════════════════════════════════

-- Remove stub projects 6-100
DELETE FROM public.projects WHERE level = 'Builders' AND order_index >= 6;

INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index) VALUES

('bld-p06', 'Styled About Me Page', 'Builders', 'CSS', 'CSS', 'beginner', 35, 'published',
'Take the About Me page from Lesson 2 and style it completely with an external CSS file.',
$P$## Project: Styled About Me Page

### What You'll Build
Transform your plain HTML About Me page into a designed, styled webpage using CSS — your first real design project.

### Requirements
1. Create a separate `styles.css` file (no inline styles)
2. Choose a **colour scheme** — at least 3 colours (background, headings, text)
3. Set a **font-family** for the whole page (from Google Fonts recommended)
4. Style every heading (`h1`, `h2`) differently from body text
5. Add **padding** and **margin** to create breathing room
6. Style the `<hr>` divider so it matches your colour scheme
7. Style at least one word using a class (e.g., `.highlight { background: yellow; }`)

### Design Brief
Imagine you're designing a profile page for a real coding platform. Make choices you'd be proud to show:
- What font says "me"?
- What colour reflects your personality?
- Is it clean and readable?

### Stretch Goals
- Add a `max-width` and `margin: 0 auto` to centre the content column
- Use Google Fonts — try Nunito, Poppins, or Merriweather
- Add a decorative border or background to your name heading

### Assessment Criteria
- CSS is in a separate file linked correctly with `<link>`
- No inline styles (`style=""` attributes)
- Clear design decisions — not just default browser colours
- Readable with good contrast
$P$,
'<!-- Your HTML from Lesson 2 here -->\n<!-- Create styles.css and link it in <head> -->',
ARRAY['css','beginner','design','typography'], 6),

('bld-p07', 'Colour Palette Website', 'Builders', 'CSS', 'CSS', 'beginner', 30, 'published',
'Design and build a colour palette display page showing your own colour scheme with hex codes.',
$P$## Project: Colour Palette Website

### What You'll Build
A colour palette showcase page — like the ones on coolors.co — showing 5 colours from your own personal colour scheme with their hex codes and names.

### How to Choose Your Colours
1. Visit **coolors.co** and generate palettes until you find one you love
2. Lock colours you like and keep generating
3. Export your 5-colour palette

### HTML Requirements
- A page title like "The [Your Name] Palette"
- 5 **colour swatch** boxes displaying your colours
- Each swatch shows: the colour as background, its hex code, and your name for it
- A brief paragraph explaining your colour choices

### CSS Requirements
- Each swatch is a `<div>` with a specific class
- The background-color is set to the hex code
- Swatches are displayed side by side (use `display: inline-block` or flexbox)
- Each swatch is at least 150px × 150px
- The hex code uses `font-family: monospace` for the code look

### Example Swatch HTML:
```html
<div class="swatch" style="background-color: #1E2140;">
  <span class="hex">#1E2140</span>
  <span class="name">Deep Navy</span>
</div>
```

### Stretch Goals
- Make the hex code copy to clipboard when clicked (JavaScript: `navigator.clipboard.writeText(hex)`)
- Add a "Complementary" section showing the complementary colour for each swatch
- Create a "Dark Mode Preview" and "Light Mode Preview" showing how the palette looks in each
$P$,
'<!-- Colour Palette Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>My Colour Palette</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n  <h1>My Colour Palette</h1>\n  <div class="palette">\n    <!-- Add 5 swatches -->\n  </div>\n</body>\n</html>',
ARRAY['css','design','colour','beginner'], 7),

('bld-p08', 'Typography Showcase', 'Builders', 'CSS', 'CSS', 'beginner', 30, 'published',
'Create a page that demonstrates typographic hierarchy using only font properties — no images.',
$P$## Project: Typography Showcase

### What You'll Build
A "type specimen" page — like the ones type foundries use — showcasing a Google Font with all its weights and sizes.

### Pick Your Font
Go to fonts.google.com and choose a font that has at least 4 weights (400, 600, 700, 900 ideally). Good options: Nunito, Inter, Poppins, Playfair Display, Raleway.

### Page Requirements
1. **Font Specimen Heading** — Font name displayed at 80px, weight 900
2. **The Alphabet** — A–Z in uppercase and lowercase at large size
3. **Numbers** — 0–9 displayed prominently
4. **Weight Scale** — Same sentence shown at 7 different weights: 100, 200, 300, 400, 500, 700, 900
5. **Size Scale** — Same word shown at: 10px, 14px, 18px, 24px, 32px, 48px, 64px
6. **Sample Paragraph** — A paragraph of body text with optimal settings (line-height: 1.6–1.8, max-width: 65ch)
7. **Font Info Section** — Designer name, year released, Google Fonts link

### CSS Requirements
- Import the font from Google Fonts in `<head>`
- Use the `font-weight` property for each weight variation
- Use CSS for all sizes (no h1–h6 default sizes — override them all)
- Choose a complementary background colour to showcase the font

### Stretch Goals
- Add a font-pairing suggestion showing your chosen font with a complementary one
- Add a "Use This Font" section with the Google Fonts copy-paste code in a `<code>` block
$P$,
'<!-- Typography Showcase Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Font Specimen</title>\n  <!-- Add Google Font link here -->\n  <link rel="stylesheet" href="specimen.css">\n</head>\n<body>\n  <h1 class="specimen-title">Font Name</h1>\n  <!-- Build your specimen -->\n</body>\n</html>',
ARRAY['css','typography','design','google-fonts'], 8),

('bld-p09', 'Box Model Demonstration', 'Builders', 'CSS', 'CSS', 'intermediate', 35, 'published',
'Build an interactive visual guide to the CSS box model showing content, padding, border, and margin.',
$P$## Project: Box Model Demonstration

### What You'll Build
An educational page that visually demonstrates the CSS box model — like a teaching tool you could show a friend who's learning CSS.

### The Core Visual
Create a large visual diagram showing the four layers of the box model using nested coloured boxes:
- **Outer box (Margin):** Light grey or tan background, labelled "Margin"
- **Border ring:** A thick visible border with a distinct colour, labelled "Border"  
- **Inner padding area:** A lighter shade, labelled "Padding"
- **Content box:** White or cream background with text, labelled "Content"

### Requirements
1. The visual diagram with all 4 layers clearly coloured and labelled
2. A CSS panel below showing the code that creates the box:
   ```
   width: 200px;
   padding: 40px;
   border: 8px solid navy;
   margin: 30px;
   ```
3. A **table** below the diagram showing what the total size equals (with and without `box-sizing: border-box`)
4. A `before/after` section: two boxes showing `box-sizing: content-box` vs `box-sizing: border-box` at the same declared width
5. Labels for each layer (position them with absolute or relative positioning)

### Stretch Goals
- JavaScript sliders that change padding/border/margin values and update the visual in real-time
- Show the calculated total width in a live display

### Assessment Criteria
- All 4 layers (margin, border, padding, content) are visually distinct and labelled
- The `box-sizing` comparison is clear and accurate
$P$,
'<!-- Box Model Demo Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>CSS Box Model</title>\n  <style>\n    /* Build your box model visual here */\n    .box-model-visual { /* outer margin */ }\n  </style>\n</head>\n<body>\n  <h1>The CSS Box Model</h1>\n  <div class="box-model-visual">\n    <!-- Nested divs for each layer -->\n  </div>\n</body>\n</html>',
ARRAY['css','box-model','educational','interactive'], 9),

('bld-p10', 'Card Collection', 'Builders', 'CSS', 'CSS', 'intermediate', 40, 'published',
'Design and build a set of 4 different card variants for different content types: course card, blog post card, team member card, and product card.',
$P$## Project: Card Collection

### What You'll Build
A component library page showing 4 different card designs. Cards are one of the most reused UI patterns in web development — every design system has them.

### The 4 Cards You'll Build

**1. Course Card**
- Cover image (top)
- Level badge (e.g., "Beginner")
- Course title
- Instructor name and avatar
- Progress bar showing 0–100% complete
- Duration label
- "Start Learning" button

**2. Blog Post Card**
- Wide horizontal image
- Category tag
- Published date
- Title (2 lines max with text-overflow)
- Short excerpt (3 lines max)
- Author name
- "Read More" link

**3. Team Member Card**
- Square portrait photo
- Name
- Job title
- Short bio
- 3 social media icons (LinkedIn, Twitter, GitHub)
- On hover: card lifts and a coloured top border appears

**4. Product Card** 
- Product image
- Brand/category
- Product name
- Star rating (5 stars, CSS only)
- Original price (struck through) and sale price
- "Add to Cart" button + "♡ Wishlist" link

### Requirements
- Each card must be in its own `<article>` or `<div class="card-[type]">`
- All cards use the same base `box-shadow` and `border-radius`
- All cards have a hover state
- Lay them out in a 2×2 grid using CSS Grid

### Stretch Goals
- Make the grid responsive (2 columns on desktop, 1 on mobile)
- Add a "copy HTML" button on each card
$P$,
'<!-- Card Collection Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Card Collection</title>\n  <link rel="stylesheet" href="cards.css">\n</head>\n<body>\n  <h1>Card Components</h1>\n  <div class="card-grid">\n    <!-- Course card -->\n    <article class="card card-course">\n    </article>\n    <!-- More cards -->\n  </div>\n</body>\n</html>',
ARRAY['css','cards','components','design','grid'], 10),

('bld-p11', 'Flexbox Navigation Bar', 'Builders', 'CSS', 'CSS', 'intermediate', 35, 'published',
'Build a complete navigation bar with logo, links, and CTA button using only flexbox for layout.',
$P$## Project: Flexbox Navigation Bar

### What You'll Build
A professional-quality navigation bar — the kind used on real websites. You'll build the full component including desktop layout and a mobile-ready version.

### Requirements

**Desktop Nav:**
- Logo on the far left (icon + text)
- Navigation links in the centre or spread out
- A CTA button on the far right (e.g., "Sign Up")
- All items vertically centred
- Active link highlighted differently from others
- Hover effect on all links

**Visual Design:**
- Dark background (navy, dark grey, or black)
- White or light text
- Gold/accent colour for the CTA button
- Sticky: stays at the top while you scroll
- `box-shadow` for depth below the nav

**Exactly Two Flexbox Containers:**
1. Outer: `display: flex; justify-content: space-between; align-items: center;` — positions logo, links group, CTA
2. Inner: `display: flex; gap: X;` — arranges the nav links themselves

### HTML Structure:
```html
<header>
  <nav>
    <a href="/" class="logo">🚀 CODEship</a>
    <ul class="nav-links">
      <li><a href="#" class="active">Home</a></li>
      ...
    </ul>
    <a href="#signup" class="cta-btn">Start Free</a>
  </nav>
</header>
```

### Stretch Goals
- Add a dropdown menu under one of the nav links
- Add a search bar that expands on click
- Add a notification badge (a red dot) over one icon

### Self-Review Questions
- Is everything centred vertically? (check `align-items: center`)
- Does the active link look noticeably different?
- Does it stay at the top when you scroll?
$P$,
'<!-- Nav Bar Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Navigation Bar</title>\n  <style>\n    * { box-sizing: border-box; margin: 0; padding: 0; }\n    body { font-family: system-ui, sans-serif; }\n    /* Build your nav here */\n  </style>\n</head>\n<body>\n  <header>\n    <nav class="navbar">\n      <a href="/" class="logo">🚀 Site Name</a>\n      <ul class="nav-links">\n        <li><a href="#">Home</a></li>\n        <li><a href="#">About</a></li>\n        <li><a href="#">Work</a></li>\n      </ul>\n      <a href="#" class="cta-btn">Get Started</a>\n    </nav>\n  </header>\n  <main style="height: 2000px; padding: 100px 40px;">\n    <p>Scroll to test sticky nav</p>\n  </main>\n</body>\n</html>',
ARRAY['css','flexbox','navigation','header'], 11),

('bld-p12', 'Photo Grid with Flexbox', 'Builders', 'CSS', 'CSS', 'intermediate', 35, 'published',
'Build a responsive photo grid that wraps automatically using flexbox with consistent image sizing.',
$P$## Project: Photo Grid with Flexbox

### What You'll Build
A flexible photo grid where images wrap to new rows automatically — no Grid needed. This teaches you the critical `flex-wrap` and `flex: 1 1 minmax` technique.

### Requirements
1. At least 9 images in your grid (use free Unsplash images or emojis in coloured boxes if no photos)
2. On desktop: 3 images per row
3. On tablet (768px): 2 images per row — achieved through `flex-basis`, not media queries!
4. On mobile (480px): 1 per row
5. All images the same height (use `object-fit: cover` and a fixed height)
6. Consistent gap between all images in both directions (use `gap`)
7. A page title and brief description above the grid

### The Key Technique:
```css
.grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}

.grid-item {
  flex: 1 1 280px; /* grows, shrinks, starts at 280px */
  max-width: calc(33.333% - 11px);
}
```

### Design Requirements
- Uniform image height: 220px
- `border-radius: 8px` on each image
- Smooth hover effect: scale up image with `transform: scale(1.03)` and `overflow: hidden` on the container

### Stretch Goals
- Add a category filter (show only "Nature", "City", "Food" etc.) using JavaScript and data-attributes
- Add a count display: "Showing 9 of 24 photos"
- Add lightbox functionality when an image is clicked
$P$,
'<!-- Photo Grid Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Photo Grid</title>\n  <style>\n    * { box-sizing: border-box; margin: 0; padding: 0; }\n    body { font-family: system-ui, sans-serif; background: #111; color: white; padding: 40px; }\n    /* Build your flex grid here */\n    .grid {\n      display: flex;\n      flex-wrap: wrap;\n      gap: 12px;\n    }\n  </style>\n</head>\n<body>\n  <h1>My Photos</h1>\n  <div class="grid">\n    <!-- Add your images here -->\n  </div>\n</body>\n</html>',
ARRAY['css','flexbox','grid','images','responsive'], 12),

('bld-p13', 'Responsive Card Layout', 'Builders', 'CSS', 'CSS', 'intermediate', 35, 'published',
'Build a card layout that changes from 3 columns to 2 to 1 as the screen shrinks, using media queries.',
$P$## Project: Responsive Card Layout

### What You'll Build
A 6-card layout that uses CSS Grid with `auto-fill` and `minmax` to create a fully responsive grid — then media queries to fine-tune the behaviour at each breakpoint.

### The Cards
Build 6 "course level" cards for CODEship Academy (or invent your own content):
1. Explorers (K-1)
2. Builders (Gr 2-3)
3. Developers (Gr 4-6)
4. Engineers (Gr 7-8)
5. Parent Dashboard
6. School Program

### Each Card Contains:
- An emoji icon (large, 2.5rem)
- Level/category name
- Age range or audience
- 2-sentence description
- "Learn More" button

### Grid Requirements:
```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
}
```

**Breakpoints to add:**
- Below 900px: max 2 columns — adjust `minmax(260px, 1fr)`  
- Below 600px: 1 column — `grid-template-columns: 1fr`
- Below 600px: reduce padding on body

### Card Design:
- White background, `border-radius: 16px`, `box-shadow`
- `padding: 24px`
- Icon styled with its own circle background
- On hover: card lifts (`translateY(-6px)`) and shadow deepens
- Button: full-width at the bottom of card

### Test at These Widths:
- 1280px — 3+ columns
- 900px — 2–3 columns
- 600px — 1–2 columns
- 375px — 1 column, cards fill screen edge-to-edge (minus padding)
$P$,
'<!-- Responsive Cards Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Responsive Cards</title>\n  <link rel="stylesheet" href="cards.css">\n</head>\n<body>\n  <div class="container">\n    <h1>Our Programs</h1>\n    <div class="cards">\n      <!-- 6 cards -->\n    </div>\n  </div>\n</body>\n</html>',
ARRAY['css','grid','responsive','cards','media-queries'], 13),

('bld-p14', 'CSS Grid Magazine Layout', 'Builders', 'CSS', 'CSS', 'intermediate', 40, 'published',
'Build a magazine-style editorial layout with a featured article taking 2 columns and shorter articles filling the remaining cells.',
$P$## Project: CSS Grid Magazine Layout

### What You'll Build
A news/magazine homepage layout with mixed-size articles — just like NYT, BBC, or The Verge. The main feature takes up twice the space of regular articles.

### Grid Architecture
```
┌────────────────┬──────────┬──────────┐
│                │  Story 2 │  Story 3 │
│  FEATURE       │          │          │
│  STORY (2×2)   ├──────────┼──────────┤
│                │  Story 4 │  Story 5 │
│                │          │          │
├──────────┬─────┴──────────┴──────────┤
│  Story 6 │     Story 7 (wide)        │
└──────────┴──────────────────────────┘
```

### Requirements
1. A 4-column CSS Grid with `grid-auto-rows: 240px`
2. Feature article spans 2 columns and 2 rows (`grid-column: span 2; grid-row: span 2`)
3. Story 7 spans 3 columns at the bottom
4. At least 7 articles in total
5. Each article has: background photo (use gradient placeholders), category badge, title, and short excerpt

### Article HTML Pattern:
```html
<article class="story story-feature">
  <div class="story-bg" style="background: linear-gradient(135deg, #1E2140, #7C3AED)"></div>
  <div class="story-content">
    <span class="category">Technology</span>
    <h2>AI is Transforming How Kids Learn</h2>
    <p>Personalized learning platforms are changing the classroom...</p>
  </div>
</article>
```

### CSS Key Points:
- `position: relative` on articles, `position: absolute; inset: 0` on the gradient background
- Text sits on top using `z-index: 1`
- Overlay gradient at bottom: `background: linear-gradient(to top, rgba(0,0,0,0.8), transparent)`

### Stretch Goals
- Make it responsive: single column on mobile
- Add category colour coding (tech = blue, culture = red, etc.)
$P$,
'<!-- Magazine Layout Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Magazine Layout</title>\n  <style>\n    * { box-sizing: border-box; margin: 0; padding: 0; }\n    .magazine {\n      display: grid;\n      grid-template-columns: repeat(4, 1fr);\n      grid-auto-rows: 240px;\n      gap: 8px;\n      padding: 24px;\n    }\n  </style>\n</head>\n<body>\n  <div class="magazine">\n    <!-- Articles here -->\n  </div>\n</body>\n</html>',
ARRAY['css','grid','magazine','layout','editorial'], 14),

('bld-p15', 'Personal Homepage', 'Builders', 'HTML', 'HTML', 'intermediate', 50, 'published',
'Build a complete personal homepage with hero, skills, projects preview, and contact sections.',
$P$## Project: Personal Homepage

### What You'll Build
Your real personal homepage — one that you can publish and use as your online presence. This is the most important project in the first half of Builders because you'll actually use it.

### Required Sections

**1. Hero Section**
- Your name as `<h1>`
- A tagline: "Grade X student · Aspiring [job] · [Hometown]"
- 2 buttons: "See My Projects" and "Contact Me"
- A profile photo or illustrated avatar

**2. About Me**
- 2–3 paragraphs about yourself
- A "fun facts" list (bullet points)
- Your languages spoken

**3. Skills**
- A visual skills section with icons or badges for each technology you know
- At minimum: HTML, CSS, Scratch
- Use a progress bar or badge system to show your level

**4. Featured Projects**
- 3 project cards linking to your best work
- Each with: screenshot/image, title, tech stack tags, brief description, live link

**5. Contact**
- A simple contact form (Name, Email, Message, Submit)
- Your email address as a mailto link
- Optional: social links (GitHub, etc.)

### Technical Requirements
- Semantic HTML throughout: `<header>`, `<main>`, `<section>`, `<footer>`
- External CSS file
- Responsive: tested at 375px, 768px, 1280px
- Smooth scroll: `html { scroll-behavior: smooth; }`
- Sticky nav that links to each section

### Publish It
When complete: deploy to Netlify (free). Add the URL to your CODEship profile.
$P$,
'<!-- Personal Homepage Starter -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>[Your Name] — Student Developer</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n  <header><!-- Nav --></header>\n  <main>\n    <section id="hero"><!-- Hero --></section>\n    <section id="about"><!-- About --></section>\n    <section id="skills"><!-- Skills --></section>\n    <section id="projects"><!-- Projects --></section>\n    <section id="contact"><!-- Contact --></section>\n  </main>\n  <footer><!-- Footer --></footer>\n</body>\n</html>',
ARRAY['html','css','portfolio','personal','responsive','publish'], 15);

-- Projects 16-100: complete real briefs
INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'bld-p' || n,
  title,
  'Builders',
  category,
  lang,
  difficulty,
  40,
  'published',
  description,
  brief,
  '<!-- ' || title || ' -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>' || title || '</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n  <!-- Your project here -->\n</body>\n</html>',
  ARRAY['builders', 'project', lang],
  n
FROM (
  VALUES
  (16,'CSS Button Collection','CSS','CSS','intermediate',
   'Design a complete set of 8 button variants for a design system.',
   $B$## Project: CSS Button Collection

### Build 8 Button Variants:
1. **Primary** — Bold filled, brand colour
2. **Secondary** — Outlined, brand colour border
3. **Ghost** — No background, subtle border
4. **Danger** — Red, for destructive actions
5. **Success** — Green, for confirmations
6. **Loading** — Spinning animation, disabled click
7. **Icon + Text** — Emoji or SVG left of label
8. **Link-style** — Looks like a text link

### Requirements for EVERY button:
- Smooth `transition: all 0.2s ease`
- `:hover` state that is visually different
- `:active` state (pressed feel — `translateY(1px)`)
- `:focus-visible` ring for keyboard navigation
- `:disabled` state with `opacity: 0.5; cursor: not-allowed`

### Layout: Display all 8 in a grid with labels underneath each one.
$B$),

  (17,'Animated Hero Section','CSS','CSS','intermediate',
   'Build a full-width hero section with a fade-in animation, gradient background, and an animated CTA button.',
   $B$## Project: Animated Hero Section

### Requirements:
- Full viewport height (`height: 100vh`)
- Linear or radial gradient background
- Headline animates in: fade up from below (`@keyframes fadeUp`)
- Subheadline animates in 0.2s later
- Button animates in 0.4s later
- Floating/pulsing badge (use `@keyframes pulse`)
- Background has subtle movement (`@keyframes gradientShift` — shift background-position)

### Animation Code Starter:
```css
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(24px); }
  to { opacity: 1; transform: translateY(0); }
}
.hero h1 { animation: fadeUp 0.7s ease forwards; }
.hero p  { animation: fadeUp 0.7s ease 0.2s both; }
.hero .btn { animation: fadeUp 0.7s ease 0.4s both; }
```

### Stretch: Add a subtle particle or star effect using multiple `box-shadow` values on a pseudo-element.
$B$),

  (18,'Product Page','HTML','HTML','intermediate',
   'Build a product detail page with image, details, variants, and add-to-cart section — like a real e-commerce product page.',
   $B$## Project: Product Page

Build a product page for a fictional tech gadget or coding accessory.

### Required Sections:
**Left column:**
- Main product image (large)
- Thumbnail strip (3 small clickable thumbnails)

**Right column:**
- Brand/category
- Product name (h1)
- Star rating + review count
- Price (sale price + original crossed out)
- Short description
- Size/colour variant selector (radio buttons styled as pills)
- Quantity selector (+/- buttons)
- "Add to Cart" button (large, full width)
- "Add to Wishlist" text link
- Shipping estimate
- Return policy snippet

### Below the fold:
- Tabs: Description | Specifications | Reviews
- "You May Also Like" card grid (3 products)

### Key CSS techniques: Two-column flexbox layout, sticky right column on desktop, tab switching with JS.
$B$),

  (19,'Blog Post Page','HTML','HTML','intermediate',
   'Build a full-length styled blog post page with a sidebar, complete typographic styling, and share buttons.',
   $B$## Project: Blog Post Page

Build a styled single blog post page — like a Medium article.

### Article Content:
- Hero image (full width, aspect-ratio 16/9)
- Title, author byline, date, reading time
- Article body: headings, paragraphs, a blockquote, an image with caption, an ordered list, a code block
- Tags at the bottom
- Author bio section

### Sidebar (sticky):
- Table of contents (links to each heading in the article)
- "Share" buttons (just styled links, no real sharing needed)
- "Related Posts" widget (3 small cards)
- Newsletter subscribe box

### Typography Requirements:
- Body text: Georgia or a serif Google Font, 18px, line-height 1.8
- `max-width: 680px` on the article content for readability
- Pull quote styled with left border and large italic text
- Code block: `background: #1E2140; color: #F5C518; font-family: monospace; padding: 16px; border-radius: 8px;`
$B$),

  (20,'Team Members Page','HTML','HTML','intermediate',
   'Build a team grid page with 6 member cards including hover overlay with bio text.',
   $B$## Project: Team Members Page

Build a team page for a fictional company (or CODEship Academy).

### Requirements:
- 6 team member cards
- Grid layout: 3 columns on desktop, 2 on tablet, 1 on mobile
- Each card has: photo, name, role, 2-sentence bio, social links
- **Hover overlay effect:** On hover, a semi-transparent overlay slides up from the bottom revealing the full bio and social links
- Department filter: buttons to show "All", "Engineering", "Design", "Marketing"

### Overlay CSS Pattern:
```css
.card-overlay {
  position: absolute; inset: 0;
  background: rgba(30,33,64,0.9);
  transform: translateY(100%);
  transition: transform 0.3s ease;
}
.card:hover .card-overlay { transform: translateY(0); }
```
$B$),

  (21,'Responsive Navigation','CSS','CSS','intermediate',
   'Build a navigation bar that collapses into a hamburger menu on mobile using CSS and minimal JavaScript.',
   $B$## Project: Responsive Navigation

Build a navigation that works perfectly at all screen sizes.

### Desktop (1024px+):
- Logo left, links centre, CTA button right
- Dropdown menu under one nav item

### Tablet (768px–1024px):
- Logo left, hamburger icon right
- 5 main links still visible horizontally (just smaller)

### Mobile (<768px):
- Logo left, hamburger (☰) right
- Click hamburger: slide-down menu with all links stacked vertically
- The ☰ animates to × when open
- Clicking a link closes the menu

### JavaScript (20 lines max):
```javascript
const toggle = document.querySelector('.nav-toggle');
const menu = document.querySelector('.nav-menu');
toggle.addEventListener('click', () => {
  menu.classList.toggle('open');
  toggle.setAttribute('aria-expanded', menu.classList.contains('open'));
});
```
$B$),

  (22,'CSS Art — Geometric Shapes','CSS','CSS','intermediate',
   'Create a piece of CSS art using only divs, borders, and CSS shapes — no images.',
   $B$## Project: CSS Art

Create a scene or object using ONLY CSS — no SVG, no images, no canvas.

### Ideas:
- A landscape scene (mountains, sun, clouds)
- A retro computer or phone
- A rocket ship in space
- The CODEship logo recreated in CSS
- A portrait (simplified geometric face)

### Techniques to use:
- `border-radius` for circles and organic shapes
- `clip-path` for triangles and polygons
- `box-shadow` for repeated shapes or glow
- `::before` and `::after` pseudo-elements
- CSS gradients for colour fills
- `transform` for rotations and positioning

### Challenge: Add a subtle animation to bring it to life — a blinking light, a rotating element, a drifting cloud.

### Share: Post your CSS art in the CODEship community gallery!
$B$),

  (23,'Testimonials Section','HTML','HTML','intermediate',
   'Build a testimonials section with 3 quote cards and a star rating, styled to build trust.',
   $B$## Project: Testimonials Section

Build a trust-building testimonials section — the kind seen on every SaaS and education website.

### Requirements:
- 3 testimonial cards displayed in a row
- Each card contains:
  - Star rating (5 gold stars using CSS)
  - Quote text (in `<blockquote>`)
  - Author avatar (round photo)
  - Author name and credential (e.g., "Parent of a Grade 3 student")
  - Source (e.g., "Google Review")

### Design:
- Cards have a subtle quote mark (`"`) as a large decorative background character
- Light background (`#F8F9FE`) with white cards
- Cards have `box-shadow` and `border-radius`
- On hover: card lifts with deeper shadow

### Stretch Goals:
- Make it a carousel: only show 1 card on mobile with prev/next arrows
- Add a "total reviews" count and aggregate star rating above the cards
- Add a logo strip below showing publications where you've been featured
$B$),

  (24,'Pricing Table','CSS','CSS','intermediate',
   'Build a 3-tier pricing table with a highlighted "Most Popular" plan using CSS Grid.',
   $B$## Project: Pricing Table

Build the pricing section for CODEship Academy (or invent a SaaS product).

### The Three Plans:
- **Starter** — Free, limited features
- **Pro** — $19/month, most popular (highlighted)
- **School** — $299/month, for institutions

### Requirements for each plan card:
- Plan name
- Price (large, prominent) with billing period
- Feature list (8 items): use ✓ for included, ✗ for not included
- Primary CTA button
- Fine print (cancel anytime, etc.)

### "Most Popular" Card:
- Scaled up with `transform: scale(1.05)` 
- Different background colour (navy or gold)
- "MOST POPULAR" badge at the top
- More prominent button

### Layout:
- CSS Grid: `grid-template-columns: 1fr 1fr 1fr`
- `align-items: start` so cards don't stretch to same height (unless you want them to)
- Responsive: stack on mobile

### Toggle: Add a Monthly/Annual toggle that switches displayed prices.
$B$),

  (25,'Restaurant Homepage','HTML','HTML','intermediate',
   'Build a full restaurant website homepage with hero, menu preview, gallery, hours, and reservation form.',
   $B$## Project: Restaurant Homepage

Build a complete restaurant website homepage.

### Sections Required:
1. **Hero** — Full-width photo background, restaurant name, "Reserve a Table" CTA
2. **About** — Story paragraph + 2 small photos in a grid
3. **Menu Preview** — 6 dishes in a 3-col grid (photo, name, description, price)
4. **Gallery** — 6-photo masonry-style grid
5. **Hours & Location** — Table of opening hours + embedded Google Map
6. **Reservation Form** — Date, time, party size, name, phone, special requests
7. **Footer** — Logo, nav links, social icons, address

### Design Palette: Warm, rich colours (deep brown, cream, gold)
### Typography: Playfair Display for headings, Nunito or Lato for body

### Key Techniques:
- Full-width hero with `background-image` and overlay
- Menu grid with `object-fit: cover` on dish photos
- Sticky header that becomes opaque on scroll (JavaScript: `window.addEventListener('scroll', ...)`)
$B$),

  (26,'Scratch Platform Jumper Game','Scratch','Scratch','intermediate',
   'Build a complete platform jumper game in Scratch with gravity, multiple platforms, a score, and a goal flag.',
   $B$## Project: Scratch Platform Jumper

Using everything from Lesson 33, build your own complete platform game.

### Required Elements:
- **Player sprite** — walks left/right with arrow keys, jumps with spacebar
- **Gravity** — applied every frame using a `yVelocity` variable
- **At least 5 platforms** — at different heights and lengths
- **Coins to collect** — at least 8, use clones
- **Score counter** — increases when coins are collected
- **Lives counter** — starts at 3, decreases when you fall off the bottom
- **Game Over screen** — when lives reach 0
- **Win condition** — reach a flag/goal to complete the level
- **Sound effects** — jump, collect, hurt, win sounds

### Polish Requirements:
- Walk animation (next costume while moving)
- Idle animation (breathing/blinking while standing still)
- Coin spin animation
- Falling sound effect

### Difficulty Tweak:
After the game works, adjust the `yVelocity` gravity amount until the jump height feels right — this is playtesting, and it's a real game development skill.
$B$),

  (27,'Scratch Quiz Show','Scratch','Scratch','intermediate',
   'Build a full Scratch quiz game with 10 questions, a timer, score, and animated right/wrong feedback.',
   $B$## Project: Scratch Quiz Show

Build a polished, complete quiz game on scratch.mit.edu.

### Requirements:
- 10 questions stored in a List
- 10 correct answers in a parallel List
- Timer bar that counts down 15 seconds per question (visual progress bar sprite)
- Score displayed on screen
- Right answer: green flash, +10 points, celebration sound
- Wrong answer: red flash, show correct answer briefly
- At the end: final score screen with grade (A/B/C/D/F)

### Choose Your Own Topic:
- Canadian geography
- Space and planets
- CODEship Academy curriculum
- Minecraft facts
- Math problems for your grade level

### Polish:
- Animated host sprite that reacts (happy/sad) based on right/wrong
- Background music throughout
- Distinct intro screen with "Click to Start"
- Game Over screen with "Play Again" button (resets all variables and starts over)

### Publish it to the Scratch community — see if your classmates can beat your high score!
$B$),

  (28,'Scratch Catch Game','Scratch','Scratch','intermediate',
   'Build a falling-objects catch game where the player moves a basket left and right to catch items, with increasing difficulty.',
   $B$## Project: Scratch Catch Game

Build a classic catch game — falling objects, player-controlled basket, increasing speed.

### Game Design:
- Objects fall from the top at random X positions (use clones)
- Player moves a basket left and right using arrow keys
- Catch the object: +1 score, play a sound, object disappears
- Miss the object: -1 life, flash the screen red
- Objects fall faster every 5 points (`Speed` variable increases)
- New object spawns every `2 - (Score / 20)` seconds (gets faster)

### Multiple Object Types (Stretch):
- Gold coin: +10 points
- Apple: +1 point  
- Bomb: -1 life (player must AVOID these)
- Make them visually distinct with different costumes

### Variables Required:
- `Score`, `Lives`, `Speed`, `SpawnDelay`, `GameOver`

### Difficulty Curve: The game should be easy for the first 10 points, moderate at 20, and very fast at 30+. Adjust your numbers in playtesting.
$B$),

  (29,'Scratch Maze Game','Scratch','Scratch','advanced',
   'Build a maze game where a sprite navigates through walls to reach an exit, with level progression.',
   $B$## Project: Scratch Maze Game

Build a top-down maze where the player navigates to the exit without touching walls.

### Core Technique (Colour Detection):
```
When green flag clicked:
Forever:
  if key[right arrow] pressed then
    change x by 3
    if touching colour [wall colour] then
      change x by -3  ← Undo the move!
    end
  end
```
Use the same pattern for left, up, and down.

### Requirements:
- At least 3 maze levels (3 backdrop designs)
- Wall collision using colour detection
- Goal/exit sprite that triggers next level when touched
- Move counter (how many moves to complete?)
- Timer
- Start screen and completion screen

### Creating the Maze:
- Design maze walls in the Backdrop editor using the paint tool
- Use a consistent wall colour (e.g., pure black `#000000`)
- Leave openings at least 30px wide so the player sprite can fit through

### Stretch: Make it a 2-player game — Player 1 uses WASD, Player 2 uses arrow keys. Race to the exit!
$B$),

  (30,'Scratch Art Generator','Scratch','Scratch','intermediate',
   'Build an interactive art generator in Scratch where mouse movement creates colourful patterns using the pen tool.',
   $B$## Project: Scratch Art Generator

Build a generative art tool that creates beautiful patterns from user input.

### The Pen Extension:
In Scratch, go to Extensions (bottom left) → Pen. This adds blocks for drawing on the stage.

### Basic Pattern Tool:
```
When green flag clicked:
Erase all
Forever:
  go to [mouse-pointer]
  Pen down
  set pen colour to [pick random 1 to 200] (use hue)
  set pen size to [pick random 1 to 5]
```

### Add These Modes (switch with number keys):
1. **Follow mode**: Sprite follows mouse, drawing continuously
2. **Stamp mode**: Sprites stamp at mouse position on click
3. **Mirror mode**: Draws at mouse position AND mirrored positions (use 4 sprites)
4. **Spiral mode**: Sprite moves in circles of increasing radius

### Controls:
- **Space bar**: Clear the canvas
- **1-4**: Switch modes
- **Up/Down arrows**: Change brush size
- **S key**: Save (screenshot) — instruct in the project notes

### Share on Scratch — your friends can create art with it!
$B$),

  (31,'FAQ Accordion Page','HTML','HTML','intermediate',
   'Build a Frequently Asked Questions page with an accordion that expands/collapses answers on click.',
   $B$## Project: FAQ Accordion Page

Build a FAQ page for CODEship Academy (or any topic you choose).

### Requirements:
- At least 10 questions
- Accordion behaviour: clicking a question expands the answer; clicking again collapses it
- Only ONE answer open at a time (opening one closes others)
- Smooth animation when expanding/collapsing

### Accessible HTML Pattern:
```html
<div class="faq-item">
  <button class="faq-question" aria-expanded="false">
    What age group is CODEship for?
    <span class="faq-icon">+</span>
  </button>
  <div class="faq-answer" hidden>
    <p>CODEship Academy serves students in Kindergarten through Grade 8...</p>
  </div>
</div>
```

### JavaScript:
```javascript
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const isOpen = btn.getAttribute('aria-expanded') === 'true';
    // Close all
    document.querySelectorAll('.faq-question').forEach(b => {
      b.setAttribute('aria-expanded', 'false');
      b.nextElementSibling.hidden = true;
    });
    // Open this one (if it was closed)
    if (!isOpen) {
      btn.setAttribute('aria-expanded', 'true');
      btn.nextElementSibling.hidden = false;
    }
  });
});
```

### Design: Clean, readable. Use `max-height` transition for smooth animation. Group questions by category.
$B$),

  (32,'Timeline Page','CSS','CSS','intermediate',
   'Build a vertical timeline showing a sequence of events or achievements with alternating left-right layout.',
   $B$## Project: Timeline Page

Build a visual timeline — perfect for: your coding journey, a historical event, a personal biography, or a project roadmap.

### Layout: Alternating Left-Right
```
   2022                           2023
   ●────────────────────    ────────────────────●
   │ Started Scratch Jr │    │   Joined CODEship  │
   └────────────────────┘    └────────────────────┘
```

### HTML Pattern:
```html
<div class="timeline">
  <div class="timeline-item left">
    <div class="timeline-dot"></div>
    <div class="timeline-content">
      <time>September 2022</time>
      <h3>Started Learning HTML</h3>
      <p>Built my very first webpage...</p>
    </div>
  </div>
  <div class="timeline-item right">...</div>
</div>
```

### CSS Key Points:
- Central vertical line: `::before` on `.timeline` with `position: absolute; left: 50%; width: 2px`
- `.timeline-item.left` content aligns right; `.right` content aligns left
- Dots at the centre: `position: absolute` circles on the line
- Appear animation: items fade in as you scroll (add class with IntersectionObserver)

### At least 6 events. Choose your own theme.
$B$),

  (33,'Progress Bar Collection','CSS','CSS','intermediate',
   'Build 6 different styled progress bar variants showing different techniques for displaying percentage values.',
   $B$## Project: Progress Bar Collection

Build a showcase of 6 different progress bar designs — a useful component reference for future projects.

### The 6 Variants:
1. **Basic horizontal** — Simple filled bar with label and percentage
2. **Striped animated** — CSS `repeating-linear-gradient` stripes that move with animation
3. **Circular** — A circle with `conic-gradient` showing percentage
4. **Multi-segment** — A bar divided into labelled segments (e.g., budget breakdown)
5. **Skill bars** — A set of stacked bars (HTML 80%, CSS 65%, Scratch 90%)
6. **Step indicator** — Shows Step 1, Step 2, Step 3 as connected dots with filled line

### For each, show:
- The visual progress bar
- The HTML used to build it
- The key CSS technique in a code block

### Circular progress bar CSS:
```css
.circle-progress {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: conic-gradient(#F5C518 72%, #E8EAF6 72%);
  /* 72% = 0.72 * 360deg = 259.2deg in the gradient */
}
```
$B$),

  (34,'Icon Grid with Hover Effects','CSS','CSS','intermediate',
   'Build a technology skills grid with icon cards that reveal a tooltip or skill description on hover.',
   $B$## Project: Icon Grid with Hover Effects

Build a skill/technology showcase grid where each icon card reveals information on hover.

### Grid Requirements:
- At least 12 technology icons (use emoji if no SVGs: 🌐 HTML, 🎨 CSS, ⚡ JS, 🐍 Python, etc.)
- Cards in a responsive grid: 6 columns desktop, 4 tablet, 3 mobile
- Each card: icon, technology name, proficiency badge ("Learning", "Comfortable", "Proficient")

### Hover Effect — Two Options (pick one or build both):
**Option A: Tooltip popup**
```css
.tech-card .tooltip {
  position: absolute; bottom: 110%; left: 50%;
  transform: translateX(-50%);
  opacity: 0; transition: opacity 0.2s;
}
.tech-card:hover .tooltip { opacity: 1; }
```

**Option B: Flip card**
```css
.card-inner { transform-style: preserve-3d; transition: transform 0.5s; }
.tech-card:hover .card-inner { transform: rotateY(180deg); }
.card-front { backface-visibility: hidden; }
.card-back { backface-visibility: hidden; transform: rotateY(180deg); }
```

### Proficiency Colour Coding:
- Learning: orange badge
- Comfortable: blue badge
- Proficient: green badge
$B$),

  (35,'Dark Mode Website','CSS','CSS','advanced',
   'Build a complete website page with a light/dark mode toggle using CSS variables and JavaScript to persist the preference.',
   $B$## Project: Dark Mode Website

Build a complete page that has both light and dark modes, switchable with a toggle button.

### Implementation Using CSS Variables:
```css
:root {
  --bg: #F8F9FE;
  --bg-card: #FFFFFF;
  --text: #2B2D42;
  --text-muted: #8B90B0;
  --border: #E8EAF6;
}

[data-theme="dark"] {
  --bg: #0F1117;
  --bg-card: #1A1D2E;
  --text: #E8EAF6;
  --text-muted: #6B7280;
  --border: #2D3148;
}
```

### Toggle Button:
```javascript
const toggle = document.querySelector('.theme-toggle');
const root = document.documentElement;

// Load saved preference
const saved = localStorage.getItem('theme') || 'light';
root.setAttribute('data-theme', saved);

toggle.addEventListener('click', () => {
  const current = root.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  toggle.textContent = next === 'dark' ? '☀️' : '🌙';
});
```

### The Page:
Build a content-rich page (blog post, product page, or dashboard) that clearly demonstrates the mode switch works across: background, cards, text, borders, buttons, and inputs.
$B$),

  (36,'Animated Loading Screen','CSS','CSS','advanced',
   'Build a branded loading/splash screen with CSS animations that fades away after 2 seconds.',
   $B$## Project: Animated Loading Screen

Build a branded loading screen that plays an animation then fades away to reveal the page.

### Animation Sequence:
1. Logo icon appears (scale from 0 to 1)
2. Logo text fades in
3. Loading bar fills from 0% to 100%
4. After 2s: entire screen fades out, page content revealed

### CSS Animations:
```css
@keyframes appear { from { opacity: 0; transform: scale(0.5); } to { opacity: 1; transform: scale(1); } }
@keyframes fill { from { width: 0; } to { width: 100%; } }
@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; pointer-events: none; } }

.loader-logo { animation: appear 0.5s ease forwards; }
.loader-bar-fill { animation: fill 1.8s ease forwards; }
.loader { animation: fadeOut 0.4s ease 2s both; }
```

### JavaScript Hide:
```javascript
setTimeout(() => {
  document.querySelector('.loader').style.display = 'none';
}, 2400); // 2s + 0.4s fadeout
```

### Build the page that appears underneath — at minimum a hero section that looks great when revealed.
$B$),

  (37,'Science Fair Poster Page','HTML','HTML','intermediate',
   'Build a science fair style project presentation page with hypothesis, methodology, results (data table), and conclusion.',
   $B$## Project: Science Fair Poster Page

Build a digital science fair poster — structured like the real tri-fold boards you'd use at school.

### Required Sections:
1. **Title** — Large, eye-catching project name
2. **Question** — The scientific question you investigated
3. **Hypothesis** — Your prediction before the experiment
4. **Background Research** — 2-3 paragraphs of context
5. **Materials** — Bulleted list
6. **Procedure** — Numbered step-by-step instructions
7. **Results** — Data table AND a visual (bar chart with CSS or SVG)
8. **Conclusion** — What you found, was your hypothesis correct?
9. **References** — Proper bibliography

### Design:
- Blue/white/gold colour scheme (science = credibility)
- Clear section separators
- Data table properly styled with alternating rows
- Print-friendly styles (`@media print`)

### Topic Ideas: Effect of light on plant growth, salt water vs fresh water ice melting, paper airplane designs.
$B$),

  (38,'My Pets Page','HTML','HTML','beginner',
   'Build a dedicated page about your pets (real or fictional) with photos, fun facts, and care information.',
   $B$## Project: My Pets Page

Build a loving tribute to your pets — real or imaginary!

### Requirements:
- Each pet gets its own `<section>` or `<article>`
- Pet profile includes: name, species, age, photo or emoji, personality description
- A "Fun Facts" list for each pet (at least 5 facts)
- A "Care Guide" section with how to care for that type of pet (ordered list)
- A comparison table if you have multiple pets

### If You Don't Have Pets:
- Fictional pets (dragons, robots, aliens)
- Pets you'd want to have someday
- Famous fictional pets (Scooby-Doo, Pikachu, Clifford)

### Extra Sections:
- "A Day in the Life" — a mini timeline of your pet's typical day
- Photo gallery (use real photos or placeholder coloured boxes)
- "Did You Know?" — 3 interesting facts about this animal species

### Make it personal and fun — this is a chance to write with your own voice!
$B$),

  (39,'Sports Stats Table','HTML','HTML','intermediate',
   'Build a sortable sports league standings or statistics table with styling for wins, losses, and ranking.',
   $B$## Project: Sports Stats Table

Build a styled sports statistics page for your favourite sport (real or invented).

### Requirements:
- Full league standings table with at least 8 teams/players
- Columns: Rank, Team/Player, Wins, Losses, Points, Last 5 Games (W/L/W/L/W format)
- Top 3 teams highlighted (gold, silver, bronze background)
- Your favourite team highlighted with a different colour
- Responsive: horizontal scroll on mobile
- Team logos (use emojis or flag emojis)

### Table Polish:
- Striped rows (`nth-child(even)`)
- Fixed table header (stays visible when scrolling a long table)
- Win/loss record column: green for winning record, red for losing
- Last 5 games shown as coloured dots: green dot = W, red dot = L

### Bonus: Player Stats Table
Add a second table below the standings showing top player statistics — goals/points/assists etc.
$B$),

  (40,'Local Heroes Feature Page','HTML','HTML','intermediate',
   'Build a feature article page about real local heroes or changemakers in your community.',
   $B$## Project: Local Heroes Feature Page

Research and build a feature article about people who are making a positive difference in your community.

### Find Your Heroes:
- Teachers who inspired you
- Local business owners or entrepreneurs  
- Community volunteers
- Local athletes
- Environmental advocates
- Young changemakers your age or close to it

### Page Structure:
- Introduction to the concept of local heroes
- 3–5 individual profiles, each as an `<article>`:
  - Portrait photo (or placeholder)
  - Name and tagline
  - Their story (2-3 paragraphs)
  - "What makes them a hero" quote
  - How to support/follow them

### Journalistic Writing Tips:
- Use real facts (research if possible)
- Write in third person ("Sarah Chen is a...")
- Include a specific achievement with a number: "She has taught over 500 students..."

### Privacy Note: If featuring real people you know, get their permission first.
$B$)
) AS t(n, title, category, lang, difficulty, description, brief);


INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'bld-p' || n, title, 'Builders', category, lang, difficulty, 40, 'published',
  description, brief,
  '<!-- ' || title || ' -->\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>' || title || '</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n</body>\n</html>',
  ARRAY['builders', 'project'], n
FROM (VALUES
  (41,'Country Profile Page','HTML','HTML','intermediate',
   'Research a country and build a comprehensive profile page with facts, map embed, and cultural highlights.',
   $B$## Country Profile Page

Pick any country and build a thorough profile page a student might use for a geography project.

### Required Sections:
- **Flag and basic facts** — Capital, population, area, language, currency (use a facts table)
- **Geography** — Regions, climate, major cities
- **Culture** — Food, music, art, traditions
- **History** — 5 key historical events on a mini timeline
- **Embed** — Google Maps embed of the country
- **Did You Know?** — 5 surprising facts

### Design: Use colours from the country's flag in your colour scheme.

### Sources: CIA World Factbook, Wikipedia, official government sites. Cite them in your footer.
$B$),

  (42,'Book Report Page','HTML','HTML','beginner',
   'Build a styled book report webpage for a book you have read, with summary, analysis, and recommendation.',
   $B$## Book Report Page

Build a digital version of a school book report — but make it look like a real book review website.

### Sections Required:
1. **Book cover image** (use the real cover from Google Images — cite it!)
2. **Book basics** — Title, Author, Year, Genre, Pages, Your Rating (stars)
3. **Plot Summary** — 3 paragraphs (setup, conflict, resolution — no spoilers in the title!)
4. **Your Favourite Character** — Name, why you liked them, a quote if you can find one
5. **A Meaningful Quote** — From the book, in a styled blockquote
6. **Would You Recommend It?** — Who would love this book and why
7. **Similar Books** — 3 other books you'd suggest for fans

### Style it like a real book review site (think Goodreads). Use book cover colours in your palette.
$B$),

  (43,'Digital Art Gallery','CSS','CSS','intermediate',
   'Build a gallery page showcasing CSS art pieces — either ones you created or a curated collection of CSS art.',
   $B$## Digital Art Gallery

Build a gallery website dedicated to CSS art — art made entirely with HTML and CSS.

### Your Gallery Contains:
- At least 5 CSS art pieces (ones you made in previous projects, or new ones)
- A gallery grid with consistent card sizes
- A detail view for each piece

### Each Gallery Card:
- The CSS art itself (live, in the browser — not a screenshot)
- Title and brief description
- Technique used (e.g., "clip-path polygons", "CSS gradients", "box-shadow")
- Time taken

### Gallery Grid:
```css
.gallery {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
}
.artwork-frame {
  aspect-ratio: 1/1;
  overflow: hidden;
  background: white;
}
```

### "Create Your Own" CTA: A button that links to the CSS Art project page.
$B$),

  (44,'Seasonal Greeting Card','CSS','CSS','intermediate',
   'Design a virtual greeting card with CSS animations — choose a season or holiday theme.',
   $B$## Seasonal Greeting Card

Build a beautiful virtual greeting card that could be emailed or shared as a URL.

### Choose Your Theme:
- Winter / Holiday
- Spring / Easter
- Summer / Back to School
- Halloween / Autumn
- Birthday
- Graduation / End of Year

### Required Elements:
- Animated background (falling snow, floating leaves, bouncing stars...)
- The greeting text with a stylish animation entrance
- Signature area
- A "Send This Card" button (can be a mailto link)

### Key Animation: Use `@keyframes` and `animation-delay` on many cloned elements to create a particle effect:
```css
.snowflake { animation: fall linear infinite; }
.snowflake:nth-child(1) { animation-duration: 4s; animation-delay: 0s; left: 10%; }
.snowflake:nth-child(2) { animation-duration: 6s; animation-delay: 1s; left: 30%; }
/* etc. for 20 snowflakes */
```

### Make it genuinely beautiful — this is a project to send to someone you care about.
$B$),

  (45,'Environmental Impact Page','HTML','HTML','intermediate',
   'Build an awareness page about an environmental issue with data visualisation and calls to action.',
   $B$## Environmental Impact Page

Build an educational page about an environmental issue you care about.

### Topic Options:
- Plastic in the ocean
- Carbon footprint
- Species extinction
- Water scarcity
- Deforestation

### Required Sections:
1. **The Problem** — What is happening? (with a striking statistic as a hero number)
2. **Visual Data** — Use CSS to create a simple bar chart or infographic showing scale
3. **Root Causes** — Numbered list of main causes
4. **The Impact** — Who/what is affected and how
5. **Solutions** — What individuals, businesses, and governments can do
6. **Take Action** — 5 specific things the reader can do TODAY
7. **Resources** — Links to organisations working on this issue

### Design: Use colours that evoke your topic (blues for ocean, greens for forests, etc.)

### Data Visualisation: Build a CSS bar chart where each bar's width is a percentage:
```html
<div class="bar" style="--value: 73%" aria-label="73% of ocean plastic comes from 10 rivers">
  <span class="bar-label">10 Major Rivers</span>
  <span class="bar-value">73%</span>
</div>
```
$B$),

  (46,'Fictional Technology Store','HTML','HTML','intermediate',
   'Build a product listing page for a fictional technology store with at least 8 products in a filterable grid.',
   $B$## Fictional Technology Store

Design and build a product listing page for your own imaginary tech store.

### Invent Your Store:
- A gadget shop set in the future
- A magic item store for wizards who use technology
- A store for space travellers
- An alien technology shop

### Requirements:
- Store name, logo (emoji + text), tagline
- At least 8 fictional products in a grid
- Each product: image (illustrated or emoji-based), name, description, price, "Add to Cart" button
- **Category filter** — at least 3 categories (e.g., Communication, Transport, Energy)
- **Price sort** — Low to High / High to Low (JavaScript required)
- Cart counter in nav that increments when "Add to Cart" is clicked

### Product Card Design: Keep consistent sizing — `aspect-ratio: 4/3` for product images, same card height with flexbox column layout.

### Stretch: Add a search bar that filters products by name as you type.
$B$),

  (47,'Responsive Image Gallery','CSS','CSS','intermediate',
   'Build a fully responsive photo gallery with CSS Grid auto-fill, hover effects, and a working lightbox.',
   $B$## Responsive Image Gallery

Build the most polished photo gallery you can — this is a portfolio-worthy project.

### Requirements:
- At least 12 images from Unsplash (free, cite them)
- CSS Grid with `auto-fill` and `minmax(250px, 1fr)` — fully responsive without media queries
- 2 "featured" images that span 2 columns
- Hover: image zooms slightly, caption slides up
- Lightbox: click any image → full-screen overlay with the image, caption, and prev/next navigation

### Lightbox Navigation:
```javascript
let currentIndex = 0;
const images = [...document.querySelectorAll('.gallery-item')];

document.addEventListener('keydown', e => {
  if (e.key === 'ArrowRight') showImage(currentIndex + 1);
  if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
  if (e.key === 'Escape') closeLightbox();
});
```

### Accessibility:
- All images have alt text
- Lightbox traps focus inside it
- Keyboard navigation with arrow keys and Escape

### Attribution Footer: List all photo credits with links to their Unsplash pages.
$B$),

  (48,'Interview with a Scientist','HTML','HTML','intermediate',
   'Write and design a Q&A interview page with a real or fictional scientist, styled like a magazine interview.',
   $B$## Interview with a Scientist

Write a Q&A interview with a scientist — real or invented — and design it as a magazine feature.

### The Interview:
- At least 8 question-and-answer pairs
- Topic: their field of research, how they got into it, advice for young people, current discoveries
- Written in first person for the scientist ("I started my research in...")

### Real Scientist Suggestions:
Research and "interview" (you write their answers based on their public work): Marie Curie, Albert Einstein, Nikola Tesla, Rosalind Franklin, Stephen Hawking, Katherine Johnson.

### Fictional Scientist: Invent a future scientist working on: AI, space colonisation, ocean exploration, time travel, cure for disease.

### Design (Magazine Style):
- Large pull quote in a decorative box
- Photo on the left, intro on the right
- Q&A section with questions in bold/different colour
- Sidebar with "Quick Facts" about the scientist
- Related reading section at the bottom

Use Playfair Display for headings for a print/magazine feel.
$B$),

  (49,'Song Lyrics Page with Typography','CSS','CSS','intermediate',
   'Choose a song and build a beautifully typeset lyrics page that uses CSS typography to create mood.',
   $B$## Song Lyrics Page with Typography

Choose a song you love and build a page that presents the lyrics in a visually beautiful, typographically considered way.

### IMPORTANT: You may only use lyrics in the public domain (before 1926) OR instrumental music (no lyrics). Alternatively, write your own original lyrics!

### The Goal: Typography TELLS the story
- Quiet verses: smaller, lighter text
- Loud chorus: larger, bolder text
- Bridge: different font or colour
- Repeated lines: visually distinct styling

### Technical Requirements:
- Custom Google Fonts (one for lyrics, one for structural text)
- Animated entrance: lyrics fade in line by line on load
- Colour palette derived from the song's mood
- `letter-spacing` and `line-height` fine-tuned for readability
- Hover on each line: subtle highlight

### Example CSS for Chorus:
```css
.chorus {
  font-size: clamp(1.2rem, 3vw, 2rem);
  font-weight: 900;
  letter-spacing: -0.02em;
  color: var(--colour-accent);
}
```
$B$),

  (50,'Portfolio Mid-Point Review','HTML','HTML','intermediate',
   'Create an updated portfolio page showcasing your best 6 projects with case study write-ups.',
   $B$## Portfolio Mid-Point Review

This is the most important project of the first half: your real, published portfolio.

### Requirements:
- 6 project cards, each with:
  - Screenshot or demo
  - Project title
  - Tech stack badges (HTML, CSS, Scratch, etc.)
  - 2-sentence description
  - "View Live" and "View Code" buttons
- Filterable by type (HTML, CSS, Scratch)
- About Me section
- Skills progress bars
- Contact form

### Quality Bar:
Every project shown must:
- Have a live URL (publish to Netlify)
- Be responsive (no broken mobile layouts)
- Have no broken images or links

### The Real Test:
Show this to someone who doesn't know you're learning to code. Do they understand what you built? Does it look professional? If yes — you've passed.

### Publish it. Send the link to admin@codeshipacademy.com — we'd love to see your work!
$B$),

  (51,'CSS-Only Accordion','CSS','CSS','advanced',
   'Build a working accordion component using only the details/summary HTML elements and CSS — no JavaScript.',
   $B$## CSS-Only Accordion

The `<details>` and `<summary>` elements provide native expand/collapse behaviour — no JavaScript needed.

### Requirements:
- At least 5 accordion items
- Smooth open/close animation using the `details[open]` selector
- Custom icon (not the default triangle): + changes to × when open
- Nested accordions: one item contains a sub-accordion

### HTML:
```html
<details class="accordion-item">
  <summary class="accordion-header">
    What is CODEship Academy?
    <span class="icon" aria-hidden="true">+</span>
  </summary>
  <div class="accordion-body">
    <p>CODEship Academy is an AI-powered coding education platform...</p>
  </div>
</details>
```

### CSS Animation Challenge:
The `details` element can't smoothly animate height. Work around using `max-height`:
```css
.accordion-body { max-height: 0; overflow: hidden; transition: max-height 0.3s ease; }
details[open] .accordion-body { max-height: 500px; }
```

### Change Icon:
```css
.accordion-header .icon::before { content: '+'; }
details[open] .accordion-header .icon::before { content: '×'; }
```
$B$),

  (52,'Multi-Step Form','HTML','HTML','intermediate',
   'Build a multi-step form wizard with step indicators, validation, and a summary review step.',
   $B$## Multi-Step Form

Build a multi-step registration form — the kind used for sign-ups that have too many fields to show at once.

### Steps (4 total):
1. **Personal Info** — Name, email, date of birth
2. **Choose Plan** — Radio button plan selector (3 plans as styled cards)
3. **Payment** — Card number, expiry, CVV (styled inputs — no real processing)
4. **Review** — Summary of all entered info, confirm button

### Step Indicator:
```html
<div class="step-indicator">
  <div class="step active">1<span>Personal</span></div>
  <div class="step-line"></div>
  <div class="step">2<span>Plan</span></div>
  <div class="step-line"></div>
  <div class="step">3<span>Payment</span></div>
</div>
```

### Navigation:
- Next button: validates current step before proceeding
- Back button: returns to previous step
- Each step is a `<div>` that is `display: none` except the active one

### Validation: Required fields must be filled; email must contain @; card number must be 16 digits.

### Accessibility: Focus moves to the first input of each new step.
$B$),

  (53,'Video Embed Page','HTML','HTML','beginner',
   'Build a curated video playlist page embedding YouTube videos on a topic you are passionate about.',
   $B$## Video Embed Page

Curate and present a collection of videos on a topic you care about.

### The Page:
- A title and intro paragraph about your topic
- At least 5 YouTube embeds in a responsive grid
- Each embed has a title, description, and category tag below it

### Topics Ideas:
- Coding tutorials
- Space exploration documentaries
- Your favourite sport highlights
- How things are made
- Amazing science experiments

### Embed Pattern:
```html
<div class="video-card">
  <div class="video-wrapper">
    <iframe 
      src="https://www.youtube.com/embed/VIDEO_ID?rel=0"
      title="Video title"
      allow="autoplay; encrypted-media" 
      allowfullscreen
      loading="lazy">
    </iframe>
  </div>
  <div class="video-info">
    <span class="tag">Tutorial</span>
    <h3>How to Build a Website in 10 Minutes</h3>
    <p>A quick intro to HTML and CSS...</p>
  </div>
</div>
```

### Grid: `display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));`
$B$),

  (54,'Community Event Page','HTML','HTML','intermediate',
   'Design a community event page for a fictional neighbourhood or school event with all required information.',
   $B$## Community Event Page

Plan and build the website for a fictional community event — a neighbourhood festival, school fair, or charity fundraiser.

### Your Event Needs:
- A catchy name and logo/emoji
- Date, time, location (with Google Maps embed)
- What's happening (schedule of activities)
- Who it benefits (if it's a fundraiser)
- Registration/RSVP form
- FAQ section (at least 5 questions)
- Contact information

### Design Requirements:
- Festive, welcoming aesthetic
- Countdown timer to the event date (JavaScript)
- Social sharing links
- Print-friendly version (`@media print` — hide the nav and footer)

### This project combines: forms, tables (schedule), maps, countdown timer, FAQ accordion, and responsive layout. It's one of the most complete projects yet!
$B$),

  (55,'Accessible Navigation Menu','HTML','HTML','intermediate',
   'Build a fully accessible navigation menu that works perfectly with keyboard and screen readers.',
   $B$## Accessible Navigation Menu

The challenge: build a navigation that passes all accessibility tests.

### Requirements:
- Desktop: horizontal nav with a dropdown under one item
- Mobile: hamburger menu
- **Keyboard accessible**: Tab to each item, Enter to activate, Escape to close dropdown
- **Screen reader**: proper ARIA labels, `aria-expanded`, `aria-haspopup`, `role="menu"`, `role="menuitem"`
- **Focus management**: when dropdown opens, focus moves to first item; Escape returns focus to trigger button
- **Skip link**: "Skip to main content" visible on focus

### Testing Checklist:
- [ ] Tab through the entire nav using only keyboard
- [ ] Dropdown opens with Enter, closes with Escape
- [ ] Screen reader announces "Navigation, 5 items, Home, link; Courses, submenu button..."
- [ ] Mobile hamburger has `aria-expanded` and `aria-label`
- [ ] No interactive elements are only reachable by mouse hover

### Run Lighthouse Accessibility audit — target 100% on the navigation area.
$B$),

  (56,'Newspaper Front Page','CSS','CSS','advanced',
   'Recreate the visual design of a newspaper front page using CSS Grid and multi-column layout.',
   $B$## Newspaper Front Page

Build a digital newspaper front page — this is an advanced CSS layout challenge.

### Layout Grid (complex!):
```
┌──────────────────────────────────────────────┐
│              NEWSPAPER MASTHEAD               │
│          THE CODER'S CHRONICLE                │
├───────────────────┬──────────────────────────┤
│ MAIN STORY (big)  │ Second story             │
│                   ├──────────────────────────┤
│   Photo + text    │ Third story              │
│                   ├──────────────────────────┤
│                   │ ADVERTISEMENT            │
├────────┬──────────┴──────────────────────────┤
│ Below-fold story  │ Sports | Weather | Arts  │
└───────────────────┴──────────────────────────┘
```

### Requirements:
- CSS Grid for the main layout
- Multi-column (`columns: 2`) for article body text
- Serif fonts (Playfair Display for headlines, Georgia for body)
- Real newspaper conventions: pull quote, photo captions, column rules (`column-rule`)
- Black/white/red colour scheme
- Today's date in the masthead
- Drop cap on the main article: `p:first-of-type::first-letter { float: left; font-size: 4em; }`
$B$),

  (57,'Product Comparison Chart','HTML','HTML','intermediate',
   'Build a comparison table showing features across three competing products with visual checkmarks and ratings.',
   $B$## Product Comparison Chart

Build a comparison chart — the kind you''d find on any SaaS pricing page.

### Compare: 3 coding platforms (real or fictional)
Example: CODEship Academy vs Tynker vs Scratch

### Table Structure:
- Rows: 12–15 features
- Columns: Feature name | Product A | Product B | Product C

### Feature Categories (use `rowspan` headers):
- **Curriculum**: Levels, Languages, Lessons
- **Experience**: AI Tutor, Games, Projects
- **Price**: Free tier, Monthly, Annual
- **Platform**: Web, iOS, Android, Bilingual

### Visual Checkmarks:
```css
td.yes::before { content: '✓'; color: #22C55E; font-weight: 900; }
td.no::before { content: '✗'; color: #EF4444; }
td.partial::before { content: '◐'; color: #F59E0B; }
```

### Your Product Wins: The comparison should legitimately highlight where CODEship is strongest.

### Sticky Header: The feature column and the header row both stay visible while scrolling.
$B$),

  (58,'My Coding Journey Blog Post','HTML','HTML','intermediate',
   'Write and design a personal blog post about your coding journey so far — your story, challenges, and victories.',
   $B$## My Coding Journey Blog Post

Write and publish a genuine personal essay about what learning to code has been like for you.

### Prompts to Address:
- Why did you start learning to code?
- What was the hardest thing you''ve learned so far?
- What was your proudest moment?
- What do you want to build someday?
- What advice would you give to someone just starting?

### Design (like a Medium article):
- Serif font for the body text
- Full-width hero image or gradient
- Author byline with avatar
- Pull quotes from key moments in your story
- `reading-time` estimate (`ceil(wordCount / 200)` minutes)

### Technical Requirements:
- Correct use of article, section, blockquote, time, cite elements
- Estimated reading time calculated with JavaScript:
```javascript
const words = document.querySelector('.post-body').textContent.split(' ').length;
document.querySelector('.reading-time').textContent = `${Math.ceil(words/200)} min read`;
```

### Publish on Netlify. This is a piece of writing you might keep for years.
$B$),

  (59,'City Guide Page','HTML','HTML','intermediate',
   'Build a travel city guide page for your city or a city you want to visit, with attractions, food, and tips.',
   $B$## City Guide Page

Build a travel guide for your city (Oshawa? Toronto? Ottawa?) or a dream destination.

### Sections:
1. **Hero** — Full-width city skyline or landmark photo with city name overlay
2. **Quick Facts** — Population, timezone, language, currency (facts table)
3. **Top Attractions** — 6 places with photo, name, address, and tip
4. **Where to Eat** — 4 restaurant recommendations with cuisine type and price range ($ to $$$$)
5. **Getting Around** — Transportation options with icons
6. **Best Time to Visit** — Monthly weather/events table
7. **Local Tips** — 5 insider tips in a styled tip box
8. **Map** — Google Maps embed centred on the city
9. **Nearby Day Trips** — 3 suggestions within 2 hours

### Design: Match the city''s personality:
- Oshawa: blue and gold (industrial pride)
- Paris: black and cream (elegance)
- Tokyo: pink and white (kawaii)
$B$),

  (60,'CSS Filters Retro Photo Effect','CSS','CSS','advanced',
   'Build a photo editing interface with CSS filter sliders that apply real-time effects to an image.',
   $B$## CSS Filters Retro Photo Effect

Build an in-browser photo editor using CSS filters and JavaScript range inputs.

### The Editor Interface:
- A photo displayed prominently
- Range sliders for each filter:
  - Brightness (0–200%)
  - Contrast (0–200%)
  - Saturation (0–200%)
  - Grayscale (0–100%)
  - Hue Rotation (0–360°)
  - Blur (0–10px)
  - Sepia (0–100%)

### Preset Filters (buttons):
- Original
- Vintage (sepia 0.8, contrast 1.1)
- Black & White (grayscale 1, contrast 1.2)
- Vivid (saturation 2, contrast 1.1)
- Dramatic (grayscale 0.5, contrast 1.5, brightness 0.8)

### JavaScript:
```javascript
function applyFilters() {
  const filters = {
    brightness: `${brightness.value}%`,
    contrast: `${contrast.value}%`,
    saturate: `${saturation.value}%`,
    grayscale: `${grayscale.value}%`,
    blur: `${blur.value}px`,
    sepia: `${sepia.value}%`
  };
  const filterString = Object.entries(filters)
    .map(([k,v]) => `${k}(${v})`).join(' ');
  photo.style.filter = filterString;
}
```

### The photo should ideally be one the student uploads (use `<input type="file">` + FileReader API).
$B$)
) AS t(n, title, category, lang, difficulty, description, brief);

-- Projects 61-100: Final batch
INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'bld-p' || n, title, 'Builders', category, lang, difficulty, 45, 'published',
  description, brief,
  '<!-- Starter: ' || title || ' -->\n<!DOCTYPE html>\n<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>' || title || '</title><link rel="stylesheet" href="styles.css"></head><body></body></html>',
  ARRAY['builders', 'project', lang], n
FROM (VALUES
  (61,'School Newsletter','HTML','HTML','intermediate',
   'Design and build a school newsletter as a webpage, with announcements, events, and student spotlight.',
   $B$## School Newsletter

Build a digital school newsletter for "CODEship Coding Academy" (or your real school).

### Newsletter Sections:
- **Masthead** — School name, newsletter name, issue number, date
- **Principal's Message** — Brief welcome paragraph
- **Announcements** — 3 important notices styled as alert boxes
- **Upcoming Events** — Table: Date, Event, Location, Who
- **Student Spotlight** — Feature one student achievement with photo
- **Class News** — 2-column multi-column layout of short class updates
- **Did You Know?** — Fun science or history fact
- **Lost & Found** — Bulleted list

### Print-Friendly: This newsletter should look great when printed to PDF. Add `@media print` styles.

### Email-Ready: Use inline styles for critical structural CSS — real email newsletters can't use external CSS files.
$B$),

  (62,'CSS Shapes Pattern Page','CSS','CSS','advanced',
   'Create a full pattern page made entirely with CSS geometric shapes — no images allowed.',
   $B$## CSS Shapes Pattern Page

Create a page entirely from geometric shapes made with CSS. No images, no SVG, no emoji — only `div`, CSS, and creativity.

### Pattern Challenge:
Build a visually interesting repeating pattern using CSS shapes. Consider:
- A tile pattern that could repeat across a floor
- A quilt block pattern
- An Islamic geometric pattern
- A honeycomb or hexagonal grid
- A checker pattern with 3D depth

### Techniques to Master:
- `clip-path: polygon()` for triangles and diamonds
- `border-radius: 50%` for circles
- `transform: rotate()` for diamonds
- CSS Grid or flexbox for repeating layout
- `::before` and `::after` pseudo-elements

### Required:
- At least 4 different geometric shapes
- A cohesive colour palette
- An animation: the pattern subtly shifts, rotates, or pulses
- Responsive: looks good at all sizes

### This is an open creative challenge — make something genuinely beautiful.
$B$),

  (63,'Favourite Movies List','HTML','HTML','beginner',
   'Build a movie collection page with ratings, descriptions, and links to trailers for your top 10 favourite films.',
   $B$## My Favourite Movies List

Build a movie collection page for your all-time favourite films.

### Movie Card Requirements (10 movies):
- Movie poster image (use actual posters from Google — cite them)
- Movie title and year
- Director
- Genre badges (action, comedy, sci-fi, etc.)
- Your rating (star display with CSS)
- 2-sentence review in your own words
- Link to trailer (YouTube embed or link)

### Page Features:
- Filter by genre
- Sort by: My Rating | Year | A-Z
- "My Movie Stats" sidebar: total movies, average rating, favourite director, favourite decade

### Design Inspiration: Letterboxd, IMDb, Rotten Tomatoes

### Movie Metadata Table (below cards):
| Title | Year | Director | Runtime | Your Rating |

### Important: Write your OWN reviews — don't copy from IMDb. Your genuine opinion is what makes it personal.
$B$),

  (64,'Sticky Header and Footer','CSS','CSS','intermediate',
   'Build a layout with a sticky header and a sticky footer that both stay visible while content scrolls between them.',
   $B$## Sticky Header and Footer Layout

Build a layout where both the header AND footer are always visible, with the main content scrolling between them.

### The Layout:
```css
body {
  display: flex;
  flex-direction: column;
  height: 100vh;
}
header { flex-shrink: 0; } /* Never shrinks */
main { flex: 1; overflow-y: auto; } /* Fills space, scrolls */
footer { flex-shrink: 0; }
```

### Header Contents:
- Logo + nav links
- Search bar
- User avatar with dropdown menu

### Footer Contents:
- Tab navigation (Dashboard, Courses, Progress, Settings)
- Active state on current tab
- Notification badge on one tab

### Content (main):
- Long enough to scroll (add fake content or a real article)
- The header search bar filters the content (simple text match with JavaScript)

### This exact layout is used by: mobile apps, dashboards, email clients. Mastering it opens up many real-world projects.
$B$),

  (65,'Photo Essay Page','HTML','HTML','intermediate',
   'Tell a visual story with 10+ photos and accompanying text in a scrolling photo essay format.',
   $B$## Photo Essay Page

Build a photo essay — a story told through a sequence of photos and text, like National Geographic or documentary journalism.

### Your Story:
Choose something you can photograph or find free images for:
- A day at a coding event
- Your neighbourhood over the seasons
- A process from start to finish (making a meal, building something)
- Before and after (renovating a room, growing a plant)
- A journey (a walk, a trip)

### Layout: Alternating photo-left + text-right and photo-right + text-left
```html
<section class="essay-panel panel-left">
  <figure><img src="" alt=""></figure>
  <div class="essay-text">
    <h2>The Beginning</h2>
    <p>It started on a cold morning in November...</p>
  </div>
</section>
<section class="essay-panel panel-right">
  <div class="essay-text">...</div>
  <figure><img src="" alt=""></figure>
</section>
```

### Full-Width Break Shots: Every 3 panels, include a full-width dramatic image with overlay text.

### Scroll Animation: Add `IntersectionObserver` so panels fade in as they scroll into view.
$B$),

  (66,'Animated Card Flip','CSS','CSS','advanced',
   'Build a set of cards that flip over on hover, revealing different content on the back using CSS 3D transforms.',
   $B$## Animated Card Flip

Build cards that flip over in 3D when hovered — revealing different content on the back.

### Use Cases (pick one):
- **Flashcards**: Front = question, back = answer
- **Team cards**: Front = photo + name, back = bio + contact
- **Product cards**: Front = product photo, back = quick specs
- **Language cards**: Front = word in English, back = French translation

### The CSS Technique:
```css
.card { perspective: 1000px; }
.card-inner {
  transform-style: preserve-3d;
  transition: transform 0.6s ease;
  position: relative;
}
.card:hover .card-inner { transform: rotateY(180deg); }

.card-front, .card-back {
  backface-visibility: hidden;
  position: absolute; inset: 0;
}
.card-back { transform: rotateY(180deg); }
```

### Requirements:
- At least 6 flip cards in a grid
- The flip is smooth and realistic (use `perspective`)
- Front and back have different background colours
- Also flips on keyboard focus (Tab + Enter) for accessibility

### Stretch: Add a "reveal all" button that flips all cards simultaneously.
$B$),

  (67,'Festival Programme Page','HTML','HTML','intermediate',
   'Design a full programme page for a fictional festival with schedule, lineup, and venue map.',
   $B$## Festival Programme Page

Design the official programme page for a fictional music or arts festival.

### Your Festival:
Name it, brand it, give it a personality. Ideas:
- CODEfest: A coding/tech festival
- LakeFest: A summer music festival in Oshawa
- Winter Lights: A holiday light festival
- BotanicFest: A garden arts festival

### Page Sections:
1. **Hero** — Festival name, dates, tagline, "Buy Tickets" CTA
2. **Line-Up Grid** — Artist/performer cards with photo, name, genre, set time
3. **Schedule** — A day-by-day timetable (use a table or CSS Grid)
4. **Stages** — Description of each stage/area (3 minimum)
5. **Getting There** — Map embed + transportation options
6. **FAQ** — 6 common questions
7. **Sponsors** — Logo grid (use branded emoji placeholders)

### Design: Should feel like a real festival brand. Choose a bold colour palette and stick to it throughout.
$B$),

  (68,'Ocean Conservation Page','HTML','HTML','intermediate',
   'Build a stunning, visually immersive awareness page about ocean conservation with ocean-themed CSS effects.',
   $B$## Ocean Conservation Page

Build a beautiful, immersive page about ocean conservation that uses CSS to evoke the feeling of being underwater.

### Visual Techniques:
- **Parallax hero**: background moves slower than content on scroll (`background-attachment: fixed`)
- **Wave animation**: `clip-path` or SVG wave that animates gently
- **Gradient backgrounds**: Deep ocean blues fading from dark to light
- **Floating elements**: Facts and figures that gently bob using `@keyframes float`

### Content Sections:
1. Immersive hero with wave animation
2. "The Numbers" — 5 statistics with large CSS-styled numbers
3. Threats: plastic, acidification, overfishing, coral bleaching — card grid
4. Species at Risk — photo cards with "Critical", "Threatened", "Vulnerable" badges
5. How You Can Help — action cards with icons
6. Organizations — links to WWF, Ocean Conservancy, etc. (with their logos cited)

### The goal: When a visitor lands on this page, they should FEEL the ocean — in the colours, the motion, the content.
$B$),

  (69,'Print-Friendly Resume','HTML','HTML','intermediate',
   'Build a resume that looks professional on screen AND prints perfectly as a one-page PDF.',
   $B$## Print-Friendly Resume

Build a real resume for yourself or a fictional character — optimised for both screen and print.

### Resume Sections:
- **Header** — Name (large), title, email, phone, LinkedIn, GitHub, location
- **Summary** — 2-3 sentence professional statement
- **Skills** — Two columns: Technical Skills | Soft Skills
- **Education** — School, dates, achievements
- **Projects** — 3 projects with tech stack and brief description
- **Activities/Awards** — Any clubs, honours, achievements

### Print CSS (Critical):
```css
@media print {
  body { font-size: 11pt; color: black; }
  @page { size: letter; margin: 0.75in; }
  header { border-bottom: 2pt solid black; }
  .no-print { display: none; } /* Hide download button */
  a::after { content: ""; } /* No URLs in print */
  section { break-inside: avoid; }
}
```

### Screen Version: Has subtle colours and hover effects on links.

### Print Version: Black and white, perfectly fits one A4 page.

### "Download PDF" Button: `onclick="window.print()"`
$B$),

  (70,'Planet Profile Pages','HTML','HTML','intermediate',
   'Build a solar system explorer with a profile page for each of the 8 planets.',
   $B$## Planet Profile Pages

Build an interactive solar system explorer with detailed profile pages for all 8 planets.

### Index Page (Solar System Overview):
- Interactive planet selector: 8 planet icons in an orbit-like layout
- Each planet is clickable and links to its profile page
- Animated: planets slowly orbit the sun (CSS `animation`)

### Each Planet Profile Page:
- Planet name (h1)
- Hero: large planet photo (NASA images are public domain — cite them)
- Quick Facts table: diameter, mass, distance from sun, day length, year length, moons
- "What's Special" — 3 unique facts about that planet
- Surface/atmosphere description
- Could humans live here? (fun speculative section)
- Links to: previous planet | next planet | back to solar system

### Design:
- Each planet gets its own colour scheme derived from its actual appearance
- Mercury: grey; Venus: golden; Earth: blue/green; Mars: rust-red; Jupiter: tan/brown/red; Saturn: golden; Uranus: teal; Neptune: deep blue

### Navigation: Persistent header shows all 8 planet icons for quick jumping between profiles.
$B$),

  (71,'Scratch Story with 5 Scenes','Scratch','Scratch','advanced',
   'Build a complete interactive story in Scratch with at least 5 scenes, branching choices, and multiple endings.',
   $B$## Scratch Story: 5 Scenes, Branching Choices

Build a polished interactive story in Scratch with real narrative arc and player agency.

### Story Requirements:
- Minimum 5 distinct scenes (different backdrops, characters, situations)
- At least 2 branching choice points (player picks what happens next)
- At least 2 different endings (good and bad/neutral)
- Character dialogue with say/think bubbles and timing
- Background music that matches each scene's mood
- Sound effects at key moments

### Suggested Arc:
- Scene 1: Introduction, establish the character and world
- Scene 2: Problem appears, first choice
- Scene 3A or 3B: Consequences of choice
- Scene 4: Climax
- Scene 5A or 5B: Resolution based on earlier choices

### Technical Standards:
- Use `broadcast and wait` to sequence scenes
- Use a `Chapter` variable to track progress
- All sprites hide/show appropriately for each scene
- Intro screen with "Click to Begin" before the story starts

### This is your most ambitious Scratch project yet — spend real time on the writing!
$B$),

  (72,'Scratch Musical Instrument','Scratch','Scratch','intermediate',
   'Build a musical instrument in Scratch that plays real notes when keys are pressed, with multiple instrument sounds.',
   $B$## Scratch Musical Instrument

Build a playable instrument in Scratch using the Music extension.

### Setup: Add the Music extension (Extensions → Music). This adds blocks for: play note, set instrument, set tempo.

### Build: A Piano (or your choice of instrument)
- 12 keys visible on screen (C, D, E, F, G, A, B + sharps/flats)
- Each key is a sprite
- Pressing the corresponding keyboard key plays the note
- Clicking the key sprite also plays it
- Key press animation: key "presses down" and changes colour briefly

### Key Mappings:
```
A key → C4  S key → D4  D key → E4
F key → F4  G key → G4  H key → A4  J key → B4
```

### Enhancements:
- Instrument selector: Piano, Violin, Guitar, Trumpet (use `set instrument` block)
- Tempo slider: a variable that controls how long notes play
- Record mode: records your sequence and plays it back
- 3 preset songs loaded in (simple nursery rhymes)

### Publish and challenge classmates to learn a song on your instrument!
$B$),

  (73,'Scratch Falling Objects Game','Scratch','Scratch','intermediate',
   'Build a polished falling objects avoidance game using clones, variables, and increasing difficulty.',
   $B$## Scratch Falling Objects Avoidance Game

Using clone techniques from Lesson 34, build a complete polished avoidance game.

### Game Design:
- Objects fall from the top. Player moves left/right to dodge them.
- Multiple object types: harmless ones, dangerous ones (red/spiky), bonus point items
- Increasing speed: every 10 seconds, `Speed` increases by 1
- Decreasing spawn delay: objects appear more frequently over time
- Score based on survival time (not caught objects)

### Polish Checklist:
- [ ] Smooth player movement (no jerky teleporting)
- [ ] Walk animation on player
- [ ] Hurt animation + brief invincibility when hit (player flashes for 2 seconds)
- [ ] Score displayed in a custom-designed counter (not the default readout)
- [ ] Combo system: survive 10 seconds without getting hit = "Combo!" banner
- [ ] High score that persists between rounds (displayed on game over screen)
- [ ] Background music that gets faster as speed increases (`set tempo`)

### Tutorial Level: First 15 seconds have slow speed so player can learn the controls.
$B$),

  (74,'Scratch Number Guessing Game','Scratch','Scratch','intermediate',
   'Build a polished number guessing game with hints, score tracking, and difficulty levels.',
   $B$## Scratch Number Guessing Game

Build a complete, polished number guessing game with multiple features.

### Core Gameplay:
- Computer picks a random number (range based on difficulty)
- Player guesses using `ask [] and wait`
- Hints: "Too high!", "Too low!", "Getting warmer!", "Getting colder!"
- Player has limited guesses (Easy: 10, Medium: 7, Hard: 5)
- Score: more points for fewer guesses

### Difficulty Selector (on start screen):
- Easy: 1–50, 10 guesses
- Medium: 1–100, 7 guesses
- Hard: 1–500, 5 guesses

### Hint Temperature System:
```
If difference < 5: "🔥 Burning hot!"
If difference < 15: "♨️ Warm"
If difference < 30: "🌡️ Getting there"
If difference > 30: "🧊 Ice cold"
```

### Animation:
- Correct guess: celebration explosion (use stamp effect or clone burst)
- Wrong guess with 1 attempt left: dramatic music and warning flash
- Game over: dramatic reveal of the correct number

### Statistics: Track total games played, total wins, best score, current win streak.
$B$),

  (75,'CSS Dark/Light Toggle','CSS','CSS','advanced',
   'Implement a system-aware dark/light mode with a manual override toggle and localStorage persistence.',
   $B$## CSS Dark/Light Mode: Complete Implementation

Build a page that automatically detects system dark/light mode preference AND lets users override it manually.

### Three States:
1. **Auto**: Follows `prefers-color-scheme` media query
2. **Manual Light**: User clicked ☀️ — stored in localStorage
3. **Manual Dark**: User clicked 🌙 — stored in localStorage

### JavaScript Logic:
```javascript
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
  document.documentElement.setAttribute('data-theme', savedTheme);
} // else: CSS media query handles it automatically

document.querySelector('.theme-toggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme') 
    || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
});
```

### CSS:
```css
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) { /* dark colours */ }
}
[data-theme="dark"] { /* dark colours */ }
[data-theme="light"] { /* light colours */ }
```

### Build a complete page (at minimum a blog post or product page) to demonstrate the mode switch.
$B$),

  (76,'Testimonial Slider','CSS','CSS','advanced',
   'Build an auto-playing testimonial carousel with manual controls, pause on hover, and keyboard navigation.',
   $B$## Testimonial Slider/Carousel

Build a professional auto-playing testimonial carousel.

### Requirements:
- 5 testimonials
- Auto-plays every 4 seconds
- Pauses on hover
- Prev/Next arrow buttons
- Dot indicators showing current slide
- Keyboard: Arrow keys and Escape to stop auto-play
- Smooth CSS transition between slides

### The Technique (CSS Transform):
```css
.slider-track {
  display: flex;
  transition: transform 0.5s ease;
}
.slide { flex: 0 0 100%; }
/* Move to slide 2: transform: translateX(-100%) */
/* Move to slide 3: transform: translateX(-200%) */
```

### JavaScript:
```javascript
let current = 0;
let timer = setInterval(next, 4000);

function goTo(n) {
  current = (n + slides.length) % slides.length;
  track.style.transform = `translateX(-${current * 100}%)`;
  dots.forEach((d,i) => d.classList.toggle('active', i === current));
}

function next() { goTo(current + 1); }
function prev() { goTo(current - 1); }

// Pause on hover
slider.addEventListener('mouseenter', () => clearInterval(timer));
slider.addEventListener('mouseleave', () => { timer = setInterval(next, 4000); });
```

### Accessibility: `aria-live="polite"` on the slide content so screen readers announce changes.
$B$),

  (77,'School Lunch Menu','HTML','HTML','intermediate',
   'Build a weekly school lunch menu with dietary labels, allergen information, and a printable version.',
   $B$## School Lunch Menu

Design a weekly cafeteria menu webpage — the kind that''d be displayed on a school''s website or TV screen.

### This Week's Menu (5 days × 3 options each):
- Main (A or B choice)
- Vegetarian option
- Salad bar (same every day)
- Dessert
- Drink options

### Requirements:
- Full 5-day grid (Monday–Friday as columns)
- Allergen badges: 🥜 Nuts, 🌾 Gluten, 🥛 Dairy, 🥚 Eggs, 🐟 Fish
- Dietary labels: 🌱 Vegan, 🥕 Vegetarian, 🌟 Student Favourite
- Calorie counts (optional)
- Printable version with `@media print`
- This week vs next week toggle

### Design: Should look like it belongs on a school website. Clean, readable, colourful enough to be appealing.

### Accessibility: All allergen information must also be in text form (not just emoji icons) for screen readers.
$B$),

  (78,'Biography Page','HTML','HTML','intermediate',
   'Write and design a long-form biography of a person you admire — historical or contemporary.',
   $B$## Biography Page

Research and write a biography of someone you genuinely admire, then design it as a beautiful, magazine-quality webpage.

### Suggested Subjects:
- A pioneer in computing (Ada Lovelace, Alan Turing, Grace Hopper, Tim Berners-Lee)
- A Canadian innovator or leader
- A scientist, artist, athlete, or changemaker
- A historical figure from a community you identify with

### Page Structure:
- **Hero** — Portrait photo, name, dates, tagline
- **Early Life** — Childhood and formative experiences
- **Rise to Prominence** — Key events and achievements
- **Major Accomplishments** — Timeline or highlighted achievements
- **Legacy** — What they left behind
- **Famous Quotes** — 3+ styled blockquotes
- **Learn More** — Links to books, documentaries, museums

### Research Standards:
- Use at least 3 different sources
- Cite them in a bibliography
- Write in your own words — no copy-pasting
- Include specific dates, places, and names
$B$),

  (79,'Game Review Page','HTML','HTML','intermediate',
   'Build a long-form game review page with score, pros/cons, screenshots, and a recommendation verdict.',
   $B$## Game Review Page

Write and design a real review of a video game you know well.

### Review Structure:
- **Score** — A numeric rating displayed prominently (e.g., 9.2/10 with a circular progress indicator)
- **Summary** — 3 sentence overall take
- **Pros** — Bulleted list of positives (at least 5)
- **Cons** — Bulleted list of negatives (at least 3)
- **Screenshots/Videos** — 4 images in a grid + 1 YouTube embed
- **Full Review** — 500+ word detailed analysis covering: Gameplay, Story, Graphics, Sound, Value
- **Who Is It For?** — Recommended audience description
- **Verdict** — Final recommendation badge: Must Play / Worth Playing / Wait for Sale / Skip

### Design: Dark, dramatic aesthetic (like IGN, GameSpot, or Metacritic)

### Scoring CSS:
```css
.score-ring {
  background: conic-gradient(#F5C518 calc(var(--score) * 1%), #1E2140 0);
  border-radius: 50%;
}
```
Set `--score: 92` for a 9.2/10 score.
$B$),

  (80,'Endangered Animals Page','HTML','HTML','intermediate',
   'Build an awareness page about endangered species with interactive cards and conservation status badges.',
   $B$## Endangered Animals Page

Build an educational awareness page about endangered animals.

### Content: 8 Endangered Species Cards
Each includes:
- Animal photo (use Wikimedia Commons — free and citable)
- Common name and scientific name
- Conservation Status badge: Critically Endangered / Endangered / Vulnerable
- Population estimate
- Where they live (map region highlighted)
- Why they're endangered (3 main threats)
- What's being done to save them
- "Adopt" link (WWF, World Animal Protection, etc.)

### Conservation Status Colours:
- Critically Endangered: Red (#EF4444)
- Endangered: Orange (#F59E0B)
- Vulnerable: Yellow (#EAB308)

### Interactive Features:
- Filter by status
- Filter by continent
- "Did you know?" random fact generator

### Partner with Reality: Link to real conservation organisations. This page could genuinely raise awareness.
$B$),

  (81,'Design System Showcase','CSS','CSS','advanced',
   'Build a complete design system documentation page showing all your components, tokens, and usage guidelines.',
   $B$## Design System Showcase

Build a living design system document — the reference guide for a fictional product''s visual language.

### Sections:

**1. Foundations**
- Colour palette (swatches with hex, RGB, usage notes)
- Typography scale (all heading levels + body sizes)
- Spacing scale (8, 16, 24, 32, 40, 48, 64, 80px)
- Border radius tokens
- Shadow levels

**2. Components**
- Buttons (all 6 variants)
- Form inputs (text, select, checkbox, radio, toggle)
- Cards (3 variants)
- Badges and tags
- Alerts (info, success, warning, error)
- Progress indicators

**3. Patterns**
- Navigation (desktop and mobile)
- Forms (single-step and multi-step)
- Modal dialog
- Toast notifications

### Format: Each component shows: visual demo + HTML code + CSS class names + "Do" and "Don't" examples.

### This is what real design systems look like: Atlassian Design, Material Design, Tailwind UI.
$B$),

  (82,'Error 404 Page','CSS','CSS','intermediate',
   'Design a creative, on-brand 404 error page with an illustration, helpful suggestions, and a way back home.',
   $B$## Error 404 Page

Build a creative, memorable 404 page — the page people see when a URL doesn''t exist.

### Why 404 Pages Matter:
A good 404 page turns an error into a brand moment. Bad 404 pages (just "404 Not Found") frustrate users. Good ones make them smile and help them find what they needed.

### Requirements:
- A creative headline ("Oops! Page not found" is boring — do better)
- CSS illustration of something relevant to the error (a lost astronaut, a broken robot, a confused coder)
- Helpful suggestions: Search bar, links to popular pages, "Go Home" button
- The HTTP status code displayed (404) in a large, designed way
- Subtle animation on the illustration

### CODEship Version:
"Oops! This code didn''t compile 🤖" with an illustration of a confused robot holding a magnifying glass.

### CSS Illustration Tips:
Use clip-path, border-radius, gradients, and absolute positioning to build the illustration from pure CSS shapes.

### This page should be genuinely delightful. When someone finds it by accident, they should smile.
$B$),

  (83,'Fundraiser Campaign Page','HTML','HTML','intermediate',
   'Build a charity fundraiser campaign page with a goal progress bar, donor list, and donation form.',
   $B$## Fundraiser Campaign Page

Build a complete charity fundraising campaign page — like GoFundMe, but designed from scratch.

### Choose Your Cause:
- Local school coding lab equipment
- Ocean cleanup
- Shelter animals
- Community garden
- Climate action

### Page Sections:
1. **Campaign Hero** — Title, cause photo, campaign organiser, location
2. **Progress Bar** — "$8,240 raised of $10,000 goal" with animated fill
3. **Campaign Story** — Why this matters, what the money does, who benefits
4. **Donation Tiers** — 4 suggested amounts with what each provides:
   - $10 → "Provides 1 coding book"
   - $50 → "Funds a student for one month"
   - $100 → "Supplies a classroom with tools"
   - Custom amount input
5. **Recent Donors** — List of last 5 donors with name, amount, message
6. **Donation Form** — Name, email, amount, message, submit
7. **Share** — Social sharing links

### Progress Bar CSS:
```css
.progress-fill {
  width: calc(var(--raised) / var(--goal) * 100%);
  transition: width 1s ease;
}
```
$B$),

  (84,'CSS Animation Showcase','CSS','CSS','advanced',
   'Build a page that demonstrates 10 different CSS animation techniques with explanations and editable code.',
   $B$## CSS Animation Showcase

Build an educational page that demonstrates your mastery of CSS animations — like a personal reference guide.

### 10 Animations to Include:

1. **Fade In Up** — Elements appear from below
2. **Pulse** — Gentle scale beat on a notification badge
3. **Spin** — Loading spinner
4. **Bounce** — Ball bouncing with `animation-timing-function: cubic-bezier()`
5. **Typewriter** — Text types itself with `steps()` timing
6. **Colour Cycle** — Background smoothly cycles through a rainbow
7. **Slide In** — Content slides in from the left
8. **Flip** — Card flips in 3D
9. **Shake** — Error shake for wrong input
10. **Particle Burst** — Multiple elements fly outward from a centre point

### For Each Animation:
- The animation itself, live
- The `@keyframes` code shown in a `<pre><code>` block
- Controls: Play / Pause / Replay buttons
- Explanation: "This works because..."

### Accessibility: All animations respect `prefers-reduced-motion`.
$B$),

  (85,'Local Restaurant Menu','HTML','HTML','intermediate',
   'Build a complete online menu for a real or fictional local restaurant you would want to exist.',
   $B$## Local Restaurant Menu

Build a complete restaurant menu website for a fictional restaurant you wish existed in your neighbourhood.

### Invent Your Restaurant:
- Name, concept, vibe (fine dining? casual? fusion?)
- Logo (emoji + text)
- Tagline
- Address on Simcoe St, Oshawa (or your real street)

### Your Menu (at least 20 items across sections):
- Starters (4 items)
- Mains (6 items)
- Sides (4 items)
- Desserts (3 items)
- Drinks (4 items)

### Each Menu Item:
- Name
- Description (appetising language!)
- Price
- Dietary badges (vegan 🌱, gluten-free 🌾, spicy 🌶️, popular 🔥)

### Features:
- Sticky navigation between menu sections
- Filter by dietary restriction
- "Order Online" form (fictional — just styling)
- Hours, location (Google Maps embed), and reservation button

### Writing Challenge: Write REAL menu descriptions that make the food sound delicious. "Crispy battered haddock served on toasted brioche with house-made tartare sauce and hand-cut fries" > "Fish and chips."
$B$),

  (86,'Accessibility Audit and Fix','HTML','HTML','advanced',
   'Take a deliberately broken HTML page with 15 accessibility issues and fix every single one.',
   $B$## Accessibility Audit and Fix

### The Challenge:
You''re given a deliberately broken HTML page with accessibility problems. Find and fix all 15 issues.

### The Broken Page (create this to start):
```html
<!-- This page has 15 accessibility issues. How many can you find? -->
<div onclick="doSomething()">Click me</div>
<img src="dog.jpg">
<input type="text" placeholder="Enter name">
<div style="color: #aaa; background: white;">Low contrast text</div>
<a href="#">Click here</a>
<h1>Title</h1><h4>Jumped heading level</h4>
<video src="video.mp4" autoplay></video>
<div class="nav"><div>Home</div><div>About</div></div>
<form><input type="submit" value="Submit"></form>
<p>Read more <a href="/article">here</a></p>
<!-- Add more issues to reach 15 total -->
```

### Audit Tools:
1. Lighthouse Accessibility audit (F12 → Lighthouse)
2. WAVE (wave.webaim.org)
3. Keyboard-only navigation test
4. Colour contrast checker (webaim.org/resources/contrastchecker)

### Document Each Fix:
For each issue: What was wrong? Why is it a problem? What did you change?

### Target: Pass Lighthouse Accessibility audit with score of 95+.
$B$),

  (87,'Multicultural Celebration Page','HTML','HTML','intermediate',
   'Build a page celebrating cultural diversity with profiles of 5 cultural celebrations or traditions from around the world.',
   $B$## Multicultural Celebration Page

Build a page celebrating cultural diversity — 5 different cultural celebrations from around the world.

### Choose Your 5 Celebrations:
- Diwali (India/South Asia)
- Lunar New Year (China, Vietnam, Korea)
- Eid al-Fitr (Muslim communities worldwide)
- Kwanzaa (African American communities)
- Holi (India)
- Día de los Muertos (Mexico)
- Nowruz (Persian/Iranian)
- Hanukkah (Jewish communities)
- Carnival (Brazil, Caribbean)
- Or choose celebrations from your own heritage!

### Each Celebration Section:
- Beautiful header image
- Name in original language + English translation
- When it''s celebrated
- Who celebrates it and where
- The meaning and traditions
- Traditional foods
- Music or dance associated with it
- "Learn More" links to credible sources

### Design: Use the colours and motifs of each celebration in its section. This page should be visually rich and joyful.

### Research respect: Write with accuracy and sensitivity. Cite your sources.
$B$),

  (88,'Career Exploration Page','HTML','HTML','intermediate',
   'Build a career explorer page for coding-related jobs with salary info, skills needed, and day in the life.',
   $B$## Career Exploration Page

Build an interactive career guide for tech and coding-related careers — something that helps young people see what''s possible.

### Careers to Feature (at least 6):
- Web Developer / Front-End Developer
- UX Designer
- Data Scientist
- Game Developer
- Cybersecurity Analyst
- AI/ML Engineer
- Software Engineer
- Mobile App Developer

### Each Career Card:
- Job title + emoji icon
- Average salary in Canada
- Education typically required
- Key skills needed
- "What a day looks like" — 3 bullet points
- Companies that hire this role
- Growth outlook (use a colour-coded badge: High / Very High)
- "How to get started" — 3 specific steps for a student

### Interactive Features:
- Filter by salary range, education level, or interest area
- Quiz: "Which tech career fits you?" — 5 questions that suggest a career match

### Research: Use reliable Canadian salary data (Government of Canada Job Bank, Glassdoor).
$B$),

  (89,'My Reading List','HTML','HTML','beginner',
   'Build a reading tracker page with books you have read, are reading, and want to read.',
   $B$## My Reading List Tracker

Build a personal reading tracker — your own mini Goodreads.

### Three Lists:
1. **Currently Reading** — What you''re reading right now (1-2 books, with progress %)
2. **Have Read** — Books you''ve completed (at least 5, with star ratings)
3. **Want to Read** — Books on your list (at least 5)

### Each Book Entry:
- Cover image (from Google — cite it)
- Title and author
- Genre tags
- Your rating (for completed books)
- One-sentence impression/note
- Date finished (for completed books)
- Progress bar (for currently reading)

### Stats Section:
- Books read this year
- Total books read
- Favourite genre (based on your list)
- Pages read estimate (average 250 per book × count)

### Design: Cosy, warm colours. Think of a library or bookshop aesthetic — cream, warm brown, deep green.
$B$),

  (90,'Space Exploration Timeline','CSS','CSS','advanced',
   'Build an animated timeline of major space exploration milestones from 1957 to today.',
   $B$## Space Exploration Timeline

Build a visually stunning, interactive timeline of humanity''s journey into space.

### Timeline Events (minimum 15):
- 1957: Sputnik 1 (first satellite)
- 1961: Yuri Gagarin (first human in space)
- 1969: Moon Landing (Apollo 11)
- 1971: First space station (Salyut 1)
- 1981: First Space Shuttle
- 1990: Hubble Space Telescope
- 1998: ISS construction begins
- 2004: Mars rovers (Spirit & Opportunity)
- 2012: Curiosity rover on Mars
- 2015: New Horizons reaches Pluto
- 2021: James Webb Space Telescope
- 2023+: Artemis Moon return program
- Add current/future milestones!

### Visual Design:
- Dark space background with star field (CSS `box-shadow` for stars)
- Timeline runs vertically
- Events alternate left and right
- Each event: mission badge icon, year, title, 2-sentence description, image
- Milestone events are larger and highlighted

### Animation: Events fade/slide in as you scroll using IntersectionObserver.

### Interactive: Click any event to see a modal with more details and a photo.
$B$),

  (91,'Video Game Tribute Fan Page','HTML','HTML','intermediate',
   'Build a tribute fan page for a video game franchise you love, with lore, characters, and media.',
   $B$## Video Game Tribute Fan Page

Build a tribute to your all-time favourite video game or game franchise.

### Sections:
1. **Hero** — Game title, tagline, key art (use official promotional art — note it as fan tribute)
2. **About** — Story synopsis (no spoilers in the preview), developer, release year, platforms
3. **Characters** — 4-6 character cards with: portrait, name, role, brief bio
4. **World/Lore** — Map or regions overview, key locations
5. **Gallery** — Screenshot grid (from your own gameplay or official screenshots)
6. **Videos** — Official trailers and gameplay clips (YouTube embeds)
7. **Why I Love It** — Your personal essay: what makes this game special to you
8. **Fan Community** — Links to subreddit, Discord, wiki

### Design: Should feel true to the game''s aesthetic. Dark fantasy game = dark, atmospheric design. Colourful platformer = bright, energetic palette.

### Legal Note: Add a disclaimer: "This is a fan tribute page and is not affiliated with [Developer]. All game assets belong to their respective owners."
$B$),

  (92,'Healthy Habits Tracker Page','HTML','HTML','intermediate',
   'Build a health and wellness tracking dashboard page with habit cards, progress, and weekly stats.',
   $B$## Healthy Habits Tracker Page

Build a health and wellness dashboard — not a real app (no backend), but a beautifully designed UI mockup.

### Dashboard Sections:
1. **Header** — "Hello, [Name]! Today is [Day]." with motivational quote
2. **Today''s Habits** — Checklist of 7 daily habits with checkboxes:
   - 💧 Drink 8 glasses of water
   - 🏃 30 minutes of physical activity
   - 📚 Read for 20 minutes
   - 🥗 Eat 5 servings of vegetables
   - 😴 8 hours of sleep (yesterday)
   - 🧘 10 minutes of mindfulness
   - 💻 1 hour of coding practice
3. **Weekly Progress** — 7 columns (Mon–Sun), each habit shown as filled/empty circle
4. **Stats Cards** — Current streak, total days completed, best streak, completion rate
5. **Motivational Section** — Quote of the day + progress message

### CSS Checkbox Animation:
When a habit is checked, the circle fills with a satisfying animation and the text gets a strikethrough.

### JavaScript: Clicking a checkbox adds/removes "completed" class and updates the streak count.
$B$),

  (93,'Local Park/Playground Page','HTML','HTML','intermediate',
   'Build a community page for a local park or playground with facilities, events, rules, and a feedback form.',
   $B$## Local Park/Playground Community Page

Build a community website for a local park in Oshawa (or invent one).

### Real Local Option: Lakeview Park, Harmony Valley, Connaught Park, or Oshawa Valley Botanical Gardens.

### Page Sections:
1. **Hero** — Park name, photo, "Your community outdoor space"
2. **About** — History, size, features
3. **Facilities** — Grid of what''s available: playground equipment, sports courts, washrooms, picnic tables, splash pad, parking
4. **Events Calendar** — Upcoming events at the park (table format): Date, Event, Time, Free/Paid
5. **Park Rules** — Numbered list (keep it friendly, not threatening)
6. **Hours and Access** — Table of seasonal hours
7. **Photo Gallery** — Community-submitted photos (use Unsplash park photos)
8. **Report an Issue** — Form: issue type (broken equipment, litter, safety concern), description, your contact
9. **Map** — Google Maps embed of the actual location

### Design: Outdoors feel — greens, blues, natural textures (try a leaf pattern CSS background).
$B$),

  (94,'Fantasy Sports League Table','HTML','HTML','intermediate',
   'Build a fantasy sports league leaderboard with a fully styled stats table, player profiles, and trade system.',
   $B$## Fantasy Sports League Table

Build a fantasy sports league management page — you invent the sport, teams, and players.

### Your Fantasy League:
- 8 teams (each "team" is one player/manager)
- 10+ rounds of results
- Point system with different scoring categories

### Standings Table:
| Rank | Manager | Team Name | Wins | Losses | Points | Last 5 | Form |
- Highlight top 3 (gold/silver/bronze)
- Highlight bottom 2 (relegation zone warning)
- "Form" column: last 5 results as coloured dots

### Player Pool Table (below standings):
- All available players with their stats
- "Star Players" highlighted
- Transfer status (available, owned, injured)

### Interactive Features:
- Sort table by any column (JavaScript)
- Filter by position
- "Trade" button that opens a modal (just visual — no real backend)

### Design: Use your sport''s aesthetic — green for football, orange for basketball, blue for hockey.
$B$),

  (95,'Inventors and Inventions Page','HTML','HTML','intermediate',
   'Build an educational page profiling 6 inventors and their inventions with a historical timeline.',
   $B$## Inventors and Inventions

Build an educational tribute page honouring inventors who changed the world.

### Your 6 Inventors:
Suggestions — or pick your own:
- Tim Berners-Lee (World Wide Web)
- Grace Hopper (compiler, COBOL)
- Nikola Tesla (AC electricity)
- Marie Curie (radioactivity research)
- Alexander Graham Bell (telephone)
- Charles Babbage (mechanical computer)

Or focus on: Canadian inventors, women inventors, inventors of colour, young inventors.

### Each Inventor Profile:
- Portrait (Wikimedia Commons — all cited, free to use)
- Name, birth–death years, nationality
- "Greatest invention" highlight box
- Biography (300 words minimum, in your own words)
- Timeline of their major contributions
- "Fun fact" sidebar
- Legacy section: "Because of them, we have..."
- Sources cited properly

### Site-wide Timeline at Bottom:
A horizontal timeline from 1800 to 2024 plotting each inventor''s major contribution.
$B$),

  (96,'Complete Business Website','HTML','HTML','advanced',
   'Build a complete 4-page business website (Home, About, Services, Contact) with consistent navigation and shared CSS.',
   $B$## Complete Business Website (4 Pages)

Build a complete multi-page business website for a fictional small business.

### Your Business:
Choose a real small business type you find interesting:
- Graphic design studio
- Tutoring service
- Photography business
- Personal training
- Event planning
- Custom cake shop

### Required Pages:
**1. index.html (Home):**
- Hero with CTA
- "Why choose us" features
- Services preview (3 cards)
- Testimonials
- CTA section

**2. about.html:**
- Our story
- Team section (3 people)
- Values
- Fun stats

**3. services.html:**
- Service cards (5 minimum)
- Pricing table
- Process (how it works)
- FAQ

**4. contact.html:**
- Contact form
- Office hours
- Address + map
- Social links

### Technical Standards:
- ONE shared `styles.css` and `nav` component (HTML included into each page)
- Responsive: all 4 pages work at 375px, 768px, 1280px
- Consistent navigation with active state on each page
- All pages have proper SEO meta tags

### Publish: Deploy to Netlify. 4 real linked pages on the internet.
$B$),

  (97,'Portfolio Capstone — Final Website','HTML','HTML','advanced',
   'Build your definitive portfolio website showcasing your best 8 projects with full case studies.',
   $B$## Portfolio Capstone: Your Best Work

This is the most important project of the Builders level. Your final portfolio is a professional-quality showcase of everything you''ve built.

### Requirements:

**Homepage:**
- Hero with your name, photo/avatar, and tagline
- Animated entrance
- Skills section
- Quick project preview (3 featured cards)
- CTA to contact you

**Projects Page:**
- 8 project showcases (choose your best work from the entire Builders level)
- Each project: screenshot, title, tech stack, brief description, 3 key techniques used, live URL

**Case Study Page (for 1 project):**
- Full written case study: problem, process, solution, results, what you learned
- Multiple screenshots (desktop + mobile)
- Code snippet showing your cleverest technique

**About Page:**
- Your coding story
- Your goals
- What you want to learn next

**Contact Page:**
- Working contact form
- Your email (you can use a mailto link)

### Quality Standard:
Every project shown must have a live URL. The portfolio itself must be fully responsive. Run Lighthouse — target 90+ on all categories.

### Publish: Share the URL with your instructor and in the CODEship community!
$B$),

  (98,'Peer Code Review Project','HTML','HTML','intermediate',
   'Review a classmate''s project and provide structured written feedback, then apply their feedback to your own work.',
   $B$## Peer Code Review

Code review is a fundamental professional skill. Every working developer gives and receives code reviews daily. This project teaches both sides.

### Part 1: Review a Classmate''s Project
Ask a classmate to share their HTML/CSS from any Builders project.

**Review these areas (provide specific, actionable feedback on each):**

1. **HTML Structure** — Is it semantic? Are headings in order? Is every input labelled?
2. **CSS Organisation** — Is it readable? Are there CSS variables? Is there unnecessary repetition?
3. **Responsiveness** — Does it work at 375px? What breaks?
4. **Accessibility** — Run Lighthouse. What are the accessibility issues?
5. **Performance** — Are images appropriately sized? Is there anything loading unnecessarily?
6. **Code Quality** — Is it properly indented? Are class names descriptive?
7. **What Works Well** — 3 specific things they did right (every review needs positives!)

**Format your feedback as:**
- What I noticed: [specific observation]
- Why it matters: [explanation]
- Suggestion: [specific change they could make]

### Part 2: Apply Feedback to Your Own Work
Share your project. Apply the feedback you receive. Write a 200-word reflection on what you changed and why.

### The Mindset: Good code review is kind, specific, and constructive — never personal.
$B$),

  (99,'Builders Showcase Presentation','HTML','HTML','intermediate',
   'Create a slide-style presentation webpage showcasing your 5 best projects from the Builders level.',
   $B$## Builders Showcase Presentation

Create a presentation-style webpage that you could screen-share to show off your best work.

### The Format: A single-page "slide deck" using CSS scroll-snap
- Each "slide" is `height: 100vh; scroll-snap-align: start`
- The page scrolls from slide to slide (or use arrow key navigation with JavaScript)

### Slide Structure (minimum 8 slides):
1. **Title Slide** — Your name, "Builders Level Showcase", date
2. **About Me Slide** — Photo, quick facts, your coding origin story
3. **Project 1** — Your best HTML project
4. **Project 2** — Your best CSS project
5. **Project 3** — Your Scratch game
6. **Skills Learned** — Visual skill badges
7. **What''s Next** — What you want to learn in Developers level
8. **Thank You + Contact** — Your live portfolio URL

### Navigation:
- Arrow navigation buttons on each slide
- Dot indicators showing current slide number
- Keyboard: Arrow keys to navigate

### Technical Note:
```css
.slides { height: 100vh; overflow-y: scroll; scroll-snap-type: y mandatory; }
.slide { height: 100vh; scroll-snap-align: start; }
```

### Share the URL in the CODEship community!
$B$),

  (100,'Open Project: Your Idea','HTML','HTML','advanced',
   'Design and build a completely original project of your own invention — something the world does not have yet.',
   $B$## Open Project: Your Original Idea

This is the final Builders project — and there are no requirements except that it must be YOUR idea.

### The Only Rules:
1. It must use HTML and CSS (and optionally JavaScript or Scratch)
2. It must be something that didn''t exist before you built it
3. It must be published on a live URL
4. You must write a 300-word description of: what it is, who it''s for, and why you built it

### Ideas to Spark Your Own:
- A tool that solves a real problem in your life
- A game you want to play but can''t find
- An educational page about something you know deeply
- A creative project that combines your interests with code
- A community resource for your school, neighbourhood, or hobby

### Process:
1. **Idea** — What will you build? Write 1 paragraph describing it.
2. **Plan** — Sketch the layout on paper. What sections? What features?
3. **Build** — Start with HTML structure, then CSS, then interactivity
4. **Test** — Mobile responsive? Accessible? No broken links?
5. **Publish** — Deploy to Netlify
6. **Share** — Post in the CODEship community and explain your creation

### You have completed the Builders level. This project is proof of what you can do.

Dream. Code. Achieve. 🚀
$B$)
) AS t(n, title, category, lang, difficulty, description, brief);

