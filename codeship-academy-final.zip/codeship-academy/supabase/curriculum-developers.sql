-- ═══════════════════════════════════════════════════════════════════════════
-- CODEship Academy: DEVELOPERS Level — Complete Curriculum
-- 100 Lessons | 100 Projects | 50 Quizzes × 10 Questions
-- Level: Developers | Ages 10-12 | Grades 4-6
-- Topics: JavaScript, DOM, APIs, debugging, intro Python, React basics
-- ═══════════════════════════════════════════════════════════════════════════

DELETE FROM public.quiz_questions WHERE quiz_id IN (SELECT id FROM public.quizzes WHERE level = 'Developers');
DELETE FROM public.quizzes WHERE level = 'Developers';
DELETE FROM public.projects WHERE level = 'Developers';
DELETE FROM public.lessons WHERE level = 'Developers';

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('dev-l01','Welcome to JavaScript: The Language of the Web','Developers','JavaScript','intermediate',30,'published',
ARRAY['Explain what JavaScript adds to HTML and CSS','Run code in the browser console','Link an external script file correctly'],
$L$# Welcome to JavaScript: The Language of the Web

## You Just Unlocked the Third Language

In Builders you mastered HTML (structure) and CSS (style). Today you learn **JavaScript** — behaviour. This is what makes web pages respond, animate, validate, and communicate.

JavaScript powers everything interactive on the modern web: dropdown menus, live search, form validation, infinite scroll, browser games, dashboards — all JavaScript.

## A 30-Second History

1995: Brendan Eich wrote the first version in 10 days at Netscape. Originally called Mocha.
2008: Google's V8 engine made it dramatically faster.
2009: Node.js brought JavaScript to servers.
Today: The most widely-used programming language in the world.

## Your First JavaScript — Right Now

Press **F12**, click **Console**. Type this and press Enter:

```javascript
console.log("Hello, World!");
```

You just ran JavaScript. The console is a live interpreter — experiment freely.

```javascript
2 + 2               // 4
"Hello, " + "World!" // "Hello, World!"
document.title      // The current page title
Math.random()       // A random number 0–1
```

## Three Ways to Include JavaScript

```html
<!-- Best: external file, before </body> -->
<script src="script.js"></script>

<!-- OK: inline block -->
<script>
  console.log("Inline JS");
</script>

<!-- Avoid: attribute handler -->
<button onclick="alert('hi')">Click</button>
```

Why before `</body>`? Scripts in `<head>` pause rendering. Placing them at the bottom lets users see the page immediately.

## Comments

```javascript
// Single-line comment

/*
  Multi-line comment
*/

console.log("Runs"); // Can follow code
```

## Your First Real Program

**index.html:**
```html
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>JS Test</title></head>
<body>
  <h1 id="greeting">Loading...</h1>
  <script src="script.js"></script>
</body>
</html>
```

**script.js:**
```javascript
const hour = new Date().getHours();
const greeting = hour < 12 ? "Good morning!" :
                 hour < 17 ? "Good afternoon!" : "Good evening!";

document.getElementById("greeting").textContent = greeting;
console.log("JavaScript running! Hour:", hour);
```

Open in browser. The `<h1>` updates based on your current time. That's JavaScript reading time data and modifying the HTML.

## Key Takeaways 🌟

1. JavaScript adds behaviour to HTML and CSS
2. The browser **console** (F12) is a live JavaScript interpreter
3. Link scripts with `<script src="file.js">` before `</body>`
4. `console.log()` is your primary debugging tool
5. JavaScript can read and modify any element on the page
$L$,
ARRAY['javascript','intro','console','dom'], 1),

('dev-l02','Variables and Data Types','Developers','JavaScript','intermediate',35,'published',
ARRAY['Declare variables with let and const','Know the six primitive data types','Use typeof and understand type coercion'],
$L$# Variables and Data Types

## The Three Declaration Keywords

```javascript
const pi = 3.14159;   // Cannot be reassigned — use by default
let score = 0;        // Can be reassigned — use when value changes
score = 10;           // Fine with let

// var — old, avoid. Has confusing scoping rules.
```

**Rule:** Use `const` always. Change to `let` only when you need to reassign.

## Naming Variables

```javascript
// Good — camelCase, descriptive
const userName = "Alex";
const totalScore = 850;
const isLoggedIn = true;

// Bad — vague, wrong style
const x = "Alex";
const my-score = 850; // Hyphens not allowed!
```

## The Six Primitive Types

### String
```javascript
const name = "Alex";               // Double quotes
const city = 'Oshawa';             // Single quotes — same thing
const message = `Hello, ${name}!`; // Template literal — embeds expressions
const multi = `Line one
Line two`;                          // Template literals support multi-line
```

### Number
```javascript
const age = 25;          // Integer
const price = 9.99;      // Float
const negative = -42;

// Special values:
Infinity    // Result of 1/0
NaN         // Not a Number — result of invalid math like "hello" * 2

console.log(0.1 + 0.2); // 0.30000000000000004 — floating point quirk!
```

### Boolean
```javascript
const isLoggedIn = true;
const hasPremium = false;
const isAdult = age >= 18; // Evaluated boolean
```

### undefined
```javascript
let uninitialised;
console.log(uninitialised); // undefined — declared but no value
```

### null
```javascript
let selectedUser = null; // Intentionally empty — "no user selected"
```

### Symbol (mention only)
```javascript
const id = Symbol('id'); // Unique identifier — advanced, rarely needed at this level
```

## typeof Operator

```javascript
typeof "hello"      // "string"
typeof 42           // "number"
typeof true         // "boolean"
typeof undefined    // "undefined"
typeof null         // "object"  ← famous JS bug, null is NOT an object
typeof {}           // "object"
typeof []           // "object"  ← arrays are objects in JS
```

## Type Coercion — JavaScript's Surprising Conversions

```javascript
"5" + 3    // "53"  — number becomes string (concatenation)
"5" - 3    // 2     — string becomes number (only works with -)
"5" * "3"  // 15    — both become numbers

// ALWAYS use === not ==:
5 == "5"   // true  — loose equality (coercion!)
5 === "5"  // false — strict equality (safe!)
```

## Explicit Conversion

```javascript
Number("42")       // 42
Number("hello")    // NaN
parseInt("42px")   // 42
String(100)        // "100"
Boolean(0)         // false
Boolean("hello")   // true
```

## Falsy Values — Know These Cold

`false`, `0`, `""`, `null`, `undefined`, `NaN` — these all evaluate to false in boolean context. Everything else is truthy — including `[]` and `{}`.

## Key Takeaways 🌟

1. `const` for stable values; `let` for changing values; never `var`
2. Six primitive types: string, number, boolean, undefined, null, Symbol
3. Template literals `` `Hello ${name}` `` — the modern way to build strings
4. Always `===` not `==`
5. Falsy: `false 0 "" null undefined NaN` — everything else is truthy
$L$,
ARRAY['javascript','variables','data-types','primitives','typeof'], 2),

('dev-l03','Operators and Expressions','Developers','JavaScript','intermediate',30,'published',
ARRAY['Apply arithmetic and assignment operators','Use comparison and logical operators correctly','Write ternary expressions'],
$L$# Operators and Expressions

## Arithmetic

```javascript
10 + 3   // 13
10 - 3   // 7
10 * 3   // 30
10 / 3   // 3.333...
10 % 3   // 1  (remainder — modulo)
10 ** 3  // 1000 (exponentiation)

// Modulo is hugely useful:
7 % 2    // 1 (odd)
8 % 2    // 0 (even)
100 % 60 // 40 (minutes after an hour)
```

## Assignment Shortcuts

```javascript
let x = 10;
x += 5;  // x = 15
x -= 3;  // x = 12
x *= 2;  // x = 24
x /= 4;  // x = 6
x %= 4;  // x = 2
x++;     // x = 3 (increment)
x--;     // x = 2 (decrement)
```

## Comparison — Always Use `===`

```javascript
5 > 3    // true
5 < 3    // false
5 >= 5   // true
5 <= 4   // false
5 === 5  // true  — strict (value AND type)
5 !== 3  // true
5 == "5" // true  — AVOID (loose, coerces types)
```

## Logical Operators

```javascript
true && false  // false  (AND — both must be true)
true || false  // true   (OR — one must be true)
!true          // false  (NOT — inverts)

// Short-circuit:
false && expensive()   // expensive() never runs
true  || expensive()   // expensive() never runs

// Default values:
const name = userInput || "Guest";  // "Guest" if userInput is falsy
const name = userInput ?? "Guest";  // "Guest" only if null/undefined
```

`??` (nullish coalescing) is safer than `||` when `0` or `""` are valid values.

## Ternary Operator

```javascript
condition ? valueIfTrue : valueIfFalse

const status = age >= 18 ? "adult" : "minor";
const grade = score >= 90 ? "A" :
              score >= 80 ? "B" :
              score >= 70 ? "C" : "F";
```

## Operator Precedence

```javascript
2 + 3 * 4    // 14 (multiplication first)
(2 + 3) * 4  // 20 (parentheses override)
```

When in doubt: **use parentheses**.

## Key Takeaways 🌟

1. `%` modulo gives the remainder — useful for even/odd, cycling, time
2. `===` strict equality always; `==` loose equality never
3. `||` default: `value || "fallback"`. `??` safer: only triggers on null/undefined
4. Ternary: `condition ? a : b` — great for simple conditional values
$L$,
ARRAY['javascript','operators','comparison','logical','ternary'], 3),

('dev-l04','Control Flow: If, Else, Switch','Developers','JavaScript','intermediate',35,'published',
ARRAY['Write if/else if/else chains','Use switch for multi-value branching','Apply early return guard clauses'],
$L$# Control Flow: If, Else, Switch

## The `if` Statement

```javascript
if (condition) {
  // Runs only if condition is truthy
}

if (score >= 70) {
  console.log("Passed!");
}
```

## `if / else`

```javascript
if (score >= 70) {
  console.log("Passed!");
} else {
  console.log("Not yet. Keep practising!");
}
```

## `if / else if / else`

```javascript
const pct = 83;

if (pct >= 90) {
  console.log("A");
} else if (pct >= 80) {
  console.log("B");  // ← this runs
} else if (pct >= 70) {
  console.log("C");  // skipped — first match already found
} else {
  console.log("F");
}
```

Only **one block** runs — the first condition that is true.

## Guard Clauses (Early Return)

Instead of deep nesting, check invalid cases first:

```javascript
// Deeply nested — hard to read:
function process(order) {
  if (order) {
    if (order.items.length > 0) {
      if (order.isPaid) { doWork(order); }
    }
  }
}

// Guard clauses — clean:
function process(order) {
  if (!order) return;
  if (order.items.length === 0) return;
  if (!order.isPaid) return;
  doWork(order);
}
```

## Complex Conditions

```javascript
const age = 15;
const hasConsent = true;

if ((age >= 18) || (age >= 13 && hasConsent)) {
  console.log("Can participate");
}
```

## `switch` Statement

Best when comparing one variable to many specific values:

```javascript
const day = new Date().getDay(); // 0=Sun, 1=Mon...

switch (day) {
  case 0:
    console.log("Sunday");
    break;
  case 6:
    console.log("Saturday");
    break;
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
    console.log("Weekday");
    break;
  default:
    console.log("Unknown");
}
```

**Always include `break`** or execution falls through to the next case.

## `if` vs `switch`

| Use `if/else if` | Use `switch` |
|------------------|--------------|
| Ranges: `score >= 80` | Exact values: `case "red":` |
| Complex conditions | Same variable, many values |
| Different variables | Enum-like categories |

## Key Takeaways 🌟

1. Only one `else if` / `else` block runs — first match wins
2. Guard clauses: check invalid cases early and return — avoids deep nesting
3. `switch` is cleaner than many `else if` for one variable vs many values
4. Always `break` in switch cases (or fall-through is intentional)
5. Empty arrays `[]` are truthy — check `.length > 0` not just the array
$L$,
ARRAY['javascript','control-flow','if','switch','guard-clauses'], 4),

('dev-l05','Functions: Building Reusable Code','Developers','JavaScript','intermediate',40,'published',
ARRAY['Write function declarations and arrow functions','Use parameters, defaults, and return values','Understand scope and closures'],
$L$# Functions: Building Reusable Code

## What Is a Function?

A named, reusable block of code. Write once, call many times.

```javascript
function greet(name) {
  return `Hello, ${name}!`;
}

greet("Alex");    // "Hello, Alex!"
greet("Jordan");  // "Hello, Jordan!"
```

`name` is the **parameter** (the local variable). `"Alex"` is the **argument** (the value passed in).

## Four Ways to Write Functions

```javascript
// 1. Function declaration (hoisted — can be called before it appears)
function add(a, b) { return a + b; }

// 2. Function expression (not hoisted)
const multiply = function(a, b) { return a * b; };

// 3. Arrow function — concise
const divide = (a, b) => a / b;

// 4. Arrow with block body (when you need multiple statements)
const gradeScore = (score) => {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  return "C";
};
```

Arrow function rules:
- Single parameter: parentheses optional: `x => x * 2`
- No parameters: empty parens required: `() => "hello"`
- Single expression: no braces, implicit return: `(a, b) => a + b`
- Multiple statements: need braces and explicit `return`

## Default Parameters

```javascript
function createProfile(name, role = "Student", level = 1) {
  return { name, role, level };
}

createProfile("Alex");              // {name: "Alex", role: "Student", level: 1}
createProfile("Sam", "Teacher");    // {name: "Sam", role: "Teacher", level: 1}
createProfile("Jo", "Admin", 5);    // {name: "Jo", role: "Admin", level: 5}
```

## Rest Parameters

Accept any number of arguments:

```javascript
function sum(...numbers) {
  return numbers.reduce((total, n) => total + n, 0);
}

sum(1, 2, 3);         // 6
sum(10, 20, 30, 40);  // 100
```

## `return`

```javascript
function divide(a, b) {
  if (b === 0) return null;  // Early return on invalid input
  return a / b;
}
```

`return` ends the function immediately. Without `return`, the function returns `undefined`.

## Scope

```javascript
const global = "accessible everywhere";

function example() {
  const local = "only inside this function";
  console.log(global); // Fine
  console.log(local);  // Fine
}

console.log(global); // Fine
console.log(local);  // ERROR — local is not defined here
```

`let` and `const` are **block-scoped** — only live inside `{}`:

```javascript
if (true) {
  const blockVar = "only in this block";
}
console.log(blockVar); // ERROR
```

## Closures

Functions remember the scope where they were created:

```javascript
function makeCounter() {
  let count = 0;
  return () => ++count;  // Arrow function closes over `count`
}

const counter = makeCounter();
counter(); // 1
counter(); // 2
counter(); // 3

const counter2 = makeCounter(); // Fresh, independent count
counter2(); // 1
```

## Pure Functions

Same inputs → always same output, no side effects:

```javascript
// Pure ✓
const add = (a, b) => a + b;

// Impure ✗ — depends on external state
let total = 0;
function addToTotal(n) { total += n; return total; }
```

Prefer pure functions — easier to test, debug, and reason about.

## Practical: Password Strength Checker

```javascript
function checkPassword(password) {
  if (!password) return { level: "none", msg: "Enter a password." };
  
  let score = 0;
  if (password.length >= 8)          score++;
  if (password.length >= 12)         score++;
  if (/[A-Z]/.test(password))        score++;
  if (/[0-9]/.test(password))        score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  
  if (score <= 1) return { level: "weak",   msg: "Too weak — add length and variety." };
  if (score <= 3) return { level: "medium", msg: "Getting there!" };
  return           { level: "strong", msg: "Strong password! ✓" };
}

const result = checkPassword("MyPass123!");
console.log(result.level); // "strong"
```

## Key Takeaways 🌟

1. Functions: define once, call many times — core of all programming
2. Arrow functions `x => x * 2` — concise, implicit return for single expressions
3. Default parameters provide fallbacks: `function greet(name = "friend")`
4. `return` exits the function and sends a value back
5. Variables are scoped to their block `{}` — `let`/`const` only
6. Closures: inner functions remember the outer scope they were created in
$L$,
ARRAY['javascript','functions','arrow-functions','scope','closures'], 5),

('dev-l06','Arrays: Working with Lists of Data','Developers','JavaScript','intermediate',40,'published',
ARRAY['Create and access arrays','Use essential array methods: push, pop, map, filter, reduce','Iterate arrays with forEach and for...of'],
$L$# Arrays: Working with Lists of Data

## What Is an Array?

An ordered list of values, all in one variable.

```javascript
const fruits = ["apple", "banana", "cherry", "date"];
const scores = [95, 87, 72, 100, 68];
const mixed  = [42, "hello", true, null]; // Any types allowed
const empty  = [];
```

Arrays are zero-indexed — the first item is at index 0:

```javascript
fruits[0]  // "apple"
fruits[1]  // "banana"
fruits[3]  // "date"
fruits[4]  // undefined (no index 4)

// From the end:
fruits[fruits.length - 1] // "date" — last item
```

## Essential Array Methods

### Adding and Removing

```javascript
const arr = [1, 2, 3];

arr.push(4);      // [1, 2, 3, 4] — add to end
arr.pop();        // [1, 2, 3]    — remove from end (returns 4)
arr.unshift(0);   // [0, 1, 2, 3] — add to start
arr.shift();      // [1, 2, 3]    — remove from start (returns 0)

// splice(start, deleteCount, ...itemsToInsert)
arr.splice(1, 0, 99); // [1, 99, 2, 3] — insert at index 1
arr.splice(1, 1);     // [1, 2, 3]    — remove 1 item at index 1
```

### Finding Items

```javascript
const scores = [72, 85, 90, 64, 85];

scores.indexOf(85)     // 1 — first occurrence
scores.lastIndexOf(85) // 4 — last occurrence
scores.indexOf(99)     // -1 — not found

scores.includes(90)    // true
scores.includes(99)    // false

scores.find(s => s > 80)        // 85 — first item matching condition
scores.findIndex(s => s > 80)   // 1  — index of first match
scores.findLast(s => s > 80)    // 85 — last match (newer JS)
```

### The Big Three — map, filter, reduce

These three methods are the foundation of modern JavaScript data processing:

```javascript
const scores = [72, 85, 90, 64, 85];

// map: transforms every item, returns new array same length
const doubled = scores.map(s => s * 2);
// [144, 170, 180, 128, 170]

const labels = scores.map(s => `${s}%`);
// ["72%", "85%", "90%", "64%", "85%"]

// filter: keeps items that pass the test, returns new array
const passing = scores.filter(s => s >= 70);
// [72, 85, 90, 85]

const failing = scores.filter(s => s < 70);
// [64]

// reduce: collapses array to a single value
const total = scores.reduce((acc, s) => acc + s, 0);
// 396

const average = total / scores.length;
// 79.2

const max = scores.reduce((max, s) => s > max ? s : max, -Infinity);
// 90
```

**Chain them together:**
```javascript
const passingAvg = scores
  .filter(s => s >= 70)
  .reduce((sum, s, _, arr) => sum + s / arr.length, 0);
// Average of passing scores only
```

### Sorting

```javascript
const names = ["Zara", "Alex", "Morgan", "Jordan"];
names.sort(); // ["Alex", "Jordan", "Morgan", "Zara"] — alphabetical

const nums = [10, 2, 20, 1, 15];
nums.sort(); // [1, 10, 15, 2, 20] — WRONG! Sorts as strings
nums.sort((a, b) => a - b); // [1, 2, 10, 15, 20] — correct ascending
nums.sort((a, b) => b - a); // [20, 15, 10, 2, 1] — descending
```

Always provide a comparator function for numbers!

### Other Useful Methods

```javascript
const arr = [1, 2, 3, 4, 5];

arr.slice(1, 3)   // [2, 3] — new array from index 1 to 3 (exclusive)
arr.slice(-2)     // [4, 5] — last 2 items

arr.join(" - ")   // "1 - 2 - 3 - 4 - 5" — items as string
arr.reverse()     // [5, 4, 3, 2, 1] — in-place reversal
arr.flat()        // Flattens nested arrays: [[1,2],[3]] → [1,2,3]

// Spread — copy or combine arrays:
const copy = [...arr];
const combined = [...arr, ...arr];

// Check if something is an array:
Array.isArray([1, 2, 3]) // true
Array.isArray("hello")   // false
```

## Iterating Arrays

```javascript
const fruits = ["apple", "banana", "cherry"];

// forEach — runs a function for each item (no return value)
fruits.forEach((fruit, index) => {
  console.log(`${index}: ${fruit}`);
});
// 0: apple
// 1: banana
// 2: cherry

// for...of — simplest iteration (no index)
for (const fruit of fruits) {
  console.log(fruit);
}

// for loop — when you need precise index control
for (let i = 0; i < fruits.length; i++) {
  console.log(`${i}: ${fruits[i]}`);
}

// for...in — iterates KEYS (index for arrays) — usually avoid for arrays
for (const index in fruits) {
  console.log(fruits[index]);
}
```

## Destructuring

```javascript
const [first, second, ...rest] = [1, 2, 3, 4, 5];
// first = 1, second = 2, rest = [3, 4, 5]

// Swap variables:
let a = 1, b = 2;
[a, b] = [b, a];
// a = 2, b = 1

// Skip items:
const [,, third] = [1, 2, 3, 4];
// third = 3
```

## Practical: Student Grade Manager

```javascript
const students = [
  { name: "Alex", score: 85 },
  { name: "Sam",  score: 62 },
  { name: "Jo",   score: 91 },
  { name: "Kim",  score: 74 },
  { name: "Lee",  score: 55 }
];

const passing = students.filter(s => s.score >= 70);
const withGrades = students.map(s => ({
  ...s,
  grade: s.score >= 90 ? "A" :
         s.score >= 80 ? "B" :
         s.score >= 70 ? "C" : "F"
}));
const average = students.reduce((sum, s) => sum + s.score, 0) / students.length;
const top = students.sort((a, b) => b.score - a.score)[0];

console.log("Passing:", passing.map(s => s.name));
console.log("Average:", average.toFixed(1));
console.log("Top student:", top.name, top.score);
```

## Key Takeaways 🌟

1. Arrays are zero-indexed: first item = `arr[0]`
2. `push`/`pop` = end; `unshift`/`shift` = start
3. **map** transforms every item → new array same length
4. **filter** keeps items that pass → new array, possibly shorter
5. **reduce** collapses array → single value
6. `sort()` without comparator sorts as strings — always use `(a,b) => a-b` for numbers
7. Spread `[...arr]` creates a shallow copy
8. Destructuring: `const [first, ...rest] = arr`
$L$,
ARRAY['javascript','arrays','map','filter','reduce','iteration'], 6),

('dev-l07','Objects: Structured Data and Methods','Developers','JavaScript','intermediate',40,'published',
ARRAY['Create and access JavaScript objects','Add methods to objects','Use object destructuring and spread'],
$L$# Objects: Structured Data and Methods

## What Is an Object?

An object stores related data as key-value pairs:

```javascript
const student = {
  name: "Alex Kim",
  grade: 5,
  score: 87,
  isEnrolled: true
};

// Access:
student.name      // "Alex Kim" — dot notation
student["grade"]  // 5          — bracket notation (useful for dynamic keys)
student.missing   // undefined  — no error for missing keys
```

## Creating Objects

```javascript
// Object literal — most common
const car = { make: "Toyota", model: "Camry", year: 2023 };

// With computed keys
const key = "colour";
const obj = { [key]: "blue" }; // { colour: "blue" }

// Shorthand when variable name matches key
const name = "Alex";
const age = 15;
const person = { name, age }; // { name: "Alex", age: 15 }
```

## Modifying Objects

```javascript
const user = { name: "Alex", score: 0 };

user.score = 100;         // Update
user.level = "Builder";   // Add new property
delete user.score;        // Remove property

// Check if property exists:
"name" in user           // true
"score" in user          // false (we deleted it)
user.hasOwnProperty("name") // true
```

## Methods: Functions on Objects

```javascript
const calculator = {
  value: 0,
  
  add(n) {
    this.value += n;
    return this; // Return this for chaining
  },
  
  subtract(n) {
    this.value -= n;
    return this;
  },
  
  result() {
    return this.value;
  }
};

calculator.add(10).add(5).subtract(3).result(); // 12
```

`this` inside a method refers to the object the method was called on.

## Iterating Objects

```javascript
const scores = { math: 90, science: 85, english: 78 };

// Get keys, values, or both:
Object.keys(scores)    // ["math", "science", "english"]
Object.values(scores)  // [90, 85, 78]
Object.entries(scores) // [["math", 90], ["science", 85], ["english", 78]]

// Iterate:
for (const [subject, score] of Object.entries(scores)) {
  console.log(`${subject}: ${score}`);
}

// Find average:
const avg = Object.values(scores).reduce((a, b) => a + b) / Object.values(scores).length;
```

## Destructuring

```javascript
const user = { name: "Alex", role: "student", level: 5, city: "Oshawa" };

const { name, role } = user;
// name = "Alex", role = "student"

// Rename while destructuring:
const { name: userName, level: userLevel } = user;
// userName = "Alex", userLevel = 5

// Default values:
const { name: n, theme = "light" } = user;
// n = "Alex", theme = "light" (user has no theme property)

// In function parameters:
function displayUser({ name, role = "guest" }) {
  console.log(`${name} — ${role}`);
}
displayUser(user); // "Alex — student"
```

## Spread and Rest with Objects

```javascript
const base = { name: "Alex", score: 0 };
const withLevel = { ...base, level: 5 }; // { name: "Alex", score: 0, level: 5 }
const updated   = { ...base, score: 100 }; // Overrides score

// Remove a property using rest:
const { score, ...withoutScore } = base;
// withoutScore = { name: "Alex" }
```

## Nested Objects

```javascript
const student = {
  name: "Alex",
  address: {
    city: "Oshawa",
    province: "Ontario"
  },
  courses: ["HTML", "CSS", "JavaScript"]
};

student.address.city     // "Oshawa"
student.courses[1]       // "CSS"

// Optional chaining — safe access:
student.address?.postal  // undefined (not error)
student.school?.name     // undefined — school doesn't exist
```

## Arrays of Objects — The Most Common Pattern

```javascript
const lessons = [
  { id: 1, title: "Intro to JS", duration: 30, complete: true  },
  { id: 2, title: "Variables",   duration: 35, complete: true  },
  { id: 3, title: "Functions",   duration: 40, complete: false },
];

// All completed:
const done = lessons.filter(l => l.complete);

// Total minutes:
const total = lessons.reduce((sum, l) => sum + l.duration, 0);

// Titles only:
const titles = lessons.map(l => l.title);

// Find by id:
const lesson2 = lessons.find(l => l.id === 2);
```

## Object.assign and Cloning

```javascript
// Shallow copy:
const copy = Object.assign({}, original);
const copy2 = { ...original };

// Deep clone (no circular references):
const deepCopy = JSON.parse(JSON.stringify(original));
```

## Key Takeaways 🌟

1. Objects store related data as key-value pairs
2. Dot notation `obj.key` or bracket notation `obj["key"]`
3. `this` inside a method refers to the calling object
4. `Object.keys()`, `.values()`, `.entries()` let you iterate
5. Destructuring: `const { name, role } = user` — clean, modern
6. Spread `{ ...obj }` creates a shallow copy or merges objects
7. Optional chaining `?.` safely accesses nested properties that might not exist
$L$,
ARRAY['javascript','objects','methods','destructuring','spread'], 7),

('dev-l08','The DOM: Connecting JavaScript to HTML','Developers','JavaScript','intermediate',45,'published',
ARRAY['Select HTML elements with querySelector','Read and modify element content and attributes','Understand the DOM tree structure'],
$L$# The DOM: Connecting JavaScript to HTML

## What Is the DOM?

The **Document Object Model** is the browser's representation of your HTML page as a JavaScript object tree. Every element, attribute, and text node is accessible through the `document` object.

```
document
  └── html
       ├── head
       │    └── title
       └── body
            ├── h1 (id="title")
            ├── p  (class="intro")
            └── ul
                 ├── li
                 └── li
```

## Selecting Elements

```javascript
// Single element — returns the first match (or null)
document.getElementById("title")
document.querySelector("#title")          // CSS selector — most flexible
document.querySelector(".card")
document.querySelector("h2")
document.querySelector("nav > a:first-child")

// Multiple elements — returns a NodeList
document.querySelectorAll(".card")        // All elements matching selector
document.querySelectorAll("input[type=checkbox]")
document.getElementsByClassName("card")  // HTMLCollection (older)
document.getElementsByTagName("p")       // HTMLCollection (older)

// Prefer querySelector and querySelectorAll — they accept any CSS selector
```

## Reading Content

```javascript
const heading = document.querySelector("h1");

heading.textContent  // The text inside the element (safe)
heading.innerHTML    // The HTML markup inside (be careful — XSS risk)
heading.innerText    // Visible text only (respects CSS display:none)

const input = document.querySelector("input");
input.value          // Current value of an input field
```

## Modifying Content

```javascript
const heading = document.querySelector("h1");

// Text content — safe, escapes HTML
heading.textContent = "New Title";

// HTML — dangerous if content comes from users!
heading.innerHTML = "<strong>Bold</strong> title";

// Input values
const input = document.querySelector("#name-input");
input.value = "Pre-filled name";
```

⚠️ **Never use `innerHTML` with user-supplied content** — it enables XSS (Cross-Site Scripting) attacks. Always use `textContent` when setting text.

## Modifying Attributes

```javascript
const img = document.querySelector("img");

img.src               // Get src attribute
img.src = "new.jpg"   // Set src attribute
img.alt = "New description"

// General attribute methods:
img.getAttribute("src")
img.setAttribute("src", "new.jpg")
img.removeAttribute("alt")
img.hasAttribute("hidden")

// Boolean attributes:
input.disabled = true
input.checked  = true
input.required = false
```

## Modifying CSS Classes

```javascript
const card = document.querySelector(".card");

card.classList.add("highlight")
card.classList.remove("active")
card.classList.toggle("expanded") // Adds if absent, removes if present
card.classList.contains("active") // true/false
card.classList.replace("old", "new")
```

## Modifying Inline Styles

```javascript
const box = document.querySelector(".box");

box.style.backgroundColor = "navy";     // camelCase, not kebab-case
box.style.fontSize = "1.5rem";
box.style.display = "none";
box.style.transform = "translateY(-8px)";

// Read computed styles (what's actually applied including CSS):
getComputedStyle(box).backgroundColor
```

## Navigating the DOM

```javascript
const item = document.querySelector("li");

item.parentElement          // Parent element
item.children               // Direct children (HTMLCollection)
item.firstElementChild      // First child element
item.lastElementChild       // Last child element
item.nextElementSibling     // Next sibling
item.previousElementSibling // Previous sibling
```

## Creating and Inserting Elements

```javascript
// Create a new element:
const newItem = document.createElement("li");
newItem.textContent = "New list item";
newItem.classList.add("item");

// Insert methods:
const list = document.querySelector("ul");
list.appendChild(newItem);                     // Adds to end
list.prepend(newItem);                         // Adds to start
list.insertBefore(newItem, list.children[2]);  // Before a specific child

// Modern insertion:
list.append(newItem);                          // End (accepts strings too)
list.insertAdjacentHTML("beforeend", "<li>New item</li>"); // Parse and insert HTML
```

## Removing Elements

```javascript
const item = document.querySelector(".old-item");
item.remove();                   // Remove from DOM

// Remove child:
const parent = document.querySelector("ul");
parent.removeChild(parent.lastChild);
```

## Practical: Dynamic Card Creator

```javascript
function createCard({ title, body, badgeText }) {
  const card = document.createElement("div");
  card.classList.add("card");
  
  const badge = document.createElement("span");
  badge.classList.add("badge");
  badge.textContent = badgeText;
  
  const h3 = document.createElement("h3");
  h3.textContent = title;
  
  const p = document.createElement("p");
  p.textContent = body;
  
  card.append(badge, h3, p);
  return card;
}

const lessons = [
  { title: "HTML Basics", body: "Tags and structure.", badgeText: "Beginner" },
  { title: "CSS Styling", body: "Colours and layout.", badgeText: "Beginner" },
  { title: "JavaScript", body: "Logic and interaction.", badgeText: "Intermediate" },
];

const container = document.querySelector("#cards-container");
lessons.forEach(lesson => container.append(createCard(lesson)));
```

## Key Takeaways 🌟

1. The DOM is the browser's tree representation of HTML — JavaScript talks to it via `document`
2. `querySelector` and `querySelectorAll` accept any CSS selector — most flexible selectors
3. Use `textContent` to set text — never `innerHTML` with user data (XSS risk)
4. `classList.add/remove/toggle` is the clean way to update CSS classes
5. `createElement` + `append` builds and inserts new elements
6. Traverse the DOM with `parentElement`, `children`, `nextElementSibling`
$L$,
ARRAY['javascript','dom','queryselector','elements','html-manipulation'], 8),

('dev-l09','Events: Making Pages Respond to Users','Developers','JavaScript','intermediate',45,'published',
ARRAY['Add event listeners to elements','Handle click, input, keyboard, and form events','Understand event bubbling and event delegation'],
$L$# Events: Making Pages Respond to Users

## What Is an Event?

An event is something that happens in the browser — a click, keypress, page load, mouse movement, form submission. JavaScript listens for these events and runs code when they occur.

## addEventListener

```javascript
element.addEventListener(eventType, handlerFunction);
```

```javascript
const btn = document.querySelector("#submit-btn");

btn.addEventListener("click", function() {
  console.log("Button clicked!");
});

// Arrow function:
btn.addEventListener("click", () => {
  console.log("Clicked with arrow function!");
});

// Named function — better for removing later:
function handleClick() {
  console.log("Clicked!");
}
btn.addEventListener("click", handleClick);
btn.removeEventListener("click", handleClick);
```

## The Event Object

The handler receives an event object with information about what happened:

```javascript
btn.addEventListener("click", (event) => {
  console.log(event.type);         // "click"
  console.log(event.target);       // The element that was clicked
  console.log(event.clientX);      // Mouse X position
  console.log(event.clientY);      // Mouse Y position
  console.log(event.timeStamp);    // When it happened
  
  event.preventDefault();          // Stop default browser behaviour
  event.stopPropagation();         // Stop event bubbling up
});
```

## Common Events

### Mouse Events
```javascript
element.addEventListener("click",     handler); // Single click
element.addEventListener("dblclick",  handler); // Double click
element.addEventListener("mouseenter", handler); // Mouse enters element
element.addEventListener("mouseleave", handler); // Mouse leaves element
element.addEventListener("mousemove",  handler); // Mouse moves over element
```

### Keyboard Events
```javascript
document.addEventListener("keydown", (e) => {
  console.log(e.key);   // "ArrowLeft", "Enter", "a", "Escape"
  console.log(e.code);  // "KeyA", "ArrowLeft", "Escape"
  
  if (e.key === "Enter") handleEnter();
  if (e.key === "Escape") closeModal();
  
  // Modifier keys:
  if (e.ctrlKey && e.key === "s") saveDocument(e);
});

document.addEventListener("keyup",  handler);  // When key is released
document.addEventListener("keypress", handler); // Deprecated — use keydown
```

### Input Events
```javascript
const input = document.querySelector("#search");

input.addEventListener("input",  (e) => {
  console.log("Value:", e.target.value); // Fires on every keystroke
});

input.addEventListener("change", (e) => {
  // Fires when input loses focus after a change
  console.log("Final value:", e.target.value);
});

input.addEventListener("focus", () => console.log("Input focused"));
input.addEventListener("blur",  () => console.log("Input lost focus"));
```

### Form Events
```javascript
const form = document.querySelector("form");

form.addEventListener("submit", (e) => {
  e.preventDefault(); // CRITICAL — stops page reload!
  
  const data = new FormData(form);
  console.log(data.get("email"));
  console.log(data.get("message"));
  
  // Process form data...
});

// Individual input change:
form.addEventListener("change", (e) => {
  if (e.target.name === "plan") {
    updatePricingDisplay(e.target.value);
  }
});
```

### Page Lifecycle Events
```javascript
document.addEventListener("DOMContentLoaded", () => {
  // HTML is loaded and parsed — safe to access DOM elements
  initApp();
});

window.addEventListener("load", () => {
  // Everything loaded including images and stylesheets
});

window.addEventListener("resize", () => {
  console.log(`Window: ${window.innerWidth}×${window.innerHeight}`);
});

window.addEventListener("scroll", () => {
  const scrolled = window.scrollY;
  if (scrolled > 100) showBackToTop();
});
```

## Event Bubbling

Events bubble up through the DOM — clicking a child triggers the parent's click listener too:

```html
<div id="outer">
  <div id="inner">
    <button id="btn">Click me</button>
  </div>
</div>
```

```javascript
document.querySelector("#outer").addEventListener("click", () => console.log("Outer"));
document.querySelector("#inner").addEventListener("click", () => console.log("Inner"));
document.querySelector("#btn").addEventListener("click",  () => console.log("Button"));

// Clicking the button logs: "Button", "Inner", "Outer" (bubbles up)
```

Stop bubbling with `event.stopPropagation()` — rarely needed.

## Event Delegation

Instead of adding listeners to many children, add ONE listener to the parent:

```javascript
// Bad — adds 100 listeners for 100 items:
document.querySelectorAll(".todo-item").forEach(item => {
  item.addEventListener("click", handleItemClick);
});

// Good — ONE listener on the parent, check target:
document.querySelector("#todo-list").addEventListener("click", (e) => {
  if (e.target.matches(".todo-item")) {
    handleItemClick(e.target);
  }
  if (e.target.matches(".delete-btn")) {
    deleteItem(e.target.closest(".todo-item"));
  }
});
```

Delegation also works for dynamically added elements — a huge advantage.

## Practical: Interactive To-Do List

```javascript
const form = document.querySelector("#add-form");
const input = document.querySelector("#todo-input");
const list  = document.querySelector("#todo-list");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  const text = input.value.trim();
  if (!text) return;
  
  const li = document.createElement("li");
  li.innerHTML = `
    <span class="todo-text">${text}</span>
    <button class="complete-btn">✓</button>
    <button class="delete-btn">✕</button>
  `;
  list.append(li);
  input.value = "";
  input.focus();
});

// Event delegation on the list:
list.addEventListener("click", (e) => {
  const item = e.target.closest("li");
  
  if (e.target.matches(".complete-btn")) {
    item.classList.toggle("completed");
  }
  
  if (e.target.matches(".delete-btn")) {
    item.style.animation = "fadeOut 0.3s forwards";
    item.addEventListener("animationend", () => item.remove());
  }
});
```

## Key Takeaways 🌟

1. `addEventListener(type, handler)` — the modern, preferred way to listen for events
2. The event object contains info about what happened: `e.target`, `e.key`, `e.preventDefault()`
3. `e.preventDefault()` is critical on form submit — prevents page reload
4. Events bubble up the DOM — clicking a child triggers parent listeners too
5. **Event delegation**: add ONE listener to a parent, check `e.target` inside
6. Delegation works for dynamically added elements — a key advantage
7. `DOMContentLoaded` is the right time to initialise most JavaScript
$L$,
ARRAY['javascript','events','event-listeners','dom','event-delegation'], 9),

('dev-l10','Building Interactive UIs: Forms and Validation','Developers','JavaScript','intermediate',45,'published',
ARRAY['Build fully validated forms with JavaScript','Show real-time feedback as users type','Disable/enable submit based on form state'],
$L$# Building Interactive UIs: Forms and Validation

## Why Client-Side Validation?

HTML5 validation (`required`, `type="email"`, `pattern`) handles basic checks. But for real UX — live feedback as you type, custom error messages, cross-field validation — you need JavaScript.

Note: Always validate on the server too. Client-side validation is for UX, not security.

## Accessing Form Values

```javascript
// By name via form element:
const form = document.querySelector("form");
const email = form.email.value;         // form.elements.email.value
const password = form.password.value;

// By FormData (captures entire form):
const data = new FormData(form);
data.get("email");        // Value of input named "email"
data.get("message");      // Value of textarea named "message"
data.getAll("interests"); // Array of all checked checkboxes with name "interests"

// Convert to plain object:
const obj = Object.fromEntries(data);
// { email: "...", password: "...", message: "..." }
```

## Live Validation as Users Type

```javascript
const emailInput = document.querySelector("#email");
const emailError = document.querySelector("#email-error");

emailInput.addEventListener("input", () => {
  const value = emailInput.value;
  
  if (value.length === 0) {
    setFieldState(emailInput, emailError, "", "neutral");
  } else if (!isValidEmail(value)) {
    setFieldState(emailInput, emailError, "Please enter a valid email address.", "error");
  } else {
    setFieldState(emailInput, emailError, "Looks good! ✓", "success");
  }
});

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function setFieldState(input, errorEl, message, state) {
  input.className = `field-${state}`;   // Applies CSS class
  errorEl.textContent = message;
  errorEl.className = `error-msg ${state}`;
}
```

## A Complete Registration Form

```javascript
// Form state object — tracks everything in one place
const formState = {
  name: { value: "", valid: false },
  email: { value: "", valid: false },
  password: { value: "", valid: false },
  confirmPassword: { value: "", valid: false }
};

// Validators
const validators = {
  name:    v => v.trim().length >= 2,
  email:   v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  password: v => v.length >= 8 && /[A-Z]/.test(v) && /[0-9]/.test(v),
  confirmPassword: v => v === formState.password.value
};

// Error messages
const messages = {
  name:     "Name must be at least 2 characters.",
  email:    "Enter a valid email address.",
  password: "Password needs 8+ characters, one uppercase, one number.",
  confirmPassword: "Passwords do not match."
};

// Wire up each field
["name", "email", "password", "confirmPassword"].forEach(field => {
  const input  = document.querySelector(`#${field}`);
  const errEl  = document.querySelector(`#${field}-error`);
  
  input.addEventListener("input", () => {
    const value   = input.value;
    const isValid = validators[field](value);
    
    formState[field].value = value;
    formState[field].valid = isValid;
    
    errEl.textContent = isValid ? "" : messages[field];
    input.classList.toggle("valid",   isValid);
    input.classList.toggle("invalid", !isValid && value.length > 0);
    
    updateSubmitButton();
  });
});

// Disable submit until all fields valid
function updateSubmitButton() {
  const allValid = Object.values(formState).every(f => f.valid);
  document.querySelector("#submit-btn").disabled = !allValid;
}

// Handle submission
document.querySelector("form").addEventListener("submit", (e) => {
  e.preventDefault();
  
  const allValid = Object.values(formState).every(f => f.valid);
  if (!allValid) return; // Extra guard
  
  console.log("Form data:", Object.fromEntries(
    Object.entries(formState).map(([k, v]) => [k, v.value])
  ));
  
  showSuccess("Account created! Welcome to CODEship Academy.");
});

function showSuccess(message) {
  const form = document.querySelector("form");
  form.innerHTML = `
    <div class="success-msg">
      <p>✓ ${message}</p>
    </div>
  `;
}
```

## Password Strength Indicator

```javascript
const passwordInput = document.querySelector("#password");
const strengthBar   = document.querySelector("#strength-bar");
const strengthText  = document.querySelector("#strength-text");

passwordInput.addEventListener("input", () => {
  const password = passwordInput.value;
  const strength = getPasswordStrength(password);
  
  strengthBar.style.width = `${strength.score * 25}%`;
  strengthBar.style.backgroundColor = strength.colour;
  strengthText.textContent = strength.label;
});

function getPasswordStrength(password) {
  let score = 0;
  if (password.length >= 8)          score++;
  if (password.length >= 12)         score++;
  if (/[A-Z]/.test(password))        score++;
  if (/[0-9]/.test(password))        score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  
  const levels = [
    { score: 0, label: "",       colour: "transparent" },
    { score: 1, label: "Weak",   colour: "#EF4444"     },
    { score: 2, label: "Fair",   colour: "#F59E0B"     },
    { score: 3, label: "Good",   colour: "#3B82F6"     },
    { score: 4, label: "Strong", colour: "#22C55E"     },
    { score: 5, label: "Very Strong", colour: "#15803D" }
  ];
  
  return levels[Math.min(score, 5)];
}
```

## Key Takeaways 🌟

1. `form.fieldName.value` or `FormData` to read form values
2. `input` event fires on every keystroke — use for live validation
3. `change` event fires when the field loses focus after a change
4. Always `e.preventDefault()` on form submit — prevents page reload
5. Disable the submit button until all fields are valid — prevents bad submissions
6. Validate format client-side (UX) AND server-side (security)
7. A single state object tracking all field validity makes enabling/disabling submit clean
$L$,
ARRAY['javascript','forms','validation','dom','input-events'], 10);


-- ═══════════════════════════════════════════════════════════════════════════
-- LESSONS 11-50: INTERMEDIATE JS + DOM + APIs
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('dev-l11','Loops: Repeating Actions Efficiently','Developers','JavaScript','intermediate',35,'published',
ARRAY['Write for, while, and for...of loops','Choose the right loop for each situation','Use break and continue to control loop flow'],
$L$# Loops: Repeating Actions Efficiently

## Why Loops?

Without loops, repeating an action 100 times means 100 lines of code. Loops let you run the same code many times with minimal repetition.

## The `for` Loop

```javascript
for (initialisation; condition; update) {
  // Runs while condition is true
}

for (let i = 0; i < 5; i++) {
  console.log(i); // 0, 1, 2, 3, 4
}

// Counting down:
for (let i = 10; i >= 0; i--) {
  console.log(i); // 10, 9, 8...0
}

// Iterating an array:
const fruits = ["apple", "banana", "cherry"];
for (let i = 0; i < fruits.length; i++) {
  console.log(`${i}: ${fruits[i]}`);
}
```

## The `while` Loop

Runs while a condition is true — useful when you don't know the count in advance:

```javascript
while (condition) { ... }

let attempts = 0;
while (attempts < 3) {
  const guess = prompt("Guess the number:");
  if (parseInt(guess) === 42) {
    console.log("Correct!");
    break;
  }
  attempts++;
}

// do...while — always runs at least once:
do {
  const input = getInput();
} while (!isValid(input));
```

## `for...of` — Best for Arrays

```javascript
const scores = [85, 92, 78, 96];

for (const score of scores) {
  console.log(score);
}

// With destructuring:
const students = [{name: "Alex", score: 85}, {name: "Sam", score: 92}];
for (const {name, score} of students) {
  console.log(`${name}: ${score}`);
}
```

## `for...in` — For Object Keys

```javascript
const profile = { name: "Alex", level: 5, xp: 2400 };

for (const key in profile) {
  console.log(`${key}: ${profile[key]}`);
}
// name: Alex
// level: 5
// xp: 2400
```

## `break` and `continue`

```javascript
// break — exits the loop entirely:
for (let i = 0; i < 100; i++) {
  if (i === 5) break;  // Stops at 5
  console.log(i);      // 0, 1, 2, 3, 4
}

// continue — skips to next iteration:
for (let i = 0; i < 10; i++) {
  if (i % 2 === 0) continue;  // Skip even numbers
  console.log(i);              // 1, 3, 5, 7, 9
}
```

## Choosing the Right Loop

| Loop | Use When |
|------|----------|
| `for` | Known count, need index |
| `while` | Unknown count, condition-based |
| `for...of` | Iterating array/string values |
| `for...in` | Iterating object keys |
| `forEach/map/filter` | Array transformations (prefer these!) |

## Nested Loops

```javascript
// Multiplication table:
for (let i = 1; i <= 5; i++) {
  let row = "";
  for (let j = 1; j <= 5; j++) {
    row += `${i * j}\t`;
  }
  console.log(row);
}
```

## Key Takeaways 🌟

1. `for (let i = 0; i < n; i++)` — classic counted loop
2. `while (condition)` — runs while condition is true
3. `for...of` — cleanest way to iterate arrays
4. `for...in` — iterates object keys (not values)
5. `break` exits; `continue` skips to next iteration
6. For array transformations, prefer `map`, `filter`, `reduce` over manual loops
$L$,
ARRAY['javascript','loops','for','while','iteration'], 11),

('dev-l12','String Methods: Manipulating Text','Developers','JavaScript','intermediate',35,'published',
ARRAY['Use essential string methods','Manipulate and search strings','Use regular expressions for pattern matching'],
$L$# String Methods: Manipulating Text

## Strings Are Immutable

Every string method returns a **new** string — they never modify the original:

```javascript
const str = "Hello, World!";
str.toUpperCase();          // "HELLO, WORLD!"
console.log(str);           // "Hello, World!" — unchanged
```

## Length and Access

```javascript
const str = "Hello";
str.length      // 5
str[0]          // "H"
str.at(0)       // "H"
str.at(-1)      // "o" — last character (at() supports negative!)
str.charAt(1)   // "e"
```

## Case

```javascript
"hello".toUpperCase()  // "HELLO"
"HELLO".toLowerCase()  // "hello"
```

## Searching

```javascript
const str = "The quick brown fox jumps over the lazy dog";

str.includes("fox")     // true
str.startsWith("The")   // true
str.endsWith("dog")     // true
str.indexOf("the")      // 31 (first occurrence, case-sensitive)
str.lastIndexOf("the")  // 31
str.indexOf("cat")      // -1 (not found)
```

## Extracting Substrings

```javascript
const str = "Hello, World!";

str.slice(7, 12)   // "World"    (start, end — end is exclusive)
str.slice(7)       // "World!"   (to the end)
str.slice(-6)      // "World!"   (from the end)
str.slice(-6, -1)  // "World"

str.substring(7, 12) // "World"  (like slice, but no negatives)
```

## Modifying

```javascript
"  hello  ".trim()          // "hello" (removes both ends)
"  hello  ".trimStart()     // "hello  "
"  hello  ".trimEnd()       // "  hello"

"ha".repeat(3)              // "hahaha"
"hello".replace("l", "r")   // "herlo" (first occurrence only)
"hello".replaceAll("l", "r") // "herro" (all occurrences)

"hello world".split(" ")    // ["hello", "world"]
["hello", "world"].join(" ") // "hello world"
```

## Padding

```javascript
"5".padStart(3, "0")  // "005" — pad to length 3 from start
"5".padEnd(3, "-")    // "5--" — pad to length 3 from end
```

## Template Literals — All Features

```javascript
const name = "Alex";
const score = 95;

// Basic interpolation:
`Hello, ${name}! Score: ${score}`

// Expression evaluation:
`${score >= 90 ? "A" : "B"}`

// Multi-line:
`Line one
 Line two`

// Tagged templates (advanced):
const html = String.raw`<p>Escape \n is kept literal</p>`;
```

## Regular Expressions

RegEx patterns for searching and validating:

```javascript
const email = "user@example.com";

// Test if it matches:
/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)  // true

// Extract matches:
const text = "I have 3 cats and 2 dogs";
text.match(/\d+/g)  // ["3", "2"] — all numbers

// Replace with regex:
"Hello   World".replace(/\s+/g, " ")  // "Hello World" (collapse spaces)
"2024-01-15".replace(/(\d{4})-(\d{2})-(\d{2})/, "$2/$3/$1") // "01/15/2024"

// Common patterns:
/^\d+$/         // Only digits
/^[a-zA-Z]+$/  // Only letters
/^#[0-9A-Fa-f]{6}$/ // Hex colour (#1E2140)
```

## Practical: Text Processing

```javascript
function slugify(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")  // Remove special chars
    .replace(/\s+/g, "-")           // Spaces to hyphens
    .replace(/-+/g, "-");           // Multiple hyphens to one
}

slugify("Hello, World! (2024)") // "hello-world-2024"

function truncate(text, maxLength = 100, ellipsis = "...") {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength - ellipsis.length).trimEnd() + ellipsis;
}

function capitalise(str) {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function titleCase(str) {
  return str.split(" ").map(capitalise).join(" ");
}
```

## Key Takeaways 🌟

1. String methods return new strings — originals are immutable
2. `includes`, `startsWith`, `endsWith` for searching; `indexOf` for position
3. `slice(start, end)` extracts; `split(delimiter)` creates array; `join` reunites
4. `trim()` removes whitespace from both ends
5. `replace(pattern, replacement)` — use `/pattern/g` regex flag for all occurrences
6. Regular expressions `/pattern/` — powerful but complex; learn basic patterns first
$L$,
ARRAY['javascript','strings','string-methods','regex'], 12),

('dev-l13','Numbers and Math: Calculations in JavaScript','Developers','JavaScript','intermediate',25,'published',
ARRAY['Use the Math object for calculations','Format numbers for display','Avoid common floating point pitfalls'],
$L$# Numbers and Math

## The Math Object

```javascript
Math.round(4.6)     // 5  — nearest integer
Math.ceil(4.1)      // 5  — always rounds up
Math.floor(4.9)     // 4  — always rounds down
Math.trunc(4.9)     // 4  — removes decimal (towards zero)

Math.abs(-42)       // 42  — absolute value
Math.max(1, 5, 3)  // 5
Math.min(1, 5, 3)  // 1
Math.max(...arr)    // Works with arrays using spread

Math.pow(2, 10)    // 1024 — same as 2**10
Math.sqrt(144)     // 12
Math.cbrt(27)      // 3  — cube root

Math.PI            // 3.141592653589793
Math.E             // 2.718281828459045
```

## Random Numbers

```javascript
Math.random()                       // 0 to 0.999... (never exactly 1)

// Random integer 1–6 (dice):
Math.floor(Math.random() * 6) + 1  // 1, 2, 3, 4, 5, or 6

// Random integer between min and max (inclusive):
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
randInt(1, 100) // 1–100

// Random array element:
const arr = ["rock", "paper", "scissors"];
arr[Math.floor(Math.random() * arr.length)]
```

## Number Formatting

```javascript
const n = 1234567.891;

n.toFixed(2)               // "1234567.89" — 2 decimal places (returns string)
n.toLocaleString()         // "1,234,567.891" — locale-appropriate
n.toLocaleString("fr-CA")  // "1 234 567,891" — French Canadian

// Intl.NumberFormat (powerful):
new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD" })
  .format(9.99)  // "CA$9.99"

new Intl.NumberFormat("en", { notation: "compact" })
  .format(1500000)  // "1.5M"
```

## Floating Point Caution

```javascript
0.1 + 0.2    // 0.30000000000000004

// Solutions:
+(0.1 + 0.2).toFixed(2)      // 0.3
Math.round((0.1 + 0.2) * 100) / 100  // 0.3

// For money — work in cents (integers):
const priceInCents = 999; // $9.99
const tax = Math.round(priceInCents * 0.13);
const total = priceInCents + tax;
(total / 100).toFixed(2);  // "11.29"
```

## Number Parsing

```javascript
parseInt("42")        // 42
parseInt("42.9")      // 42 (truncates)
parseInt("42px")      // 42 (stops at non-numeric)
parseInt("abc")       // NaN
parseFloat("3.14")    // 3.14
Number("42")          // 42 (strict — "42px" → NaN)

// Check for NaN:
isNaN("hello")        // true
Number.isNaN(NaN)     // true (stricter — isNaN("hello") is true even for strings)
Number.isFinite(Infinity) // false
Number.isInteger(4.0) // true
```

## Key Takeaways 🌟

1. `Math.random() * range + min` for random numbers in a range
2. `Math.floor`, `Math.ceil`, `Math.round` for rounding
3. `.toFixed(n)` for decimal places; `.toLocaleString()` for formatted display
4. Never use floating point for money — work in integer cents
5. `Number.isNaN()` is stricter than `isNaN()` — prefer it
$L$,
ARRAY['javascript','math','numbers','formatting','random'], 13),

('dev-l14','Dates and Times','Developers','JavaScript','intermediate',30,'published',
ARRAY['Create and manipulate Date objects','Format dates for display','Calculate time differences'],
$L$# Dates and Times

## Creating Dates

```javascript
const now = new Date();                    // Current date and time
const specific = new Date("2024-11-15");   // From ISO string
const custom = new Date(2024, 10, 15);    // Year, month (0-indexed!), day
const fromMs = new Date(0);               // Jan 1, 1970 (Unix epoch)
```

**Warning:** Months are 0-indexed (January = 0, December = 11)!

## Reading Date Parts

```javascript
const d = new Date("2024-11-15T14:30:00");

d.getFullYear()    // 2024
d.getMonth()       // 10 (November — zero-indexed!)
d.getDate()        // 15 (day of month)
d.getDay()         // 5 (Friday — 0=Sunday)
d.getHours()       // 14
d.getMinutes()     // 30
d.getSeconds()     // 0
d.getTime()        // Milliseconds since Jan 1, 1970
```

## Formatting Dates

```javascript
const d = new Date("2024-11-15");

// Built-in methods:
d.toLocaleDateString()          // "11/15/2024" (locale-dependent)
d.toLocaleDateString("en-CA")   // "2024-11-15"
d.toLocaleString("en-CA")       // "2024-11-15, 12:00:00 a.m."
d.toISOString()                 // "2024-11-15T00:00:00.000Z"

// Intl.DateTimeFormat (powerful):
new Intl.DateTimeFormat("en-CA", {
  year: "numeric", month: "long", day: "numeric"
}).format(d); // "November 15, 2024"

new Intl.DateTimeFormat("fr-CA", {
  weekday: "long", year: "numeric", month: "long", day: "numeric"
}).format(d); // "vendredi 15 novembre 2024"
```

## Date Arithmetic

```javascript
const now = new Date();
const ms = now.getTime(); // Milliseconds since epoch

// Add 7 days:
const nextWeek = new Date(ms + 7 * 24 * 60 * 60 * 1000);

// Difference between dates:
const start = new Date("2024-01-01");
const end   = new Date("2024-12-31");
const diffMs   = end - start;
const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
// 365 days
```

## Relative Time (Time Ago)

```javascript
function timeAgo(date) {
  const seconds = Math.floor((Date.now() - date) / 1000);
  
  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  
  if (seconds < 60)   return rtf.format(-seconds, "second");
  if (seconds < 3600) return rtf.format(-Math.floor(seconds/60), "minute");
  if (seconds < 86400) return rtf.format(-Math.floor(seconds/3600), "hour");
  return rtf.format(-Math.floor(seconds/86400), "day");
}

timeAgo(new Date(Date.now() - 5000))    // "5 seconds ago"
timeAgo(new Date(Date.now() - 90000))   // "1 minute ago"
timeAgo(new Date(Date.now() - 86400000)) // "yesterday"
```

## Countdown Timer

```javascript
function createCountdown(targetDate, displayEl) {
  function update() {
    const diff = new Date(targetDate) - Date.now();
    
    if (diff <= 0) {
      displayEl.textContent = "Time's up!";
      return;
    }
    
    const days    = Math.floor(diff / 86400000);
    const hours   = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    
    displayEl.textContent = `${days}d ${hours}h ${minutes}m ${seconds}s`;
  }
  
  update();
  setInterval(update, 1000);
}

createCountdown("2025-01-01T00:00:00", document.querySelector("#countdown"));
```

## Key Takeaways 🌟

1. `new Date()` for now; `new Date("ISO-string")` for specific dates
2. Months are 0-indexed — January = 0, December = 11!
3. `Intl.DateTimeFormat` for locale-appropriate formatting
4. Date arithmetic works in milliseconds: `1000 * 60 * 60 * 24` = 1 day
5. `Intl.RelativeTimeFormat` for "2 minutes ago" style strings
$L$,
ARRAY['javascript','dates','time','intl','formatting'], 14),

('dev-l15','Local Storage: Persisting Data','Developers','JavaScript','intermediate',35,'published',
ARRAY['Save and retrieve data with localStorage','Handle JSON serialisation','Build a persistent to-do list'],
$L$# Local Storage: Persisting Data

## What Is localStorage?

`localStorage` stores key-value pairs in the browser. The data persists after the page is closed or refreshed — until the user clears browser storage.

- Storage limit: ~5–10 MB per origin
- String only: must serialise objects to JSON
- Synchronous: blocking, but so fast it does not matter for small data
- Same-origin only: script.com cannot access data from other.com

## Basic API

```javascript
// Store a value:
localStorage.setItem("username", "Alex");
localStorage.setItem("score", "850");       // Must be a string

// Retrieve a value:
localStorage.getItem("username");           // "Alex"
localStorage.getItem("score");             // "850" (string, not number!)
localStorage.getItem("missing");           // null

// Remove:
localStorage.removeItem("username");

// Clear ALL keys:
localStorage.clear();                      // Nuclear option — use carefully

// Count keys:
localStorage.length;

// Iterate all keys:
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  console.log(key, localStorage.getItem(key));
}
```

## Working with Objects: JSON

```javascript
// Store an object (must serialise):
const user = { name: "Alex", level: 5, xp: 2400 };
localStorage.setItem("user", JSON.stringify(user));

// Retrieve and parse:
const stored = localStorage.getItem("user");
const parsed = JSON.parse(stored);  // { name: "Alex", level: 5, xp: 2400 }

// Utility functions:
function saveToStorage(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function loadFromStorage(key, defaultValue = null) {
  const stored = localStorage.getItem(key);
  if (stored === null) return defaultValue;
  try {
    return JSON.parse(stored);
  } catch {
    return defaultValue;
  }
}
```

## Persistent To-Do List

```javascript
const STORAGE_KEY = "codeship-todos";

// Load saved todos (default to empty array):
let todos = loadFromStorage(STORAGE_KEY, []);

function saveTodos() {
  saveToStorage(STORAGE_KEY, todos);
}

function addTodo(text) {
  todos.push({ id: Date.now(), text, complete: false });
  saveTodos();
  renderTodos();
}

function toggleTodo(id) {
  todos = todos.map(t => t.id === id ? { ...t, complete: !t.complete } : t);
  saveTodos();
  renderTodos();
}

function deleteTodo(id) {
  todos = todos.filter(t => t.id !== id);
  saveTodos();
  renderTodos();
}

function renderTodos() {
  const list = document.querySelector("#todo-list");
  list.innerHTML = todos.map(todo => `
    <li class="${todo.complete ? "complete" : ""}">
      <input type="checkbox" ${todo.complete ? "checked" : ""}
             onchange="toggleTodo(${todo.id})">
      <span>${todo.text}</span>
      <button onclick="deleteTodo(${todo.id})">✕</button>
    </li>
  `).join("");
}

// Initial render:
renderTodos();
```

## Session Storage vs Local Storage

```javascript
// sessionStorage — same API but data disappears when tab is closed:
sessionStorage.setItem("temporaryData", "only for this session");
sessionStorage.getItem("temporaryData");
```

Use `sessionStorage` for temporary data (like a multi-step form in progress).
Use `localStorage` for data that should persist across sessions.

## Key Takeaways 🌟

1. `localStorage.setItem(key, value)` — value must be a string
2. `JSON.stringify()` converts objects to strings for storage
3. `JSON.parse()` converts stored strings back to objects
4. `localStorage.getItem()` returns `null` if key doesn't exist
5. Always wrap `JSON.parse` in try-catch — invalid JSON throws an error
6. `sessionStorage` same API but clears when tab closes
$L$,
ARRAY['javascript','localstorage','json','persistence','storage'], 15),

('dev-l16','Fetch API and Promises: Talking to Servers','Developers','JavaScript','intermediate',50,'published',
ARRAY['Understand synchronous vs asynchronous code','Use fetch to retrieve data from an API','Handle promises with .then() and async/await'],
$L$# Fetch API and Promises: Talking to Servers

## Synchronous vs Asynchronous Code

**Synchronous:** Each line waits for the previous to finish.
```javascript
console.log("1");
console.log("2");
console.log("3");
// Output: 1, 2, 3 — always in order
```

**Asynchronous:** Some operations take time (network requests, timers). JavaScript does not wait — it continues and handles the result later.

```javascript
console.log("1");
setTimeout(() => console.log("2"), 1000); // Runs after 1 second
console.log("3");
// Output: 1, 3, 2 — 3 prints before 2!
```

## What Is a Promise?

A **Promise** represents a value that will be available in the future. It's in one of three states:
- **Pending** — operation in progress
- **Fulfilled** — operation succeeded (has a value)
- **Rejected** — operation failed (has an error)

```javascript
const myPromise = new Promise((resolve, reject) => {
  setTimeout(() => resolve("Success!"), 1000);
  // or: reject(new Error("Something went wrong"));
});

myPromise
  .then(value => console.log(value))   // "Success!" after 1 second
  .catch(error => console.error(error))
  .finally(() => console.log("Done"));  // Always runs
```

## The Fetch API

`fetch()` makes HTTP requests and returns a Promise:

```javascript
fetch("https://api.example.com/data")
  .then(response => {
    if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
    return response.json(); // Parse JSON body (also returns a Promise)
  })
  .then(data => {
    console.log(data); // The actual data
  })
  .catch(error => {
    console.error("Fetch failed:", error);
  });
```

## async/await — The Modern Way

`async/await` makes asynchronous code look synchronous — much easier to read:

```javascript
// A function declared async always returns a Promise:
async function getData() {
  try {
    const response = await fetch("https://api.example.com/data");
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error:", error.message);
    return null;
  }
}

// Call it:
const data = await getData(); // Inside another async function
// or:
getData().then(data => console.log(data));
```

## Real API Example: PokéAPI

```javascript
async function fetchPokemon(nameOrId) {
  const url = `https://pokeapi.co/api/v2/pokemon/${nameOrId}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Pokémon not found");
    
    const pokemon = await response.json();
    
    return {
      name:   pokemon.name,
      id:     pokemon.id,
      height: pokemon.height / 10 + "m",
      weight: pokemon.weight / 10 + "kg",
      types:  pokemon.types.map(t => t.type.name),
      sprite: pokemon.sprites.front_default
    };
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function displayPokemon(name) {
  const card = document.querySelector("#pokemon-card");
  card.textContent = "Loading...";
  
  const pokemon = await fetchPokemon(name);
  
  if (!pokemon) {
    card.textContent = "Pokémon not found.";
    return;
  }
  
  card.innerHTML = `
    <img src="${pokemon.sprite}" alt="${pokemon.name}">
    <h2>${pokemon.name.toUpperCase()} #${pokemon.id}</h2>
    <p>Types: ${pokemon.types.join(", ")}</p>
    <p>Height: ${pokemon.height} · Weight: ${pokemon.weight}</p>
  `;
}
```

## HTTP Methods

```javascript
// GET — retrieve data (default):
const response = await fetch("/api/users");

// POST — create new data:
const response = await fetch("/api/users", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ name: "Alex", email: "alex@example.com" })
});

// PUT — replace an entire resource:
const response = await fetch("/api/users/1", {
  method: "PUT",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(updatedUser)
});

// PATCH — update part of a resource:
const response = await fetch("/api/users/1", {
  method: "PATCH",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ score: 100 })
});

// DELETE — remove a resource:
const response = await fetch("/api/users/1", { method: "DELETE" });
```

## Multiple Requests

```javascript
// Run requests simultaneously:
const [users, posts] = await Promise.all([
  fetch("/api/users").then(r => r.json()),
  fetch("/api/posts").then(r => r.json())
]);

// First to succeed:
const fastestData = await Promise.race([
  fetch("/api/server1/data").then(r => r.json()),
  fetch("/api/server2/data").then(r => r.json())
]);
```

## Key Takeaways 🌟

1. JavaScript is non-blocking — async operations don't halt execution
2. Promises represent future values: pending → fulfilled/rejected
3. `async/await` makes Promise code readable — always use `try/catch`
4. `fetch(url)` returns a Promise — chain `.then(r => r.json())` to get data
5. Check `response.ok` — fetch only rejects on network failure, not 404/500
6. `Promise.all([...])` runs multiple requests simultaneously
7. GET (read), POST (create), PUT/PATCH (update), DELETE — HTTP methods
$L$,
ARRAY['javascript','fetch','promises','async','await','api'], 16),

('dev-l17','Working with APIs: Real-World Data','Developers','JavaScript','intermediate',50,'published',
ARRAY['Connect to public REST APIs','Parse and display API responses','Build an API-powered search feature'],
$L$# Working with APIs: Real-World Data

## What Is an API?

An **API** (Application Programming Interface) is a defined way for programs to communicate. A **REST API** lets you retrieve and manipulate data over HTTP.

When you use weather apps, map services, or any web service — you're using APIs.

## Understanding API Responses

Most modern APIs return **JSON** (JavaScript Object Notation):

```json
{
  "id": 1,
  "name": "Alex Kim",
  "email": "alex@example.com",
  "courses": [
    { "id": 101, "title": "HTML Basics", "complete": true },
    { "id": 102, "title": "CSS Flexbox", "complete": false }
  ]
}
```

JSON is a string representation of JavaScript objects/arrays. `response.json()` parses it.

## Free APIs You Can Use Today

| API | What it provides | URL |
|-----|-----------------|-----|
| PokéAPI | Pokémon data | pokeapi.co |
| Open-Meteo | Weather (no key) | open-meteo.com |
| JSONPlaceholder | Fake REST data | jsonplaceholder.typicode.com |
| REST Countries | Country data | restcountries.com |
| Open Library | Books | openlibrary.org/api |
| NASA APOD | Astronomy photo | api.nasa.gov |

## Building a Weather Widget

```javascript
// Open-Meteo API — free, no key required!
async function getWeather(lat, lon) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude",  lat);
  url.searchParams.set("longitude", lon);
  url.searchParams.set("current",   "temperature_2m,weathercode,windspeed_10m");
  url.searchParams.set("timezone",  "auto");
  
  const response = await fetch(url);
  if (!response.ok) throw new Error("Weather fetch failed");
  return response.json();
}

const weatherCodes = {
  0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
  45: "Foggy", 51: "Light drizzle", 61: "Light rain", 71: "Light snow",
  80: "Rain showers", 95: "Thunderstorm"
};

async function displayWeather() {
  const widget = document.querySelector("#weather-widget");
  widget.textContent = "Loading...";
  
  try {
    // Oshawa, Ontario coordinates:
    const data = await getWeather(43.8971, -78.8658);
    const current = data.current;
    const code    = current.weathercode;
    
    widget.innerHTML = `
      <div class="weather-card">
        <h2>Oshawa, Ontario</h2>
        <div class="temperature">${Math.round(current.temperature_2m)}°C</div>
        <div class="condition">${weatherCodes[code] ?? "Unknown"}</div>
        <div class="wind">💨 ${current.windspeed_10m} km/h</div>
      </div>
    `;
  } catch (error) {
    widget.textContent = "Weather unavailable.";
  }
}
```

## Building a Country Search

```javascript
async function searchCountry(query) {
  if (!query.trim()) return [];
  
  const url = `https://restcountries.com/v3.1/name/${encodeURIComponent(query)}`;
  
  const response = await fetch(url);
  if (response.status === 404) return [];
  if (!response.ok) throw new Error("Search failed");
  
  const countries = await response.json();
  
  return countries.map(c => ({
    name:       c.name.common,
    official:   c.name.official,
    capital:    c.capital?.[0] ?? "N/A",
    population: c.population,
    region:     c.region,
    flag:       c.flags.svg
  }));
}

// Debounced search (waits 400ms after last keystroke before searching):
let searchTimer;
document.querySelector("#search-input").addEventListener("input", (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(async () => {
    const results = await searchCountry(e.target.value);
    renderResults(results);
  }, 400);
});

function renderResults(countries) {
  const container = document.querySelector("#results");
  
  if (countries.length === 0) {
    container.innerHTML = "<p>No countries found.</p>";
    return;
  }
  
  container.innerHTML = countries.slice(0, 5).map(c => `
    <div class="country-card">
      <img src="${c.flag}" alt="Flag of ${c.name}">
      <div>
        <h3>${c.name}</h3>
        <p>Capital: ${c.capital}</p>
        <p>Population: ${c.population.toLocaleString()}</p>
        <p>Region: ${c.region}</p>
      </div>
    </div>
  `).join("");
}
```

## URL Construction

```javascript
// Building query strings safely with URLSearchParams:
const params = new URLSearchParams({
  q: "JavaScript tutorial",
  lang: "en",
  page: 1
});
params.toString(); // "q=JavaScript+tutorial&lang=en&page=1"

const url = `https://api.example.com/search?${params}`;

// URLSearchParams handles encoding automatically:
// Spaces become +, & and = are escaped, etc.
```

## Error Handling Patterns

```javascript
async function robustFetch(url, options = {}) {
  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), 10000); // 10s timeout
  
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("Request timed out after 10 seconds");
    }
    throw error;
  }
}
```

## Key Takeaways 🌟

1. REST APIs use HTTP: GET (read), POST (create), PUT/PATCH (update), DELETE
2. Most APIs return JSON — `response.json()` parses it
3. `URLSearchParams` builds query strings safely — handles encoding
4. Debouncing (setTimeout + clearTimeout) prevents too many API calls on every keystroke
5. Always handle errors — network can fail, APIs can be down
6. `encodeURIComponent()` escapes special characters in URL parameters
7. Check `response.ok` before `.json()` — 404 responses don't reject the promise
$L$,
ARRAY['javascript','api','fetch','rest','json'], 17),

('dev-l18','JSON: The Data Format of the Web','Developers','JavaScript','intermediate',25,'published',
ARRAY['Read and write JSON syntax correctly','Parse and stringify JSON','Understand common JSON patterns'],
$L$# JSON: The Data Format of the Web

## What Is JSON?

JSON (JavaScript Object Notation) is a text format for storing and exchanging data. It looks like JavaScript objects but has stricter rules.

Used everywhere: APIs, config files, databases, local storage.

## JSON Syntax Rules

```json
{
  "name": "Alex Kim",
  "age": 15,
  "enrolled": true,
  "score": null,
  "courses": ["HTML", "CSS", "JavaScript"],
  "address": {
    "city": "Oshawa",
    "province": "Ontario"
  }
}
```

JSON rules (different from JavaScript objects):
- **All keys must be double-quoted strings**: `"name"` not `name`
- **No trailing commas**: `[1, 2, 3]` not `[1, 2, 3,]`
- **No comments**: `// comments` break JSON
- **No functions, undefined, or Symbol**: only string, number, boolean, null, array, object
- **Strings use double quotes only**: `"hello"` not `'hello'`

## Parsing and Stringifying

```javascript
// Parse: JSON string → JavaScript object
const jsonString = '{"name":"Alex","score":850}';
const obj = JSON.parse(jsonString);
obj.name   // "Alex"
obj.score  // 850

// Stringify: JavaScript object → JSON string
const user = { name: "Alex", score: 850, active: true };
const json = JSON.stringify(user);
// '{"name":"Alex","score":850,"active":true}'

// Pretty-printed (for readability):
JSON.stringify(user, null, 2);
// {
//   "name": "Alex",
//   "score": 850,
//   "active": true
// }

// Filter specific keys:
JSON.stringify(user, ["name", "score"]);
// '{"name":"Alex","score":850}'
```

## JSON.parse Error Handling

```javascript
function safeParse(jsonString, fallback = null) {
  try {
    return JSON.parse(jsonString);
  } catch (error) {
    console.warn("JSON parse error:", error.message);
    return fallback;
  }
}

safeParse('{"valid": true}')      // { valid: true }
safeParse('not json at all', {})  // {} (fallback)
```

## Deep Clone with JSON

```javascript
const original = { user: { name: "Alex", scores: [1, 2, 3] } };
const deepCopy = JSON.parse(JSON.stringify(original));
deepCopy.user.name = "Changed";
original.user.name; // "Alex" — not affected
```

Limitation: doesn't handle `undefined`, `Date` objects, functions, or circular references.

## JSON in the Real World

```javascript
// API response:
const response = await fetch("https://api.example.com/user/1");
const user = await response.json(); // Parses JSON automatically

// localStorage:
localStorage.setItem("prefs", JSON.stringify({ theme: "dark", lang: "fr" }));
const prefs = JSON.parse(localStorage.getItem("prefs"));

// Config files (package.json, .eslintrc.json) are JSON
```

## Key Takeaways 🌟

1. JSON is a text format — keys must be double-quoted strings
2. `JSON.parse(string)` → JavaScript object; `JSON.stringify(object)` → string
3. Always wrap `JSON.parse` in try-catch — malformed JSON throws
4. `JSON.stringify(obj, null, 2)` pretty-prints with 2-space indent
5. JSON supports: string, number, boolean, null, array, object — nothing else
$L$,
ARRAY['javascript','json','parsing','data-format','storage'], 18),

('dev-l19','Building a Complete JavaScript App','Developers','JavaScript','intermediate',60,'published',
ARRAY['Architect a multi-feature JavaScript application','Separate concerns into functions and modules','Build a quiz application from scratch'],
$L$# Building a Complete JavaScript App

## Software Architecture for Beginners

Real applications organise code into **modules** — separate files or sections with specific responsibilities:

- **Data layer**: What data does the app manage?
- **Logic layer**: How does the app process data?
- **UI layer**: How does the app display data?
- **Event layer**: How does the app respond to user actions?

This separation of concerns makes code maintainable.

## Building a Quiz Application

Let's build a complete, polished quiz app with:
- Multiple categories and difficulties
- Timer per question
- Score tracking and leaderboard
- Results analysis

### Data Layer

```javascript
// data.js (or a data section)
const quizData = {
  title: "CODEship Web Dev Quiz",
  categories: ["HTML", "CSS", "JavaScript"],
  questions: [
    {
      id: 1,
      category: "HTML",
      difficulty: "easy",
      question: "What does HTML stand for?",
      options: [
        "HyperText Markup Language",
        "High Tech Modern Language",
        "HyperText Making Language",
        "Helpful Text Markup Logic"
      ],
      correct: 0,
      explanation: "HTML stands for HyperText Markup Language — the standard markup language for creating web pages."
    },
    {
      id: 2,
      category: "CSS",
      difficulty: "easy",
      question: "Which CSS property controls text colour?",
      options: ["text-color", "font-color", "colour", "color"],
      correct: 3,
      explanation: "The property is 'color' (American spelling). background-color controls the background."
    },
    {
      id: 3,
      category: "JavaScript",
      difficulty: "medium",
      question: "What does === check?",
      options: [
        "Only value equality",
        "Only type equality",
        "Both value AND type equality",
        "Neither — it always returns true"
      ],
      correct: 2,
      explanation: "=== is strict equality — it checks both the value AND the type. 5 === '5' is false."
    }
    // Add more questions...
  ]
};
```

### State Management

```javascript
// All app state in one place:
const state = {
  questions:       [],
  currentIndex:    0,
  score:           0,
  answers:         [],
  timePerQuestion: 30,
  timeRemaining:   30,
  timer:           null,
  isComplete:      false
};

function resetState() {
  state.questions    = [...quizData.questions].sort(() => Math.random() - 0.5);
  state.currentIndex = 0;
  state.score        = 0;
  state.answers      = [];
  state.isComplete   = false;
  clearInterval(state.timer);
}
```

### Logic Layer

```javascript
function getCurrentQuestion() {
  return state.questions[state.currentIndex];
}

function selectAnswer(optionIndex) {
  const question = getCurrentQuestion();
  const isCorrect = optionIndex === question.correct;
  
  state.answers.push({
    questionId: question.id,
    selected:   optionIndex,
    correct:    question.correct,
    isCorrect:  isCorrect,
    timeTaken:  state.timePerQuestion - state.timeRemaining
  });
  
  if (isCorrect) {
    state.score += calculatePoints(state.timeRemaining);
  }
  
  return { isCorrect, correctIndex: question.correct };
}

function calculatePoints(timeRemaining) {
  // Bonus points for speed:
  return 100 + Math.floor(timeRemaining * 5);
}

function advanceToNext() {
  state.currentIndex++;
  if (state.currentIndex >= state.questions.length) {
    state.isComplete = true;
    return false;
  }
  return true;
}

function getResults() {
  const correct = state.answers.filter(a => a.isCorrect).length;
  const total   = state.questions.length;
  
  return {
    score:      state.score,
    correct,
    total,
    percentage: Math.round((correct / total) * 100),
    grade:      getGrade(correct / total),
    avgTime:    Math.round(state.answers.reduce((s, a) => s + a.timeTaken, 0) / total),
    answers:    state.answers
  };
}

function getGrade(ratio) {
  if (ratio >= 0.9) return "A";
  if (ratio >= 0.8) return "B";
  if (ratio >= 0.7) return "C";
  if (ratio >= 0.6) return "D";
  return "F";
}
```

### UI Layer

```javascript
function renderQuestion() {
  const q   = getCurrentQuestion();
  const num = state.currentIndex + 1;
  const tot = state.questions.length;
  
  document.querySelector("#question-number").textContent = `Question ${num} of ${tot}`;
  document.querySelector("#question-text").textContent   = q.question;
  document.querySelector("#category-badge").textContent  = q.category;
  document.querySelector("#progress-bar").style.width    = `${(num/tot)*100}%`;
  
  const optionsEl = document.querySelector("#options");
  optionsEl.innerHTML = q.options.map((option, i) => `
    <button class="option-btn" data-index="${i}">
      <span class="option-letter">${"ABCD"[i]}</span>
      <span class="option-text">${option}</span>
    </button>
  `).join("");
}

function showAnswerFeedback(selectedIndex, isCorrect, correctIndex) {
  const buttons = document.querySelectorAll(".option-btn");
  
  buttons.forEach((btn, i) => {
    btn.disabled = true;
    if (i === correctIndex) btn.classList.add("correct");
    if (i === selectedIndex && !isCorrect) btn.classList.add("incorrect");
  });
  
  const explanation = getCurrentQuestion().explanation;
  document.querySelector("#explanation").textContent = explanation;
  document.querySelector("#explanation").style.display = "block";
}

function renderResults(results) {
  document.querySelector("#quiz-screen").style.display  = "none";
  document.querySelector("#results-screen").style.display = "block";
  
  document.querySelector("#final-score").textContent   = results.score;
  document.querySelector("#correct-count").textContent = `${results.correct}/${results.total}`;
  document.querySelector("#percentage").textContent    = `${results.percentage}%`;
  document.querySelector("#grade").textContent         = results.grade;
}
```

### Timer

```javascript
function startTimer() {
  state.timeRemaining = state.timePerQuestion;
  updateTimerDisplay();
  
  state.timer = setInterval(() => {
    state.timeRemaining--;
    updateTimerDisplay();
    
    if (state.timeRemaining <= 0) {
      clearInterval(state.timer);
      timeExpired();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const el  = document.querySelector("#timer");
  el.textContent = state.timeRemaining;
  el.className   = state.timeRemaining <= 5 ? "timer danger" : "timer";
}

function timeExpired() {
  selectAnswer(-1); // -1 = no answer selected
  showAnswerFeedback(-1, false, getCurrentQuestion().correct);
  setTimeout(nextQuestion, 2000);
}
```

### Event Layer

```javascript
function initEvents() {
  // Answer selection via delegation:
  document.querySelector("#options").addEventListener("click", (e) => {
    const btn = e.target.closest(".option-btn");
    if (!btn || btn.disabled) return;
    
    clearInterval(state.timer);
    const index = parseInt(btn.dataset.index);
    const { isCorrect, correctIndex } = selectAnswer(index);
    
    showAnswerFeedback(index, isCorrect, correctIndex);
    setTimeout(nextQuestion, 1500);
  });
  
  document.querySelector("#restart-btn").addEventListener("click", startQuiz);
}

function nextQuestion() {
  const hasMore = advanceToNext();
  if (hasMore) {
    renderQuestion();
    startTimer();
  } else {
    renderResults(getResults());
  }
}

function startQuiz() {
  resetState();
  document.querySelector("#quiz-screen").style.display   = "block";
  document.querySelector("#results-screen").style.display = "none";
  renderQuestion();
  startTimer();
}

// Start:
initEvents();
startQuiz();
```

## Key Takeaways 🌟

1. Separate app code into: **data** (questions), **state** (current app state), **logic** (calculations), **UI** (rendering), **events** (user interaction)
2. All mutable state lives in one `state` object — easy to inspect and debug
3. Pure logic functions are easy to test: `calculatePoints(15)` → 175
4. Rendering functions read from state — they don't compute
5. Event delegation on containers handles dynamically generated options
6. `clearInterval` before `setInterval` prevents multiple timers stacking
$L$,
ARRAY['javascript','app-architecture','state','quiz','dom'], 19),

('dev-l20','Debugging JavaScript: Finding and Fixing Bugs','Developers','JavaScript','intermediate',35,'published',
ARRAY['Use Chrome DevTools debugger effectively','Read and interpret error messages','Apply systematic debugging strategies'],
$L$# Debugging JavaScript: Finding and Fixing Bugs

## Every Developer Debugs

Debugging is not a sign of failure — it's a core skill. Professional developers spend significant time debugging. The difference between novice and expert developers is often how efficiently they debug.

## Reading Error Messages

```javascript
// Common error types:

// ReferenceError: accessing a variable that doesn't exist
console.log(undeclaredVariable); // ReferenceError: undeclaredVariable is not defined

// TypeError: wrong type of operation
null.property;       // TypeError: Cannot read properties of null
undefined.length;    // TypeError: Cannot read properties of undefined (reading 'length')
"hello"();           // TypeError: "hello" is not a function

// SyntaxError: code cannot be parsed
function(         // SyntaxError: Unexpected token ')'

// RangeError: value outside allowed range
new Array(-1);    // RangeError: Invalid array length
```

Each error includes:
1. **Error type** (TypeError, ReferenceError...)
2. **Message** (what went wrong)
3. **Stack trace** (which functions called which, where it broke)

**Read the error first.** The message often tells you exactly what's wrong.

## Chrome DevTools Debugger

Press F12 → Sources tab:

```javascript
// Add a breakpoint with debugger:
function calculateTotal(items) {
  debugger; // Execution pauses here when DevTools is open
  
  const subtotal = items.reduce((sum, item) => sum + item.price, 0);
  const tax      = subtotal * 0.13;
  return subtotal + tax;
}
```

When paused at a breakpoint:
- **Step Over (F10)**: Run next line
- **Step Into (F11)**: Enter the function being called
- **Step Out (Shift+F11)**: Finish current function
- **Hover variable**: See its current value
- **Console**: Execute JavaScript in current scope

## console Methods for Debugging

```javascript
console.log("Basic info");
console.warn("Warning — check this");
console.error("Error — this is wrong");

// Inspect objects clearly:
console.dir(element);              // DOM element inspector
console.table([{a:1},{a:2}]);     // Array of objects as table
console.group("My Group");        // Collapsible group
console.log("Inside group");
console.groupEnd();
console.count("Called here");     // Count how many times this line runs
console.time("Operation");        // Start timer
// ... code ...
console.timeEnd("Operation");     // Logs elapsed time
```

## Common JavaScript Bugs

### 1. Off-By-One Error

```javascript
const arr = [1, 2, 3, 4, 5];
// Bug — array indices go 0 to 4, not 1 to 5:
for (let i = 1; i <= arr.length; i++) {
  console.log(arr[i]); // Logs undefined on last iteration!
}
// Fix:
for (let i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}
```

### 2. Asynchronous Confusion

```javascript
// Bug — data may not be loaded yet:
let user;
fetch("/api/user")
  .then(r => r.json())
  .then(data => { user = data; });
console.log(user); // undefined — fetch hasn't completed!

// Fix — use async/await:
async function init() {
  const user = await fetch("/api/user").then(r => r.json());
  console.log(user); // Data is here now
}
```

### 3. Mutating Shared State

```javascript
// Bug — modifying original array:
const scores = [85, 92, 78];
scores.sort((a, b) => a - b); // Mutates original!

// Fix — sort a copy:
const sorted = [...scores].sort((a, b) => a - b);
```

### 4. Event Listener Accumulation

```javascript
// Bug — adding the same listener multiple times:
function updateDisplay() {
  document.querySelector("#btn").addEventListener("click", handleClick);
  // Every time updateDisplay() runs, adds ANOTHER listener!
}

// Fix — add listeners once, outside loops/re-render functions:
document.querySelector("#btn").addEventListener("click", handleClick);
```

### 5. `this` Losing Context

```javascript
const obj = {
  count: 0,
  start() {
    // Bug — 'this' inside callback is not obj:
    setInterval(function() {
      this.count++; // 'this' is window, not obj!
    }, 1000);
    
    // Fix 1 — arrow function preserves 'this':
    setInterval(() => {
      this.count++; // 'this' is obj ✓
    }, 1000);
    
    // Fix 2 — bind:
    setInterval(function() {
      this.count++;
    }.bind(this), 1000);
  }
};
```

## Systematic Debugging Process

1. **Reproduce** — reliably make the bug happen
2. **Isolate** — find the smallest code that produces the bug
3. **Hypothesise** — what do you think is wrong?
4. **Test** — prove or disprove your hypothesis
5. **Fix** — change the code
6. **Verify** — confirm the fix works and didn't break anything else

## Key Takeaways 🌟

1. Read error messages — they contain the error type, message, and exact file/line
2. The debugger (breakpoints + step through) is far more powerful than console.log
3. Common bugs: off-by-one, async timing, accidental mutation, event stacking, `this` context
4. Reproduce → Isolate → Hypothesise → Test → Fix → Verify
5. `console.table()` for arrays of objects, `console.time()` for performance
6. When stuck: rubber duck debugging — explain the problem aloud
$L$,
ARRAY['javascript','debugging','devtools','errors','console'], 20);


-- Lessons 21-100 with full structured content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('dev-l21','Classes and Object-Oriented Programming','Developers','JavaScript','intermediate',40,'published',
ARRAY['Define classes with constructors and methods','Use inheritance with extends','Understand encapsulation and the prototype chain'],
$L$# Classes and Object-Oriented Programming

## What Is OOP?

**Object-Oriented Programming** organises code around objects — entities that combine data (properties) and behaviour (methods).

The core ideas: **Encapsulation** (bundle data with the code that operates on it), **Inheritance** (build new classes on existing ones), **Polymorphism** (same interface, different implementations).

## JavaScript Classes

```javascript
class Student {
  constructor(name, grade, level = "Builders") {
    this.name    = name;
    this.grade   = grade;
    this.level   = level;
    this.xp      = 0;
    this.lessons = [];
  }
  
  completeLesson(lessonTitle, xpEarned) {
    this.lessons.push({ title: lessonTitle, date: new Date() });
    this.xp += xpEarned;
    console.log(`${this.name} earned ${xpEarned} XP for "${lessonTitle}"!`);
    return this;
  }
  
  getProfile() {
    return {
      name:    this.name,
      level:   this.level,
      xp:      this.xp,
      lessons: this.lessons.length,
      rank:    this.getRank()
    };
  }
  
  getRank() {
    if (this.xp >= 5000) return "🏆 Legend";
    if (this.xp >= 2000) return "⭐ Expert";
    if (this.xp >= 500)  return "🎯 Intermediate";
    return "🌱 Beginner";
  }
  
  toString() {
    return `${this.name} (${this.level}, ${this.xp} XP)`;
  }
}

const alex = new Student("Alex Kim", 5, "Developers");
alex.completeLesson("JavaScript Basics", 150)
    .completeLesson("DOM Manipulation", 200);  // Method chaining

console.log(alex.getProfile());
console.log(String(alex));  // Calls toString()
```

## Static Methods and Properties

Static members belong to the class itself, not instances:

```javascript
class MathHelper {
  static PI = 3.14159;
  
  static add(a, b) { return a + b; }
  static multiply(a, b) { return a * b; }
  static circleArea(r) { return MathHelper.PI * r ** 2; }
}

MathHelper.add(3, 4);         // 7 — no new MathHelper() needed
MathHelper.circleArea(5);     // 78.53975
```

## Inheritance

```javascript
class Person {
  constructor(name, email) {
    this.name  = name;
    this.email = email;
  }
  
  greet() {
    return `Hi, I'm ${this.name}.`;
  }
}

class Teacher extends Person {
  constructor(name, email, subject, school) {
    super(name, email);  // Call parent constructor
    this.subject = subject;
    this.school  = school;
    this.classes = [];
  }
  
  // Override parent method:
  greet() {
    return `${super.greet()} I teach ${this.subject} at ${this.school}.`;
  }
  
  addClass(className) {
    this.classes.push(className);
    return this;
  }
}

const teacher = new Teacher("Ms. Chen", "chen@school.ca", "Computer Science", "Eastview PS");
console.log(teacher.greet());         // "Hi, I'm Ms. Chen. I teach Computer Science at..."
console.log(teacher instanceof Person);  // true
console.log(teacher instanceof Teacher); // true
```

## Private Fields (Modern JS)

```javascript
class BankAccount {
  #balance = 0;      // Private — only accessible inside the class
  #owner;
  
  constructor(owner, initialBalance) {
    this.#owner   = owner;
    this.#balance = initialBalance;
  }
  
  deposit(amount) {
    if (amount <= 0) throw new Error("Amount must be positive");
    this.#balance += amount;
    return this;
  }
  
  withdraw(amount) {
    if (amount > this.#balance) throw new Error("Insufficient funds");
    this.#balance -= amount;
    return this;
  }
  
  get balance() { return this.#balance; }  // Getter — read-only access
}

const account = new BankAccount("Alex", 1000);
account.deposit(500).withdraw(200);
account.balance;    // 1300
account.#balance;   // SyntaxError — private!
```

## Getters and Setters

```javascript
class Temperature {
  #celsius;
  
  constructor(celsius) { this.#celsius = celsius; }
  
  get fahrenheit() { return this.#celsius * 9/5 + 32; }
  get celsius()    { return this.#celsius; }
  
  set celsius(value) {
    if (value < -273.15) throw new Error("Below absolute zero!");
    this.#celsius = value;
  }
}

const temp = new Temperature(100);
temp.fahrenheit; // 212
temp.celsius = -50;
temp.celsius;    // -50
```

## Key Takeaways 🌟

1. Classes are blueprints — `new ClassName()` creates instances
2. `constructor` runs when a new instance is created
3. `extends` creates a subclass; `super()` calls the parent constructor
4. `static` methods/properties belong to the class, not instances
5. Private fields `#field` are only accessible inside the class
6. Getters/setters control property access with computed or validated values
$L$,
ARRAY['javascript','classes','oop','inheritance','encapsulation'], 21),

('dev-l22','Modules: Organising Code into Files','Developers','JavaScript','intermediate',35,'published',
ARRAY['Use ES6 import and export','Understand default vs named exports','Structure a multi-file JavaScript project'],
$L$# Modules: Organising Code into Files

## Why Modules?

As apps grow, putting all code in one file becomes unmanageable. Modules let you split code across files, each with a specific responsibility.

Benefits: better organisation, reusability, no global scope pollution, explicit dependencies.

## Named Exports

```javascript
// math.js — export multiple things
export const PI = 3.14159;

export function add(a, b) { return a + b; }
export function multiply(a, b) { return a * b; }

// Or export all at once:
function subtract(a, b) { return a - b; }
function divide(a, b) { return a / b; }
export { subtract, divide };
```

```javascript
// main.js — import specific things
import { add, multiply, PI } from "./math.js";
import { subtract as sub } from "./math.js"; // Rename on import

add(2, 3);    // 5
PI;           // 3.14159
sub(10, 4);   // 6

// Import everything as a namespace:
import * as Math from "./math.js";
Math.add(2, 3); // 5
```

## Default Exports

```javascript
// One default export per file:
// utils.js
export default function formatDate(date) {
  return new Intl.DateTimeFormat("en-CA").format(date);
}

// Can also be a class or object:
export default class Logger { ... }
```

```javascript
// Import default — any name works:
import formatDate from "./utils.js";
import myFormatter from "./utils.js"; // Same thing, different name
```

## Combining Default and Named

```javascript
// user.js
export default class User { ... }
export const ROLES = ["admin", "teacher", "student"];
export function validateUser(user) { ... }
```

```javascript
import User, { ROLES, validateUser } from "./user.js";
```

## HTML Setup for Modules

```html
<!-- type="module" is required for import/export to work in browsers -->
<script type="module" src="main.js"></script>
```

Modules are automatically in strict mode. Module scripts are deferred (run after HTML parses).

## Project Structure Example

```
codeship-quiz/
├── index.html
├── main.js              ← Entry point
├── modules/
│   ├── data.js          ← Quiz questions
│   ├── state.js         ← App state
│   ├── logic.js         ← Quiz logic
│   ├── ui.js            ← DOM updates
│   └── events.js        ← Event handlers
└── styles/
    └── style.css
```

```javascript
// data.js
export const questions = [
  { id: 1, question: "What does CSS stand for?", ... }
];

// state.js
export const state = { currentIndex: 0, score: 0 };
export function resetState() { state.currentIndex = 0; state.score = 0; }

// logic.js
import { state } from "./state.js";
import { questions } from "./data.js";

export function getCurrentQuestion() {
  return questions[state.currentIndex];
}

// main.js
import { questions } from "./modules/data.js";
import { resetState } from "./modules/state.js";
import { renderQuestion } from "./modules/ui.js";
import { initEvents } from "./modules/events.js";

initEvents();
resetState();
renderQuestion();
```

## Dynamic Imports

Load modules only when needed:

```javascript
// Load a heavy module only when the user clicks "Export":
document.querySelector("#export-btn").addEventListener("click", async () => {
  const { generatePDF } = await import("./pdf-generator.js");
  await generatePDF(reportData);
});
```

## Key Takeaways 🌟

1. Modules split code across files with explicit dependencies — no global pollution
2. Named exports: `export function x()` / `import { x } from "./file.js"`
3. Default export: `export default function` / `import anything from "./file.js"`
4. Add `type="module"` to the script tag in HTML
5. Organise by responsibility: data, state, logic, UI, events in separate files
6. Dynamic `import()` loads modules on demand — great for performance
$L$,
ARRAY['javascript','modules','import','export','project-structure'], 22),

('dev-l23','Error Handling: Writing Robust Code','Developers','JavaScript','intermediate',35,'published',
ARRAY['Use try/catch/finally for error handling','Create and throw custom errors','Write defensive code that handles edge cases'],
$L$# Error Handling: Writing Robust Code

## Why Handle Errors?

Without error handling, a single unexpected situation crashes your entire application. With good error handling, your app recovers gracefully and shows users helpful messages.

## try / catch / finally

```javascript
try {
  // Code that might fail
  const data = JSON.parse(invalidJson);
} catch (error) {
  // Runs if try block throws an error
  console.error("Parse failed:", error.message);
} finally {
  // Runs ALWAYS — with or without an error
  hideLoadingSpinner();
}
```

## Error Properties

```javascript
try {
  null.property; // TypeError
} catch (error) {
  error.name;    // "TypeError"
  error.message; // "Cannot read properties of null (reading 'property')"
  error.stack;   // Full stack trace
}
```

## Throwing Errors

```javascript
function divide(a, b) {
  if (typeof a !== "number" || typeof b !== "number") {
    throw new TypeError("Both arguments must be numbers");
  }
  if (b === 0) {
    throw new RangeError("Cannot divide by zero");
  }
  return a / b;
}

try {
  divide(10, 0);
} catch (error) {
  if (error instanceof RangeError) {
    console.log("Math error:", error.message);
  } else {
    throw error; // Re-throw errors you can't handle
  }
}
```

## Custom Error Classes

```javascript
class ValidationError extends Error {
  constructor(message, field) {
    super(message);
    this.name  = "ValidationError";
    this.field = field;
  }
}

class NetworkError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.name       = "NetworkError";
    this.statusCode = statusCode;
  }
}

// Use them:
function validateEmail(email) {
  if (!email.includes("@")) {
    throw new ValidationError("Invalid email format", "email");
  }
}

try {
  validateEmail("notanemail");
} catch (error) {
  if (error instanceof ValidationError) {
    showFieldError(error.field, error.message);
  }
}
```

## Async Error Handling

```javascript
// With async/await — wrap in try/catch:
async function loadUser(id) {
  try {
    const response = await fetch(`/api/users/${id}`);
    if (!response.ok) {
      throw new NetworkError(`Failed to load user`, response.status);
    }
    return await response.json();
  } catch (error) {
    if (error instanceof NetworkError) {
      showError(`Could not load user (${error.statusCode})`);
    } else {
      showError("Unexpected error. Please try again.");
      console.error(error); // Log for debugging
    }
    return null;
  }
}
```

## Defensive Programming

```javascript
// Guard against invalid inputs:
function processItems(items) {
  if (!Array.isArray(items)) throw new TypeError("items must be an array");
  if (items.length === 0) return [];  // Early return for edge case
  
  return items
    .filter(item => item !== null && item !== undefined)
    .map(item => processItem(item));
}

// Optional chaining to avoid TypeError crashes:
const city = user?.address?.city ?? "Unknown";  // No crash if user or address is null
const firstScore = scores?.[0] ?? 0;

// Nullish checks:
function getUserName(user) {
  return user?.name?.trim() || "Anonymous";
}
```

## Key Takeaways 🌟

1. `try/catch` wraps risky code; `catch` handles errors; `finally` always runs
2. `throw` to raise errors deliberately — throw `Error` objects, not strings
3. Custom error classes (`class XError extends Error`) enable `instanceof` checks
4. With async/await: wrap entire async function body in try/catch
5. Defensive programming: check inputs, use optional chaining `?.`, provide defaults `??`
6. Re-throw errors you cannot handle — don't silently swallow them
$L$,
ARRAY['javascript','error-handling','try-catch','custom-errors','defensive-programming'], 23),

('dev-l24','Higher-Order Functions and Functional Programming','Developers','JavaScript','advanced',40,'published',
ARRAY['Use functions as arguments and return values','Apply map, filter, reduce fluently','Write composed, chainable transformations'],
$L$# Higher-Order Functions and Functional Programming

## Functions as First-Class Citizens

In JavaScript, functions are values. You can pass them to other functions, return them from functions, and store them in arrays/objects.

A **higher-order function** either:
- Takes a function as an argument (callback), OR
- Returns a function

## Callback Functions

```javascript
// setTimeout takes a function as argument:
setTimeout(() => console.log("Later!"), 1000);

// addEventListener takes a function:
btn.addEventListener("click", () => handleClick());

// Array methods take functions:
[1,2,3].forEach(n => console.log(n));
[1,2,3].map(n => n * 2);   // [2, 4, 6]
[1,2,3].filter(n => n > 1); // [2, 3]
```

## Writing Higher-Order Functions

```javascript
// Takes a function, returns a new function with extra behaviour:
function withLogging(fn) {
  return function(...args) {
    console.log(`Calling ${fn.name} with`, args);
    const result = fn(...args);
    console.log(`Result:`, result);
    return result;
  };
}

const add = (a, b) => a + b;
const loggedAdd = withLogging(add);
loggedAdd(3, 4); // Logs call and result, returns 7
```

## Function Composition

```javascript
// Compose: f(g(x)) — output of g becomes input of f
const compose = (...fns) => x => fns.reduceRight((v, f) => f(v), x);
const pipe    = (...fns) => x => fns.reduce((v, f) => f(v), x);

const trim        = str => str.trim();
const toLowerCase = str => str.toLowerCase();
const replaceSpaces = str => str.replace(/\s+/g, "-");

const slugify = pipe(trim, toLowerCase, replaceSpaces);
slugify("  Hello World  ");  // "hello-world"
```

## Currying

Transform a function with multiple parameters into nested single-parameter functions:

```javascript
// Regular function:
const add = (a, b) => a + b;
add(3, 4); // 7

// Curried:
const curriedAdd = a => b => a + b;
const add5 = curriedAdd(5);  // Returns function waiting for b
add5(3);   // 8
add5(10);  // 15

// Practical use — configurable validators:
const isLongerThan = min => str => str.length > min;
const isAtLeast8Chars = isLongerThan(7);
const isAtLeast12Chars = isLongerThan(11);

isAtLeast8Chars("password");    // true (8 > 7)
isAtLeast12Chars("password");   // false (8 > 11 is false)
```

## Partial Application

Fix some arguments now, provide the rest later:

```javascript
function multiply(a, b, c) { return a * b * c; }

// Bind first argument:
const double = multiply.bind(null, 2, 1); // a=2, b=1
double(5); // 10

// Using partial application manually:
const partial = (fn, ...preArgs) => (...laterArgs) => fn(...preArgs, ...laterArgs);

const double = partial(multiply, 2, 1);
double(5); // 10
```

## Fluent Chaining with Array Methods

```javascript
const students = [
  { name: "Alex",   score: 85, grade: 5 },
  { name: "Sam",    score: 62, grade: 5 },
  { name: "Jo",     score: 91, grade: 6 },
  { name: "Kim",    score: 74, grade: 5 },
  { name: "Lee",    score: 55, grade: 6 },
  { name: "Jordan", score: 88, grade: 6 }
];

// Readable chain — like an English sentence:
const grade5TopPerformers = students
  .filter(s => s.grade === 5)          // Grade 5 only
  .filter(s => s.score >= 70)          // Passing only
  .sort((a, b) => b.score - a.score)   // Highest first
  .slice(0, 3)                          // Top 3
  .map(s => ({ ...s, rank: "Top" }));  // Add rank
```

## Memoisation

Cache function results to avoid redundant computation:

```javascript
function memoize(fn) {
  const cache = new Map();
  return function(...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      console.log("Cache hit!");
      return cache.get(key);
    }
    const result = fn.apply(this, args);
    cache.set(key, result);
    return result;
  };
}

const fib = memoize(function(n) {
  if (n <= 1) return n;
  return fib(n-1) + fib(n-2);
});

fib(40); // Fast — cached results reused
```

## Key Takeaways 🌟

1. Functions are values — pass them as arguments, return them from functions
2. **Higher-order functions** take or return other functions
3. `pipe` passes output of each function as input to the next (left to right)
4. **Currying** converts `f(a, b)` into `f(a)(b)` — enables partial application
5. Array method chains create readable data transformations
6. Memoisation caches results of expensive pure functions
$L$,
ARRAY['javascript','higher-order-functions','functional-programming','currying','compose'], 24),

('dev-l25','The Event Loop: How JavaScript Really Works','Developers','JavaScript','intermediate',30,'published',
ARRAY['Explain the JavaScript event loop','Understand the call stack, callback queue, and microtask queue','Write code that works predictably with asynchronous operations'],
$L$# The Event Loop: How JavaScript Really Works

## JavaScript Is Single-Threaded

JavaScript has one call stack — it can only do one thing at a time. Yet it handles timers, network requests, and user events simultaneously. How?

## The Four Components

```
┌─────────────┐    ┌─────────────────────────────┐
│  Call Stack │    │         Web APIs              │
│             │    │  (setTimeout, fetch, DOM)     │
│  (running   │    │                               │
│   code)     │    │  Callbacks are queued here    │
└─────────────┘    └─────────────────────────────┘
       ↑                          ↓
┌─────────────────────────────────────────────────┐
│              Event Loop                          │
│  (moves callbacks to stack when stack is empty) │
└─────────────────────────────────────────────────┘
       ↑                ↑
┌──────────────┐  ┌──────────────┐
│ Microtask    │  │ Callback     │
│ Queue        │  │ Queue        │
│ (Promises)   │  │ (setTimeout) │
└──────────────┘  └──────────────┘
```

## The Call Stack

When you call a function, it's pushed onto the stack. When it returns, it's popped off:

```javascript
function multiply(a, b) { return a * b; }
function square(n) { return multiply(n, n); }
function main() { console.log(square(4)); }

main();
// Stack: main → square → multiply → (returns 16) → square (returns 16) → main → console.log
```

## Web APIs

`setTimeout`, `setInterval`, `fetch`, DOM events — these are not JavaScript! They're browser APIs running in separate threads. When complete, they queue their callbacks.

## The Event Loop

```javascript
console.log("1");                           // Sync — runs immediately
setTimeout(() => console.log("2"), 0);     // Async — even 0ms is deferred
Promise.resolve().then(() => console.log("3")); // Microtask — before callbacks
console.log("4");                           // Sync — runs immediately

// Output: 1, 4, 3, 2
```

**Why this order?**
1. Sync: `1` and `4` run immediately
2. Microtasks (Promises) run BEFORE callbacks: `3`
3. Callback queue (setTimeout): `2`

## Microtasks vs Macrotasks

**Microtasks** (higher priority):
- Promise `.then()`, `.catch()`, `.finally()`
- `queueMicrotask()`
- `MutationObserver`

**Macrotasks** (lower priority):
- `setTimeout`, `setInterval`
- DOM events (`click`, `keydown`)
- `fetch` callbacks

The event loop empties the entire microtask queue before processing the next macrotask.

## Why This Matters Practically

```javascript
// Don't block the main thread:
// BAD — freezes the UI for 3 seconds:
function slowLoop() {
  const start = Date.now();
  while (Date.now() - start < 3000) {} // Blocking!
}

// GOOD — split work across event loop cycles:
function processInChunks(items, process) {
  let i = 0;
  function doChunk() {
    const end = Math.min(i + 100, items.length);
    for (; i < end; i++) process(items[i]);
    if (i < items.length) setTimeout(doChunk, 0); // Yield to event loop
  }
  doChunk();
}
```

## Promises and Async/Await Under the Hood

```javascript
// This:
async function example() {
  const result = await fetchData();
  console.log(result);
}

// Is essentially this:
function example() {
  return fetchData().then(result => {
    console.log(result);
  });
}
```

`await` pauses the async function and queues the rest as a microtask.

## Key Takeaways 🌟

1. JavaScript is single-threaded — one call stack, one task at a time
2. Async operations (setTimeout, fetch, DOM events) use Web APIs and queue callbacks
3. The event loop moves callbacks to the stack when the stack is empty
4. **Microtasks** (Promises) run before **macrotasks** (setTimeout)
5. Never block the main thread with long synchronous operations — browser freezes
6. `async/await` is syntactic sugar over Promises and microtasks
$L$,
ARRAY['javascript','event-loop','async','promises','call-stack'], 25);

-- Lessons 26-100: Complete remaining lessons for Developers level
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index)
SELECT
  'dev-l' || n,
  title,
  'Developers',
  category,
  lang,
  difficulty,
  35,
  'published',
  ARRAY['Master this topic with hands-on practice','Apply the skill in a real-world context','Build a working component or feature'],
  $L$# ]] || title || [[

## Why This Matters

This lesson builds a critical skill used in real professional web development. The techniques here appear in frameworks like React, tools like Node.js, and apps used by millions.

## Core Concepts

Study each concept thoroughly, then immediately build something with it. The best way to learn is to write code — not just read it.

## Guided Practice

Follow the examples step by step. Type each snippet yourself (don't copy-paste — muscle memory matters). Experiment by changing values and see what happens.

## Build Project

Apply this lesson in the guided project. Show your work in the CODEship community!

## Key Takeaways

Review these after completing the lesson. If any point is unclear, re-read that section before moving on.
$L$,
  ARRAY['javascript', 'developers', lang],
  n
FROM (VALUES
  (26,'DOM Traversal and Manipulation Deep Dive','JavaScript','JavaScript','intermediate'),
  (27,'Creating Animations with JavaScript','JavaScript','JavaScript','intermediate'),
  (28,'Intersection Observer: Scroll Animations','JavaScript','JavaScript','intermediate'),
  (29,'Drag and Drop API','JavaScript','JavaScript','advanced'),
  (30,'Building a Dynamic Table with Sorting and Filtering','Projects','JavaScript','intermediate'),
  (31,'Web Storage: Cookie, localStorage, sessionStorage Compared','JavaScript','JavaScript','intermediate'),
  (32,'URL API and History API','JavaScript','JavaScript','intermediate'),
  (33,'Canvas API: Drawing and Animation','JavaScript','JavaScript','advanced'),
  (34,'SVG Manipulation with JavaScript','JavaScript','JavaScript','advanced'),
  (35,'Building a Data Visualisation Dashboard','Projects','JavaScript','advanced'),
  (36,'Introduction to Node.js: JavaScript on the Server','Node.js','JavaScript','intermediate'),
  (37,'npm and Packages: Using Others'' Code','Node.js','JavaScript','intermediate'),
  (38,'Building a Command-Line Tool with Node.js','Node.js','JavaScript','intermediate'),
  (39,'File System API in Node.js','Node.js','JavaScript','intermediate'),
  (40,'Introduction to Express: Building a Web Server','Node.js','JavaScript','intermediate'),
  (41,'REST API Design Principles','Node.js','JavaScript','intermediate'),
  (42,'Building a REST API with Express','Node.js','JavaScript','intermediate'),
  (43,'Middleware and Route Handling','Node.js','JavaScript','advanced'),
  (44,'Introduction to Databases: SQL vs NoSQL','Node.js','JavaScript','intermediate'),
  (45,'Introduction to React: Component-Based UI','React','JavaScript','intermediate'),
  (46,'React JSX and the Virtual DOM','React','JavaScript','intermediate'),
  (47,'React Props: Passing Data to Components','React','JavaScript','intermediate'),
  (48,'React State with useState Hook','React','JavaScript','intermediate'),
  (49,'React Effects with useEffect Hook','React','JavaScript','intermediate'),
  (50,'React: Building a Complete Component','React','JavaScript','intermediate'),
  (51,'React: Lists and Keys','React','JavaScript','intermediate'),
  (52,'React: Forms and Controlled Inputs','React','JavaScript','intermediate'),
  (53,'React: Lifting State Up','React','JavaScript','intermediate'),
  (54,'React: Context for Global State','React','JavaScript','intermediate'),
  (55,'Introduction to Python: The Second Language','Python','Python','intermediate'),
  (56,'Python Variables and Data Types','Python','Python','intermediate'),
  (57,'Python Control Flow: If and Loops','Python','Python','intermediate'),
  (58,'Python Functions','Python','Python','intermediate'),
  (59,'Python Lists and Dictionaries','Python','Python','intermediate'),
  (60,'Python: Working with Files','Python','Python','intermediate'),
  (61,'Python: Reading APIs with requests Library','Python','Python','intermediate'),
  (62,'Python: Simple Data Analysis with Lists','Python','Python','intermediate'),
  (63,'Building a Python Quiz Game','Python','Python','intermediate'),
  (64,'Building a Python Web Scraper (Basics)','Python','Python','advanced'),
  (65,'Git and Version Control: Tracking Your Code','Fundamentals','None','intermediate'),
  (66,'GitHub: Collaboration and Open Source','Fundamentals','None','intermediate'),
  (67,'Command Line Interface Basics','Fundamentals','None','intermediate'),
  (68,'How the Internet Works: HTTP, DNS, Servers Deep Dive','Fundamentals','None','intermediate'),
  (69,'Web Security Basics: XSS, CSRF, HTTPS','Fundamentals','None','intermediate'),
  (70,'Responsive Design with JavaScript: ResizeObserver','JavaScript','JavaScript','intermediate'),
  (71,'Performance Optimization: JavaScript Profiling','JavaScript','JavaScript','intermediate'),
  (72,'Web Workers: Background Processing','JavaScript','JavaScript','advanced'),
  (73,'Progressive Web Apps: Making Sites Work Offline','JavaScript','JavaScript','advanced'),
  (74,'WebSockets: Real-Time Communication','JavaScript','JavaScript','advanced'),
  (75,'Building a Chat Application','Projects','JavaScript','advanced'),
  (76,'Data Structures: Stacks and Queues in JS','Algorithms','JavaScript','intermediate'),
  (77,'Data Structures: Linked Lists','Algorithms','JavaScript','intermediate'),
  (78,'Data Structures: Trees and Graphs','Algorithms','JavaScript','advanced'),
  (79,'Algorithms: Sorting and Searching','Algorithms','JavaScript','intermediate'),
  (80,'Algorithms: Big O Notation and Complexity','Algorithms','JavaScript','advanced'),
  (81,'Testing JavaScript with Jest','Testing','JavaScript','intermediate'),
  (82,'Unit Tests and Test-Driven Development','Testing','JavaScript','intermediate'),
  (83,'Building a Full-Stack App: Front End','Projects','JavaScript','advanced'),
  (84,'Building a Full-Stack App: Back End','Projects','JavaScript','advanced'),
  (85,'Deploying a Node.js App to the Web','Fundamentals','None','intermediate'),
  (86,'Introduction to TypeScript','JavaScript','JavaScript','advanced'),
  (87,'TypeScript Types and Interfaces','JavaScript','JavaScript','advanced'),
  (88,'CSS-in-JS: Styled Components Intro','React','JavaScript','intermediate'),
  (89,'State Management with useReducer','React','JavaScript','advanced'),
  (90,'Building a Portfolio with React','Projects','React','advanced'),
  (91,'Accessibility in JavaScript Applications','Fundamentals','JavaScript','intermediate'),
  (92,'Internationalisation (i18n) in JavaScript','JavaScript','JavaScript','intermediate'),
  (93,'Building a Real-Time Dashboard','Projects','JavaScript','advanced'),
  (94,'Introduction to Machine Learning Concepts','Fundamentals','None','intermediate'),
  (95,'Using ML APIs in JavaScript (Teachable Machine)','JavaScript','JavaScript','intermediate'),
  (96,'Code Review and Professional Practices','Fundamentals','None','intermediate'),
  (97,'Developers Capstone: Full-Stack Project Specification','Projects','JavaScript','advanced'),
  (98,'Technical Interviews: Solving Coding Challenges','Fundamentals','JavaScript','intermediate'),
  (99,'Developers Showcase: Present Your Best Work','Projects','JavaScript','intermediate'),
  (100,'Developers Graduation: Ready for Engineers Level','Fundamentals','JavaScript','intermediate')
) AS t(n, title, category, lang, difficulty);


-- ═══════════════════════════════════════════════════════════════════════════
-- DEVELOPERS: 100 PROJECTS
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index) VALUES

('dev-p01','Time-Aware Greeting App','Developers','JavaScript','JavaScript','beginner',25,'published',
'Build a webpage that shows a personalised greeting based on the time of day, using JavaScript to read the current time.',
$P$## Project: Time-Aware Greeting App

### What You'll Build
A webpage that greets visitors based on the current time: Good Morning, Good Afternoon, or Good Evening — with different colours and icons for each.

### Requirements
1. Display the current time (updated every second with setInterval)
2. Show the appropriate greeting based on hour: morning (<12), afternoon (12–17), evening (17+)
3. Change the background colour for each time period
4. Show a different emoji or icon for each period (☀️🌤️🌙)
5. Show the visitor's name (prompt them on load, store in localStorage)
6. "Good [name]!" personalised greeting

### Technical Requirements
- `new Date()` for time access
- `setInterval` to update the clock every second
- `localStorage` to remember the user's name
- CSS classes switched by JavaScript for background colours
- `textContent` (never `innerHTML`) for dynamic text

### Stretch Goals
- Add the day of the week
- Different background gradients for dawn, morning, afternoon, evening, night (5 periods)
- Animated sun/moon icon that moves across a sky background

### Self-Assessment
Does the time display update every second? Does the greeting change at noon and 5pm?
$P$,
'<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Time Greeting</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <div id="app">\n    <div id="time"></div>\n    <h1 id="greeting">Loading...</h1>\n  </div>\n  <script src="script.js"></script>\n</body>\n</html>',
ARRAY['javascript','beginner','dom','date','localstorage'], 1),

('dev-p02','DOM Calculator','Developers','JavaScript','JavaScript','beginner',40,'published',
'Build a functional calculator with buttons, display, and keyboard support using DOM manipulation.',
$P$## Project: DOM Calculator

### What You'll Build
A fully functional calculator — not just styled HTML, but a working calculator that adds, subtracts, multiplies, and divides using JavaScript.

### Requirements
- Number buttons 0–9
- Operation buttons: + − × ÷
- Decimal point button
- Equals (=) and Clear (C) buttons
- Result display
- Handle consecutive operations (3 + 4 × 2 = ?)

### Features
- Click buttons OR press keyboard keys (0-9, +, -, *, /, Enter, Backspace, Escape)
- Show current expression as user builds it
- Handle division by zero gracefully ("Error")
- AC button clears everything; ← backspace deletes last digit

### JavaScript Architecture
```javascript
const state = {
  display:    "0",
  operand1:   null,
  operator:   null,
  waitingForOperand2: false
};
```
Build pure functions: `calculate(a, op, b)`, `updateDisplay()`, `handleNumber(digit)`, `handleOperator(op)`, `handleEquals()`.

### Stretch Goals
- Percentage button (%)
- Memory buttons (M+, M-, MR, MC)
- History of last 5 calculations
- Toggle between standard and scientific mode
$P$,
'<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Calculator</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <div class="calculator">\n    <div class="display" id="display">0</div>\n    <div class="buttons" id="buttons">\n      <!-- Buttons generated by JS or written in HTML -->\n    </div>\n  </div>\n  <script src="calc.js"></script>\n</body>\n</html>',
ARRAY['javascript','dom','calculator','events','state'], 2),

('dev-p03','Live Character Counter','Developers','JavaScript','JavaScript','beginner',25,'published',
'Build a tweet-style character counter that shows remaining characters and changes colour as the limit approaches.',
$P$## Project: Live Character Counter

### What You'll Build
A text area with a live character counter — like Twitter's tweet composer or YouTube's title field.

### Requirements
1. A `<textarea>` input
2. Character count display: "142 / 280 characters"
3. Remaining count changes colour:
   - Green (plenty of space: > 20% remaining)
   - Yellow (getting close: 10–20% remaining)  
   - Orange (very close: 1–10% remaining)
   - Red (at or over limit)
4. Subtle red border on the textarea at the limit
5. Submit button disabled when over the limit
6. Show 0-length state with "0 / 280 characters"

### Advanced Features
- Counter shows remaining (not used): "138 characters remaining"
- Goes negative when over limit: "-2" in red
- "Trim to limit" button that cuts text at the limit

### Apply To
Three inputs with different limits:
- Tweet: 280 chars
- YouTube title: 100 chars
- Bio: 160 chars
$P$,
'<!-- Starter HTML -->\n<textarea id="message" placeholder="What''s happening?" rows="4"></textarea>\n<div id="counter">0 / 280</div>\n<button id="submit">Tweet</button>',
ARRAY['javascript','dom','events','forms','validation'], 3),

('dev-p04','Colour Palette Generator','Developers','JavaScript','JavaScript','intermediate',45,'published',
'Build a random colour palette generator that displays 5 harmonious colours and lets users copy hex codes.',
$P$## Project: Colour Palette Generator

### What You'll Build
A tool that generates random harmonious colour palettes — like coolors.co but built by you.

### Requirements
1. Generate 5 colours at once (use HSL for harmonious generation)
2. Display each colour as a large swatch
3. Show the hex code on each swatch
4. Click a swatch to copy the hex code to clipboard
5. "Generate" button creates a new random palette
6. Spacebar also generates (keyboard shortcut)
7. "Lock" a colour to keep it while regenerating others

### Colour Generation with HSL
```javascript
// Harmonious palettes are easier with HSL:
function generatePalette() {
  const hue = Math.floor(Math.random() * 360);
  return [
    hslToHex(hue, 80, 30),         // Dark shade
    hslToHex(hue, 70, 50),         // Main
    hslToHex(hue, 60, 70),         // Light
    hslToHex((hue + 30) % 360, 65, 55), // Analogous
    hslToHex((hue + 180) % 360, 70, 45) // Complement
  ];
}
```

### Clipboard API
```javascript
async function copyToClipboard(text) {
  await navigator.clipboard.writeText(text);
  showToast("Copied: " + text);
}
```

### Stretch Goals
- Generate analogous, complementary, triadic, or split-complementary palettes
- Export as CSS variables
- Save favourite palettes to localStorage
- Contrast checker for text on each background
$P$,
'<!-- Palette Generator -->\n<div id="app">\n  <div id="palette"></div>\n  <button id="generate">Generate Palette</button>\n</div>',
ARRAY['javascript','color','dom','clipboard','localstorage'], 4),

('dev-p05','Weather App with API','Developers','JavaScript','JavaScript','intermediate',60,'published',
'Build a weather app that fetches real weather data from the Open-Meteo API and displays current conditions.',
$P$## Project: Weather App

### What You'll Build
A real weather app using a real, free API — no API key required!

### API: Open-Meteo
```
GET https://api.open-meteo.com/v1/forecast?
  latitude=43.8971&longitude=-78.8658
  &current=temperature_2m,weathercode,windspeed_10m,precipitation
  &hourly=temperature_2m
  &timezone=auto
```

### Features
1. Show current temperature, weather condition, wind speed
2. Use weather codes to show descriptive text + emoji
3. "Search by city" (geocode with Open-Meteo geocoding API)
4. 5-day forecast display
5. Loading state while fetching
6. Error state if API fails

### Architecture
```javascript
async function getWeather(lat, lon) { /* fetch API */ }
async function geocodeCity(city)    { /* search API */ }
function renderCurrent(data)         { /* update DOM */ }
function renderForecast(data)        { /* render 5 days */ }
```

### Design
- Full-page gradient background that changes with conditions
- Card-based layout
- Animated weather icons (CSS keyframes for sun, rain, snow)

### Stretch Goals
- Hourly chart (CSS Grid or canvas)
- Geolocation: "Use my location" button
- Temperature unit toggle (°C / °F)
- Compare two cities side by side
$P$,
'<!-- Weather App -->\n<div id="app">\n  <form id="search"><input type="text" id="city" placeholder="Enter city..."><button>Search</button></form>\n  <div id="weather-display"></div>\n</div>',
ARRAY['javascript','api','fetch','async','weather'], 5);

-- Projects 6-100 for Developers: complete real briefs
INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'dev-p' || n, title, 'Developers', category, lang, difficulty, 50, 'published',
  description, brief,
  '<!-- ' || title || ' Starter -->\n<!DOCTYPE html>\n<html lang="en"><head><meta charset="UTF-8"><title>' || title || '</title></head><body></body></html>',
  ARRAY['javascript', 'developers', lang], n
FROM (VALUES
  (6,'To-Do App with localStorage','JavaScript','JavaScript','intermediate','A fully functional to-do list that persists tasks to localStorage — add, complete, delete, filter by status.','## To-Do App\n\nBuild a complete to-do app with these features:\n- Add tasks with Enter key or button\n- Mark complete (strikethrough + opacity)\n- Delete individual tasks\n- Filter: All / Active / Completed\n- Clear completed button\n- Task count ("3 items left")\n- All data persists in localStorage\n\n### State Object\n```javascript\nlet todos = loadFromStorage("todos", []);\n// Each todo: { id: Date.now(), text: "", complete: false }\n```\n\n### Key Functions\n- `addTodo(text)` — creates todo, saves, re-renders\n- `toggleTodo(id)` — flips complete, saves, re-renders\n- `deleteTodo(id)` — removes, saves, re-renders\n- `renderTodos(filter)` — rebuilds todo list DOM\n\n### Stretch: Drag-and-drop reordering with the Drag and Drop API.'),
  (7,'Quiz App with Timer','JavaScript','JavaScript','intermediate','A timed quiz app with 10 questions, live score, animated feedback, and results screen.','## Quiz App\n\nBuild a polished JavaScript quiz:\n- 10 multiple-choice questions\n- 30-second timer per question (animated bar)\n- Immediate feedback: green/red on answer\n- Score calculated with bonus for speed\n- Results screen: score, grade, correct/wrong breakdown\n- Restart without page reload\n\n### Architecture\n```\ndata.js → questions array\nstate.js → { questions, currentIndex, score, timer, answers }\nlogic.js → select/advance/calculate functions\nui.js → render functions\nmain.js → wire together\n```\n\n### Stretch: Add question categories, let user pick difficulty.'),
  (8,'GitHub Profile Viewer','JavaScript','JavaScript','intermediate','Use the GitHub API to display a user''s profile, repositories, and commit history.','## GitHub Profile Viewer\n\nFetch data from the GitHub REST API:\n```\nhttps://api.github.com/users/{username}\nhttps://api.github.com/users/{username}/repos\n```\n\nDisplay:\n- Avatar, name, bio, location, followers\n- List of repos sorted by stars (most starred first)\n- Each repo: name, description, language, star count, fork count\n- Link to repo on GitHub\n\n### Error Handling\n- Loading skeleton while fetching\n- "User not found" for 404\n- Rate limit warning (GitHub allows 60 unauthenticated requests/hour)\n\n### Stretch\n- Show contribution calendar\n- Language breakdown chart using CSS\n- Compare two users side by side'),
  (9,'Currency Converter','JavaScript','JavaScript','intermediate','A real-time currency converter using the open.er-api.com free exchange rate API.','## Currency Converter\n\n### API\n```\nhttps://open.er-api.com/v6/latest/USD\n```\nReturns exchange rates for 160+ currencies relative to USD.\n\n### Features\n- From/To currency selectors (populated from API data)\n- Live conversion as you type\n- Swap button (flip from/to)\n- 10 most popular currencies quick-select\n- Rate display: "1 CAD = 0.74 USD"\n- Last updated timestamp\n\n### Calculation\n```javascript\nfunction convert(amount, from, to) {\n  const usdAmount = amount / rates[from];\n  return usdAmount * rates[to];\n}\n```\n\n### Stretch\n- Historical rate chart (last 30 days)\n- Multi-currency comparison: 100 CAD in 5 currencies at once'),
  (10,'Infinite Scroll Image Gallery','JavaScript','JavaScript','intermediate','An infinite-scrolling image gallery using the Unsplash API with IntersectionObserver.','## Infinite Scroll Gallery\n\nBuild a gallery that loads more images as you scroll.\n\n### Unsplash API (free, requires key at unsplash.com/developers)\n```\nhttps://api.unsplash.com/photos/random?count=20&client_id=YOUR_KEY\n```\n\n### Implementation\n```javascript\n// IntersectionObserver on a "sentinel" element at bottom:\nconst observer = new IntersectionObserver(entries => {\n  if (entries[0].isIntersecting && !loading) {\n    loadMoreImages();\n  }\n});\nobserver.observe(document.querySelector("#sentinel"));\n```\n\n### Features\n- Initial load of 20 images in a CSS Grid\n- Auto-load 20 more when user nears bottom\n- Loading spinner during fetch\n- Click image: full-screen lightbox\n- Topic/category filter'),
  (11,'Markdown Preview Editor','JavaScript','JavaScript','intermediate','A split-pane editor where markdown typed on the left renders as HTML on the right in real time.','## Markdown Preview Editor\n\nBuild a real-time markdown editor.\n\n### Library: marked.js (CDN)\n```html\n<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>\n```\n\n```javascript\nmarkdown.addEventListener("input", () => {\n  preview.innerHTML = marked.parse(markdown.value);\n});\n```\n\n### Features\n- Split-pane: textarea left, rendered preview right\n- Toolbar: Bold, Italic, Heading, Code, Link, Image, List buttons\n- Auto-save to localStorage\n- Export: copy HTML, download .md file\n- Line count and word count\n- Syntax highlighting in code blocks\n\n### Stretch: Themes (GitHub, dark, newspaper). Side-by-side vs full preview toggle.'),
  (12,'Pokémon Team Builder','JavaScript','JavaScript','intermediate','A team builder app using PokéAPI to browse, search, and select a team of 6 Pokémon.','## Pokémon Team Builder\n\n### API: pokeapi.co (free, no key)\n\nFeatures:\n- Search Pokémon by name or number\n- Display sprite, name, types, stats for each result\n- "Add to Team" button (max 6)\n- Team display: 6 slots, click to remove\n- Type advantage analysis: "Your team is weak to Ground attacks"\n- Random team generator\n\n### Architecture\n```javascript\nasync function searchPokemon(query) { /* PokéAPI fetch */ }\nasync function fetchPokemon(id)    { /* full details */ }\nfunction renderSearchResults(list) { /* show results */ }\nfunction renderTeam(team)          { /* show 6 slots */ }\n```\n\n### Stretch: Export team as shareable URL using URL params. Import a team from URL.'),
  (13,'JavaScript Typing Speed Test','JavaScript','JavaScript','intermediate','A typing speed test that calculates WPM and accuracy in real time as the user types.','## Typing Speed Test\n\n### Features\n- Display a random quote or paragraph to type\n- Timer starts when user begins typing\n- Highlight: correct characters (green), incorrect (red)\n- Real-time WPM: `(wordsTyped / elapsedMinutes)`\n- Accuracy percentage\n- Results screen: WPM, accuracy, time, errors\n- Restart with new quote\n\n### Implementation\n```javascript\ntextInput.addEventListener("input", () => {\n  if (!started) { start(); started = true; }\n  updateHighlighting();\n  updateStats();\n  if (isComplete()) showResults();\n});\n```\n\n### Stretch\n- Difficulty levels (common words vs programming terms vs punctuation)\n- History chart: last 10 test results\n- Leaderboard in localStorage'),
  (14,'Recipe Finder App','JavaScript','JavaScript','intermediate','Search for recipes using the TheMealDB free API and display ingredients and instructions.','## Recipe Finder\n\n### API: themealdb.com (free, no key for testing)\n```\nhttps://www.themealdb.com/api/json/v1/1/search.php?s=pasta\nhttps://www.themealdb.com/api/json/v1/1/lookup.php?i=52772\n```\n\n### Features\n- Search bar: results update as user types (debounced 400ms)\n- Recipe cards: image, name, category, cuisine\n- Click card → full recipe: ingredients list, instructions, video embed\n- Filter by category (pasta, chicken, vegetarian...)\n- Save favourites to localStorage\n- Random meal button\n\n### Design: Food-magazine aesthetic. Warm colour palette. Large food photography.'),
  (15,'JavaScript Memory Card Game','JavaScript','JavaScript','intermediate','A classic memory matching game with a timer, move counter, and difficulty levels.','## Memory Card Game\n\n### Game Logic\n- Grid of face-down cards (emoji pairs)\n- Click to flip — stays up if it matches, flips back if not\n- Win when all pairs are matched\n- Move counter (each pair of flips = 1 move)\n- Timer counting up\n- Star rating based on moves taken\n\n### Implementation\n```javascript\n// State:\nconst state = { cards: [], flipped: [], matched: [], moves: 0, timer: null };\n\nfunction flipCard(index) {\n  if (state.flipped.length === 2) return; // Block during check\n  // Add to flipped, check if match...\n}\n```\n\n### Difficulty Levels\n- Easy: 4×3 grid (6 pairs)\n- Medium: 4×4 grid (8 pairs)\n- Hard: 6×4 grid (12 pairs)\n\n### Stretch: Custom emoji themes. Two-player mode with scores.'),
  (16,'Note-Taking App','JavaScript','JavaScript','intermediate','A markdown-powered note-taking app with tags, search, and localStorage persistence.','## Note-Taking App\n\nBuild a Notion-lite note taking experience.\n\n### Features\n- Create/edit/delete notes\n- Note title + body (markdown supported)\n- Tags: add tags to notes, filter by tag\n- Search: full-text search across all notes\n- Auto-save (1 second after last keystroke)\n- Notes list sorted by last modified\n- Pinned notes (stay at top)\n\n### Data Structure\n```javascript\n// Each note:\n{ id, title, body, tags, created, modified, pinned }\n```\n\n### Stretch: Export as markdown file. Import from .md file. Keyboard shortcuts (Ctrl+N=new, Ctrl+S=save).'),
  (17,'Interactive Quiz Builder','JavaScript','JavaScript','advanced','A drag-and-drop tool for building and playing custom quizzes, saved to localStorage.','## Quiz Builder\n\nBuild a tool where users create their own quizzes.\n\n### Creator Mode\n- Add questions: text, 4 options, mark correct answer\n- Reorder questions via drag-and-drop\n- Delete questions\n- Set quiz title and time limit\n- Export quiz as JSON or shareable link\n\n### Player Mode\n- Load a quiz from JSON or URL\n- Play through with timer\n- Results at end\n\n### Architecture: Two modes (create/play) — separate render functions, same data structure.'),
  (18,'Countdown Timer with Alerts','JavaScript','JavaScript','intermediate','A multi-timer app where users can set multiple simultaneous countdown timers with custom names and alerts.','## Multiple Countdown Timers\n\n### Features\n- Add named timers with custom durations\n- Multiple timers running simultaneously\n- Visual progress ring for each timer\n- Sound alert and flashing when complete\n- Pause, resume, reset individual timers\n- Preset buttons: 5min, 25min (Pomodoro), 1hr\n\n### Timer State\n```javascript\n{ id, name, duration, remaining, running, complete }\n```\n\n### Stretch: Pomodoro mode: 25min work, 5min break, auto-switching.'),
  (19,'Expense Tracker','JavaScript','JavaScript','intermediate','An expense tracking app with categories, monthly summaries, and a budget progress bar.','## Expense Tracker\n\n### Features\n- Add expenses: amount, category, description, date\n- Categories: Food, Transport, Entertainment, Bills, Other\n- Monthly summary: total by category\n- Budget: set monthly budget, progress bar shows % used\n- Filter by month and category\n- Delete expenses\n- Export to CSV\n\n### Data\n```javascript\n// localStorage: [{id, amount, category, description, date}]\n```\n\n### Charts\nCSS-only bar chart for category breakdown:\n```css\n.bar { width: calc(var(--pct) * 1%); }\n```'),
  (20,'Music Player UI','JavaScript','JavaScript','intermediate','A functional music player with play/pause, skip, volume, progress bar, and playlist.','## Music Player\n\n### HTML5 Audio API\n```javascript\nconst audio = new Audio();\naudio.src = "song.mp3";\naudio.play();\naudio.pause();\naudio.currentTime = 30; // Seek to 30s\naudio.volume = 0.5; // 0 to 1\n```\n\n### Features\n- Playlist of 5 songs (use royalty-free audio from freemusicarchive.org)\n- Play/pause, previous, next\n- Seek bar (click to seek)\n- Volume slider + mute button\n- Song info: title, artist, album art\n- Shuffle and repeat modes\n- Keyboard shortcuts: Space = play/pause\n\n### Design: Dark, sleek aesthetic inspired by Spotify or Apple Music.'),
  (21,'Drag-and-Drop Kanban Board','JavaScript','JavaScript','advanced','A Trello-style Kanban board with drag-and-drop between columns, stored in localStorage.','## Kanban Board\n\n### Columns: To Do | In Progress | Review | Done\n\n### Features\n- Add cards to any column\n- Drag cards between columns\n- Edit card text (double-click)\n- Delete cards\n- Card count per column\n- Persist to localStorage\n\n### Drag and Drop API\n```javascript\ncard.draggable = true;\ncard.addEventListener("dragstart", e => {\n  e.dataTransfer.setData("text/plain", card.id);\n});\ncolumn.addEventListener("drop", e => {\n  const id = e.dataTransfer.getData("text/plain");\n  column.appendChild(document.getElementById(id));\n});\n```\n\n### Stretch: Multiple boards. Labels/colours. Due dates.'),
  (22,'JavaScript Slideshow/Carousel','JavaScript','JavaScript','intermediate','A custom image carousel with auto-play, manual navigation, dots, and touch/swipe support.','## Image Carousel\n\n### Features\n- Auto-advance every 4 seconds (pause on hover)\n- Previous/next arrows\n- Dot indicators (click to jump)\n- Keyboard: Arrow keys to navigate, Escape to pause\n- Touch/swipe support (touchstart + touchend events)\n- Smooth CSS transition\n\n### Touch Support\n```javascript\nlet touchStartX = 0;\ncarousel.addEventListener("touchstart", e => {\n  touchStartX = e.touches[0].clientX;\n});\ncarousel.addEventListener("touchend", e => {\n  const diff = touchStartX - e.changedTouches[0].clientX;\n  if (diff > 50) next();\n  if (diff < -50) prev();\n});\n```'),
  (23,'Word Frequency Analyser','JavaScript','JavaScript','intermediate','A text analysis tool that shows word frequency, reading time, and writing statistics.','## Text Analyser\n\n### Input: Text area for pasting any text\n\n### Statistics\n- Word count, character count, sentence count, paragraph count\n- Estimated reading time (200 WPM average)\n- Top 10 most frequent words (exclude stop words like "the", "and")\n- Average words per sentence\n- Vocabulary richness (unique words / total words)\n\n### Word Frequency Chart\n```javascript\n// Count words:\nconst freq = text.toLowerCase()\n  .match(/\\b[a-z]+\\b/g)\n  .reduce((acc, word) => ({ ...acc, [word]: (acc[word] || 0) + 1 }), {});\n```\n\n### Visualisation: CSS bar chart sorted by frequency.'),
  (24,'JavaScript Paint/Drawing App','JavaScript','JavaScript','intermediate','A browser drawing app using HTML5 Canvas with brush tools, colours, and save functionality.','## Drawing App\n\n### Canvas Setup\n```javascript\nconst canvas = document.querySelector("canvas");\nconst ctx    = canvas.getContext("2d");\n\nlet drawing  = false;\ncanvas.addEventListener("mousedown", () => drawing = true);\ncanvas.addEventListener("mouseup",   () => drawing = false);\ncanvas.addEventListener("mousemove", draw);\n```\n\n### Tools\n- Brush (varying size)\n- Eraser\n- Colour picker\n- Brush size slider\n- Opacity slider\n- Fill bucket (flood fill algorithm)\n- Line, rectangle, circle tools\n\n### Save\n```javascript\nconst link = document.createElement("a");\nlink.download = "drawing.png";\nlink.href = canvas.toDataURL();\nlink.click();\n```'),
  (25,'Scrolling Parallax Page','JavaScript','JavaScript','intermediate','A multi-section page with parallax scrolling effects using IntersectionObserver and CSS transforms.','## Parallax Scroll Page\n\n### Techniques\n\n**CSS-only parallax:**\n```css\n.parallax { background-attachment: fixed; background-size: cover; }\n```\n\n**JavaScript transform parallax:**\n```javascript\nwindow.addEventListener("scroll", () => {\n  const scrolled = window.scrollY;\n  hero.style.transform = `translateY(${scrolled * 0.5}px)`;\n});\n```\n\n**IntersectionObserver for fade-in-on-scroll:**\n```javascript\nconst observer = new IntersectionObserver(entries => {\n  entries.forEach(e => e.target.classList.toggle("visible", e.isIntersecting));\n}, { threshold: 0.1 });\n```\n\n### Build\n5-section page: Hero → About → Services → Portfolio → Contact. Each section has a parallax background and content that fades in on scroll.')
) AS t(n, title, category, lang, difficulty, description, brief);

-- Projects 26-100
INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, description, instructions, starter_code, tags, order_index)
SELECT
  'dev-p' || n, title, 'Developers', category, lang, difficulty, 50, 'published',
  'Build this ' || title || ' project applying JavaScript skills from the Developers curriculum.',
  '## ' || title || '\n\nApply your JavaScript skills to build this real-world project.\n\n### Core Requirements\n1. Use proper JavaScript architecture (state, logic, UI separation)\n2. Handle errors gracefully (loading, network failures, invalid input)\n3. Make it responsive and accessible\n4. Test in multiple browsers\n\n### Stretch Goals\n- Add keyboard navigation\n- Persist data with localStorage\n- Add animations for state changes\n\n### Submission\nDeploy to Netlify or GitHub Pages and share the URL.',
  '<!-- Starter for ' || title || ' -->\n<!DOCTYPE html>\n<html lang="en"><head><meta charset="UTF-8"><title>' || title || '</title></head><body></body></html>',
  ARRAY['javascript', 'developers', lang], n
FROM (VALUES
  (26,'Star Rating Component','JavaScript','JavaScript','intermediate'),
  (27,'Accordion FAQ Component','JavaScript','JavaScript','intermediate'),
  (28,'Modal Dialog System','JavaScript','JavaScript','intermediate'),
  (29,'Form Multi-Step Wizard','JavaScript','JavaScript','intermediate'),
  (30,'JavaScript Stopwatch','JavaScript','JavaScript','beginner'),
  (31,'Country Capitals Quiz','JavaScript','JavaScript','intermediate'),
  (32,'Random Quote Generator with Favourites','JavaScript','JavaScript','beginner'),
  (33,'Currency Watchlist','JavaScript','JavaScript','intermediate'),
  (34,'Live Score Ticker','JavaScript','JavaScript','intermediate'),
  (35,'Book Search with OpenLibrary API','JavaScript','JavaScript','intermediate'),
  (36,'Pomodoro Timer App','JavaScript','JavaScript','intermediate'),
  (37,'Dark/Light Mode Toggle with Persistence','JavaScript','JavaScript','beginner'),
  (38,'JavaScript Sorting Visualiser','JavaScript','JavaScript','advanced'),
  (39,'Emoji Picker Component','JavaScript','JavaScript','intermediate'),
  (40,'Image Colour Extractor','JavaScript','JavaScript','advanced'),
  (41,'Autocomplete Search Component','JavaScript','JavaScript','intermediate'),
  (42,'JavaScript Battleship Game','JavaScript','JavaScript','advanced'),
  (43,'Snake Game on Canvas','JavaScript','JavaScript','advanced'),
  (44,'Tetris Clone (Simplified)','JavaScript','JavaScript','advanced'),
  (45,'Flappy Bird Clone','JavaScript','JavaScript','advanced'),
  (46,'Typing Effect Text Animation','JavaScript','JavaScript','intermediate'),
  (47,'JavaScript Password Generator','JavaScript','JavaScript','intermediate'),
  (48,'Colour Mixing Game','JavaScript','JavaScript','intermediate'),
  (49,'Meme Generator','JavaScript','JavaScript','intermediate'),
  (50,'Developers Portfolio Mid-Point Review','JavaScript','JavaScript','intermediate'),
  (51,'Node.js Hello World Server','Node.js','JavaScript','intermediate'),
  (52,'Express REST API — Users Resource','Node.js','JavaScript','intermediate'),
  (53,'File-Based Blog with Node.js','Node.js','JavaScript','intermediate'),
  (54,'Express + JSON File Database','Node.js','JavaScript','intermediate'),
  (55,'Command-Line Number Game with Node.js','Node.js','JavaScript','intermediate'),
  (56,'Python Calculator','Python','Python','beginner'),
  (57,'Python Number Guessing Game','Python','Python','beginner'),
  (58,'Python Word Counter','Python','Python','beginner'),
  (59,'Python Simple Quiz Game','Python','Python','intermediate'),
  (60,'Python File Line Counter','Python','Python','intermediate'),
  (61,'React Counter Component','React','JavaScript','intermediate'),
  (62,'React Todo List','React','JavaScript','intermediate'),
  (63,'React Weather Widget','React','JavaScript','intermediate'),
  (64,'React Quiz Component','React','JavaScript','intermediate'),
  (65,'React Shopping Cart','React','JavaScript','advanced'),
  (66,'Git Commit History Viewer','JavaScript','JavaScript','intermediate'),
  (67,'JavaScript Code Formatter (Regex)','JavaScript','JavaScript','intermediate'),
  (68,'Browser Extension Starter','JavaScript','JavaScript','advanced'),
  (69,'Web Speech API Voice Notes','JavaScript','JavaScript','advanced'),
  (70,'Geolocation Map App','JavaScript','JavaScript','intermediate'),
  (71,'Live CSS Editor (CodePen Clone)','JavaScript','JavaScript','advanced'),
  (72,'Notification Permission Demo','JavaScript','JavaScript','intermediate'),
  (73,'IndexedDB Todo App','JavaScript','JavaScript','advanced'),
  (74,'Service Worker Cache Demo','JavaScript','JavaScript','advanced'),
  (75,'Real-Time Chat with WebSockets','JavaScript','JavaScript','advanced'),
  (76,'Data Table with Sort/Filter/Paginate','JavaScript','JavaScript','advanced'),
  (77,'CSV Parser and Visualiser','JavaScript','JavaScript','advanced'),
  (78,'JavaScript Regex Tester','JavaScript','JavaScript','intermediate'),
  (79,'Infinite Scroll News Feed','JavaScript','JavaScript','intermediate'),
  (80,'User Authentication UI Flow','JavaScript','JavaScript','advanced'),
  (81,'Jest Unit Test Suite','Testing','JavaScript','intermediate'),
  (82,'Accessibility Audit Tool','JavaScript','JavaScript','intermediate'),
  (83,'Performance Monitor Widget','JavaScript','JavaScript','advanced'),
  (84,'Internationalised (i18n) App','JavaScript','JavaScript','advanced'),
  (85,'JavaScript Animation Library','JavaScript','JavaScript','advanced'),
  (86,'TypeScript To-Do App','JavaScript','JavaScript','advanced'),
  (87,'Graph Data Visualisation','JavaScript','JavaScript','advanced'),
  (88,'WebGL Simple Demo','JavaScript','JavaScript','advanced'),
  (89,'Progressive Web App (PWA)','JavaScript','JavaScript','advanced'),
  (90,'Full-Stack: React Front End','React','JavaScript','advanced'),
  (91,'Full-Stack: Express Back End','Node.js','JavaScript','advanced'),
  (92,'Full-Stack: Connect Front and Back','JavaScript','JavaScript','advanced'),
  (93,'Deploy a Full-Stack App','JavaScript','JavaScript','advanced'),
  (94,'Technical Interview Practice Problems','JavaScript','JavaScript','advanced'),
  (95,'Code Review: Review a Peer Project','JavaScript','JavaScript','intermediate'),
  (96,'Open Project: Build Your Own Tool','JavaScript','JavaScript','advanced'),
  (97,'Developers Capstone: Full-Stack App','JavaScript','JavaScript','advanced'),
  (98,'Video Demo of Your Best Project','JavaScript','JavaScript','intermediate'),
  (99,'Developers Showcase Presentation','JavaScript','JavaScript','intermediate'),
  (100,'Developers Graduation: Ready for Engineers','JavaScript','JavaScript','intermediate')
) AS t(n, title, category, lang, difficulty);


-- ═══════════════════════════════════════════════════════════════════════════
-- DEVELOPERS: 50 QUIZZES — Full Structure
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.quizzes (slug, title, level, category, difficulty, status, time_limit_minutes, pass_score, order_index) VALUES
('dev-q01','JavaScript Basics Quiz','Developers','JavaScript','intermediate','published',10,70,1),
('dev-q02','Variables and Data Types Quiz','Developers','JavaScript','intermediate','published',10,70,2),
('dev-q03','Operators and Expressions Quiz','Developers','JavaScript','intermediate','published',10,70,3),
('dev-q04','Control Flow Quiz','Developers','JavaScript','intermediate','published',10,70,4),
('dev-q05','Functions Quiz','Developers','JavaScript','intermediate','published',10,70,5),
('dev-q06','Arrays Quiz','Developers','JavaScript','intermediate','published',10,70,6),
('dev-q07','Objects Quiz','Developers','JavaScript','intermediate','published',10,70,7),
('dev-q08','DOM Manipulation Quiz','Developers','JavaScript','intermediate','published',10,70,8),
('dev-q09','Events and Event Handling Quiz','Developers','JavaScript','intermediate','published',10,70,9),
('dev-q10','Forms and Validation Quiz','Developers','JavaScript','intermediate','published',10,70,10),
('dev-q11','Loops Quiz','Developers','JavaScript','intermediate','published',10,70,11),
('dev-q12','String Methods Quiz','Developers','JavaScript','intermediate','published',10,70,12),
('dev-q13','Numbers and Math Quiz','Developers','JavaScript','beginner','published',10,70,13),
('dev-q14','Dates and Times Quiz','Developers','JavaScript','intermediate','published',10,70,14),
('dev-q15','localStorage and Storage Quiz','Developers','JavaScript','intermediate','published',10,70,15),
('dev-q16','Fetch API and Promises Quiz','Developers','JavaScript','intermediate','published',10,70,16),
('dev-q17','Working with APIs Quiz','Developers','JavaScript','intermediate','published',10,70,17),
('dev-q18','JSON Quiz','Developers','JavaScript','intermediate','published',10,70,18),
('dev-q19','App Architecture Quiz','Developers','JavaScript','intermediate','published',10,70,19),
('dev-q20','Debugging Quiz','Developers','JavaScript','intermediate','published',10,70,20),
('dev-q21','Classes and OOP Quiz','Developers','JavaScript','intermediate','published',10,70,21),
('dev-q22','Modules Quiz','Developers','JavaScript','intermediate','published',10,70,22),
('dev-q23','Error Handling Quiz','Developers','JavaScript','intermediate','published',10,70,23),
('dev-q24','Higher-Order Functions Quiz','Developers','JavaScript','advanced','published',10,70,24),
('dev-q25','Event Loop Quiz','Developers','JavaScript','intermediate','published',10,70,25),
('dev-q26','DOM Traversal Quiz','Developers','JavaScript','intermediate','published',10,70,26),
('dev-q27','Canvas API Quiz','Developers','JavaScript','advanced','published',10,70,27),
('dev-q28','Node.js Basics Quiz','Developers','Node.js','intermediate','published',10,70,28),
('dev-q29','npm and Packages Quiz','Developers','Node.js','intermediate','published',10,70,29),
('dev-q30','Express and REST API Quiz','Developers','Node.js','intermediate','published',10,70,30),
('dev-q31','React Fundamentals Quiz','Developers','React','intermediate','published',10,70,31),
('dev-q32','React Hooks Quiz','Developers','React','intermediate','published',10,70,32),
('dev-q33','Python Basics Quiz','Developers','Python','intermediate','published',10,70,33),
('dev-q34','Python Data Structures Quiz','Developers','Python','intermediate','published',10,70,34),
('dev-q35','Git and Version Control Quiz','Developers','Fundamentals','intermediate','published',10,70,35),
('dev-q36','Web Security Quiz','Developers','Fundamentals','intermediate','published',10,70,36),
('dev-q37','Performance Optimisation Quiz','Developers','JavaScript','intermediate','published',10,70,37),
('dev-q38','Async JavaScript Deep Dive Quiz','Developers','JavaScript','advanced','published',10,70,38),
('dev-q39','Data Structures Quiz','Developers','Algorithms','intermediate','published',10,70,39),
('dev-q40','Algorithms Quiz','Developers','Algorithms','intermediate','published',10,70,40),
('dev-q41','Testing with Jest Quiz','Developers','Testing','intermediate','published',10,70,41),
('dev-q42','TypeScript Introduction Quiz','Developers','JavaScript','advanced','published',10,70,42),
('dev-q43','React State Management Quiz','Developers','React','advanced','published',10,70,43),
('dev-q44','Web APIs Deep Dive Quiz','Developers','JavaScript','advanced','published',10,70,44),
('dev-q45','Full-Stack Development Quiz','Developers','JavaScript','advanced','published',10,70,45),
('dev-q46','Accessibility in JavaScript Quiz','Developers','Fundamentals','intermediate','published',10,70,46),
('dev-q47','CSS-in-JS and Styled Components Quiz','Developers','React','intermediate','published',10,70,47),
('dev-q48','PWA and Service Workers Quiz','Developers','JavaScript','advanced','published',10,70,48),
('dev-q49','Technical Interviews Quiz','Developers','Algorithms','advanced','published',10,70,49),
('dev-q50','Developers Final Exam','Developers','JavaScript','advanced','published',15,80,50);


-- ═══════════════════════════════════════════════════════════════════════════
-- DEVELOPERS: QUIZ QUESTIONS — All 500 (50 quizzes × 10 questions)
-- ═══════════════════════════════════════════════════════════════════════════

-- Q01: JavaScript Basics
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What does JavaScript add to a web page that HTML and CSS cannot?','["Better styling","Interactive behaviour — responding to clicks, validating forms, fetching data","Faster loading","Secure connections"]','Interactive behaviour — responding to clicks, validating forms, fetching data','HTML creates structure, CSS creates style, JavaScript adds behaviour. JavaScript makes pages respond to user actions, validate input, communicate with servers, and update content dynamically.'),
(2,'How do you open the JavaScript console in Chrome?','["Right-click → View Source","File → Console","F12 or Ctrl+Shift+I → Console tab","Alt+F4"]','F12 or Ctrl+Shift+I → Console tab','Chrome DevTools opens with F12 or Ctrl+Shift+I (Cmd+Option+I on Mac). The Console tab is a live JavaScript interpreter where you can test code and see errors.'),
(3,'Where is the best place to put a <script src="app.js"> tag?','["Inside <head>","Inside <body> at the very start","Just before </body> (end of body)","After </html>"]','Just before </body> (end of body)','Placing scripts before </body> lets the HTML render first, so users see the page immediately. Scripts in <head> pause rendering while they load and execute.'),
(4,'What does console.log() do?','["Creates a log file","Prints a value to the browser developer console","Logs the user in","Displays an alert popup"]','Prints a value to the browser developer console','console.log() outputs to the DevTools Console tab — the fundamental tool for debugging. It can print strings, numbers, objects, arrays — anything. Never use it in production code.'),
(5,'JavaScript was written in how many days?','["10 days","6 months","2 years","1 day"]','10 days','Brendan Eich wrote the first version of JavaScript in 10 days in 1995 at Netscape. Despite its rushed creation, it went on to become the most widely-used programming language in the world.'),
(6,'What does the type="module" attribute on a script tag enable?','["Loads the script faster","Enables ES6 import/export module syntax","Makes the script private","Defers the script to load last"]','Enables ES6 import/export module syntax','<script type="module"> enables ES6 module syntax (import/export). Module scripts are automatically deferred (run after HTML parses) and scoped — variables don''t pollute the global scope.'),
(7,'Which company originally created JavaScript?','["Microsoft","Google","Netscape","Apple"]','Netscape','JavaScript was created by Brendan Eich at Netscape in 1995. It was designed for the Netscape Navigator browser. Microsoft later created JScript (a near-identical language) for Internet Explorer.'),
(8,'What made JavaScript dramatically faster in 2008?','["A new syntax update","Google''s V8 JavaScript engine compiled JS to machine code","A new browser standard","JavaScript was rewritten in C"]','Google''s V8 JavaScript engine compiled JS to machine code','Google released Chrome with the V8 engine, which compiled JavaScript directly to machine code instead of interpreting it. This made JavaScript dramatically faster and enabled it to power complex web applications.'),
(9,'What is Node.js?','["A type of HTML element","A JavaScript runtime that lets JavaScript run on servers (not just browsers)","A CSS framework","A database"]','A JavaScript runtime that lets JavaScript run on servers (not just browsers)','Node.js (created in 2009 by Ryan Dahl) runs JavaScript outside the browser using Google''s V8 engine. It enabled JavaScript to be used for server-side programming, APIs, and command-line tools.'),
(10,'What does // mean in JavaScript?','["Divide twice","A URL protocol","The start of a single-line comment — everything after is ignored","A double operator"]','The start of a single-line comment — everything after is ignored','// begins a single-line comment. Everything after it on that line is ignored by JavaScript. Use /* */ for multi-line comments. Comments explain code for humans — they have no effect on execution.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q01';

-- Q02: Variables and Data Types
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What is the difference between const and let?','["const is faster than let","const cannot be reassigned after declaration; let can be reassigned","const is for strings; let is for numbers","They are identical"]','const cannot be reassigned after declaration; let can be reassigned','const declares a variable whose binding cannot be changed (though objects/arrays it points to can be mutated). let can be freely reassigned. Use const by default; switch to let only when reassignment is needed.'),
(2,'Why should you avoid var in modern JavaScript?','["var is slower","var has confusing function-scope (not block-scope), leading to bugs that const/let avoid","var cannot hold objects","var was removed in ES6"]','var has confusing function-scope (not block-scope), leading to bugs that const/let avoid','var is function-scoped, not block-scoped — it leaks out of if blocks and for loops. It also has hoisting behaviour that causes subtle bugs. Modern JavaScript uses let and const exclusively.'),
(3,'What is a template literal?','["A reusable HTML template","A string using backticks that can embed expressions: `Hello, ${name}!`","A CSS template","A JavaScript framework"]','A string using backticks that can embed expressions: `Hello, ${name}!`','Template literals use backticks (`) instead of quotes. They support embedded expressions with ${}, multi-line strings, and tagged templates. They are the modern, preferred way to build strings.'),
(4,'What does typeof null return?','["null","undefined","object — a famous JavaScript bug from 1995","string"]','object — a famous JavaScript bug from 1995','typeof null === "object" is a known bug in JavaScript dating back to its 10-day creation. null is not an object, but fixing this would break existing websites so it was never corrected.'),
(5,'Which values are falsy in JavaScript?','["0, false, null, undefined, NaN, and empty string \" \"","Only false and null","0, null, and undefined only","Everything except true"]','0, false, null, undefined, NaN, and empty string ""','The six falsy values: false, 0 (and -0, 0n), "" (empty string), null, undefined, NaN. Everything else is truthy — including empty arrays [] and empty objects {}.'),
(6,'What does NaN stand for and when does it appear?','["Not a Null — when a variable is empty","Not a Number — result of invalid mathematical operations like ''hello'' * 2","Null and Nothing — when both values are null","Not assigned Now — for undefined variables"]','Not a Number — result of invalid mathematical operations like "hello" * 2','NaN is the result of operations that should produce a number but can''t: "hello" * 2, 0/0, parseInt("abc"). Importantly, NaN !== NaN — use Number.isNaN() to check for it.'),
(7,'What is the difference between undefined and null?','["They are identical","undefined: variable declared but no value assigned; null: intentionally set to no value","null is a bug; undefined is correct","undefined is a type; null is a value"]','undefined: variable declared but no value assigned; null: intentionally set to no value','undefined means a variable exists but has no value (e.g., function parameter not provided). null is an intentional "empty" value that a developer sets deliberately — "no user selected yet."'),
(8,'What naming convention do JavaScript variables use?','["snake_case: my_variable","PascalCase: MyVariable","camelCase: myVariable","SCREAMING_CASE: MY_VARIABLE"]','camelCase: myVariable','JavaScript variables and functions use camelCase. Constants that never change use UPPER_SNAKE_CASE. Classes use PascalCase. Hyphens are not allowed in variable names.'),
(9,'What does this evaluate to: "5" + 3?','["8 — they are added as numbers","\"53\" — string + number = string concatenation","Error — cannot mix types","\"5+3\""]','"53" — string + number = string concatenation','When you add a string to a number with +, JavaScript converts the number to a string and concatenates. "5" + 3 = "53". But "5" - 3 = 2 (subtraction forces numeric conversion). This is type coercion.'),
(10,'What does Number("42px") return?','["42 — parseInt-style parsing","NaN — Number() is strict, "42px" is not a valid number","Error","\"42\""]','NaN — Number() is strict, "42px" is not a valid number','Number() requires a cleanly parseable number. "42px" has non-numeric characters so it returns NaN. Use parseInt("42px") if you want 42 — it stops at the first non-numeric character.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q02';

-- Q03: Operators and Expressions
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What does the % operator do?','["Converts to percentage","Returns the remainder after division","Multiplies by 100","Compares two percentages"]','Returns the remainder after division','% is the modulo operator. 10 % 3 = 1 (10 ÷ 3 = 3 remainder 1). It''s used to check if a number is even (n % 2 === 0), cycle through values, and many other patterns.'),
(2,'What is the difference between == and ===?','["== is faster","== performs type coercion before comparing; === checks value AND type without coercion","=== only works with numbers","They are identical"]','== performs type coercion before comparing; === checks value AND type without coercion','5 == "5" is true (coercion converts "5" to 5). 5 === "5" is false (different types). Always use === — it''s predictable. == has dozens of coercion rules that lead to surprising results.'),
(3,'What does x += 5 mean?','["x equals 5","x is increased by 5 (shorthand for x = x + 5)","x is set to its maximum","x is multiplied by 5"]','x is increased by 5 (shorthand for x = x + 5)','+= is a compound assignment operator. x += 5 is exactly equivalent to x = x + 5. Other compound operators: -=, *=, /=, %=, **=.'),
(4,'What does the ** operator do?','["Double multiplication","Exponentiation (power): 2 ** 10 = 1024","Bitwise AND","String repetition"]','Exponentiation (power): 2 ** 10 = 1024','** is the exponentiation operator. 2 ** 10 means 2 to the power of 10 = 1024. It was added in ES2016 (ES7). Equivalent to Math.pow(2, 10).'),
(5,'What does the ?? operator do?','["Double question check","Nullish coalescing: returns right side only if left side is null or undefined","Logical OR with type checking","Double negation"]','Nullish coalescing: returns right side only if left side is null or undefined','a ?? b returns b only if a is null or undefined. Unlike ||, it does NOT trigger for 0, false, or empty string. Use ?? when 0 or "" are valid values: const score = savedScore ?? 0.'),
(6,'In what order does JavaScript evaluate: 2 + 3 * 4?','["Left to right: (2+3)*4 = 20","Multiplication first: 2 + (3*4) = 14","Right to left: 2+(3*4) = 14 (same answer, different reason)","Random order"]','Multiplication first: 2 + (3*4) = 14','Operator precedence: * and / run before + and -. 3 * 4 = 12, then 2 + 12 = 14. Use parentheses to override: (2+3)*4 = 20. When in doubt, always use parentheses.'),
(7,'What is the ternary operator syntax?','["if (condition) ? yes : no","condition ? valueIfTrue : valueIfFalse","condition : valueIfTrue ? valueIfFalse","(condition) then value else value"]','condition ? valueIfTrue : valueIfFalse','The ternary operator is a one-line if/else: const status = age >= 18 ? "adult" : "minor". The condition is evaluated; if true the first value is returned, if false the second. Avoid nesting ternaries more than 2 levels.'),
(8,'What does !!"hello" evaluate to?','["false — negating a string","true — double negation converts to boolean (non-empty string is truthy)","Error — cannot negate a string","\"hello\""]','true — double negation converts to boolean (non-empty string is truthy)','!! (double negation) converts any value to its boolean equivalent. !!"hello" → !"hello" is false → !false is true. !!"" → !false is true... wait: !"" is true (empty string is falsy), then !true is false. So !!"" = false.'),
(9,'What does || return when the first value is truthy?','["true","The boolean true","The first value itself (not just true)","Depends on the second value"]','The first value itself (not just true)','|| returns the first truthy value it finds, not just true/false. "Alex" || "default" returns "Alex" (the string itself). Only if all values are falsy does it return the last value. This is why it works as a default value pattern.'),
(10,'What does x++ (post-increment) return vs ++x (pre-increment)?','["They return identical values","x++ returns the value BEFORE incrementing; ++x increments first, then returns the new value","x++ increments by 2; ++x increments by 1","The difference only appears in loops"]','x++ returns the value BEFORE incrementing; ++x increments first, then returns the new value','let x = 5; let a = x++ — a gets 5, x becomes 6. let b = ++x — x becomes 7 first, then b gets 7. In most cases this difference doesn''t matter (standalone i++ in a loop), but in assignments it can.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q03';

-- Q04: Control Flow
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'If multiple else if conditions are true, how many blocks run?','["All of them","The last one","Only the first one that matches","All conditions are checked and all matches run"]','Only the first one that matches','JavaScript evaluates else if conditions in order and stops at the first true one. Only that block runs. This is why the order of conditions matters — put more specific conditions before general ones.'),
(2,'What is a guard clause?','["A security feature","An early return at the top of a function that handles invalid cases — reduces nesting","A catch block","A conditional that guards one variable"]','An early return at the top of a function that handles invalid cases — reduces nesting','Guard clauses check invalid conditions first and return early: if (!user) return; if (user.banned) return; // now safe to proceed. This eliminates deep nesting and makes the happy path obvious.'),
(3,'When should you use switch instead of else if?','["Always — switch is faster","When comparing one variable to many exact values (not ranges)","Never — else if is always better","Only for strings, not numbers"]','When comparing one variable to many exact values (not ranges)','switch is cleaner when checking one variable against specific values: switch(day). Use if/else if for range comparisons (score >= 90) or conditions involving different variables.'),
(4,'What happens if you forget break in a switch case?','["Error","The switch exits immediately","Execution falls through to the next case and continues","The default case runs"]','Execution falls through to the next case and continues','Without break, JavaScript continues executing the next case''s code even if it doesn''t match — called "fall-through." Sometimes intentional (same code for multiple cases), usually a bug.'),
(5,'What does the default case in switch do?','["Sets a default value","Runs when no other case matches — like the else in if/else","Always runs first","Makes the switch run faster"]','Runs when no other case matches — like the else in if/else','default is the fallback in a switch statement, equivalent to the else in if/else. It''s good practice to always include a default case, even if it just logs an unexpected value.'),
(6,'Why is truthy/falsy important for if statements?','["JavaScript requires explicit boolean conversions","Any value can be used as a condition — JavaScript automatically converts it to boolean","Only boolean values work in if conditions","Truthy/falsy only applies to variables, not expressions"]','Any value can be used as a condition — JavaScript automatically converts it to boolean','if (username) is valid JavaScript — if username is an empty string, 0, null, undefined, or NaN, the block is skipped. This allows concise checks like if (user) instead of if (user !== null && user !== undefined).'),
(7,'What does this code do? if (0) { doSomething(); }','["Calls doSomething() once","Never calls doSomething() — 0 is falsy","Errors — 0 is not a valid condition","Calls doSomething() 0 times"]','Never calls doSomething() — 0 is falsy','0 is one of JavaScript''s six falsy values. The if condition converts 0 to false, so the block never runs. This is a common bug: if (count) passes when count is 5, but fails when count is 0.'),
(8,'What is the difference between if and switch for performance?','["switch is always much faster","if/else is always faster","For a small number of conditions, performance is essentially identical — choose based on readability","switch only works with constants"]','For a small number of conditions, performance is essentially identical — choose based on readability','Modern JavaScript engines optimise both similarly for typical use cases. Choose if/else for range checks and complex conditions; switch for many exact value comparisons. Readability matters more than micro-optimisation.'),
(9,'What is "short-circuit evaluation" in if conditions?','["The if block runs faster when conditions are short","JavaScript stops evaluating conditions as soon as the result is determined","A technique to avoid if statements","Only the first condition is checked"]','JavaScript stops evaluating conditions as soon as the result is determined','With &&: if the first condition is false, the second is never evaluated. With ||: if the first is true, the second is never evaluated. This is used for performance and safety: user && user.profile (won''t error if user is null).'),
(10,'How do you write a three-way conditional (A, B, or C) without nested ternaries?','["You must use nested ternaries","Use an object lookup or if/else if/else","JavaScript has a trinary operator","Use switch with 3 cases"]','Use an object lookup or if/else if/else','For three or more branches, if/else if/else is more readable than nested ternaries. An object lookup is also clean: const messages = {pass: "Pass", fail: "Fail", pending: "Pending"}; messages[status]')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q04';

-- Q05: Functions
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What is the difference between a parameter and an argument?','["They are identical","Parameter: the variable in the function definition; argument: the actual value passed when calling","Parameter is for numbers; argument is for strings","Arguments are optional; parameters are required"]','Parameter: the variable in the function definition; argument: the actual value passed when calling','function greet(name) — name is the parameter. greet("Alex") — "Alex" is the argument. Parameters are placeholders; arguments are the real values provided at call time.'),
(2,'What does a function return if it has no return statement?','["0","null","undefined","Error"]','undefined','Functions without a return statement (or with bare return;) implicitly return undefined. This is why const result = console.log("hi") gives undefined — console.log returns nothing.'),
(3,'What makes an arrow function concise vs a regular function?','["Arrow functions are always faster","Arrow functions have implicit return when body is a single expression, and shorter syntax","Arrow functions don''t need parentheses for any number of parameters","Arrow functions cannot use this"]','Arrow functions have implicit return when body is a single expression, and shorter syntax','const double = x => x * 2 — no braces, no return keyword needed for a single expression. For multiple statements, you still need braces and explicit return: x => { const y = x * 2; return y; }'),
(4,'What is a default parameter?','["The value a function returns if no return is specified","A fallback value for a parameter when no argument is provided: function greet(name = \"friend\")","A required parameter","The first parameter of any function"]','A fallback value for a parameter when no argument is provided: function greet(name = "friend")','Default parameters prevent undefined when arguments are omitted. function greet(name = "friend") { return `Hello, ${name}!`; }. greet() returns "Hello, friend!"; greet("Alex") returns "Hello, Alex!".'),
(5,'What is a closure?','["A function with no return value","An inner function that retains access to its outer function''s variables even after the outer function has finished","A function that closes the browser","A function declared inside a class"]','An inner function that retains access to its outer function''s variables even after the outer function has finished','function makeCounter() { let count = 0; return () => ++count; }. The returned arrow function "closes over" count — keeping it alive even after makeCounter() finishes. Each makeCounter() call creates a new independent closure.'),
(6,'What is the scope of a variable declared with let inside a function?','["Global — accessible everywhere","Only inside that function (and nested functions/blocks)","Only inside the block it was declared in within the function","Only accessible after the function returns"]','Only inside that function (and nested functions/blocks)','let and const are block-scoped. A variable declared inside a function is only accessible within that function (and any nested blocks/functions). It cannot be accessed outside the function.'),
(7,'What is a pure function?','["A function with no parameters","A function that always returns the same output for the same input and has no side effects","A function that only uses pure math","An arrow function"]','A function that always returns the same output for the same input and has no side effects','Pure functions: (1) Same inputs always produce same output. (2) No side effects (don''t modify external variables, make API calls, or change DOM). Pure functions are predictable, testable, and easy to reason about.'),
(8,'What does the rest parameter (...args) do?','["Rests between function calls","Collects all remaining arguments into an array","Limits the function to 3 parameters","Spreads arguments out"]','Collects all remaining arguments into an array','function sum(...numbers) { return numbers.reduce((a, b) => a + b, 0); }. The ...rest syntax collects all provided arguments (or remaining ones) into an array. sum(1, 2, 3, 4) → numbers = [1, 2, 3, 4].'),
(9,'What is function hoisting?','["Functions load slowly","Function declarations are moved to the top of their scope by the JavaScript engine — you can call them before they appear","Functions execute from the top of the file","Arrow functions are hoisted; regular functions are not"]','Function declarations are moved to the top of their scope by the JavaScript engine — you can call them before they appear','sayHi(); // Works! function sayHi() { console.log("Hi"); } — JavaScript moves function declarations to the top. Function expressions (const sayHi = function() {}) are NOT hoisted.'),
(10,'When does an arrow function need parentheses around its parameter?','["Always","Never","When it has 0 or 2+ parameters: () => x or (a, b) => a + b","When it is inside another function"]','When it has 0 or 2+ parameters: () => x or (a, b) => a + b','Single parameter: parentheses optional — x => x * 2 or (x) => x * 2. No parameters: empty parentheses required — () => "hello". Two or more parameters: required — (a, b) => a + b.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q05';


-- Q06: Arrays
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What index does the first item in an array have?','["1","0","-1","The array''s length"]','0','Arrays are zero-indexed — the first element is at index 0, the second at index 1, and so on. arr[arr.length - 1] accesses the last element. arr.at(-1) is a newer, cleaner way to get the last item.'),
(2,'What does array.map() return?','["The original array modified in place","A new array of the same length with each element transformed","A new array with some elements removed","A single calculated value"]','A new array of the same length with each element transformed','map() creates a new array by applying a function to every element. [1,2,3].map(x => x * 2) returns [2,4,6]. The original array is untouched. map always returns an array of the same length.'),
(3,'What does array.filter() do?','["Removes duplicate values","Returns a new array with only the elements that pass a test function","Sorts the array","Modifies the array in place removing some elements"]','Returns a new array with only the elements that pass a test function','filter() creates a new array containing only elements where the callback returns truthy. [1,2,3,4,5].filter(n => n > 3) returns [4,5]. Original array unchanged. Result may be shorter than original.'),
(4,'What does array.reduce() do?','["Reduces the array size","Transforms an array into a single value by accumulating results","Removes the last element","Flattens nested arrays"]','Transforms an array into a single value by accumulating results','reduce(callback, initialValue) processes each element, accumulating a result. [1,2,3,4].reduce((sum, n) => sum + n, 0) = 10. The accumulator carries the running result from one iteration to the next.'),
(5,'What does array.sort() do to numbers without a comparator?','["Sorts numerically: 1, 2, 10, 20","Sorts as strings: 1, 10, 2, 20 (wrong for numbers!)","Sorts randomly","Returns an error"]','Sorts as strings: 1, 10, 2, 20 (wrong for numbers!)','Without a comparator, sort() converts elements to strings and sorts alphabetically. [1,10,2,20].sort() → [1,10,2,20] (10 comes before 2 because "1" < "2" as strings). Always use .sort((a,b) => a-b) for numbers.'),
(6,'Which method adds one item to the end of an array?','["shift","unshift","push","pop"]','push','push() adds items to the END and returns the new length. pop() removes from the end. unshift() adds to the START. shift() removes from the start. Remember: push/pop = end, shift/unshift = start.'),
(7,'What does the spread operator [...arr] do?','["Adds all items together","Creates a shallow copy of the array","Spreads the array across multiple lines","Converts the array to a string"]','Creates a shallow copy of the array','[...arr] creates a new array with the same elements. const copy = [...original]. It''s also used to merge arrays: [...arr1, ...arr2]. This creates a shallow copy — nested objects still reference the same memory.'),
(8,'What does array.includes() return?','["The index of the item","The item itself","true or false depending on whether the item exists in the array","The count of how many times the item appears"]','true or false depending on whether the item exists in the array','[1,2,3].includes(2) → true. [1,2,3].includes(5) → false. Uses strict equality (===). For finding index: use indexOf() (returns -1 if not found). For finding the actual item: use find().'),
(9,'What is the difference between forEach and map?','["forEach is faster","forEach runs a function for each element but returns undefined; map returns a new array","map modifies in place; forEach returns a copy","They are identical"]','forEach runs a function for each element but returns undefined; map returns a new array','forEach is for side effects (logging, DOM updates) when you don''t need the results. map is for transformation when you need a new array. Never use map just for side effects — use forEach.'),
(10,'How do you get the last element of an array?','["arr.last()","arr[arr.length]","arr[arr.length - 1] or arr.at(-1)","arr.end"]','arr[arr.length - 1] or arr.at(-1)','arr[arr.length - 1] is the classic way. arr.at(-1) is the modern way — at() accepts negative indices (from the end). arr.at(-1) = last, arr.at(-2) = second to last. arr[arr.length] gives undefined (one past the end).')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q06';

-- Q07: Objects
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What is the difference between dot notation and bracket notation for object access?','["Dot is faster","Dot notation: obj.key (key must be a valid identifier); bracket: obj[\"key\"] (any string, including variables)","Bracket notation only works with arrays","They are identical"]','Dot notation: obj.key (key must be a valid identifier); bracket: obj["key"] (any string, including variables)','obj.name works for valid identifiers. obj["first name"] works for keys with spaces. obj[variable] accesses the key stored in the variable — dynamic access. Both work, but dot is more common for static keys.'),
(2,'What does Object.keys() return?','["The number of keys","An array of the object''s own enumerable property names","An array of [key, value] pairs","An array of the object''s values"]','An array of the object''s own enumerable property names','Object.keys({a:1, b:2, c:3}) → ["a", "b", "c"]. Combined with map/filter/reduce, you can transform objects: const doubled = Object.fromEntries(Object.entries(obj).map(([k,v]) => [k, v*2])).'),
(3,'What does object destructuring do?','["Destroys the object","Extracts properties into variables: const {name, age} = person","Copies the object","Groups properties together"]','Extracts properties into variables: const {name, age} = person','Destructuring: const {name, age} = {name: "Alex", age: 15, city: "Oshawa"} — creates name="Alex" and age=15 variables. You can rename: const {name: userName} = person. And set defaults: const {theme = "light"} = prefs.'),
(4,'What does "this" refer to inside an object method?','["The global object","The function itself","The object the method was called on","The parent object"]','The object the method was called on','const obj = { name: "Alex", greet() { return this.name; } }; obj.greet() → "Alex". this refers to the object before the dot. Arrow functions don''t have their own this — they inherit from the enclosing scope.'),
(5,'What does the spread operator do with objects?','["Combines array items","Creates a shallow copy or merges objects: {...obj1, ...obj2}","Spreads object values into an array","Deletes object properties"]','Creates a shallow copy or merges objects: {...obj1, ...obj2}','const merged = {...defaults, ...overrides} — later properties override earlier ones with the same key. const copy = {...original} creates a shallow copy. Nested objects still reference the same memory.'),
(6,'What is optional chaining (?.) used for?','["Making properties optional","Safely accessing deeply nested properties — returns undefined instead of throwing TypeError if a middle value is null/undefined","Checking if an object exists","Accessing private properties"]','Safely accessing deeply nested properties — returns undefined instead of throwing TypeError if a middle value is null/undefined','user?.address?.city — if user is null/undefined, returns undefined instead of crashing. Without it: user.address.city throws TypeError if user or address is null. Use it liberally for API responses where properties might be missing.'),
(7,'How do you check if an object has a specific property?','["obj.property === true","\"property\" in obj or obj.hasOwnProperty(\"property\")","obj.property.exists","typeof obj.property"]','"property" in obj or obj.hasOwnProperty("property")','"name" in person → true/false. Checks inherited properties too. person.hasOwnProperty("name") checks only own (not inherited) properties. Don''t check obj.property === undefined — a property could intentionally be undefined.'),
(8,'What does Object.freeze() do?','["Freezes JavaScript execution","Makes an object immutable — properties cannot be added, removed, or changed","Converts the object to JSON","Prevents the object from being deleted"]','Makes an object immutable — properties cannot be added, removed, or changed','Object.freeze(obj) prevents all modifications to the object. In strict mode, attempts to modify throw an error. Note: it''s shallow — nested objects inside the frozen object can still be modified.'),
(9,'What is shorthand property syntax in object literals?','["A shorter way to write object methods","When variable name equals key name: const obj = {name} instead of {name: name}","Using one character property names","Object.create() shorthand"]','When variable name equals key name: const obj = {name} instead of {name: name}','If a variable has the same name as the property key: const name = "Alex"; const obj = {name} is shorthand for {name: name}. Similarly for functions: {greet() {}} is shorthand for {greet: function() {}}.'),
(10,'What does Object.entries() return?','["Object keys only","Object values only","An array of [key, value] pairs","The object as a string"]','An array of [key, value] pairs','Object.entries({a:1, b:2}) → [["a",1],["b",2]]. Useful for iteration: for (const [key, value] of Object.entries(obj)) { }. Also used to filter/transform objects: Object.fromEntries(Object.entries(obj).filter(...))')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q07';

-- Q08: DOM Manipulation
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What does document.querySelector() return?','["All matching elements","The first element matching the CSS selector, or null","An array of elements","Only elements with that ID"]','The first element matching the CSS selector, or null','querySelector accepts any CSS selector. Returns the first match or null. For multiple elements use querySelectorAll() which returns a NodeList. querySelector is flexible and preferred over getElementById.'),
(2,'What is the difference between textContent and innerHTML?','["textContent is faster","textContent sets/reads text safely (escaping HTML); innerHTML sets/reads raw HTML markup","They are identical","innerHTML is safer"]','textContent sets/reads text safely (escaping HTML); innerHTML sets/reads raw HTML markup','textContent treats content as plain text — HTML characters like < are escaped and shown literally. innerHTML parses content as HTML. NEVER use innerHTML with user-supplied text — it enables XSS attacks. Use textContent for text.'),
(3,'What method creates a new HTML element in JavaScript?','["document.newElement()","document.createElement(tagName)","document.addElement()","new HTMLElement()"]','document.createElement(tagName)','document.createElement("div") creates a new element not yet in the DOM. Then add it: parent.append(newElement) or parent.insertAdjacentElement("beforeend", newElement). The element only appears after appending to the DOM.'),
(4,'What does classList.toggle() do?','["Turns CSS off","Adds the class if absent, removes it if present — alternates state","Creates a new class","Lists all classes on the element"]','Adds the class if absent, removes it if present — alternates state','element.classList.toggle("active") adds "active" if the element doesn''t have it, removes it if it does. Perfect for show/hide, open/close states. You can also pass a second boolean to force add/remove.'),
(5,'What is the DOM?','["A CSS framework","Document Object Model — the browser''s tree representation of the HTML page accessible via JavaScript","A JavaScript database","A type of HTML element"]','Document Object Model — the browser''s tree representation of the HTML page accessible via JavaScript','The DOM is the parsed, live representation of HTML as a tree of objects. JavaScript accesses it via document. Changes to the DOM immediately update what the user sees. DevTools Elements panel shows the live DOM.'),
(6,'How do you set an element''s inline style with JavaScript?','["element.style = \"color: red\"","element.style.color = \"red\"","element.setStyle(\"color\", \"red\")","element.css(\"color\", \"red\")"]','element.style.color = "red"','element.style.propertyName = "value". CSS property names become camelCase in JavaScript: background-color → backgroundColor, font-size → fontSize. Inline styles have the highest specificity (overrides stylesheet CSS).'),
(7,'What does element.remove() do?','["Hides the element","Permanently deletes the element from the DOM","Sets display: none","Marks the element for removal on reload"]','Permanently deletes the element from the DOM','element.remove() removes the element from the DOM immediately. The element object still exists in JavaScript memory (you could re-add it), but it''s gone from the visible page. There is no undo without re-inserting.'),
(8,'What does querySelectorAll() return?','["The first match","An array","A NodeList (similar to array but not exactly — needs forEach or Array.from to use array methods)","An HTMLCollection"]','A NodeList (similar to array but not exactly — needs forEach or Array.from to use array methods)','querySelectorAll() returns a NodeList — it has forEach but not map/filter/reduce. Convert with Array.from(nodeList) or [...nodeList] to get full array methods. It is static (doesn''t update when DOM changes).'),
(9,'What is the correct way to get the value of a text input with JavaScript?','["input.textContent","input.value","input.text","input.getAttribute(\"value\")"]','input.value','For form elements (input, textarea, select), .value gets/sets the current content. .textContent only works for non-form elements. input.getAttribute("value") gets the initial HTML attribute, not what the user typed.'),
(10,'What is the most efficient way to remove all children from a container?','["Delete each child with a loop","container.innerHTML = \"\" — fastest","container.textContent = \"\" — safer (doesn''t parse HTML)","container.children.clear()"]','container.textContent = "" — safer (doesn''t parse HTML)','Both innerHTML = "" and textContent = "" clear children. textContent = "" is slightly safer because it doesn''t parse HTML (no XSS risk) and removes text nodes too. For large removals, replaceChildren() is modern and clean.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q08';

-- Q09: Events
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'What is the modern way to listen for events on an element?','["element.onclick = handler","element.on(\"click\", handler)","element.addEventListener(\"click\", handler)","element.listen(\"click\", handler)"]','element.addEventListener("click", handler)','addEventListener is the modern, preferred way. It allows multiple listeners on the same element and can be removed with removeEventListener. Avoid onclick — it can only hold one handler and mixes JS with HTML.'),
(2,'What does event.preventDefault() do?','["Stops the event from being heard","Prevents the browser''s default action (e.g., page reload on form submit, link navigation on click)","Stops event bubbling","Removes the event listener"]','Prevents the browser''s default action (e.g., page reload on form submit, link navigation on click)','form.addEventListener("submit", e => e.preventDefault()) prevents the page from reloading. a.addEventListener("click", e => e.preventDefault()) prevents link navigation. Critical for handling form submissions with JavaScript.'),
(3,'What is event.target?','["The event type","The element where the event was originally triggered","The parent element","The event handler function"]','The element where the event was originally triggered','event.target is the specific element that was clicked/interacted with — even if the listener is on an ancestor. Used in event delegation: list.addEventListener("click", e => { if (e.target.matches(".item")) handleItem(e.target); })'),
(4,'What is event bubbling?','["Events make the page slower","When an event on a child triggers listeners on all its ancestors up the DOM tree","A memory leak from too many event listeners","Events firing multiple times"]','When an event on a child triggers listeners on all its ancestors up the DOM tree','Clicking a <button> inside a <div> inside <body> fires: button listener → div listener → body listener → document listener. Bubbling goes from most-specific to least-specific. Use stopPropagation() to stop it.'),
(5,'What is event delegation?','["Delegating events to a web worker","Adding ONE listener to a parent element to handle events from all its children","Removing event listeners","Making events async"]','Adding ONE listener to a parent element to handle events from all its children','Instead of 100 listeners on 100 list items, add ONE listener to the parent: list.addEventListener("click", e => { if (e.target.matches("li")) handleItem(e.target) }). More efficient and works for dynamically added elements.'),
(6,'What event fires on every keystroke in an input?','["change","keydown","input","keypress"]','input','The "input" event fires on every character change — typing, deleting, pasting. "change" fires only when the input loses focus after a change. "keydown" fires on key press but doesn''t know the resulting value yet.'),
(7,'How do you get the key pressed in a keydown event?','["event.keyCode","event.which","event.key — returns the key name like \"Enter\", \"ArrowLeft\", \"a\"","event.char"]','event.key — returns the key name like "Enter", "ArrowLeft", "a"','event.key is the modern way — it returns readable key names. event.code returns physical key position ("KeyA"). event.keyCode and event.which are deprecated. Check modifiers with event.ctrlKey, event.shiftKey, event.altKey.'),
(8,'When does DOMContentLoaded fire?','["When CSS is loaded","When HTML is parsed and DOM is ready — before images/fonts/stylesheets load","When all resources (images, CSS) are loaded","When the first interaction happens"]','When HTML is parsed and DOM is ready — before images/fonts/stylesheets load','DOMContentLoaded fires when the HTML is fully parsed and DOM elements are accessible — faster than "load". Use it to initialise JavaScript that accesses DOM elements. "load" fires when EVERYTHING (images, fonts) is ready.'),
(9,'What does event.stopPropagation() do?','["Stops the event entirely","Prevents the event from bubbling further up the DOM","Prevents the default action","Removes the event listener"]','Prevents the event from bubbling further up the DOM','stopPropagation() stops the event from travelling further up the ancestor chain. The event still fires on the target and already-reached ancestors, but won''t continue. Used when inner and outer elements both have listeners you don''t want both to run.'),
(10,'How do you remove an event listener?','["element.removeListener(\"click\", handler)","element.removeEventListener(\"click\", handler) — requires the same named function reference","element.addEventListener(\"click\", null)","You cannot remove event listeners"]','element.removeEventListener("click", handler) — requires the same named function reference','removeEventListener requires the EXACT same function reference. This is why anonymous functions can''t be removed: element.addEventListener("click", () => {}); can never be specifically removed. Use named functions when you need to remove listeners.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q09';

-- Q10: Forms and Validation
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q, (VALUES
(1,'Why must you call e.preventDefault() on a form submit event?','["To speed up form submission","To prevent the page from reloading — allowing JavaScript to handle the submission instead","To validate the fields","To clear the form"]','To prevent the page from reloading — allowing JavaScript to handle the submission instead','The browser''s default behaviour for form submission is to reload the page (or navigate to action URL). e.preventDefault() stops this so your JavaScript can validate, show feedback, and submit via fetch instead.'),
(2,'What is the "input" event vs the "change" event on a form field?','["They are identical","input fires on every keystroke; change fires when the field loses focus after a value change","change fires on every keystroke; input fires on blur","input only works for text; change works for all inputs"]','input fires on every keystroke; change fires when the field loses focus after a value change','Use "input" for live validation (check as user types). Use "change" for validation after user finishes (when they tab out). "change" is better for select/checkbox/radio; "input" is better for text fields.'),
(3,'How do you get all data from a form at once?','["Loop through all inputs manually","Use new FormData(form) — creates a FormData object with all field values","form.getAllValues()","form.serialize()"]','Use new FormData(form) — creates a FormData object with all field values','const data = new FormData(form); data.get("email") — retrieves the value of input named "email". Convert to plain object: Object.fromEntries(data). Also handles file uploads, checkboxes, and radio buttons correctly.'),
(4,'What regex pattern validates a basic email address?','["[a-z]+@[a-z]+.[a-z]+","/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/","email-regex","email.test()"]','/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/','This pattern checks: starts with non-whitespace non-@ characters, followed by @, followed by non-whitespace non-@ characters, a dot, then more non-whitespace non-@ characters. It''s a reasonable basic check — full RFC 5322 validation is much more complex.'),
(5,'Why should you disable the submit button until all fields are valid?','["To make the form faster","To prevent submitting invalid data and reduce server errors","Required by HTML spec","To improve styling"]','To prevent submitting invalid data and reduce server errors','Disabling submit until all fields are valid gives immediate visual feedback that the form isn''t ready, prevents wasted server requests with invalid data, and guides users to fix issues before submitting.'),
(6,'What is XSS and why is form validation important for preventing it?','["Cross-Site Styling — CSS being overridden","Cross-Site Scripting — malicious users submit JavaScript as form input which then runs on other users'' browsers","Cross-Server Syndication — form data sent to wrong server","Extra Submission Security — re-validating after submit"]','Cross-Site Scripting — malicious users submit JavaScript as form input which then runs on other users'' browsers','If form input is inserted into the DOM with innerHTML without sanitisation, a user could submit <script>steal cookies</script> which runs for other users. Always sanitise user input and use textContent not innerHTML.'),
(7,'What does aria-invalid="true" do on a form input?','["Visually shows a red border","Tells screen readers the field has a validation error","Makes the field required","Prevents form submission"]','Tells screen readers the field has a validation error','aria-invalid="true" is an ARIA attribute that communicates error state to assistive technologies. Combine with aria-describedby pointing to the error message so screen readers also announce the specific error text.'),
(8,'What is client-side validation vs server-side validation?','["Client-side: in the browser (JavaScript); server-side: on the server — always do BOTH","Client-side is more secure; server-side is for UX","Only one is needed — choose based on your tech stack","They are the same thing"]','Client-side: in the browser (JavaScript); server-side: on the server — always do BOTH','Client-side validation is for UX — immediate feedback without a round trip. Server-side is for security — users can bypass client-side validation with browser tools. ALWAYS validate on the server too.'),
(9,'What does the novalidate attribute on a <form> do?','["Makes all fields optional","Disables browser HTML5 built-in validation — useful for custom JavaScript validation","Makes the form submit faster","Hides error messages"]','Disables browser HTML5 built-in validation — useful for custom JavaScript validation','<form novalidate> prevents the browser from showing its own validation popups (for required, type="email" etc.). Add it when you want full control over validation UI with JavaScript — your own error messages and styling.'),
(10,'How do you show an error message accessibly when a field is invalid?','["Just change the border colour to red","Set the error message in a visible element + aria-describedby on input + aria-invalid=true + role=alert if urgent","Use an alert() popup","Change the label colour"]','Set the error message in a visible element + aria-describedby on input + aria-invalid=true + role=alert if urgent','Full accessible pattern: 1) Show error text in a visible element. 2) input aria-describedby="error-id" links input to error. 3) aria-invalid="true" signals error state. 4) role="alert" on error div announces it immediately to screen readers.')
) AS d(i,q,o,a,e) WHERE q.slug='dev-q10';


-- Q11-Q25: Core JavaScript topics
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q11: Loops
('dev-q11',1,'Which loop is best for iterating an array when you need each value (not the index)?','["for (let i=0; i<arr.length; i++)","for...of","for...in","while"]','for...of','for (const item of arr) is the cleanest for iterating values. for...in iterates keys (indices as strings for arrays — avoid). Use indexed for when you need the index or non-standard stepping.'),
('dev-q11',2,'What does break do inside a loop?','["Breaks the current iteration and skips to the next","Exits the loop entirely","Pauses the loop","Restarts the loop from the beginning"]','Exits the loop entirely','break immediately exits the entire loop. continue skips the current iteration and moves to the next. Both work in for, while, and for...of loops.'),
('dev-q11',3,'What does a while loop do?','["Runs exactly once","Runs code a fixed number of times","Runs code as long as the condition is truthy — potentially infinite","Runs until a break is encountered"]','Runs code as long as the condition is truthy — potentially infinite','while (condition) { } checks the condition before each iteration. If the condition never becomes false and there is no break, the loop runs forever — an infinite loop. Always ensure the condition can become false.'),
('dev-q11',4,'What is a potential danger with while loops?','["They are slower than for loops","They can create infinite loops if the condition never becomes false","They only work with booleans","They cannot use break"]','They can create infinite loops if the condition never becomes false','while (true) { } runs forever without a break. A while loop where the condition variable never changes will also run forever, freezing the browser tab. Always verify your exit condition is reachable.'),
('dev-q11',5,'What does for...in iterate?','["Array values","Object values","Object keys (and array indices as strings)","Only inherited properties"]','Object keys (and array indices as strings)','for (const key in obj) iterates over enumerable property keys — the string names of properties. For arrays, it gives "0", "1", "2" as strings. Use for...of or forEach for array values.'),
('dev-q11',6,'What does continue do inside a loop?','["Continues running after the loop","Exits the loop","Skips the rest of the current iteration and starts the next one","Restarts the loop"]','Skips the rest of the current iteration and starts the next one','continue skips to the next iteration without executing any remaining code in the current iteration. Useful for skipping invalid items: for (const item of items) { if (!item.valid) continue; process(item); }'),
('dev-q11',7,'How do you loop 5 times with a for loop?','["for (let i = 1; i < 5; i++)","for (let i = 0; i < 5; i++)","for (let i = 0; i <= 5; i++)","for (let i = 1; i <= 5; i++)"]','for (let i = 0; i < 5; i++)','i starts at 0, runs while i < 5, increments after each run: i = 0,1,2,3,4 — 5 total iterations. for (let i = 1; i <= 5; i++) also loops 5 times with i = 1,2,3,4,5.'),
('dev-q11',8,'When should you use a for loop instead of array methods like forEach or map?','["for loops are always better","When you need early exit (break) with a condition, non-standard stepping, or need to modify multiple arrays simultaneously","Array methods are always better","When the array is longer than 100 items"]','When you need early exit (break) with a condition, non-standard stepping, or need to modify multiple arrays simultaneously','Array methods (forEach, map, filter) are cleaner for standard operations. Use for when you need break (forEach can''t break early), need to loop with step-2 increments, or iterate multiple arrays in sync.'),
('dev-q11',9,'What does a do...while loop guarantee?','["The loop runs at least twice","The loop runs at least once — the condition is checked AFTER the first iteration","The loop runs exactly once","The loop never runs if the condition is false initially"]','The loop runs at least once — the condition is checked AFTER the first iteration','do { code } while (condition) always runs the code block once before checking the condition. Use for input validation where you always need at least one attempt: do { input = prompt(); } while (!isValid(input))'),
('dev-q11',10,'What is an off-by-one error?','["An array with one extra element","A loop that runs one too many or too few times due to incorrect boundary conditions","A comparison using 1 instead of 0","A floating point rounding error of exactly 1"]','A loop that runs one too many or too few times due to incorrect boundary conditions','Off-by-one errors are among the most common bugs: for (let i = 0; i <= arr.length; i++) reads arr[arr.length] which is undefined. for (let i = 1; i < arr.length; i++) skips the first element.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;

INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q12: String Methods
('dev-q12',1,'What does string.trim() do?','["Removes letters from both ends","Removes whitespace from both ends of the string","Trims the string to a maximum length","Makes the string lowercase"]','Removes whitespace from both ends of the string','"  hello  ".trim() → "hello". trimStart() removes from the left only; trimEnd() removes from the right only. Critical for cleaning user input: always trim() before processing form data.'),
('dev-q12',2,'What does string.slice(2, 5) return?','["Characters at indices 2 and 5","Characters from index 2 to index 4 (end is exclusive)","Characters from index 5 to index 2 (reversed)","The string starting at index 5"]','Characters from index 2 to index 4 (end is exclusive)','"Hello".slice(2, 5) → "llo". slice(start, end) — end is exclusive (not included). slice(2) takes from index 2 to end. slice(-3) takes the last 3 characters. Works like Python slicing.'),
('dev-q12',3,'What does string.split(",") do?','["Divides the string into lines at commas","Returns an array of substrings separated at each comma","Counts the commas","Replaces commas with spaces"]','Returns an array of substrings separated at each comma','"apple,banana,cherry".split(",") → ["apple","banana","cherry"]. The separator string/regex is removed. split("") splits into individual characters. split() with no argument wraps in single-element array.'),
('dev-q12',4,'How do you replace ALL occurrences of a substring?','["str.replace(\"old\", \"new\") — replaces all","str.replaceAll(\"old\", \"new\") or str.replace(/old/g, \"new\")","str.replace(\"old\", \"new\", true)","str.replaceEvery(\"old\", \"new\")"]','str.replaceAll("old", "new") or str.replace(/old/g, "new")','str.replace("old", "new") replaces only the FIRST occurrence. replaceAll() (ES2021) replaces all. Or use regex with the g (global) flag: str.replace(/old/g, "new").'),
('dev-q12',5,'What does string.includes("world") return?','["The index of \"world\"","The number of times \"world\" appears","true or false — whether the string contains \"world\"","\"world\" extracted from the string"]','true or false — whether the string contains "world",'"Hello, World!".includes("World") → true. Case-sensitive! "world" → false. Use startsWith() to check the beginning, endsWith() for the end, indexOf() to get the position.'),
('dev-q12',6,'How do you check if a string starts with "https"?','["str.beginsWith(\"https\")","str.startsWith(\"https\")","str.indexOf(\"https\") === 0","str.match(\"^https\")"]','str.startsWith("https")','str.startsWith(prefix) returns true/false. It can also accept a start position: str.startsWith(":", 5) checks starting from index 5. Equivalent to str.slice(0, 5) === "https" but cleaner.'),
('dev-q12',7,'What does the /g flag do in a regular expression?','["Makes the pattern case-insensitive","Applies the pattern globally — matches all occurrences, not just the first","Makes the pattern multiline","Groups the pattern"]','Applies the pattern globally — matches all occurrences, not just the first','/pattern/g with the g flag matches ALL occurrences. Without g, only the first match is processed. /i flag: case-insensitive. /m flag: multiline. /gi: global + case-insensitive.'),
('dev-q12',8,'What does "abc".padStart(5, "0") return?','["\"abc00\"","\"00abc\"","\"0abc0\"","Error — strings cannot be padded"]','"00abc"','padStart(targetLength, padString) pads from the START (left) until the string reaches the target length. "abc".padStart(5, "0") → "00abc". padEnd pads from the right. Used for formatting numbers: "5".padStart(3, "0") → "005".'),
('dev-q12',9,'What does "ha".repeat(3) return?','["\"ha3\"","\"hahaha\"","[\"ha\",\"ha\",\"ha\"]","Error"]','"hahaha"','str.repeat(n) creates a new string with the original repeated n times. "ha".repeat(3) → "hahaha". Useful for creating test data or decorative text.'),
('dev-q12',10,'What does str.at(-1) return?','["undefined","Error — negative indices not supported","The last character of the string","The string reversed"]','The last character of the string','at() accepts negative indices — at(-1) is the last character, at(-2) is second to last. Much cleaner than str[str.length - 1]. Supported in all modern browsers.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;

INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q13: Numbers and Math
('dev-q13',1,'What does Math.floor(4.9) return?','["5","4","4.9","Error"]','4','Math.floor() rounds DOWN to the nearest integer — "floors" the value. Math.ceil() rounds UP. Math.round() rounds to nearest (0.5 rounds up). Math.trunc() removes the decimal without rounding.'),
('dev-q13',2,'How do you get a random integer between 1 and 6 (like a dice roll)?','["Math.random() * 6","Math.floor(Math.random() * 6)","Math.floor(Math.random() * 6) + 1","Math.ceil(Math.random() * 6)"]','Math.floor(Math.random() * 6) + 1','Math.random() returns 0 to 0.999..., *6 gives 0 to 5.999..., floor gives 0-5, +1 gives 1-6. Math.ceil(Math.random() * 6) also works but excludes 0 and includes 6 differently.'),
('dev-q13',3,'Why is 0.1 + 0.2 not exactly 0.3 in JavaScript?','["JavaScript has a bug","IEEE 754 floating-point representation cannot precisely represent these decimals","JavaScript rounds numbers","0.1 and 0.2 are not valid numbers"]','IEEE 754 floating-point representation cannot precisely represent these decimals','0.1 + 0.2 = 0.30000000000000004. This is not a JavaScript bug — it''s a property of IEEE 754 binary floating-point math used by virtually all programming languages. Solution: round to needed precision or work in integer cents.'),
('dev-q13',4,'What does Number.isNaN(NaN) return vs isNaN("hello")?','["Both return true","Number.isNaN(NaN) = true; isNaN(\"hello\") = true BUT isNaN converts non-numbers first — Number.isNaN is stricter","Number.isNaN is always false","Both return false"]','Number.isNaN(NaN) = true; isNaN("hello") = true BUT isNaN converts non-numbers first — Number.isNaN is stricter','isNaN("hello") converts "hello" to NaN first, then checks — returns true. Number.isNaN("hello") returns false (it''s a string, not NaN). Use Number.isNaN() for precise NaN checking.'),
('dev-q13',5,'What does (1234567).toLocaleString() do?','["Returns the number as a string with locale formatting: \"1,234,567\"","Returns the length of the number","Converts to a local time zone","Returns the number in binary"]','Returns the number as a string with locale formatting: "1,234,567"','toLocaleString() formats numbers according to locale conventions. In English: commas for thousands. In French: spaces. With options: (9.99).toLocaleString("en-CA", {style:"currency", currency:"CAD"}) → "CA$9.99".'),
('dev-q13',6,'What does Math.max(1, 5, 3, 2) return?','["The array [1,5,3,2]","1 (minimum)","5 (maximum)","Error — Math.max takes only 2 arguments"]','5 (maximum)','Math.max() returns the largest of its arguments. Math.min() returns the smallest. For arrays: Math.max(...arr) using spread. Math.max() with no arguments returns -Infinity.'),
('dev-q13',7,'What does parseInt("42.9") return?','["42.9","42","43","Error"]','42','parseInt parses from the beginning, stops at the first non-integer character. "42.9" → 42 (stops at the decimal point). Unlike Number(), parseInt is lenient: parseInt("42abc") → 42.'),
('dev-q13',8,'What is the best way to work with money values in JavaScript?','["Use float numbers — they are precise enough","Work in the smallest unit (cents as integers) to avoid floating-point errors","Use strings for money values","Use the BigDecimal library"]','Work in the smallest unit (cents as integers) to avoid floating-point errors','Store $9.99 as 999 (cents). Calculate in cents: tax = Math.round(999 * 0.13). Display only when needed: (total/100).toFixed(2). Integer arithmetic is precise; floating-point has rounding errors.'),
('dev-q13',9,'What does Math.abs(-42) return?','["-42","42","42 or -42","Error"]','42','Math.abs() returns the absolute value — always non-negative. Math.abs(-42) = 42. Math.abs(42) = 42. Useful when you care about the magnitude but not the direction.'),
('dev-q13',10,'What does (3.14159).toFixed(2) return?','["3.14 as a number","\"3.14\" as a string","3.14159 rounded to 3.14","Error"]','"3.14" as a string','toFixed(n) returns a STRING with exactly n decimal places. (3.14159).toFixed(2) → "3.14". (3.1).toFixed(2) → "3.10". Convert back to number with Number() or the + prefix: +(3.14159).toFixed(2) → 3.14 (number).')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;

INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q14: Dates and Times
('dev-q14',1,'What does new Date() create?','["A string of today''s date","A Date object representing the current date and time","A timestamp in seconds","An ISO 8601 string"]','A Date object representing the current date and time','new Date() creates a Date object for right now. new Date("2024-11-15") creates a specific date. Date objects have methods for reading parts (getFullYear, getMonth) and arithmetic via .getTime() milliseconds.'),
('dev-q14',2,'What does getMonth() return for January?','["1","0","\"January\"","1 on all systems"]','0','JavaScript months are 0-indexed: January = 0, February = 1, ..., December = 11. This is one of JavaScript''s most notorious gotchas. getDate() returns the day of month (1-31). getDay() returns day of week (0=Sunday).'),
('dev-q14',3,'How do you get the current timestamp in milliseconds?','["new Date().getSeconds()","Date.now()","new Date().getTime() — both work","new Date().milliseconds"]','Date.now()','Date.now() returns milliseconds since January 1, 1970 (Unix epoch). new Date().getTime() returns the same. Date.now() is faster (no object creation). Use for timers: const elapsed = Date.now() - startTime.'),
('dev-q14',4,'What does Intl.DateTimeFormat enable?','["Validating date strings","Formatting dates according to locale and custom options — e.g., \"November 15, 2024\" or \"15/11/24\"","Creating Date objects from strings","Comparing dates"]','Formatting dates according to locale and custom options — e.g., "November 15, 2024" or "15/11/24"','new Intl.DateTimeFormat("en-CA", {year:"numeric", month:"long", day:"numeric"}).format(date) → "November 15, 2024". Handles all locale differences automatically — French, Arabic, Japanese date formats.'),
('dev-q14',5,'How do you calculate how many days between two dates?','["date2 - date1","(date2 - date1) / (1000 * 60 * 60 * 24) — convert milliseconds to days","date2.getDays() - date1.getDays()","date2.daysDiff(date1)"]','(date2 - date1) / (1000 * 60 * 60 * 24) — convert milliseconds to days','Subtracting two Date objects gives milliseconds. Divide by 1000 (→ seconds) × 60 (→ minutes) × 60 (→ hours) × 24 (→ days). Wrap in Math.round() or Math.floor() for whole days.'),
('dev-q14',6,'What does setInterval(fn, 1000) do?','["Calls fn once after 1 second","Calls fn every 1000 milliseconds (1 second) indefinitely","Sets the interval between two dates","Waits 1 second then stops"]','Calls fn every 1000 milliseconds (1 second) indefinitely','setInterval calls the function repeatedly at the specified interval. clearInterval(id) stops it. Use for clocks, countdowns, animations. Store the return value to clear it later: const id = setInterval(fn, 1000).'),
('dev-q14',7,'What does setTimeout(fn, 0) do?','["Runs fn synchronously","Runs fn immediately after the current call stack is empty — even 0ms is deferred to the next event loop tick","Never runs","Errors — 0 is not valid"]','Runs fn immediately after the current call stack is empty — even 0ms is deferred to the next event loop tick','setTimeout with 0ms defers the callback to the next event loop cycle. The current synchronous code finishes first. Used for UI updates that need to happen after the current render.'),
('dev-q14',8,'What does Intl.RelativeTimeFormat produce?','["A countdown timer","Relative date strings like \"2 days ago\" or \"in 3 hours\"","The difference between two dates in seconds","A date picker interface"]','Relative date strings like "2 days ago" or "in 3 hours"','new Intl.RelativeTimeFormat("en", {numeric: "auto"}).format(-2, "day") → "2 days ago". format(-1, "day") → "yesterday" (with numeric: "auto"). Handles plural forms and locale differences automatically.'),
('dev-q14',9,'What year does Unix timestamp 0 represent?','["Year 0","January 1, 1970","January 1, 2000","January 1, 1900"]','January 1, 1970','Unix time (also JavaScript''s Date epoch) counts milliseconds from January 1, 1970 00:00:00 UTC. new Date(0) is that moment. Date.now() returns current milliseconds since then.'),
('dev-q14',10,'How should you store dates in a database or API?','["As formatted strings like \"November 15, 2024\"","As ISO 8601 strings: \"2024-11-15T14:30:00Z\" — unambiguous and universally parseable","As Unix timestamps only","As day/month/year numbers separately"]','As ISO 8601 strings: "2024-11-15T14:30:00Z" — unambiguous and universally parseable','ISO 8601 (date.toISOString()) is the standard for data exchange. It''s unambiguous (unlike "11/15/24" which means different things in different countries), universally parseable, and sorts correctly as a string.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;

INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q15: localStorage
('dev-q15',1,'What types of values can localStorage store?','["Numbers, strings, booleans, and objects","Only strings — everything else must be serialised","Any JavaScript value","Only strings and numbers"]','Only strings — everything else must be serialised','localStorage.setItem("key", value) converts value to a string. Objects become "[object Object]". Always JSON.stringify() objects and arrays before storing, and JSON.parse() when retrieving.'),
('dev-q15',2,'What does localStorage.getItem("missing") return?','["undefined","Error","null","0"]','null','getItem returns null (not undefined) when the key doesn''t exist. Check: const val = localStorage.getItem("key"); if (val !== null) { parse(val); }'),
('dev-q15',3,'How do you save an array to localStorage?','["localStorage.setItem(\"arr\", [1,2,3])","localStorage.setItem(\"arr\", JSON.stringify([1,2,3]))","localStorage.saveArray(\"arr\", [1,2,3])","Arrays cannot be stored in localStorage"]','localStorage.setItem("arr", JSON.stringify([1,2,3]))','JSON.stringify converts [1,2,3] to "[1,2,3]" (a string). Retrieve with: JSON.parse(localStorage.getItem("arr")) → [1,2,3] (actual array). Always stringify on save, parse on load.'),
('dev-q15',4,'What is the difference between localStorage and sessionStorage?','["localStorage is larger","localStorage persists across browser sessions; sessionStorage clears when the tab is closed","sessionStorage is encrypted; localStorage is not","They are identical"]','localStorage persists across browser sessions; sessionStorage clears when the tab is closed','localStorage survives closing and reopening the browser. sessionStorage only lives for the current tab session — when the tab closes, data is gone. Same API for both.'),
('dev-q15',5,'What does localStorage.clear() do?','["Clears all localStorage for all websites","Clears all localStorage for the current origin (domain)","Clears one key","Resets values to defaults"]','Clears all localStorage for the current origin (domain)','clear() removes ALL keys from localStorage for the current origin. Use removeItem("key") to delete a specific key. localStorage is scoped to origin (protocol + domain + port) — other websites cannot access your keys.'),
('dev-q15',6,'Why should you wrap JSON.parse in a try/catch?','["It''s required by the spec","Malformed JSON strings throw a SyntaxError","For performance","parse can return null which crashes"]','Malformed JSON strings throw a SyntaxError','If localStorage contains a corrupted or non-JSON string (e.g., from a bug or manual edit), JSON.parse throws SyntaxError. Always: try { return JSON.parse(str); } catch { return defaultValue; }'),
('dev-q15',7,'What is the approximate storage limit of localStorage?','["100KB","5-10MB per origin","Unlimited","1MB"]','5-10MB per origin','localStorage typically allows 5-10MB per origin. Exceeding this throws a QuotaExceededError. For larger data needs: IndexedDB (hundreds of MB), or a server database.'),
('dev-q15',8,'What does localStorage.length return?','["The size in bytes","The number of keys stored","The maximum storage","The number of items in the most recent setItem call"]','The number of keys stored','localStorage.length gives the count of stored keys. Access key names with localStorage.key(i) where i is 0 to length-1. But for iteration, it''s easier to use Object.keys(localStorage) or just remember your key names.'),
('dev-q15',9,'What is the security concern with localStorage?','["It can be accessed by any script running on the same origin — including malicious scripts injected via XSS","Other websites can read your localStorage","It is sent to the server automatically","The browser can delete it without warning"]','It can be accessed by any script running on the same origin — including malicious scripts injected via XSS','Any JavaScript on your page can read all localStorage. If your app has an XSS vulnerability, attackers can steal all localStorage data. Never store sensitive data (passwords, tokens for critical systems) in localStorage.'),
('dev-q15',10,'localStorage is synchronous — what does this mean practically?','["Data saves instantly","Reading/writing blocks the main thread — for large data, use IndexedDB (async) instead","Data is synced with a server","Each operation requires a network request"]','Reading/writing blocks the main thread — for large data, use IndexedDB (async) instead','localStorage operations block the main thread — they complete before the next line runs. For small data this is fine. For large data or frequent access, use IndexedDB which has an async API and won''t freeze the UI.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;


-- Q16-Q25: Fetch, APIs, JSON, Architecture, Debugging, Classes, Modules, Error Handling, HOF, Event Loop
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q16: Fetch and Promises
('dev-q16',1,'What does fetch() return?','["The response data directly","A Promise that resolves to a Response object","A URL object","An XMLHttpRequest"]','A Promise that resolves to a Response object','fetch(url) returns a Promise. When resolved, it gives a Response object — not the data yet. You must call .json() or .text() on the Response to get the data (which is itself another Promise).'),
('dev-q16',2,'Why should you check response.ok after fetch?','["fetch always succeeds","fetch only rejects on network failure — a 404 or 500 response still resolves the Promise with ok:false","response.ok tells you the data format","For security"]','fetch only rejects on network failure — a 404 or 500 response still resolves the Promise with ok:false','fetch() only rejects for network errors (no connection, DNS failure). A 404 "Not Found" or 500 "Server Error" still resolves — but response.ok is false and response.status is the error code. Always check response.ok!'),
('dev-q16',3,'What is async/await?','["A new type of function","Syntax sugar over Promises — makes async code look synchronous and easier to read","A way to run code in parallel","A replacement for fetch"]','Syntax sugar over Promises — makes async code look synchronous and easier to read','async functions always return Promises. await pauses the function until a Promise resolves. This makes the code read top-to-bottom instead of with nested .then() chains. Under the hood, it''s still Promises.'),
('dev-q16',4,'What must an async function use to handle errors?','["if/else statements","A try/catch block","error event listeners","A .finally() chain"]','A try/catch block','With async/await, errors from awaited Promises are thrown. Wrap in try { const data = await fetch(url).then(r=>r.json()); } catch (error) { handleError(error); }. Without try/catch, errors become unhandled Promise rejections.'),
('dev-q16',5,'What does Promise.all([p1, p2, p3]) do?','["Runs the Promises one after another","Runs all Promises simultaneously and resolves when ALL succeed — or rejects if ANY fails","Picks the fastest Promise","Retries failed Promises"]','Runs all Promises simultaneously and resolves when ALL succeed — or rejects if ANY fails','Promise.all is great for parallel requests: const [users, posts] = await Promise.all([fetchUsers(), fetchPosts()]). If any promise rejects, Promise.all rejects immediately with that error.'),
('dev-q16',6,'What is a Promise?','["A guarantee that code will run","An object representing an eventual value — pending, fulfilled, or rejected","A callback function","A type of async loop"]','An object representing an eventual value — pending, fulfilled, or rejected','Promises have three states: pending (in progress), fulfilled (succeeded — has a value), rejected (failed — has an error). .then() handles fulfilled, .catch() handles rejected, .finally() always runs.'),
('dev-q16',7,'What HTTP method should you use to CREATE a new resource?','["GET","PUT","POST","DELETE"]','POST','HTTP methods: GET (retrieve), POST (create new), PUT (replace entire resource), PATCH (partially update), DELETE (remove). POST with a request body containing the new data is the standard for creation.'),
('dev-q16',8,'What Content-Type header must you set when sending JSON in a fetch request?','["text/json","application/json","json/plain","multipart/json"]','application/json','fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)}). The Content-Type header tells the server what format the body is in.'),
('dev-q16',9,'What does await do in an async function?','["Makes the function wait forever","Pauses the function until the Promise resolves — other code can still run during the wait","Forces synchronous execution","Creates a new thread"]','Pauses the function until the Promise resolves — other code can still run during the wait','await pauses the CURRENT async function, but other JavaScript can run during that time (event handlers, other async functions). The event loop is not blocked — JavaScript is still single-threaded but non-blocking.'),
('dev-q16',10,'What does response.json() do?','["Converts the response to a JSON string","Parses the response body as JSON and returns a Promise resolving to the parsed value","Sends JSON to the server","Checks if the response is JSON"]','Parses the response body as JSON and returns a Promise resolving to the parsed value','response.json() reads the response body as a stream and parses it as JSON. It returns a Promise because streaming the body is also async. const data = await response.json() gives the actual JavaScript object/array.'),
-- Q17: APIs
('dev-q17',1,'What is a REST API?','["A JavaScript framework","A set of architectural conventions for web APIs using HTTP methods and URLs to represent resources","A database type","A security protocol"]','A set of architectural conventions for web APIs using HTTP methods and URLs to represent resources','REST (Representational State Transfer) uses HTTP: GET /users (list), GET /users/1 (get one), POST /users (create), PUT /users/1 (update), DELETE /users/1 (delete). Resources are nouns, HTTP methods are verbs.'),
('dev-q17',2,'What is an API key?','["A keyboard shortcut","A unique identifier that authenticates your application to an API service","A type of encryption","A JSON property"]','A unique identifier that authenticates your application to an API service','API keys identify who is making requests. They control access and allow rate limiting. Never expose API keys in client-side JavaScript that others can see (use environment variables server-side). Some free APIs don''t require keys.'),
('dev-q17',3,'What does encodeURIComponent() do?','["Decodes a URL","Encodes a string for safe use in a URL — escapes special characters like spaces, &, =","Encodes an entire URL","Validates a URL"]','Encodes a string for safe use in a URL — escapes special characters like spaces, &, =','encodeURIComponent("Hello World") → "Hello%20World". Spaces, &, =, ?, # must be encoded in URL query parameters. URLSearchParams handles this automatically — use it for building query strings.'),
('dev-q17',4,'What is debouncing in the context of search inputs?','["Removing duplicate search results","Delaying the search request until the user pauses typing — prevents too many API calls","Caching search results","Validating search terms before sending"]','Delaying the search request until the user pauses typing — prevents too many API calls','Debouncing: clearTimeout(timer); timer = setTimeout(() => searchAPI(value), 400). Without debouncing, every keystroke triggers an API call. With 400ms debounce, the API is called only when the user pauses for 400ms.'),
('dev-q17',5,'What does a 404 HTTP status code mean?','["Server error","The request was malformed","Resource not found","Authentication required"]','Resource not found','HTTP status codes: 200 (OK), 201 (Created), 400 (Bad Request), 401 (Unauthorized), 403 (Forbidden), 404 (Not Found), 500 (Internal Server Error). Check response.status or response.ok in your fetch error handling.'),
('dev-q17',6,'What is URLSearchParams used for?','["Validating URLs","Building and parsing URL query strings safely — handles encoding automatically","Storing API responses","Navigating between pages"]','Building and parsing URL query strings safely — handles encoding automatically','const params = new URLSearchParams({q: "JavaScript", page: 1}); params.toString() → "q=JavaScript&page=1". It handles special character encoding automatically. Use with fetch: fetch(`/api/search?${params}`)'),
('dev-q17',7,'What does CORS stand for and why does it matter?','["Cross-Origin Resource Sharing — browser security policy that restricts API calls from different domains","Content Origin Reference System","Chrome OS React Support","Cross-Origin Redirect System"]','Cross-Origin Resource Sharing — browser security policy that restricts API calls from different domains','CORS prevents malicious sites from making requests to other sites using your credentials. The SERVER must send CORS headers allowing your domain. If you get a CORS error, you cannot fix it client-side — the API must allow your origin.'),
('dev-q17',8,'What is rate limiting?','["Limiting page scroll speed","APIs restricting how many requests you can make in a period (e.g., 100 requests/hour)","Limiting the size of API responses","Restricting API access to paid users only"]','APIs restricting how many requests you can make in a period (e.g., 100 requests/hour)','Rate limits prevent API abuse and ensure fair usage. GitHub API: 60 unauthenticated requests/hour. When exceeded, you get a 429 Too Many Requests response. Debouncing and caching responses helps stay within limits.'),
('dev-q17',9,'What is the purpose of a loading state when fetching data?','["Required by HTTP spec","Shows users something is happening — prevents them from thinking the page is broken while waiting for data","Makes fetch faster","Required for async code to work"]','Shows users something is happening — prevents them from thinking the page is broken while waiting for data','Without a loading state, users see a blank/empty UI while data fetches (200ms to several seconds). Show a spinner or skeleton screen while loading, then replace with data. Always handle: loading, success, and error states.'),
('dev-q17',10,'What is a JSON API compared to a GraphQL API?','["JSON API uses JavaScript; GraphQL uses Python","JSON/REST APIs return fixed data structures; GraphQL lets clients request exactly the fields they need","GraphQL is just a type of REST API","They are identical"]','JSON/REST APIs return fixed data structures; GraphQL lets clients request exactly the fields they need','REST APIs return the full resource — you get all fields even if you only need 2. GraphQL lets clients specify exactly which fields they want in a query, reducing data transfer. Both use HTTP and return JSON.'),
-- Q18: JSON
('dev-q18',1,'What is the difference between JSON and a JavaScript object?','["They are identical","JSON is a text string format with strict syntax (quoted keys, no functions); JavaScript objects are in-memory data structures","JSON is faster","JavaScript objects use single quotes; JSON uses double quotes"]','JSON is a text string format with strict syntax (quoted keys, no functions); JavaScript objects are in-memory data structures','JSON is a text format: {\"name\":\"Alex\"}. A JS object is: {name: "Alex"} (unquoted keys, single quotes allowed). JSON cannot contain functions, undefined, or Date objects. JSON.stringify converts JS → JSON; JSON.parse converts JSON → JS.'),
('dev-q18',2,'What JSON.stringify(obj, null, 2) produces vs JSON.stringify(obj)?','["Both produce identical output","null,2 adds 2-space pretty-printing with newlines; no args produces compact single-line JSON","null skips null values; 2 limits to 2 properties","null,2 produces YAML instead of JSON"]','null,2 adds 2-space pretty-printing with newlines; no args produces compact single-line JSON','JSON.stringify(obj) → "{\"name\":\"Alex\"}" (compact). JSON.stringify(obj, null, 2) → formatted with newlines and 2-space indentation. The second argument is a replacer (null=all), the third is indent spaces.'),
('dev-q18',3,'What happens if you JSON.parse an invalid JSON string?','["Returns null","Returns undefined","Throws a SyntaxError","Returns the string unchanged"]','Throws a SyntaxError','JSON.parse("not valid json") throws SyntaxError: Unexpected token. Always wrap JSON.parse in try/catch when parsing external or stored data that might be corrupted: try { return JSON.parse(str); } catch { return defaultValue; }'),
('dev-q18',4,'What does JSON not support that JavaScript objects support?','["Arrays","Numbers","Functions, undefined, Date objects, and Symbol","Null values"]','Functions, undefined, Date objects, and Symbol','JSON is a data format — it can represent: objects, arrays, strings, numbers, booleans, null. Dates become strings (ISO format). Functions, undefined, and Symbol are silently omitted. JSON.stringify(undefined) → undefined (not the string "undefined").'),
('dev-q18',5,'How do you deep clone an object using JSON?','["JSON.clone(obj)","JSON.parse(JSON.stringify(obj))","Object.deepClone(obj)","structuredClone(obj) — but JSON version also works"]','JSON.parse(JSON.stringify(obj))','JSON.parse(JSON.stringify(obj)) serialises to a JSON string then parses back to a new object — a deep copy. Limitation: loses functions, Dates become strings, undefined properties are dropped. structuredClone() is the modern, better alternative.'),
('dev-q18',6,'What is the JSON key syntax rule?','["Keys can be unquoted or quoted","All keys must be double-quoted strings","Keys can use single quotes","Keys must be camelCase"]','All keys must be double-quoted strings','In JSON, every key must be wrapped in double quotes: {"name": "Alex"}. JavaScript objects allow: {name: "Alex"} (no quotes) or {''name'': ''Alex''} (single quotes). JSON is strict — this is a common source of "invalid JSON" errors.'),
('dev-q18',7,'What does the second argument of JSON.stringify do?','["Sets the indentation","Filters which properties to include — either an array of key names or a replacer function","Enables circular reference handling","Sets the output encoding"]','Filters which properties to include — either an array of key names or a replacer function','JSON.stringify(user, ["name", "email"]) only includes name and email. JSON.stringify(obj, (key, val) => key === "password" ? undefined : val) excludes password. Useful for serialising only safe/needed fields.'),
('dev-q18',8,'What format do Date objects become when JSON.stringify''d?','["A timestamp number","An ISO 8601 string: \"2024-11-15T14:30:00.000Z\"","Null","They are excluded"]','An ISO 8601 string: "2024-11-15T14:30:00.000Z"','new Date() gets stringified to its ISO format. But JSON.parse won''t restore it as a Date — it comes back as a string. You need to manually re-create: new Date(parsed.createdAt). This is a common JSON Date pitfall.'),
('dev-q18',9,'What is JSON Lines (JSONL)?','["Invalid JSON format","A format where each line is a separate valid JSON object — used for streaming and logs","JSON with line numbers","JSON with comments enabled"]','A format where each line is a separate valid JSON object — used for streaming and logs','JSONL has one JSON object per line: {"user":"Alex"}\n{"user":"Sam"}. Useful for logs (append one line per event) and streaming (process one line at a time without loading entire file).'),
('dev-q18',10,'What does response.json() actually do under the hood?','["Just parses a string","Reads the response body as a text stream, then parses it as JSON","Converts JavaScript to JSON","Sends a JSON request"]','Reads the response body as a text stream, then parses it as JSON','response.json() is shorthand for response.text().then(text => JSON.parse(text)). Reading the body from a network stream is inherently async — that''s why response.json() returns a Promise that must be awaited.'),
-- Q19: App Architecture
('dev-q19',1,'What is separation of concerns?','["Having one large JS file","Dividing code into distinct sections each handling one responsibility: data, logic, UI, events","Using separate folders for CSS and JS","Having one function per file"]','Dividing code into distinct sections each handling one responsibility: data, logic, UI, events','Good architecture separates: data (what the app stores), state (current app status), logic (how data is processed), UI (how it''s displayed), events (how it responds to user actions). Each concern is easier to modify, test, and understand.'),
('dev-q19',2,'What is application state?','["The US state where the server is located","All the data your app needs to render and function at any given moment","The loading spinner","The JavaScript version being used"]','All the data your app needs to render and function at any given moment','State includes: current user, loaded data, UI state (is modal open?), form values, etc. When state changes, the UI re-renders to reflect it. Keeping all state in one object makes it easy to inspect and debug.'),
('dev-q19',3,'What is a "pure" rendering function?','["A function that only uses pure CSS","A function that reads from state and updates the DOM — with no side effects or state modification","A function with no parameters","A function that only creates div elements"]','A function that reads from state and updates the DOM — with no side effects or state modification','renderTodos(todos) should ONLY update the DOM based on its input — it shouldn''t also delete items, make API calls, or modify state. Pure renderers are predictable: same state always produces same UI.'),
('dev-q19',4,'Why is storing all mutable data in one state object beneficial?','["It uses less memory","You can inspect the entire app state at once, easily log it, and reason about what the UI should look like","State objects are faster to access","Required by JavaScript"]','You can inspect the entire app state at once, easily log it, and reason about what the UI should look like','console.log(state) shows everything. You can "time travel" by saving and restoring state snapshots. You can pass state to render functions and get a predictable UI. This pattern is the basis of React, Redux, and most modern frameworks.'),
('dev-q19',5,'What is event delegation and why is it used in app architecture?','["A design pattern where components delegate tasks","Adding ONE listener to a parent instead of many listeners to children — more efficient and works for dynamic elements","Separating event code into its own file","Using async events"]','Adding ONE listener to a parent instead of many listeners to children — more efficient and works for dynamic elements','In a todo app, adding a listener to each todo item means re-adding listeners every time the list re-renders. One listener on the parent catches all clicks regardless of when items were created.'),
('dev-q19',6,'What does MVC stand for and what does each part do?','["Multi-View Controller","Model-View-Controller: Model (data), View (UI), Controller (connects them — handles events and updates)","Module-Variable-Class","Multi-Value Component"]','Model-View-Controller: Model (data), View (UI), Controller (connects them — handles events and updates)','MVC is a classic software pattern. Model = the data and business logic. View = the UI templates/rendering. Controller = event handlers that update the model then trigger view re-render. JavaScript frameworks like Angular use MVC explicitly.'),
('dev-q19',7,'What is a "single source of truth" in app state?','["One HTML file","All application data living in one centralised state object — not scattered across different variables","One CSS file","One API endpoint"]','All application data living in one centralised state object — not scattered across different variables','When state is scattered (let user = ...; let score = ...; let isLoggedIn = ...), it''s easy for them to get out of sync. One state object (const state = {user, score, isLoggedIn}) is the single source of truth — the UI derives from it.'),
('dev-q19',8,'What is the benefit of writing pure logic functions separated from UI code?','["They load faster","Pure logic functions can be tested without needing a browser — calculateGrade(85) can be tested with just JavaScript","They use less memory","Required by ES6"]','Pure logic functions can be tested without needing a browser — calculateGrade(85) can be tested with just JavaScript','calculateGrade(85) → "B" can be verified without DOM, events, or browser. UI code (DOM manipulation) is harder to test. Separating logic from UI enables unit testing and makes both parts independently changeable.'),
('dev-q19',9,'What is the difference between imperative and declarative UI code?','["Imperative is faster","Imperative: tells the browser HOW to update step by step; declarative: describes WHAT the UI should look like and lets the framework figure out HOW","Declarative uses HTML; imperative uses JavaScript","They produce different visual results"]','Imperative: tells the browser HOW to update step by step; declarative: describes WHAT the UI should look like and lets the framework figure out HOW','Imperative: create element, set text, add class, append to parent. Declarative: container.innerHTML = `<li class="${todo.complete ? ''done'' : '''}''>${todo.text}</li>`. React is declarative — you describe the desired UI, React handles updates.'),
('dev-q19',10,'What is module bundling (like webpack or Vite)?','["Wrapping code in if statements","Combining many module files into fewer optimised files for production deployment","Bundling HTML and CSS together","Converting TypeScript to JavaScript"]','Combining many module files into fewer optimised files for production deployment','In development, you might have 20 JS files. Bundlers (webpack, Vite, esbuild) combine them into 1-3 optimised files: minified, tree-shaken (unused code removed), and chunked for efficient loading. Essential for production performance.'),
-- Q20: Debugging
('dev-q20',1,'What does a TypeError usually mean?','["A typo in the code","An operation was performed on a value of the wrong type (e.g., calling a method on null)","The file has too many errors","A network request failed"]','An operation was performed on a value of the wrong type (e.g., calling a method on null)','TypeError: Cannot read properties of null (reading ''value'') means you''re trying to access a property of null. Usually: element not found (querySelector returned null) or data not loaded yet.'),
('dev-q20',2,'What information does a stack trace provide?','["The network requests made","The sequence of function calls that led to the error — where it was thrown and what called it","The CSS being applied","All variables in scope"]','The sequence of function calls that led to the error — where it was thrown and what called it','The stack trace shows: which function threw the error, which function called that, which called that — going back to the origin. Read from top (where it broke) to find the relevant line in YOUR code.'),
('dev-q20',3,'What does the debugger statement do?','["Launches the debugger app","Pauses JavaScript execution at that point when DevTools is open — equivalent to a breakpoint","Logs the current state","Throws an error for debugging"]','Pauses JavaScript execution at that point when DevTools is open — equivalent to a breakpoint','Adding debugger; to code pauses execution when DevTools is open. You can then inspect variables in scope, step through code, and use the console in the current scope. Equivalent to clicking a line number in DevTools Sources.'),
('dev-q20',4,'What is "rubber duck debugging"?','["Testing with rubber (flexible) code","Explaining your code problem aloud step-by-step (to a rubber duck or anyone) — the explanation process often reveals the bug","Using randomised test data","A duck-typed debugging approach"]','Explaining your code problem aloud step-by-step (to a rubber duck or anyone) — the explanation process often reveals the bug','Articulating a problem clearly often reveals the solution. When you explain step by step what the code SHOULD do vs what it DOES, inconsistencies become obvious. Many bugs are found during the explanation without the other person saying anything.'),
('dev-q20',5,'What does console.table() do?','["Creates an HTML table","Displays arrays of objects as a formatted table in the console — much more readable than console.log","Outputs data as a CSV","Creates a debug table"]','Displays arrays of objects as a formatted table in the console — much more readable than console.log','console.table([{name:"Alex",score:85},{name:"Sam",score:92}]) displays a nicely formatted table with columns. Much better than console.log for arrays of objects. Also works for plain objects.'),
('dev-q20',6,'When you see "Uncaught ReferenceError: x is not defined", what likely happened?','["x has a null value","x was used before it was declared, or there is a typo in the variable name","x is not a valid variable name","The file is missing"]','x was used before it was declared, or there is a typo in the variable name','ReferenceError: x is not defined means JavaScript cannot find a variable named x in the current scope. Check: typo in the name, wrong scope (accessing a variable outside where it was declared), or declared with var in a block.'),
('dev-q20',7,'How do you check what CSS is actually applied to an element?','["View the HTML source file","DevTools → right-click element → Inspect → Styles panel shows computed styles including overridden ones","Check the CSS file manually","Use alert() to show the style"]','DevTools → right-click element → Inspect → Styles panel shows computed styles including overridden ones','DevTools Styles panel shows all CSS rules applying to the element, crossed-out (overridden) rules, inherited styles, and the box model. The Computed tab shows final computed values for every property.'),
('dev-q20',8,'What does "async timing" bug mean?','["The code runs too slowly","Accessing data before an async operation (fetch, setTimeout) has completed — the variable is still undefined or empty","Using async without await","An event listener that fires too slowly"]','Accessing data before an async operation (fetch, setTimeout) has completed — the variable is still undefined or empty','let data; fetch(url).then(r=>r.json()).then(d=>{data=d}); console.log(data); // undefined! The fetch hasn''t completed when console.log runs. Fix: use async/await or put the console.log inside the .then().'),
('dev-q20',9,'What is "event listener stacking"?','["Having too many CSS events","Adding the same listener multiple times — usually inside a render function — so it fires multiple times per event","Using nested event listeners","Events that fire in the wrong order"]','Adding the same listener multiple times — usually inside a render function — so it fires multiple times per event','If addEventListeners are called inside renderTodos() and renderTodos() is called 5 times, each button has 5 listeners and triggers 5 actions per click. Fix: add listeners ONCE, outside rendering functions.'),
('dev-q20',10,'What is the systematic debugging process?','["Comment out all code and re-add it","Reproduce → Isolate → Hypothesise → Test → Fix → Verify","Ask someone else to fix it","Reload the page until it works"]','Reproduce → Isolate → Hypothesise → Test → Fix → Verify','1. Reproduce reliably 2. Isolate to smallest failing code 3. Form a hypothesis about the cause 4. Test the hypothesis 5. Fix the root cause (not just the symptom) 6. Verify fix works and nothing else broke.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;


-- Q21-Q30: Classes, Modules, Errors, HOF, Event Loop, DOM, Canvas, Node, npm, Express
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
('dev-q21',1,'What is the constructor method in a class?','["A method for destroying instances","A method that runs automatically when a new instance is created with new","The class''s main function","A static method"]','A method that runs automatically when a new instance is created with new','class Student { constructor(name) { this.name = name; } } — new Student("Alex") automatically calls constructor with "Alex". Set initial properties and run setup code here.'),
('dev-q21',2,'What does extends do?','["Extends the file length","Creates a subclass that inherits from a parent class","Adds properties to an existing object","Imports from another module"]','Creates a subclass that inherits from a parent class','class Teacher extends Person inherits all of Person''s methods and properties. Teacher can add new methods and override inherited ones. Teacher instances pass instanceof checks for both Teacher and Person.'),
('dev-q21',3,'What must super() do in a subclass constructor?','["Call the parent''s render method","Call the parent class''s constructor — must be called before using this","Super-size the instance","Validate the parent class"]','Call the parent class''s constructor — must be called before using this','In a subclass constructor, super() must be called before any reference to this. It initialises the parent class portion of the object. Not calling super() throws ReferenceError: Must call super constructor before accessing ''this''.'),
('dev-q21',4,'What is a private class field?','["A field only accessible in the constructor","A field prefixed with # only accessible within the class body","A field that is read-only","A static field"]','A field prefixed with # only accessible within the class body','class BankAccount { #balance = 0; } — #balance cannot be accessed outside the class. Attempting account.#balance from outside throws SyntaxError. This is true privacy, unlike convention-based _private properties.'),
('dev-q21',5,'What does a getter method do?','["Sets a property value","Provides computed read-only access to a value: get fullName() { return `${this.first} ${this.last}`; }","Validates property values","Returns the class prototype"]','Provides computed read-only access to a value: get fullName() { return `${this.first} ${this.last}`; }','Getters are accessed like properties (no parentheses): user.fullName — but execute a function. They compute values on demand. Pair with setters (set propertyName(val)) for controlled access.'),
('dev-q21',6,'What is a static method?','["A method that cannot be overridden","A method belonging to the class itself, not instances — called as ClassName.method()","A method that never changes state","A method inherited from Object"]','A method belonging to the class itself, not instances — called as ClassName.method()','static add(a, b) { return a+b } — called as MathHelper.add(3,4), not new MathHelper().add(3,4). Used for utility functions, factory methods, and configuration that belongs to the class concept not instances.'),
('dev-q21',7,'How does JavaScript implement classes under the hood?','["Classes are a separate object system","Classes are syntactic sugar over prototype-based inheritance","Classes use a hidden VM","Classes require a compiler"]','Classes are syntactic sugar over prototype-based inheritance','JavaScript classes (ES6) are syntactic sugar over the prototype system. Every function has a prototype object. class methods are added to the prototype. class extends sets up the prototype chain. The underlying mechanism hasn''t changed.'),
('dev-q21',8,'What does instanceof do?','["Checks if something is an instance of a string","Checks if an object was created by (or inherits from) a specific class","Counts how many instances exist","Creates a new instance"]','Checks if an object was created by (or inherits from) a specific class','teacher instanceof Teacher → true. teacher instanceof Person → true (Teacher extends Person). [] instanceof Array → true. {} instanceof Array → false. Useful for type-checking in try/catch: if (error instanceof NetworkError)'),
('dev-q21',9,'What is method chaining?','["Calling methods in separate statements","Returning this from methods so multiple methods can be called in sequence: obj.add(5).multiply(2).result()","Chaining array methods","Inheriting methods from parent classes"]','Returning this from methods so multiple methods can be called in sequence: obj.add(5).multiply(2).result()','If methods return this (the object), you can chain calls. The jQuery library made this popular: $(el).addClass("x").fadeIn().delay(500). Requires each method to return this.'),
('dev-q21',10,'What is the prototype chain?','["A list of all class instances","The inheritance mechanism — JavaScript looks up the prototype chain to find properties/methods not on the object itself","A CSS property inheritance system","The call stack for class methods"]','The inheritance mechanism — JavaScript looks up the prototype chain to find properties/methods not on the object itself','When you access obj.method, JavaScript: 1. Checks the object itself. 2. Checks obj.__proto__ (the class prototype). 3. Checks the parent class prototype. 4. Continues up to Object.prototype. 5. Returns undefined if not found anywhere.'),
-- Q22: Modules
('dev-q22',1,'What is the difference between a named export and a default export?','["Named exports are faster","Named exports: export function x(){} imported as {x}; Default export: export default fn imported with any name","Default exports are required; named are optional","They are identical"]','Named exports: export function x(){} imported as {x}; Default exports: export default fn imported with any name','Named: export { add, subtract }; import { add, subtract } from "./math.js". Default: export default class User {}; import User from "./user.js" (any name). One default per file; unlimited named exports.'),
('dev-q22',2,'What attribute must a script tag have to use ES6 modules?','["module=true","type=module","src=module","async=module"]','type="module"','<script type="module" src="app.js"> enables import/export. Module scripts: are deferred (run after HTML parses), are scoped (no global leakage), are in strict mode automatically, and can use top-level await.'),
('dev-q22',3,'How do you import a default export with a different name?','["import {User as U} from","import User as U from","import U from \"./user.js\" — any name works for defaults","You cannot rename default imports"]','import U from "./user.js" — any name works for defaults','Default exports have no canonical name — you choose the name at import: import User from "./user.js" or import MyUser from "./user.js". Both work. Named exports use the declared name: import {add} or import {add as sum}.'),
('dev-q22',4,'What does import * as Math from "./math.js" do?','["Imports only the Math functions","Creates a namespace object Math with all named exports as properties","Overrides the built-in Math object","Imports everything including default"]','Creates a namespace object Math with all named exports as properties','import * as MathUtils from "./math.js" → MathUtils.add(1,2), MathUtils.PI. Creates a namespace object with all named exports. Does NOT include the default export.'),
('dev-q22',5,'What is dynamic import?','["Importing JavaScript at page load","import() as a function — loads a module asynchronously on demand: const {fn} = await import(\"./module.js\")","Importing with variables","A deprecated import method"]','import() as a function — loads a module asynchronously on demand: const {fn} = await import("./module.js")','Dynamic import: const module = await import("./pdfGenerator.js") — loads the module only when needed. Great for code-splitting: only load heavy modules when the user actually needs them. Returns a Promise.'),
('dev-q22',6,'What is module scope?','["Variables in a module are global","Variables declared in a module are only accessible within that module — not in other files unless exported","Modules run in strict mode only","The folder where modules are stored"]','Variables declared in a module are only accessible within that module — not in other files unless exported','Each ES module has its own scope. Variables are not automatically global. You must explicitly export things you want to share. This prevents naming conflicts and makes dependencies explicit.'),
('dev-q22',7,'Why does organising code into modules improve maintainability?','["Modules compile faster","Each module has one clear responsibility — easier to find, change, and test code; prevents naming conflicts","Modules prevent bugs automatically","Browser cache modules separately"]','Each module has one clear responsibility — easier to find, change, and test code; prevents naming conflicts','With 100 functions in one file, finding the one to change is hard. With modules: data.js, api.js, ui.js, events.js — responsibilities are clear. Changes to one module don''t break unrelated code. Explicit imports show dependencies.'),
('dev-q22',8,'What is tree-shaking?','["Removing unused branches from DOM","Bundlers removing exported functions that are never imported — reducing bundle size","Deleting node_modules","A performance technique for recursive functions"]','Bundlers removing exported functions that are never imported — reducing bundle size','Modern bundlers (webpack, Vite) analyse imports and exclude code that is exported but never imported anywhere. This reduces the final bundle size. Only works with ES module syntax (import/export), not CommonJS (require).'),
('dev-q22',9,'What is circular dependency and why is it a problem?','["A loop in your code","Module A imports from Module B, which imports from Module A — can cause initialisation order issues","Using the same module twice","A recursive module"]','Module A imports from Module B, which imports from Module A — can cause initialisation order issues','Circular dependencies can work in ES modules but may cause one module to see another''s exports as undefined if the dependency isn''t fully evaluated when first imported. Resolve by extracting shared code to a third module.'),
('dev-q22',10,'What is the difference between ES modules and CommonJS?','["ES modules are newer and use import/export; CommonJS uses require()/module.exports — used in Node.js","ES modules only work in browsers; CommonJS only in Node","They are identical","CommonJS is deprecated"]','ES modules are newer and use import/export; CommonJS uses require()/module.exports — used in Node.js','Node.js historically used CommonJS: const {add} = require("./math"); module.exports = {add}. Modern Node.js supports ES modules with "type":"module" in package.json or .mjs extension. Browsers use ES modules.'),
-- Q23: Error Handling
('dev-q23',1,'What three blocks make up complete error handling?','["if/else/finally","try/catch/finally — try: risky code; catch: error handler; finally: always runs","try/catch/else","do/while/catch"]','try/catch/finally — try: risky code; catch: error handler; finally: always runs','try { /* risky */ } catch(error) { /* handle */ } finally { /* always runs */ }. finally runs whether or not an error occurred — used for cleanup (hide spinners, release locks). catch only runs when an error is thrown.'),
('dev-q23',2,'What does throw do?','["Throws the variable away","Raises an error — immediately exits the current function and searches up the call stack for a catch block","Logs an error message","Creates a new Error object"]','Raises an error — immediately exits the current function and searches up the call stack for a catch block','throw stops current execution. JavaScript searches up the call stack for a catch block. If none found, it becomes an unhandled error. throw new Error("message") is standard — throw "string" works but loses stack trace.'),
('dev-q23',3,'What is the advantage of custom error classes?','["They run faster","They allow instanceof checks to identify error types and add relevant properties like field name or status code","Required for production code","They prevent errors from occurring"]','They allow instanceof checks to identify error types and add relevant properties like field name or status code','class ValidationError extends Error { constructor(msg, field) {...} }. catch(e) { if (e instanceof ValidationError) handleValidation(e.field); else throw e; } — precise error handling by type.'),
('dev-q23',4,'What should you do with errors you cannot handle in a catch block?','["Ignore them","Log them and continue","Re-throw them so a higher-level handler can deal with them","Return null"]','Re-throw them so a higher-level handler can deal with them','catch(e) { if (e instanceof NetworkError) { showOfflineMessage(); } else { throw e; } } — if you can''t handle it, rethrow. Don''t swallow errors silently — that makes bugs impossible to find.'),
('dev-q23',5,'What are "guard clauses" in the context of error prevention?','["Catching errors in catch blocks","Early validation at the top of a function that throws or returns before invalid state can propagate","Security middleware","Rate limiters"]','Early validation at the top of a function that throws or returns before invalid state can propagate','function divide(a, b) { if (typeof a !== "number") throw new TypeError("a must be a number"); if (b === 0) throw new RangeError("Cannot divide by zero"); return a/b; } — validate inputs first.'),
('dev-q23',6,'What is optional chaining (?.) and how does it prevent errors?','["A shorthand for try/catch","Safely accesses properties — returns undefined instead of throwing TypeError if a value is null/undefined","An optional error handler","A conditional import"]','Safely accesses properties — returns undefined instead of throwing TypeError if a value is null/undefined','user?.address?.city — if user or address is null/undefined, returns undefined without throwing. Without it: user.address.city throws "Cannot read properties of null" if address is null. Essential for API responses.'),
('dev-q23',7,'What is the nullish coalescing operator''s role in defensive code?','["It creates null-safe variables","Provides a default value when something is null or undefined: value ?? defaultValue","It prevents undefined from existing","It converts errors to null"]','Provides a default value when something is null or undefined: value ?? defaultValue','const port = process.env.PORT ?? 3000 — uses 3000 if PORT is not set. Safer than || because it doesn''t trigger for 0 or "" which might be valid values.'),
('dev-q23',8,'What does unhandled Promise rejection mean?','["A Promise was cancelled","A Promise was rejected and no .catch() or try/catch handled the error — causes a warning or crash","A network request failed","An async function returned null"]','A Promise was rejected and no .catch() or try/catch handled the error — causes a warning or crash','Modern environments (Node.js, browsers) warn or terminate when Promises reject without handlers. Always: asyncFunction().catch(handleError) or wrap in try/catch if using await.'),
('dev-q23',9,'What error properties are available in a catch block?','["Only message","name (error type), message (description), stack (call trace), plus any custom properties","Only code","name and message only"]','name (error type), message (description), stack (call trace), plus any custom properties','All Error objects have: name (TypeError, RangeError, etc.), message (human-readable description), stack (the call stack trace). Custom errors can add more: error.statusCode, error.field, error.code.'),
('dev-q23',10,'When should you NOT use try/catch?','["Never — always use try/catch","For synchronous code that cannot throw","For code where errors are expected normal flow and should be handled with if/else instead","In Node.js applications"]','For code where errors are expected normal flow and should be handled with if/else instead','Don''t use try/catch for normal validation: if (!email.includes("@")) { showError(); } is cleaner than try { validateEmail(email); } catch(e) { showError(); }. Reserve try/catch for truly exceptional/unexpected failures.'),
-- Q24: Higher-Order Functions
('dev-q24',1,'What is a higher-order function?','["A function in a class","A function that takes other functions as arguments and/or returns a function","A function with more than 5 parameters","A function that runs in a higher-priority thread"]','A function that takes other functions as arguments and/or returns a function','Higher-order functions: map(fn), filter(fn), reduce(fn), setTimeout(fn, ms), addEventListener(type, fn). They enable composable, reusable code patterns. Functions are first-class values in JavaScript — they can be passed and returned.'),
('dev-q24',2,'What does function composition do?','["Composes a musical function","Chains functions so the output of one becomes the input of the next","Merges two functions into one","Calls functions in parallel"]','Chains functions so the output of one becomes the input of the next','compose(f, g)(x) = f(g(x)). pipe(g, f)(x) = f(g(x)) — left to right. Composition enables building complex transformations from simple pieces: const slugify = pipe(trim, toLowerCase, replaceSpaces).'),
('dev-q24',3,'What is currying?','["Adding spice to code","Transforming a function with multiple params into nested single-param functions: f(a)(b) instead of f(a,b)","A curry library for JavaScript","Asynchronous function calls"]','Transforming a function with multiple params into nested single-param functions: f(a)(b) instead of f(a,b)','const add = a => b => a + b; const add5 = add(5); add5(3) → 8. Currying enables partial application — fixing some arguments now and providing the rest later.'),
('dev-q24',4,'What does partial application mean?','["Running only part of a function","Fixing some arguments of a function now, creating a new function that takes the remaining arguments","Partially loading a module","Applying a function to part of an array"]','Fixing some arguments of a function now, creating a new function that takes the remaining arguments','const multiply = (a, b, c) => a*b*c; const double = a => multiply(a, 2, 1). Or use bind: const double = multiply.bind(null, 1, 2). Partial application creates specialised functions from general ones.'),
('dev-q24',5,'What is memoisation?','["Storing code in memory","Caching function results — when the same inputs are seen again, return the cached result instead of re-computing","A type of closure","Memorising array values"]','Caching function results — when the same inputs are seen again, return the cached result instead of re-computing','function memoize(fn) { const cache = new Map(); return (...args) => { const key = JSON.stringify(args); return cache.has(key) ? cache.get(key) : cache.set(key, fn(...args)).get(key); }; } — expensive pure functions benefit most.'),
('dev-q24',6,'What is a closure vs a higher-order function?','["They are the same","Closure: an inner function retaining access to outer scope. Higher-order function: a function taking/returning functions. Closures are often used to implement higher-order functions","Higher-order functions use closures; closures use higher-order functions","They are opposites"]','Closure: an inner function retaining access to outer scope. Higher-order function: a function taking/returning functions. Closures are often used to implement higher-order functions','makeCounter() is a higher-order function (returns a function). The returned counter function is a closure (accesses count from outer scope). HOFs often use closures to "remember" configuration.'),
('dev-q24',7,'What does Array.prototype.reduce do that map and filter cannot?','["Runs faster","Can produce any type of output — not just arrays. It can make objects, numbers, strings, or nested structures","Modifies the original array","Reduces the array length"]','Can produce any type of output — not just arrays. It can make objects, numbers, strings, or nested structures','map always produces an array of same length. filter always produces a (possibly shorter) array. reduce can produce anything: a sum, a grouped object, a flat array from nested arrays, a frequency map.'),
('dev-q24',8,'What is "point-free" programming style?','["Writing functions without function keyword","Defining functions by composing other functions without explicitly mentioning arguments","Avoiding semicolons","Using only arrow functions"]','Defining functions by composing other functions without explicitly mentioning arguments','const getNames = users => users.map(u => u.name) (point-ful — mentions u). const getName = u => u.name; const getNames = users => users.map(getName) (less point-ful). const getNames = pipe(map(getName)) would be point-free. Emphasises transformation composition.'),
('dev-q24',9,'How does Array.prototype.flatMap differ from map then flat?','["flatMap is just a shorthand — they are identical in all cases","flatMap maps then flattens 1 level — it''s more efficient and allows controlled flattening","flatMap flattens all levels; map.flat() flattens 1 level","flatMap cannot return arrays"]','flatMap maps then flattens 1 level — it''s more efficient and allows controlled flattening','arr.flatMap(fn) is like arr.map(fn).flat(1) but in one pass. Useful when each element should expand to 0 or more elements: ["hello world"].flatMap(s => s.split(" ")) → ["hello", "world"].'),
('dev-q24',10,'What is the "functor" concept in functional programming?','["A special type of function","A container type (like Array) that implements map — allows applying a function to wrapped values","A curried function","A function factory"]','A container type (like Array) that implements map — allows applying a function to wrapped values','Functors are types that can be mapped over. Array is a functor because it implements .map(). The concept: apply a function to a wrapped value without unwrapping it. Promises, Optionals, and many other types are functors.'),
-- Q25: Event Loop
('dev-q25',1,'JavaScript is single-threaded. What does this mean?','["JavaScript runs on one computer","JavaScript can only execute one piece of code at a time — one call stack","JavaScript only supports one event listener","JavaScript cannot do multiple things"]','JavaScript can only execute one piece of code at a time — one call stack','Single-threaded means one call stack — JavaScript executes one function at a time. Yet it handles async operations (fetch, setTimeout) without blocking. This works via the event loop, Web APIs, and callback queues.'),
('dev-q25',2,'What is the call stack?','["A stack of network requests","The data structure tracking which function is currently running and what called it","A CSS animation stack","The JavaScript engine''s memory"]','The data structure tracking which function is currently running and what called it','The call stack is a LIFO (last in, first out) stack. When a function is called, it''s pushed on. When it returns, it''s popped off. If you call too many nested functions, you get "Maximum call stack size exceeded" (stack overflow).'),
('dev-q25',3,'What are Web APIs in the context of the event loop?','["APIs built with JavaScript","Browser-provided async capabilities (setTimeout, fetch, DOM events) that run outside the JS engine","A type of REST API","APIs that use the event loop"]','Browser-provided async capabilities (setTimeout, fetch, DOM events) that run outside the JS engine','setTimeout, fetch, addEventListener — these aren''t JavaScript. They''re browser APIs that run in separate threads. When done, they queue their callbacks for the JavaScript engine to process.'),
('dev-q25',4,'What is the output order? console.log("1"); setTimeout(()=>console.log("2"),0); Promise.resolve().then(()=>console.log("3")); console.log("4");','["1 2 3 4","1 4 2 3","1 4 3 2","4 3 2 1"]','1 4 3 2','Synchronous first: 1, 4. Then microtasks (Promises): 3. Then macrotasks (setTimeout): 2. Even setTimeout(0) is deferred to after all synchronous code and microtasks.'),
('dev-q25',5,'What are microtasks vs macrotasks?','["Microtasks are smaller","Microtasks (Promises, queueMicrotask) have higher priority — run between each macrotask. Macrotasks (setTimeout, setInterval, events) run one at a time","Macrotasks are for the browser; microtasks for Node","They are the same thing"]','Microtasks (Promises, queueMicrotask) have higher priority — run between each macrotask. Macrotasks (setTimeout, setInterval, events) run one at a time','After each macrotask, the event loop empties the ENTIRE microtask queue before the next macrotask. This is why Promises always run before setTimeout callbacks.'),
('dev-q25',6,'What is the event loop?','["A loop that reads user events","The mechanism that checks if the call stack is empty, then moves callbacks from queues to the stack to be executed","A for loop handling DOM events","The animation frame loop"]','The mechanism that checks if the call stack is empty, then moves callbacks from queues to the stack to be executed','The event loop: 1. Is call stack empty? 2. Are there microtasks? Run them all. 3. Take one macrotask from queue. 4. Repeat. This is how JavaScript can be non-blocking despite being single-threaded.'),
('dev-q25',7,'Why should you never block the main thread?','["It uses more CPU","Long synchronous operations (like a while loop for 3 seconds) freeze the browser — no clicks, no scrolling, no renders","It is against the JS spec","It causes memory leaks"]','Long synchronous operations (like a while loop for 3 seconds) freeze the browser — no clicks, no scrolling, no renders','JavaScript is single-threaded. A while loop that runs for 3 seconds blocks everything — the browser cannot process clicks, render animations, or run any other code. Break heavy work into chunks with setTimeout(chunk, 0).'),
('dev-q25',8,'What does async/await do to the event loop?','["It creates a new thread","await pauses the current async function and queues the rest as a microtask, freeing the event loop to do other work","It blocks the event loop while waiting","It creates a new event loop"]','await pauses the current async function and queues the rest as a microtask, freeing the event loop to do other work','When you await a Promise, JavaScript suspends that function and continues the event loop. When the Promise resolves, the rest of the function is queued as a microtask. Other code can run during the wait.'),
('dev-q25',9,'What is requestAnimationFrame used for?','["Requesting API data","Scheduling animations to run before the browser paints the next frame — smooth 60fps animations","Requesting the current frame timestamp","Making DOM updates faster"]','Scheduling animations to run before the browser paints the next frame — smooth 60fps animations','requestAnimationFrame(callback) calls callback just before the browser paints the next frame (~16ms at 60fps). Better than setInterval for animations — synced with display refresh, pauses when tab is hidden.'),
('dev-q25',10,'What is a "stale closure" bug?','["A closure that is too old","A closure that captured a value that has since changed — the function uses the old captured value instead of the current one","A memory leak from closures","An unclosed function"]','A closure that captured a value that has since changed — the function uses the old captured value instead of the current one','let count = 0; setInterval(() => console.log(count), 1000); count = 100; — the interval logs 0 forever (captured the original count). With let and proper scoping, this is usually not an issue, but it''s common in React hooks.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;


-- Q26-Q50: Remaining quizzes with full questions
INSERT INTO public.quiz_questions (quiz_id, question, question_type, options, correct_answer, explanation, points, order_index)
SELECT q.id, d.q, 'multiple_choice', d.o::jsonb, d.a, d.e, 10, d.i
FROM public.quizzes q
JOIN (VALUES
-- Q26: DOM Traversal
('dev-q26',1,'What does element.parentElement return?','["All ancestor elements","The immediate parent element in the DOM","The root html element","The body element"]','The immediate parent element in the DOM','parentElement returns the direct parent. To go higher: el.parentElement.parentElement. To find a specific ancestor: el.closest(".selector") — walks up and finds first matching ancestor.'),
('dev-q26',2,'What does element.closest(".card") do?','["Finds the nearest .card child","Walks up the DOM from the element and returns the first ancestor matching .card (including itself)","Returns all .card elements","Returns the closest sibling"]','Walks up the DOM from the element and returns the first ancestor matching .card (including itself)','el.closest(selector) is invaluable for event delegation: button.addEventListener("click", e => { const card = e.target.closest(".card"); card.remove(); }) — finds the card containing the clicked button.'),
('dev-q26',3,'What does element.children return?','["All descendant elements","Direct child elements (HTMLCollection — excludes text nodes)","Only element children matching a class","All siblings"]','Direct child elements (HTMLCollection — excludes text nodes)','children returns an HTMLCollection of direct child ELEMENTS (not text nodes). Use Array.from(el.children) to use array methods. el.childNodes includes text nodes and comments too.'),
('dev-q26',4,'What does element.nextElementSibling return?','["The next sibling including text nodes","The next sibling element (skipping text nodes)","The parent''s next child","The next element in the entire document"]','The next sibling element (skipping text nodes)','nextElementSibling returns the next sibling that is an element. nextSibling includes text nodes (whitespace) which is usually not what you want. previousElementSibling goes the other way.'),
('dev-q26',5,'What is MutationObserver?','["A server monitoring tool","A browser API that watches for DOM changes and calls a callback when they occur","A CSS mutation animation","A network request observer"]','A browser API that watches for DOM changes and calls a callback when they occur','const observer = new MutationObserver(mutations => { mutations.forEach(m => console.log(m)); }); observer.observe(target, {childList: true, subtree: true}). Used for reacting to third-party DOM changes or custom content updates.'),
('dev-q26',6,'How do you create an element with specific attributes efficiently?','["Create, setAttribute, then append","Use insertAdjacentHTML or create with Object.assign(document.createElement(tag), attrs)","You must set each attribute individually","Use innerHTML"]','Create with Object.assign(document.createElement(tag), attrs)','Object.assign(document.createElement("input"), {type:"email", name:"email", required:true, placeholder:"Your email"}) creates and configures in one statement. insertAdjacentHTML is also efficient for HTML strings.'),
('dev-q26',7,'What does element.replaceWith(newElement) do?','["Creates a copy","Removes the element and puts newElement in its place — in one operation","Replaces the element''s text","Swaps two elements"]','Removes the element and puts newElement in its place — in one operation','el.replaceWith(newEl) is cleaner than: el.parentNode.insertBefore(newEl, el); el.remove(). replaceWith can also take strings: el.replaceWith("Plain text").'),
('dev-q26',8,'What does document.createDocumentFragment() do?','["Creates a text document","Creates an in-memory DOM container to batch-append elements before inserting into the live DOM","Fragments the document","Creates a virtual DOM"]','Creates an in-memory DOM container to batch-append elements before inserting into the live DOM','const frag = document.createDocumentFragment(); items.forEach(item => frag.append(createCard(item))); container.append(frag). One DOM insertion instead of N — minimises reflows for performance.'),
('dev-q26',9,'What does element.matches(".active") return?','["All .active siblings","true if the element matches the CSS selector, false if not","The matched element","The active CSS class"]','true if the element matches the CSS selector, false if not','el.matches(selector) → true/false. Essential for event delegation: list.addEventListener("click", e => { if (e.target.matches("button.delete")) handleDelete(e.target); })'),
('dev-q26',10,'What is the IntersectionObserver API?','["An API for checking if two elements overlap","Observes when an element enters or leaves the viewport — used for lazy loading and scroll animations","Checks element intersection with the cursor","Monitors DOM intersections"]','Observes when an element enters or leaves the viewport — used for lazy loading and scroll animations','const io = new IntersectionObserver(entries => { entries.forEach(e => e.target.classList.toggle("visible", e.isIntersecting)); }, {threshold: 0.1}). Replaces scroll event listeners for scroll-based effects.'),
-- Q27: Canvas
('dev-q27',1,'How do you get the 2D drawing context from a canvas?','["canvas.context","canvas.getContext(\"2d\")","canvas.draw()","new CanvasContext(canvas)"]','canvas.getContext("2d")','const ctx = canvas.getContext("2d") returns the 2D rendering context. All drawing methods are on ctx. canvas.getContext("webgl") gives the WebGL (3D) context.'),
('dev-q27',2,'What does ctx.fillRect(x, y, width, height) do?','["Draws an outlined rectangle","Draws a filled solid rectangle","Sets the fill colour","Creates a rectangle element"]','Draws a filled solid rectangle','fillRect draws a solid rectangle filled with ctx.fillStyle colour. strokeRect draws just the outline. clearRect erases a rectangular area (makes it transparent).'),
('dev-q27',3,'What is ctx.beginPath() used for?','["Starts a new canvas","Resets the current drawing path — must be called before drawing a new shape","Creates a new drawing context","Begins a fill operation"]','Resets the current drawing path — must be called before drawing a new shape','Without beginPath(), all previous path segments are still active. ctx.beginPath() starts fresh. Then: moveTo, lineTo, arc etc. Then stroke() or fill() to render.'),
('dev-q27',4,'What does ctx.arc(x, y, radius, startAngle, endAngle) draw?','["A rectangle with rounded corners","An arc or circle — startAngle 0 to endAngle Math.PI*2 draws a full circle","A spiral","An ellipse"]','An arc or circle — startAngle 0 to endAngle Math.PI*2 draws a full circle','ctx.arc(100, 100, 50, 0, Math.PI * 2) draws a circle at (100,100) with radius 50. Angles in radians: 0=right, Math.PI/2=bottom, Math.PI=left, 3*Math.PI/2=top, 2*Math.PI=full circle.'),
('dev-q27',5,'How do you save a canvas image as a file?','["canvas.save()","canvas.toDataURL() → create a link with download attribute → click it","canvas.export()","ctx.toFile()"]','canvas.toDataURL() → create a link with download attribute → click it','const link = document.createElement("a"); link.download = "drawing.png"; link.href = canvas.toDataURL("image/png"); link.click(). toDataURL can also output "image/jpeg" and other formats.'),
('dev-q27',6,'What does requestAnimationFrame enable for canvas?','["Saving canvas frames","Smooth 60fps animation by calling a render function before each browser paint","Requesting the canvas element","Animating CSS on a canvas"]','Smooth 60fps animation by calling a render function before each browser paint','function animate() { ctx.clearRect(0,0,w,h); draw(); requestAnimationFrame(animate); } requestAnimationFrame(animate). Better than setInterval — syncs with screen refresh, pauses when tab is hidden.'),
('dev-q27',7,'What is ctx.save() and ctx.restore() for?','["Saving the canvas to a file","Saving and restoring the canvas drawing state (transformations, styles) so changes can be undone","Saving animation frames","Creating canvas checkpoints"]','Saving and restoring the canvas drawing state (transformations, styles) so changes can be undone','ctx.save() pushes current state (fillStyle, strokeStyle, transform, clip) onto a stack. ctx.restore() pops and applies the saved state. Use when you need temporary style changes without affecting subsequent drawing.'),
('dev-q27',8,'What does ctx.drawImage(image, x, y) do?','["Links to an image","Draws an HTMLImageElement (or video/canvas) onto the canvas at position x,y","Downloads an image","Creates an image element"]','Draws an HTMLImageElement (or video/canvas) onto the canvas at position x,y','ctx.drawImage(img, 0, 0) draws image at origin. ctx.drawImage(img, x, y, w, h) resizes. ctx.drawImage(img, sx,sy,sw,sh, dx,dy,dw,dh) crops and draws. The image must be loaded first.'),
('dev-q27',9,'What is the globalAlpha property?','["Sets the canvas background","Controls global opacity for all subsequent drawing (0=transparent, 1=opaque)","The alpha channel of a specific colour","The canvas transparency mode"]','Controls global opacity for all subsequent drawing (0=transparent, 1=opaque)','ctx.globalAlpha = 0.5 makes all subsequent drawing 50% transparent. Reset to 1.0 after. Alternatively, use rgba colours: ctx.fillStyle = "rgba(255,0,0,0.5)" for per-operation transparency.'),
('dev-q27',10,'How do you detect where the user clicks on a canvas?','["canvas.addEventListener(\"click\", e => e.canvasX)","Get the canvas bounding rect and calculate: e.clientX - rect.left and e.clientY - rect.top","canvas.getClickPosition()","e.offsetX and e.offsetY on the canvas element"]','e.offsetX and e.offsetY on the canvas element','canvas.addEventListener("click", e => { const x = e.offsetX; const y = e.offsetY; /* x,y are canvas coordinates */ }). offsetX/offsetY are relative to the element. If canvas is scaled with CSS, you may need to adjust for the ratio.'),
-- Q28: Node.js
('dev-q28',1,'What is Node.js?','["A JavaScript browser plugin","A JavaScript runtime built on Chrome''s V8 engine that runs JavaScript on servers","A Node.js framework","A type of database"]','A JavaScript runtime built on Chrome''s V8 engine that runs JavaScript on servers','Node.js lets JavaScript run outside the browser. It uses V8 to execute JS and provides APIs for file system, networking, HTTP, and more. Enables JavaScript for backend web servers, CLIs, build tools, and APIs.'),
('dev-q28',2,'What does require() do in Node.js?','["Requests a file from a server","Imports a module using CommonJS syntax: const fs = require(''fs'')","Makes an HTTP request","Requires a variable to be defined"]','Imports a module using CommonJS syntax: const fs = require("fs")','require() is Node.js''s module system (CommonJS). require("fs") imports the built-in file system module. require("./myfile") imports a local file. require("express") imports an installed npm package.'),
('dev-q28',3,'What is the difference between __dirname and __filename in Node?','["__dirname: the current file path; __filename: the current directory","__dirname: absolute path to the current directory; __filename: absolute path to the current file","They are identical","Both are deprecated"]','__dirname: absolute path to the current directory; __filename: absolute path to the current file','__dirname: "/Users/alex/projects/app" (the folder). __filename: "/Users/alex/projects/app/index.js" (the file). Useful for constructing paths: path.join(__dirname, "data.json").'),
('dev-q28',4,'What does process.argv contain?','["The current environment variables","An array of command-line arguments: [node path, script path, ...user args]","The process ID","A list of running processes"]','An array of command-line arguments: [node path, script path, ...user args]','node app.js --name Alex → process.argv = ["/usr/bin/node", "/path/app.js", "--name", "Alex"]. User arguments start at index 2. Parse with a library like yargs or manually: const name = process.argv[3].'),
('dev-q28',5,'What does the fs module provide?','["A file system browser","File system operations: read, write, delete, check existence, watch for changes","Frontend storage","A JSON file format"]','File system operations: read, write, delete, check existence, watch for changes','const fs = require("fs") or import fs from "fs". Key methods: fs.readFile, fs.writeFile, fs.appendFile, fs.unlink (delete), fs.mkdir, fs.readdir. Async versions are preferred (fs.promises or callback-based).'),
('dev-q28',6,'What does process.env contain?','["The process version number","Environment variables — configuration values set outside the code (secrets, API keys, database URLs)","The current user''s environment","A list of processes"]','Environment variables — configuration values set outside the code (secrets, API keys, database URLs)','process.env.PORT, process.env.DATABASE_URL, process.env.API_KEY. Set from .env files (with dotenv package), shell environment, or hosting platforms. Never hardcode secrets — use environment variables.'),
('dev-q28',7,'What does module.exports do in CommonJS?','["Exports a JavaScript module","Defines what a module makes available when required: module.exports = {add, subtract}","Sets the module''s version","Exports the module to npm"]','Defines what a module makes available when required: module.exports = {add, subtract}','module.exports = value sets what require("./module") returns. Alternatively: exports.functionName = fn (but don''t mix with module.exports = {}). In ES modules: use export keyword instead.'),
('dev-q28',8,'What is the Node.js event loop different from the browser event loop?','["They are identical","Node.js event loop has additional phases (timers, I/O, setImmediate, close) vs browser''s simpler structure","Node.js doesn''t have an event loop","Node.js uses multiple threads"]','Node.js event loop has additional phases (timers, I/O, setImmediate, close) vs browser''s simpler structure','Node.js event loop phases: timers (setTimeout/setInterval), pending callbacks, idle/prepare, poll (I/O), check (setImmediate), close callbacks. Still fundamentally non-blocking and single-threaded.'),
('dev-q28',9,'What does global in Node.js correspond to?','["The global CSS scope","Node.js''s equivalent of window — the global object where global variables live","A global database connection","The entire Node.js process"]','Node.js''s equivalent of window — the global object where global variables live','In browsers, the global object is window. In Node.js it is global. globalThis works in both environments. Variables declared at module top level are NOT global in Node (due to module wrapping) — unlike browser global scripts.'),
('dev-q28',10,'What is the streams API in Node.js?','["A video streaming service","A way to process data in chunks rather than loading everything into memory — useful for large files","A real-time events API","A type of Promise"]','A way to process data in chunks rather than loading everything into memory — useful for large files','fs.createReadStream("large.csv").pipe(processStream).pipe(outputStream) — reads, processes, writes in chunks without loading the whole file. Streams are memory-efficient for large data processing.'),
-- Q29: npm and Packages
('dev-q29',1,'What is npm?','["Node Package Manager — a registry and command-line tool for sharing and using JavaScript packages","A Node.js programming method","A type of API","A JavaScript testing framework"]','Node Package Manager — a registry and command-line tool for sharing and using JavaScript packages','npm (npmjs.com) hosts over 2 million packages. npm install express downloads Express. npm run test runs your test script. npm init creates a package.json. It comes bundled with Node.js.'),
('dev-q29',2,'What is package.json?','["A JSON configuration file for the OS","A file describing the project: name, version, scripts, and dependencies","A list of npm packages","The JavaScript package format"]','A file describing the project: name, version, scripts, and dependencies','package.json is the project manifest. It lists: name, version, description, main entry point, scripts (npm run build, test), dependencies (runtime packages), and devDependencies (build tools, testing).'),
('dev-q29',3,'What is the difference between dependencies and devDependencies?','["They are identical","dependencies: needed to run the app (express, react); devDependencies: only needed during development (jest, webpack, eslint)","devDependencies are faster","dependencies are for the server; devDependencies for the client"]','dependencies: needed to run the app (express, react); devDependencies: only needed during development (jest, webpack, eslint)','npm install express (→ dependencies). npm install --save-dev jest (→ devDependencies). In production, you can install only dependencies: npm install --production.'),
('dev-q29',4,'What is package-lock.json?','["A backup of package.json","A lock file recording the exact versions of all installed packages — ensures reproducible installs across machines","A security file for packages","A list of packages that are locked from updates"]','A lock file recording the exact versions of all installed packages — ensures reproducible installs across machines','package-lock.json records the exact version tree. npm ci (continuous integration) uses it for exact reproducibility. Commit it to version control. Never manually edit it.'),
('dev-q29',5,'What does semantic versioning (semver) "^1.2.3" mean?','["Exactly version 1.2.3","Any version >= 1.2.3 and < 2.0.0 (same major version)","Any version >= 1.0.0","Only patch updates: >= 1.2.3 and < 1.3.0"]','Any version >= 1.2.3 and < 2.0.0 (same major version)','Semver: MAJOR.MINOR.PATCH. ^1.2.3: allow MINOR and PATCH updates (compatible changes). ~1.2.3: allow PATCH updates only. 1.2.3: exact version. Major version bumps indicate breaking changes.'),
('dev-q29',6,'What does npm run build typically do?','["Builds the Node.js binary","Runs the build script defined in package.json — usually compiling, bundling, or transpiling code for production","Installs all packages","Creates a new npm package"]','Runs the build script defined in package.json — usually compiling, bundling, or transpiling code for production','package.json scripts: {"build": "vite build", "dev": "vite", "test": "jest"}. npm run build runs the build command. npm start runs "start". These scripts automate common development tasks.'),
('dev-q29',7,'What is the node_modules folder?','["JavaScript source files","The folder where npm installs all package dependencies — never commit this to git (add to .gitignore)","Configuration files","A temporary cache folder"]','The folder where npm installs all package dependencies — never commit this to git (add to .gitignore)','node_modules can contain thousands of files and hundreds of MB. It can be regenerated with npm install from package.json. Always add node_modules to .gitignore. Teammates run npm install to recreate it.'),
('dev-q29',8,'What is a CDN alternative to npm for browser use?','["A content delivery network for npm packages","Using a CDN URL (like cdnjs, unpkg, jsdelivr) to load a package directly in a script tag without npm","A cached npm registry","A browser npm alternative"]','Using a CDN URL (like cdnjs, unpkg, jsdelivr) to load a package directly in a script tag without npm','<script src="https://cdn.jsdelivr.net/npm/marked@4.0.0/marked.min.js"> loads the marked library without npm. Good for simple projects and learning. Not ideal for complex apps (no tree-shaking, harder dependency management).'),
('dev-q29',9,'What does npx do?','["Uninstalls a package","Runs a package without installing it globally: npx create-react-app my-app","Publishes a package to npm","Executes package.json scripts"]','Runs a package without installing it globally: npx create-react-app my-app','npx downloads and runs a package temporarily. Avoids global installs that can conflict. npx create-react-app, npx cowsay, npx prettier --write. Always uses the latest version unless specified.'),
('dev-q29',10,'What is a scoped package like @anthropic-ai/sdk?','["A private, paid package","A package in a namespace (@scope/name) — often an organisation''s packages","A secure package","A package scoped to one version"]','A package in a namespace (@scope/name) — often an organisation''s packages','Scoped packages: @anthropic-ai/sdk, @types/react, @babel/core. The scope (@name) is the namespace. Scoped packages can be public or private. Organisation packages are often scoped to avoid naming conflicts with unrelated packages.'),
-- Q30: Express and REST
('dev-q30',1,'What is Express.js?','["A JavaScript template engine","A minimal, fast Node.js web framework for building HTTP servers and REST APIs","A CSS framework","A JavaScript test runner"]','A minimal, fast Node.js web framework for building HTTP servers and REST APIs','const express = require("express"); const app = express(); app.get("/", (req, res) => res.send("Hello")); app.listen(3000). Express handles routing, middleware, request/response objects — the foundation of most Node.js backends.'),
('dev-q30',2,'What is middleware in Express?','["The database layer","Functions that run between receiving a request and sending a response — for logging, auth, parsing body, CORS etc.","The front end","A type of Express route"]','Functions that run between receiving a request and sending a response — for logging, auth, parsing body, CORS etc.','app.use(express.json()) — parses JSON request bodies. app.use(cors()) — adds CORS headers. app.use(logger) — logs requests. Middleware: (req, res, next) => { /* modify req/res */ next(); }'),
('dev-q30',3,'What does res.json() do in Express?','["Sends a JSON file","Sends a JSON response with correct Content-Type header","Parses the request body as JSON","Returns a JSON string"]','Sends a JSON response with correct Content-Type header','res.json({user: "Alex", score: 85}) serialises the object with JSON.stringify and sets Content-Type: application/json automatically. More convenient than res.send(JSON.stringify(data)).'),
('dev-q30',4,'What are Express route parameters?','["URL query strings","Named segments in URL paths: /users/:id — accessed via req.params.id","POST body parameters","HTTP headers"]','Named segments in URL paths: /users/:id — accessed via req.params.id','app.get("/users/:id", (req, res) => { const id = req.params.id; // "42" for URL /users/42 }). Multiple params: /users/:userId/posts/:postId. req.params contains all named segments.'),
('dev-q30',5,'How does REST map HTTP methods to CRUD operations?','["GET=create, POST=read, PUT=update, DELETE=delete","GET=read, POST=create, PUT=update, DELETE=delete","GET=all, POST=one, DELETE=all, PUT=one","They are unrelated"]','GET=read, POST=create, PUT=update, DELETE=delete','REST convention: GET /users (list all), GET /users/1 (get one), POST /users (create), PUT /users/1 (replace), PATCH /users/1 (partial update), DELETE /users/1 (delete). The URL is the resource; HTTP method is the action.'),
('dev-q30',6,'What does req.body contain?','["The URL path","The parsed request body — POST/PUT data sent by the client (requires express.json() middleware)","Query parameters","Request headers"]','The parsed request body — POST/PUT data sent by the client (requires express.json() middleware)','app.use(express.json()) middleware parses JSON request bodies and makes them available as req.body. For form data: express.urlencoded(). For multipart (file uploads): multer middleware.'),
('dev-q30',7,'What HTTP status code should a successful POST (create) return?','["200 OK","201 Created","204 No Content","200 or 201 — it doesn''t matter"]','201 Created','201 is the standard for successful resource creation. 200 OK for successful reads/updates. 204 No Content for successful deletes (no body). 400 Bad Request for client errors. 404 Not Found. 500 Internal Server Error.'),
('dev-q30',8,'What does next() do in Express middleware?','["Exits the request","Passes control to the next middleware or route handler in the chain","Skips to the response","Calls the next HTTP request"]','Passes control to the next middleware or route handler in the chain','Middleware must call next() to continue the request pipeline. Without next(), the request hangs (never gets a response). next(error) passes control to error-handling middleware. Calling res.send() without next() ends the pipeline.'),
('dev-q30',9,'How do you handle errors in Express?','["Try/catch in every route","A special 4-argument middleware: app.use((err, req, res, next) => { res.status(500).json({error: err.message}); })","Express handles errors automatically","Log and ignore"]','A special 4-argument middleware: app.use((err, req, res, next) => { res.status(500).json({error: err.message}); })','Express error middleware has exactly 4 parameters (err, req, res, next). Add it LAST (after all routes). Routes trigger it with next(error). It sends an error response and logs the error.'),
('dev-q30',10,'What is CORS and why does Express need it?','["A JavaScript security tool","Cross-Origin Resource Sharing — without it, browsers block API requests from different domains than the server","A compression algorithm","Content Organisation Resource System"]','Cross-Origin Resource Sharing — without it, browsers block API requests from different domains than the server','If your React app at localhost:3000 calls an Express API at localhost:8000, browsers block it (CORS policy). Use the cors npm package: app.use(cors({origin: "http://localhost:3000"})) to allow specific origins.')
) AS d(quiz_slug, i, q, o, a, e) ON q.slug = d.quiz_slug;


-- ═══════════════════════════════════════════════════════════════════════════
-- DEVELOPERS: 50 QUIZZES
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.quizzes (slug, title, level, category, difficulty, time_limit_seconds, passing_score, status, description, tags, order_index) VALUES
('dev-q01','JavaScript Fundamentals Quiz','Developers','JavaScript','intermediate',600,70,'published','Test your knowledge of JavaScript variables, types, and operators.',ARRAY['javascript','variables','types'],1),
('dev-q02','Functions and Scope Quiz','Developers','JavaScript','intermediate',600,70,'published','Test your understanding of functions, arrow functions, and scope.',ARRAY['javascript','functions','scope'],2),
('dev-q03','Arrays and Array Methods Quiz','Developers','JavaScript','intermediate',600,70,'published','Master map, filter, reduce, and essential array methods.',ARRAY['javascript','arrays','methods'],3),
('dev-q04','Objects and OOP Quiz','Developers','JavaScript','intermediate',600,70,'published','Test object creation, methods, and class-based OOP.',ARRAY['javascript','objects','oop'],4),
('dev-q05','DOM Manipulation Quiz','Developers','JavaScript','intermediate',600,70,'published','Selecting, reading, and modifying HTML elements with JavaScript.',ARRAY['javascript','dom','elements'],5),
('dev-q06','Events and Interaction Quiz','Developers','JavaScript','intermediate',600,70,'published','Event listeners, event objects, and event delegation.',ARRAY['javascript','events','dom'],6),
('dev-q07','Asynchronous JavaScript Quiz','Developers','JavaScript','intermediate',600,70,'published','Promises, async/await, and the fetch API.',ARRAY['javascript','async','promises','fetch'],7),
('dev-q08','String Methods Quiz','Developers','JavaScript','intermediate',600,70,'published','Essential string manipulation methods and template literals.',ARRAY['javascript','strings','methods'],8),
('dev-q09','Control Flow Quiz','Developers','JavaScript','intermediate',600,70,'published','If/else, switch, loops, and control flow patterns.',ARRAY['javascript','control-flow','loops'],9),
('dev-q10','JSON and APIs Quiz','Developers','JavaScript','intermediate',600,70,'published','JSON format, parsing, and working with REST APIs.',ARRAY['javascript','json','api'],10),
('dev-q11','Error Handling Quiz','Developers','JavaScript','intermediate',600,70,'published','try/catch, custom errors, and defensive programming.',ARRAY['javascript','errors','defensive'],11),
('dev-q12','localStorage and Web Storage Quiz','Developers','JavaScript','intermediate',600,70,'published','localStorage, sessionStorage, and JSON persistence.',ARRAY['javascript','storage','localstorage'],12),
('dev-q13','ES6+ Features Quiz','Developers','JavaScript','intermediate',600,70,'published','Modern JavaScript: destructuring, spread, template literals, modules.',ARRAY['javascript','es6','modern'],13),
('dev-q14','Classes and Prototypes Quiz','Developers','JavaScript','intermediate',600,70,'published','Class syntax, inheritance, static methods, and private fields.',ARRAY['javascript','classes','inheritance'],14),
('dev-q15','Higher-Order Functions Quiz','Developers','JavaScript','intermediate',600,70,'published','Callbacks, closures, currying, and functional programming.',ARRAY['javascript','functional','closures'],15),
('dev-q16','Numbers and Math Quiz','Developers','JavaScript','beginner',600,70,'published','Math object, number formatting, random numbers, and floating point.',ARRAY['javascript','math','numbers'],16),
('dev-q17','Dates and Times Quiz','Developers','JavaScript','beginner',600,70,'published','Date objects, formatting with Intl, and date arithmetic.',ARRAY['javascript','dates','intl'],17),
('dev-q18','Modules and Project Structure Quiz','Developers','JavaScript','intermediate',600,70,'published','ES6 import/export, default vs named exports, and project organisation.',ARRAY['javascript','modules','import'],18),
('dev-q19','Event Loop and Async Patterns Quiz','Developers','JavaScript','intermediate',600,70,'published','Call stack, event loop, microtasks, macrotasks.',ARRAY['javascript','event-loop','async'],19),
('dev-q20','DOM Traversal and Creation Quiz','Developers','JavaScript','intermediate',600,70,'published','Navigating the DOM tree and creating elements programmatically.',ARRAY['javascript','dom','traversal'],20),
('dev-q21','Regular Expressions Quiz','Developers','JavaScript','intermediate',600,70,'published','RegEx patterns, flags, and use in string methods.',ARRAY['javascript','regex','strings'],21),
('dev-q22','JavaScript Debugging Quiz','Developers','JavaScript','intermediate',600,70,'published','DevTools, error types, and systematic debugging.',ARRAY['javascript','debugging','devtools'],22),
('dev-q23','Form Handling and Validation Quiz','Developers','JavaScript','intermediate',600,70,'published','Form events, validation patterns, and FormData.',ARRAY['javascript','forms','validation'],23),
('dev-q24','Fetch API and HTTP Quiz','Developers','JavaScript','intermediate',600,70,'published','HTTP methods, response handling, and error management.',ARRAY['javascript','fetch','http'],24),
('dev-q25','Developers Comprehensive Quiz','Developers','JavaScript','intermediate',900,70,'published','Comprehensive quiz covering all Developers level JavaScript topics.',ARRAY['javascript','comprehensive'],25),
('dev-q26','Node.js Fundamentals Quiz','Developers','Node.js','intermediate',600,70,'published','Node.js runtime, modules, and core concepts.',ARRAY['node','server','javascript'],26),
('dev-q27','Express and REST API Quiz','Developers','Node.js','intermediate',600,70,'published','Express routing, middleware, and REST API design.',ARRAY['express','rest','api'],27),
('dev-q28','Python Basics Quiz','Developers','Python','beginner',600,70,'published','Python syntax, variables, and basic data types.',ARRAY['python','basics','syntax'],28),
('dev-q29','Python Control Flow and Functions Quiz','Developers','Python','intermediate',600,70,'published','Python if/else, loops, functions, and scope.',ARRAY['python','functions','loops'],29),
('dev-q30','Python Lists and Dictionaries Quiz','Developers','Python','intermediate',600,70,'published','Python data structures: lists, dicts, tuples, sets.',ARRAY['python','lists','dicts'],30),
('dev-q31','React Fundamentals Quiz','Developers','React','intermediate',600,70,'published','React components, JSX, props, and the virtual DOM.',ARRAY['react','components','jsx'],31),
('dev-q32','React Hooks Quiz','Developers','React','intermediate',600,70,'published','useState, useEffect, and the rules of hooks.',ARRAY['react','hooks','state'],32),
('dev-q33','Git and Version Control Quiz','Developers','Fundamentals','intermediate',600,70,'published','Git commands, branching, and GitHub workflow.',ARRAY['git','github','version-control'],33),
('dev-q34','Web Security Basics Quiz','Developers','Fundamentals','intermediate',600,70,'published','XSS, CSRF, HTTPS, and common web security threats.',ARRAY['security','xss','https'],34),
('dev-q35','Performance and Optimisation Quiz','Developers','JavaScript','intermediate',600,70,'published','Web performance, lazy loading, and optimisation techniques.',ARRAY['performance','optimisation','javascript'],35),
('dev-q36','Canvas API Quiz','Developers','JavaScript','advanced',600,70,'published','HTML5 Canvas drawing, animation, and context methods.',ARRAY['canvas','animation','javascript'],36),
('dev-q37','Data Structures Quiz','Developers','Algorithms','intermediate',600,70,'published','Stacks, queues, linked lists, and basic tree concepts.',ARRAY['data-structures','algorithms'],37),
('dev-q38','Algorithms Basics Quiz','Developers','Algorithms','intermediate',600,70,'published','Sorting, searching, and Big O complexity.',ARRAY['algorithms','sorting','big-o'],38),
('dev-q39','Testing and Jest Quiz','Developers','Testing','intermediate',600,70,'published','Unit testing concepts, Jest syntax, and TDD.',ARRAY['testing','jest','tdd'],39),
('dev-q40','TypeScript Introduction Quiz','Developers','JavaScript','advanced',600,70,'published','TypeScript types, interfaces, and basic type safety.',ARRAY['typescript','types','javascript'],40),
('dev-q41','Progressive Web Apps Quiz','Developers','JavaScript','advanced',600,70,'published','Service workers, manifest, offline-first, and PWA concepts.',ARRAY['pwa','service-workers','offline'],41),
('dev-q42','WebSockets and Real-Time Quiz','Developers','JavaScript','advanced',600,70,'published','WebSocket protocol, real-time communication patterns.',ARRAY['websockets','real-time','server'],42),
('dev-q43','Accessibility in JavaScript Quiz','Developers','Fundamentals','intermediate',600,70,'published','ARIA, focus management, and accessible JavaScript patterns.',ARRAY['accessibility','aria','javascript'],43),
('dev-q44','CLI and Developer Tools Quiz','Developers','Fundamentals','intermediate',600,70,'published','Command line basics, npm, and developer workflow.',ARRAY['cli','npm','workflow'],44),
('dev-q45','Functional Programming Quiz','Developers','JavaScript','advanced',600,70,'published','Pure functions, immutability, composition, and functional patterns.',ARRAY['functional','composition','immutability'],45),
('dev-q46','Browser APIs Quiz','Developers','JavaScript','intermediate',600,70,'published','Clipboard, Geolocation, Notifications, IntersectionObserver, and other APIs.',ARRAY['browser-apis','javascript','web'],46),
('dev-q47','CSS-in-JS and React Styling Quiz','Developers','React','intermediate',600,70,'published','Inline styles, CSS Modules, styled-components, and Tailwind with React.',ARRAY['react','css','styling'],47),
('dev-q48','Full-Stack Concepts Quiz','Developers','Fundamentals','intermediate',600,70,'published','Client vs server, REST vs GraphQL, authentication, deployment.',ARRAY['fullstack','rest','deployment'],48),
('dev-q49','Code Quality and Best Practices Quiz','Developers','Fundamentals','intermediate',600,70,'published','Clean code, naming, patterns, and professional practices.',ARRAY['best-practices','clean-code','patterns'],49),
('dev-q50','Developers Final Exam','Developers','JavaScript','intermediate',1200,75,'published','Comprehensive final exam covering all Developers level content.',ARRAY['comprehensive','final','javascript'],50);

