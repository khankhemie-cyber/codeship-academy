-- ─────────────────────────────────────────────────────────────────────────────
-- CODEship Academy — Schema Patch
-- Run AFTER schema.sql, curriculum.sql, school-portal.sql, classes.sql
-- Fixes missing columns and constraints identified in audit
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Add visibility to student_profiles (for leaderboard opt-in/out)
alter table public.student_profiles
  add column if not exists visibility text default 'public'
  check (visibility in ('public', 'class_only', 'private'));

-- 2. Add teacher_id to student_profiles (for teacher-student direct link)
alter table public.student_profiles
  add column if not exists teacher_id uuid references public.users(id) on delete set null;

create index if not exists idx_student_profiles_teacher_id
  on public.student_profiles(teacher_id) where teacher_id is not null;

-- 3. Add unique constraint to certificates (student can only have one cert per level)
alter table public.certificates
  drop constraint if exists certificates_student_level_unique;

alter table public.certificates
  add constraint certificates_student_level_unique unique (student_id, level);

-- 4. Add locale to users table (for bilingual support)
alter table public.users
  add column if not exists locale text default 'en'
  check (locale in ('en', 'fr'));

-- 5. Add completed_at to quiz_attempts (was missing, needed for weekly digest)
alter table public.quiz_attempts
  add column if not exists completed_at timestamptz default now();

-- 6. Add avatar_url to student_profiles (for custom uploaded avatars)
alter table public.student_profiles
  add column if not exists avatar_url text;

-- 7. Add xp_multiplier for streak bonuses
alter table public.student_profiles
  add column if not exists xp_multiplier numeric default 1.0;

-- 8. Update award_xp function to respect multiplier
create or replace function public.award_xp(p_student_id uuid, p_xp integer)
returns void language plpgsql security definer as $$
declare
  v_multiplier numeric;
begin
  select coalesce(xp_multiplier, 1.0) into v_multiplier
  from public.student_profiles where id = p_student_id;

  update public.student_profiles
  set xp_points = xp_points + round(p_xp * v_multiplier)
  where id = p_student_id;
end;
$$;

-- 9. Update streak function to set multiplier bonus
create or replace function public.update_streak(p_student_id uuid)
returns void language plpgsql security definer as $$
declare
  v_last_active date;
  v_streak integer;
begin
  select last_active_at::date, streak_days
  into v_last_active, v_streak
  from public.student_profiles
  where id = p_student_id;

  if v_last_active = current_date then
    return; -- already updated today
  end if;

  if v_last_active = current_date - 1 then
    v_streak := coalesce(v_streak, 0) + 1;
  else
    v_streak := 1; -- streak broken
  end if;

  -- Set XP multiplier based on streak length
  update public.student_profiles set
    streak_days    = v_streak,
    last_active_at = now(),
    xp_multiplier  = case
      when v_streak >= 30 then 2.0
      when v_streak >= 14 then 1.5
      when v_streak >= 7  then 1.25
      else 1.0
    end
  where id = p_student_id;
end;
$$;

-- 10. Add session_packs tracking column to subscriptions
alter table public.subscriptions
  add column if not exists session_packs_remaining integer default 0;

-- 11. Add quiz pass tracking per topic (mastery system foundation)
create table if not exists public.topic_mastery (
  id            uuid primary key default gen_random_uuid(),
  student_id    uuid references public.student_profiles(id) on delete cascade not null,
  level         text not null,
  topic         text not null,
  mastery_pct   integer default 0 check (mastery_pct between 0 and 100),
  items_done    integer default 0,
  items_total   integer default 0,
  last_updated  timestamptz default now(),
  unique (student_id, level, topic)
);

alter table public.topic_mastery enable row level security;

create policy "topic_mastery_owner" on public.topic_mastery for all
  using (
    student_id in (
      select id from public.student_profiles
      where user_id = auth.uid() or parent_id = auth.uid()
    ) or exists (select 1 from public.users where id = auth.uid() and role in ('admin','teacher'))
  );

-- 12. Add locale-aware RLS helper
create or replace function public.get_user_locale()
returns text language sql security definer as $$
  select coalesce(locale, 'en') from public.users where id = auth.uid();
$$;

select '✅ Schema patch applied successfully' as status;
