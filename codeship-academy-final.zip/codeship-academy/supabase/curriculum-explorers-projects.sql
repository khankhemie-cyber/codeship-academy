
-- ═══════════════════════════════════════════════════════════════════════════
-- EXPLORERS: 100 PROJECTS
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, starter_code, tags, order_index) VALUES

('exp-p01', 'My Digital Introduction Card', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published',
ARRAY['Create a self-introduction animation','Use multiple characters and backgrounds','Apply sequences and speech bubbles'],
$P$# Project: My Digital Introduction Card

## What You Are Building
A digital introduction card — like a business card but animated and interactive! When someone taps it, they learn all about you through a fun Scratch Jr animation.

## Real-World Connection
Professionals around the world use digital introductions. LinkedIn profiles, portfolio websites, and video pitches all serve the same purpose: introducing yourself in a compelling, memorable way.

## Project Requirements
Your digital introduction card must include:
- Your name displayed clearly
- Something you love (a hobby, sport, animal, or food)
- Something you are good at
- One goal or dream you have
- At least 3 different backgrounds (scenes)
- At least 2 animated characters
- Sound effects or music

## Building Step by Step

### Scene 1: Welcome Screen
Background: Something colourful and exciting
Character: An avatar representing you
Action: Character waves and says your name

Code for Character 1:
```
START FLAG
  SAY your name for 3 seconds
  MOVE RIGHT 2
  CHANGE COSTUME (wave!)
```

### Scene 2: What I Love
Background: Related to your hobby
Action: Show your favourite thing

```
ON PAGE 2, START FLAG
  SAY what you love for 2 seconds
  JUMP animation
```

### Scene 3: My Dream
Background: Future setting
Action: Character shares their dream

```
ON PAGE 3, START FLAG
  SAY your dream for 3 seconds
  CELEBRATION animation
```

## Personalisation Challenges
Challenge 1: Add a 4th page showing a favourite place
Challenge 2: Add background music that fits each scene mood
Challenge 3: Draw your own character instead of using a built-in one
Challenge 4: Add a clickable button that says more about you

## Sharing Your Card
Show your project to a family member. Did they learn something new about you? Did the animation tell your story clearly?

## Reflection Questions
- Would someone who does not know me understand who I am from this?
- Is it interesting to watch?
- Does the animation enhance the story or distract from it?

## Key Learning
You built a personal brand presentation using code. Every element was a choice you made. That is what design and development feel like professionally!
$P$,
NULL, ARRAY['scratch-jr','creative','introduction','K-1'], 1),

('exp-p02', 'Counting Machine: A Number Learning App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 45, 'published',
ARRAY['Create an interactive counting tool','Use tap interactions to count','Add visual and audio feedback'],
$P$# Project: Counting Machine

## What You Are Building
An interactive counting app that helps younger children practice counting from 1 to 10. Tap a button, see a visual counter, hear a sound.

## Real-World Connection
Apps like Starfall, ABCmouse, and Khan Academy Kids teach early math through interactive technology. Educational apps are a multi-billion dollar industry.

## Project Requirements
Your counting machine must:
- Count from 1 to 10 visually
- Show a new item on screen for each count (stars, animals, or dots)
- Play a sound for each number
- Display the number clearly
- Have a reset button to start over
- Celebrate when reaching 10!

## Building Your Counter

### The Visual Counter
Create 11 pages in Scratch Jr:
- Page 1: One star and the number 1
- Page 2: Two stars and the number 2
- Continue to Page 10
- Page 11: Celebration screen!

Each page has:
- The number large and visible
- A NEXT arrow button to advance
- A sound that plays when the page loads

### The NEXT Button
Add a character shaped like an arrow:
```
WHEN TAPPED
  SEND MESSAGE to go to next page
```

### The Celebration Screen
On page 11:
```
START
  GROW big
  PLAY celebration sound
  SAY You counted to 10! Amazing! for 3 seconds
  SPIN
```

### Reset Button
A character that returns to page 1:
```
WHEN TAPPED
  GO TO page 1
```

## Extensions
Extension 1: Add French counting! Un, deux, trois...
Extension 2: Count backwards from 10 to 1
Extension 3: Count by 2s: 2, 4, 6, 8, 10

## Testing Your App
Have a younger child try your app WITHOUT instructions. Observe what confuses them and fix it. This is real user testing!
$P$,
NULL, ARRAY['scratch-jr','educational','counting','interactive'], 2),

('exp-p03', 'The Little Robot Who Could: An Animated Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 50, 'published',
ARRAY['Write and code an original story','Use at least 5 scenes','Apply character development through animation'],
$P$# Project: The Little Robot Who Could

## What You Are Building
An original animated story about a robot learning something new. You are the author, animator, AND programmer.

## Story Framework

Page 1: Meet the robot. What do they look like? What is their name? Where do they live?

Page 2: The robot wants something. What do they want to learn? (Dance? Cook? Make friends? Fly?)

Page 3: The first try fails! Make the failure funny or touching. Use the shake animation.

Page 4: Learning and practice. Show someone helping. Use a REPEAT loop for practice scenes.

Page 5: The robot succeeds! BIG celebration animation.

Page 6: What the robot learned. A simple message about the story theme.

## Scratch Jr Techniques

For the failure scene:
```
REPEAT 3 times:
  MOVE LEFT 1
  MOVE RIGHT 1
```
This creates a shaking motion!

For the practice scene:
```
REPEAT 5 times:
  TRY the action
  WAIT 1 second
```

For the celebration:
```
GROW big
SPIN
CHANGE COLOUR
PLAY celebration sound
```

## Making It Yours
Give your robot a unique name and personality. Choose a goal that means something to you. Make the failure scene funny. End with a message you believe in.

## Quality Checklist
- Does each page connect to the one before?
- Does the robot have a consistent personality?
- Does the ending feel satisfying?
- Would a 5-year-old enjoy this?

## Sharing
Read the story aloud to someone as it plays. See if words and animation work together!
$P$,
NULL, ARRAY['scratch-jr','storytelling','animation','narrative'], 3);


INSERT INTO public.projects (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, starter_code, tags, order_index) VALUES
('exp-p04', 'Pattern Maker: My Colourful Design', 'Explorers', 'Art and Design', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Pattern Maker: My Colourful Design

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 4),
('exp-p05', 'The Alphabet Adventure App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Alphabet Adventure App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 5),
('exp-p06', 'Jungle Animal Parade', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Jungle Animal Parade

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 6),
('exp-p07', 'My Favourite Season Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Favourite Season Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 7),
('exp-p08', 'The Helpful Robot Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Helpful Robot Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 8),
('exp-p09', 'Shape Sorter Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Shape Sorter Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 9),
('exp-p10', 'Underwater World Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Underwater World Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 10),
('exp-p11', 'Space Explorer: Fly to the Moon', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Space Explorer: Fly to the Moon

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 11),
('exp-p12', 'My Family Story Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Family Story Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 12),
('exp-p13', 'The Vegetable Garden Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Vegetable Garden Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 13),
('exp-p14', 'Rainy Day Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Rainy Day Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 14),
('exp-p15', 'A Day in My Life Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: A Day in My Life Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 15),
('exp-p16', 'The Magic Forest Adventure', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Magic Forest Adventure

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 16),
('exp-p17', 'Colour Mixing Lab', 'Explorers', 'Art and Design', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Colour Mixing Lab

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 17),
('exp-p18', 'The Helpful Community Worker', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Helpful Community Worker

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 18),
('exp-p19', 'My Dream Bedroom Designer', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Dream Bedroom Designer

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 19),
('exp-p20', 'The Singing Animals Show', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Singing Animals Show

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 20),
('exp-p21', 'Planet Earth Facts Slideshow', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Planet Earth Facts Slideshow

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 21),
('exp-p22', 'The Lost Puppy Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Lost Puppy Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 22),
('exp-p23', 'Weather Report Animation', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Weather Report Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 23),
('exp-p24', 'The Olympic Sports Show', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Olympic Sports Show

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 24),
('exp-p25', 'Fruit and Vegetable Sorting Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Fruit and Vegetable Sorting Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 25),
('exp-p26', 'The Brave Little Coder Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Brave Little Coder Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 26),
('exp-p27', 'My Pet Care Guide', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Pet Care Guide

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 27),
('exp-p28', 'Dino Dance Party', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Dino Dance Party

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 28),
('exp-p29', 'The Birthday Party Planner', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Birthday Party Planner

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 29),
('exp-p30', 'Safe Online Quiz Game', 'Explorers', 'Digital Citizenship', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Safe Online Quiz Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 30),
('exp-p31', 'The Seasons Around the World', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Seasons Around the World

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 31),
('exp-p32', 'Ocean Friends Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Ocean Friends Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 32),
('exp-p33', 'The Three Little Robots', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Three Little Robots

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 33),
('exp-p34', 'My Community Helpers Book', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Community Helpers Book

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 34),
('exp-p35', 'Stars and Planets Show', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Stars and Planets Show

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 35),
('exp-p36', 'The Kindness Robot Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Kindness Robot Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 36),
('exp-p37', 'Insect World Animation', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Insect World Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 37),
('exp-p38', 'Canadian Landmarks Slideshow', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Canadian Landmarks Slideshow

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 38),
('exp-p39', 'The Recycling Helper Game', 'Explorers', 'Digital Citizenship', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Recycling Helper Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 39),
('exp-p40', 'Morning Routine Sequence Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Morning Routine Sequence Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 40),
('exp-p41', 'The Sharing Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Sharing Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 41),
('exp-p42', 'Animal Homes Animation', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Animal Homes Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 42),
('exp-p43', 'My Future Career Vision Board', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Future Career Vision Board

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 43),
('exp-p44', 'The Coding Superhero Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Coding Superhero Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 44),
('exp-p45', 'Number Patterns Explorer', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Number Patterns Explorer

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 45),
('exp-p46', 'The Friendly Dragon Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Friendly Dragon Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 46),
('exp-p47', 'Canadian Wildlife Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Canadian Wildlife Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 47),
('exp-p48', 'The Ice Cream Flavour Chooser', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Ice Cream Flavour Chooser

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 48),
('exp-p49', 'Bedtime Story Creator', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Bedtime Story Creator

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 49),
('exp-p50', 'The Classroom Rules Game', 'Explorers', 'Digital Citizenship', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Classroom Rules Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 50),
('exp-p51', 'My Heritage Story Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Heritage Story Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 51),
('exp-p52', 'The Math Helper App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Math Helper App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 52),
('exp-p53', 'Garden Growing Simulator', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Garden Growing Simulator

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 53),
('exp-p54', 'The Lighthouse Keeper Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Lighthouse Keeper Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 54),
('exp-p55', 'Safety Rules Animation', 'Explorers', 'Digital Citizenship', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Safety Rules Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 55),
('exp-p56', 'The Invention Convention', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Invention Convention

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 56),
('exp-p57', 'Emotion Faces Interactive Book', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Emotion Faces Interactive Book

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 57),
('exp-p58', 'The Good Morning Song', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Good Morning Song

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 58),
('exp-p59', 'My Favourite Book Animation', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Favourite Book Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 59),
('exp-p60', 'The Penguin Adventure', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Penguin Adventure

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 60),
('exp-p61', 'Healthy Foods Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Healthy Foods Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 61),
('exp-p62', 'The Ancient World Explorer', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Ancient World Explorer

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 62),
('exp-p63', 'My School Day Slideshow', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My School Day Slideshow

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 63),
('exp-p64', 'The Snowflake Pattern Maker', 'Explorers', 'Art and Design', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Snowflake Pattern Maker

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 64),
('exp-p65', 'Bug Catcher Game', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Bug Catcher Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 65),
('exp-p66', 'The Friendship Tree Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Friendship Tree Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 66),
('exp-p67', 'Traffic Light Game', 'Explorers', 'Digital Citizenship', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Traffic Light Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 67),
('exp-p68', 'The Singing Robot Music App', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Singing Robot Music App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 68),
('exp-p69', 'Desert Animals Animation', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Desert Animals Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 69),
('exp-p70', 'The Bedtime Routine Helper', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Bedtime Routine Helper

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 70),
('exp-p71', 'Rainbow Bridge Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Rainbow Bridge Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 71),
('exp-p72', 'The Weather Station App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Weather Station App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 72),
('exp-p73', 'My Dream Home Designer', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Dream Home Designer

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 73),
('exp-p74', 'The Brave Knight Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Brave Knight Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 74),
('exp-p75', 'Counting Coins Game', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Counting Coins Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 75),
('exp-p76', 'The Robot Bakery Animation', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Robot Bakery Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 76),
('exp-p77', 'Arctic Explorer Adventure', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Arctic Explorer Adventure

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 77),
('exp-p78', 'The Helpful Neighbours Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Helpful Neighbours Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 78),
('exp-p79', 'My Reading Log App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Reading Log App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 79),
('exp-p80', 'The City Builder Game', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The City Builder Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 80),
('exp-p81', 'Science Experiment Slideshow', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Science Experiment Slideshow

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 81),
('exp-p82', 'The Mystery Box Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Mystery Box Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 82),
('exp-p83', 'Sorting Hat Game', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Sorting Hat Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 83),
('exp-p84', 'The Explorers Map Adventure', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Explorers Map Adventure

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 84),
('exp-p85', 'My Spelling Practice App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Spelling Practice App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 85),
('exp-p86', 'The Tiny Seed Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Tiny Seed Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 86),
('exp-p87', 'The Obstacle Course Game', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Obstacle Course Game

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 87),
('exp-p88', 'Native Plants of Canada Animation', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Native Plants of Canada Animation

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 88),
('exp-p89', 'The Coding Club Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Coding Club Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 89),
('exp-p90', 'My Favourite Recipe Card', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Favourite Recipe Card

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 90),
('exp-p91', 'The Robot Gardener Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Robot Gardener Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 91),
('exp-p92', 'Star Map Interactive App', 'Explorers', 'Educational App', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Star Map Interactive App

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 92),
('exp-p93', 'The Friendship Bracelet Designer', 'Explorers', 'Art and Design', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Friendship Bracelet Designer

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 93),
('exp-p94', 'Nursery Rhyme Animator', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Nursery Rhyme Animator

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 94),
('exp-p95', 'The Biggest Dream Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Biggest Dream Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 95),
('exp-p96', 'My Award Certificate Creator', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Award Certificate Creator

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 96),
('exp-p97', 'The Time Machine Story', 'Explorers', 'Storytelling', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: The Time Machine Story

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 97),
('exp-p98', 'Explorers Portfolio Showcase', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Explorers Portfolio Showcase

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 98),
('exp-p99', 'My Best Work Exhibition', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: My Best Work Exhibition

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 99),
('exp-p100', 'Explorers Grand Finale', 'Explorers', 'Creative Coding', 'Scratch Jr', 'beginner', 40, 'published', ARRAY['Complete project requirements', 'Apply lesson concepts', 'Share your creation'], $P$# Project: Explorers Grand Finale

## What You Are Building
In this project, you will apply the coding skills you have learned to create something original and meaningful. Follow the steps below, personalise as much as possible, and test your work!

## Project Requirements
- Apply at least 3 coding concepts from recent lessons
- Personalise the project to reflect your interests
- Test your project and fix any bugs you find
- Share your finished project with someone

## Building Step by Step

Step 1 - Plan: Before coding, sketch what you want to build. What characters? What backgrounds? What will happen when the viewer interacts?

Step 2 - Build: Start with the simplest version. Get the basics working before adding extras. Remember: sequence, loops, and conditions!

Step 3 - Test: Run your project and look for bugs. Fix anything that does not work as planned. Use the rubber duck method if you get stuck.

Step 4 - Improve: Add one creative element that was not in the original plan. What makes YOUR version special?

Step 5 - Share: Show your finished project to a family member or friend. Explain what you built and how you built it.

## Extension Challenges
- Add sound effects or background music
- Add an extra scene or page
- Make it interactive with buttons the viewer can tap
- Teach a younger child how to use your creation

## Reflection
After completing this project:
- What was the hardest part?
- What are you most proud of?
- What would you do differently next time?
- What coding concepts did you use?$P$, NULL, ARRAY['scratch-jr','creative','K-1'], 100);
