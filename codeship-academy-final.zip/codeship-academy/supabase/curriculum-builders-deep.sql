-- ═══════════════════════════════════════════════════════════════════════════
-- CODEship Academy: BUILDERS Deep Lesson Content — Lessons 16–100
-- Replaces stub content with full educational lessons
-- Run AFTER curriculum-builders.sql
-- ═══════════════════════════════════════════════════════════════════════════

-- Remove stub lessons 16-100
DELETE FROM public.lessons WHERE level = 'Builders' AND order_index >= 16;

-- ═══════════════════════════════════════════════════════════════════════════
-- LESSONS 16–40: CSS ADVANCED + HTML ACCESSIBILITY
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l16', 'CSS Pseudo-Classes: Styling Interactive States', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Use :hover, :focus, :active on interactive elements','Apply structural pseudo-classes like :first-child and :nth-child','Create a fully interactive button and form with state styles'],
$L$# CSS Pseudo-Classes: Styling Interactive States

## What Is a Pseudo-Class?

A **pseudo-class** is a keyword added to a CSS selector that lets you style an element based on its **state** or **position** — without adding a class to the HTML.

```css
selector:pseudo-class { ... }
```

They're called "pseudo" because the class doesn't actually exist in your HTML — CSS generates it automatically based on what's happening.

## Interaction Pseudo-Classes

These respond to user actions:

### `:hover` — When the mouse is over an element
```css
.btn:hover {
  background-color: #E6B800;
  transform: translateY(-2px);
}

a:hover {
  color: #F5C518;
  text-decoration: underline;
}

.card:hover {
  box-shadow: 0 12px 32px rgba(0,0,0,0.15);
}
```

`:hover` is the most used pseudo-class. Use it on anything clickable: links, buttons, cards, nav items.

### `:focus` — When an element has keyboard/input focus
```css
input:focus {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
  border-color: #F5C518;
}

button:focus {
  outline: 3px solid #1E2140;
  outline-offset: 2px;
}
```

**Critical for accessibility:** Never remove the focus outline completely with `outline: none` unless you replace it with something equally visible. Keyboard users (including many people with disabilities) rely on the focus indicator to know where they are on the page.

```css
/* DO THIS - custom visible focus */
:focus-visible {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
}

/* DON'T DO THIS - removes all focus indicators */
* { outline: none; } /* ← ACCESSIBILITY VIOLATION */
```

### `:active` — While an element is being clicked/pressed
```css
.btn:active {
  transform: translateY(0); /* Cancels the hover lift */
  box-shadow: none;
  background-color: #C9A010;
}
```

The `:active` state lasts only for the moment the mouse button is held down. Use it to create a "pressed" feeling on buttons.

### `:visited` — A link that has already been clicked
```css
a:visited {
  color: #8B90B0;
}
```

Browsers automatically track which links you've visited. `:visited` lets you style them differently so users know where they've already been.

### `:focus-within` — When a child element has focus
```css
.form-group:focus-within {
  background-color: #FFFBEB;
  border-left: 3px solid #F5C518;
}
```

Useful for highlighting entire form sections when the user is inside them.

## Structural Pseudo-Classes

These select elements based on their position in the document:

### `:first-child` and `:last-child`
```css
li:first-child {
  font-weight: bold;     /* Make the first list item bold */
  color: #1E2140;
}

li:last-child {
  border-bottom: none;   /* Remove border from last item */
}
```

### `:nth-child()` — Every N items
```css
/* Zebra striping on table rows */
tr:nth-child(even) {
  background-color: #F8F9FE;
}
tr:nth-child(odd) {
  background-color: white;
}

/* Every 3rd item */
li:nth-child(3n) {
  color: #F5C518;
}

/* The 5th item specifically */
li:nth-child(5) {
  font-weight: 900;
}

/* Items from the 3rd onwards */
li:nth-child(n+3) {
  opacity: 0.6;
}
```

### `:nth-of-type()` — Like nth-child but only counts that element type
```css
/* Second paragraph, ignoring other element types */
p:nth-of-type(2) {
  font-size: 1.2em;
}
```

### `:only-child` — An element with no siblings
```css
li:only-child {
  list-style: none; /* No bullet if only one item */
}
```

### `:not()` — Everything EXCEPT what's inside
```css
/* All buttons except disabled ones */
button:not([disabled]) {
  cursor: pointer;
}

/* All list items except the last */
li:not(:last-child) {
  border-bottom: 1px solid #eee;
}

/* All inputs except submit and hidden */
input:not([type="submit"]):not([type="hidden"]) {
  border: 1px solid #ccc;
  padding: 8px;
}
```

## Form Pseudo-Classes

```css
/* Required fields */
input:required {
  border-left: 3px solid #EF4444;
}

/* Valid input */
input:valid {
  border-color: #22C55E;
}

/* Invalid input (only shows after interaction) */
input:invalid {
  border-color: #EF4444;
}

/* Disabled inputs */
input:disabled {
  background-color: #F0F0F0;
  cursor: not-allowed;
  opacity: 0.6;
}

/* Checked checkboxes */
input[type="checkbox"]:checked + label {
  color: #22C55E;
  font-weight: bold;
}

/* Placeholder text */
input::placeholder {
  color: #B0B4D0;
  font-style: italic;
}
```

## The Anchor Link Order: LVHA

For anchor (`<a>`) tags, you must declare the pseudo-classes in this specific order:

```css
a:link    { color: #1E2140; }     /* Unvisited links */
a:visited { color: #8B90B0; }     /* Visited links */
a:hover   { color: #F5C518; }     /* Mouse over */
a:active  { color: #C9A010; }     /* Being clicked */
```

The mnemonic: **L**o**V**e **HA**te (LVHA). If you write them in a different order, some states may not work correctly due to CSS specificity.

## Building a Professional Button System

```html
<button class="btn btn-primary">Primary Action</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-outline">Outline</button>
<button class="btn btn-primary" disabled>Disabled</button>
```

```css
.btn {
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 700;
  font-size: 1rem;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.2s ease;
  display: inline-block;
  text-decoration: none;
}

/* Primary */
.btn-primary {
  background: #F5C518;
  color: #1E2140;
}
.btn-primary:hover {
  background: #E6B800;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(245,197,24,0.4);
}
.btn-primary:active {
  transform: translateY(0);
  box-shadow: none;
}
.btn-primary:focus-visible {
  outline: 3px solid #1E2140;
  outline-offset: 2px;
}

/* Disabled state - all buttons */
.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none !important;
  box-shadow: none !important;
}
```

## Interactive Form Styling

```css
.form-group {
  margin-bottom: 20px;
  padding: 16px;
  border-radius: 8px;
  border: 2px solid transparent;
  transition: all 0.2s ease;
}

.form-group:focus-within {
  border-color: #F5C518;
  background-color: #FFFBEB;
}

.form-group label {
  display: block;
  margin-bottom: 6px;
  font-weight: 700;
  color: #1E2140;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 10px 14px;
  border: 2px solid #E8EAF6;
  border-radius: 6px;
  font-size: 1rem;
  transition: border-color 0.2s ease;
}

.form-group input:focus {
  outline: none;
  border-color: #F5C518;
}

.form-group input:valid:not(:placeholder-shown) {
  border-color: #22C55E;
}

.form-group input:invalid:not(:placeholder-shown) {
  border-color: #EF4444;
}
```

## Key Takeaways 🌟

1. Pseudo-classes style elements based on **state** or **position** without adding HTML classes
2. Interaction pseudo-classes: `:hover`, `:focus`, `:active`, `:visited`
3. Structural pseudo-classes: `:first-child`, `:last-child`, `:nth-child()`, `:not()`
4. **Never remove focus styles** — replace them with a visible alternative for accessibility
5. `:focus-visible` is better than `:focus` — only shows for keyboard navigation, not mouse clicks
6. The LVHA order matters for anchor tag pseudo-classes
7. Form pseudo-classes (`:valid`, `:invalid`, `:required`, `:disabled`) enable powerful UX
8. Combine pseudo-classes for specific targeting: `li:not(:last-child):hover`
$L$,
ARRAY['css','pseudo-classes','hover','focus','accessibility','forms'], 16),

('bld-l17', 'CSS Custom Properties: Building a Design Token System', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Create and use CSS custom properties throughout a stylesheet','Build a complete design token system','Implement a dark mode toggle using CSS variables'],
$L$# CSS Custom Properties: Building a Design Token System

## The Problem CSS Variables Solve

Imagine your website uses the colour `#1E2140` (your navy blue) in 47 different places across your CSS. Your client calls and says "we're rebranding — change the navy to dark green." Without CSS variables, you'd find and replace 47 instances, probably missing some.

With CSS variables, you change **one line** and everything updates everywhere.

## CSS Custom Properties Syntax

Custom properties (CSS variables) are defined with two dashes before the name:

```css
:root {
  --colour-primary: #1E2140;
  --colour-accent: #F5C518;
  --font-size-base: 16px;
  --spacing-md: 16px;
}
```

Used with the `var()` function:

```css
button {
  background-color: var(--colour-accent);
  color: var(--colour-primary);
  padding: var(--spacing-md);
  font-size: var(--font-size-base);
}
```

## The `:root` Selector

`:root` is a pseudo-class that matches the root element of the document (the `<html>` element). Using it to define variables makes them **globally available** — accessible from any rule anywhere in your CSS.

```css
:root {
  --my-variable: value;
}

/* Now --my-variable works anywhere below */
.any-element {
  property: var(--my-variable);
}
```

## Fallback Values

The `var()` function accepts a second argument — a fallback value used if the variable doesn't exist:

```css
.element {
  color: var(--colour-text, #333);         /* Falls back to #333 */
  font-size: var(--font-size-body, 1rem);  /* Falls back to 1rem */
}
```

## Variables Can Reference Other Variables

```css
:root {
  --hue: 230;
  --saturation: 40%;
  --colour-base: hsl(var(--hue), var(--saturation), 20%);
  --colour-light: hsl(var(--hue), var(--saturation), 90%);
}
```

## Building a Complete Design Token System

Design tokens are the building blocks of a design system — the single source of truth for every design decision.

```css
:root {
  /* ── Colours ──────────────────────────── */
  /* Brand */
  --colour-navy: #1E2140;
  --colour-navy-light: #3A3D5C;
  --colour-gold: #F5C518;
  --colour-gold-dark: #C9A010;

  /* Semantic (what colours MEAN, not what they are) */
  --colour-primary: var(--colour-navy);
  --colour-primary-hover: var(--colour-navy-light);
  --colour-accent: var(--colour-gold);
  --colour-accent-hover: var(--colour-gold-dark);

  /* Text */
  --colour-text: #2B2D42;
  --colour-text-muted: #8B90B0;
  --colour-text-inverse: #FFFFFF;

  /* Backgrounds */
  --colour-bg: #F8F9FE;
  --colour-bg-card: #FFFFFF;
  --colour-bg-subtle: #EEF0FA;

  /* Status */
  --colour-success: #22C55E;
  --colour-warning: #F59E0B;
  --colour-error: #EF4444;
  --colour-info: #0EA5E9;

  /* ── Typography ────────────────────────── */
  --font-sans: 'Nunito', system-ui, sans-serif;
  --font-mono: 'Courier New', monospace;

  --text-xs: 0.75rem;     /* 12px */
  --text-sm: 0.875rem;    /* 14px */
  --text-base: 1rem;      /* 16px */
  --text-lg: 1.125rem;    /* 18px */
  --text-xl: 1.25rem;     /* 20px */
  --text-2xl: 1.5rem;     /* 24px */
  --text-3xl: 1.875rem;   /* 30px */
  --text-4xl: 2.25rem;    /* 36px */

  --font-normal: 400;
  --font-semibold: 600;
  --font-bold: 700;
  --font-black: 900;

  --leading-tight: 1.25;
  --leading-normal: 1.5;
  --leading-relaxed: 1.75;

  /* ── Spacing ───────────────────────────── */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;

  /* ── Borders ───────────────────────────── */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-2xl: 24px;
  --radius-full: 9999px;

  --border-width: 1px;
  --border-colour: #E8EAF6;

  /* ── Shadows ───────────────────────────── */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
  --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.12);
  --shadow-xl: 0 16px 48px rgba(0, 0, 0, 0.16);

  /* ── Transitions ───────────────────────── */
  --transition-fast: 0.15s ease;
  --transition-normal: 0.25s ease;
  --transition-slow: 0.4s ease;

  /* ── Layout ────────────────────────────── */
  --container-max: 1200px;
  --container-padding: var(--space-6);
}
```

Now use all these tokens in your components:

```css
body {
  font-family: var(--font-sans);
  font-size: var(--text-base);
  color: var(--colour-text);
  background-color: var(--colour-bg);
  line-height: var(--leading-normal);
}

.card {
  background: var(--colour-bg-card);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-md);
  border: var(--border-width) solid var(--border-colour);
}

.card:hover {
  box-shadow: var(--shadow-lg);
  transition: box-shadow var(--transition-normal);
}

.btn-primary {
  background-color: var(--colour-accent);
  color: var(--colour-primary);
  padding: var(--space-3) var(--space-6);
  border-radius: var(--radius-md);
  font-weight: var(--font-bold);
  font-size: var(--text-base);
  transition: all var(--transition-fast);
}

.btn-primary:hover {
  background-color: var(--colour-accent-hover);
}
```

## Dark Mode with CSS Variables

The most powerful use of CSS variables is implementing dark mode:

```css
/* Light mode (default) */
:root {
  --colour-bg: #F8F9FE;
  --colour-bg-card: #FFFFFF;
  --colour-text: #2B2D42;
  --colour-text-muted: #8B90B0;
  --colour-border: #E8EAF6;
}

/* Dark mode — only redefine what changes! */
:root[data-theme="dark"],
@media (prefers-colour-scheme: dark) {
  :root {
    --colour-bg: #0F1117;
    --colour-bg-card: #1A1D2E;
    --colour-text: #E8EAF6;
    --colour-text-muted: #6B7280;
    --colour-border: #2D3148;
  }
}
```

Everything else stays the same — your buttons, cards, and layouts automatically use the updated values!

**Toggle dark mode with JavaScript:**

```html
<button onclick="toggleDark()">🌙 Toggle Dark Mode</button>

<script>
function toggleDark() {
  const current = document.documentElement.getAttribute('data-theme');
  document.documentElement.setAttribute(
    'data-theme', 
    current === 'dark' ? 'light' : 'dark'
  );
}
</script>
```

## Variables Have Scope

Variables defined on a selector only work inside that element:

```css
:root {
  --colour: #1E2140;  /* Works everywhere */
}

.card {
  --colour: #F5C518;  /* Only works inside .card */
}

/* Inside .card, --colour is gold; outside, it's navy */
```

This enables component-level theming without global interference!

## Inspecting Variables in DevTools

Chrome DevTools (F12) shows computed CSS variable values in the Styles panel. When you hover over `var(--colour-primary)`, it shows the resolved value. This makes debugging design token issues much faster.

## Key Takeaways 🌟

1. CSS custom properties are defined with `--name: value` and used with `var(--name)`
2. Define global variables on `:root` so they're available everywhere
3. Variables can reference other variables
4. `var(--name, fallback)` provides a default if the variable doesn't exist
5. Design tokens separate **what something is** (colour values) from **what it means** (primary, accent)
6. Dark mode is easiest with CSS variables — just redefine colours under `prefers-colour-scheme: dark`
7. Variables have scope — local variables override global ones inside their element
8. A design token system makes your CSS maintainable as it grows
$L$,
ARRAY['css','custom-properties','variables','design-system','dark-mode'], 17),

('bld-l18', 'Navigation Patterns: Tabs, Dropdowns, and Sidebars', 'CSS', 'HTML', 'intermediate', 35, 'published',
ARRAY['Build accessible tab navigation with HTML and CSS','Create a CSS-only dropdown menu','Understand the difference between horizontal and sidebar navigation'],
$L$# Navigation Patterns: Tabs, Dropdowns, and Sidebars

## Navigation Is UX

Navigation is how users find what they're looking for. Good navigation is invisible — users don't think about it; they just find things. Bad navigation is a wall people bounce off.

There are three major navigation patterns you'll encounter constantly in web development. Let's build all three.

## Pattern 1: Tab Navigation

Tabs organise content into groups on the same page. Common on dashboards, settings pages, and product pages.

```html
<div class="tabs">
  <div class="tab-list" role="tablist" aria-label="Course levels">
    <button class="tab active" role="tab" aria-selected="true" 
            data-tab="explorers">Explorers</button>
    <button class="tab" role="tab" aria-selected="false" 
            data-tab="builders">Builders</button>
    <button class="tab" role="tab" aria-selected="false" 
            data-tab="developers">Developers</button>
    <button class="tab" role="tab" aria-selected="false" 
            data-tab="engineers">Engineers</button>
  </div>

  <div class="tab-panel active" id="panel-explorers">
    <h2>Explorers — Ages 6-7, Grades K-1</h2>
    <p>Block coding, patterns, algorithms, and digital citizenship.</p>
  </div>
  <div class="tab-panel" id="panel-builders">
    <h2>Builders — Ages 8-9, Grades 2-3</h2>
    <p>HTML, CSS, web design, and Scratch.</p>
  </div>
  <div class="tab-panel" id="panel-developers">
    <h2>Developers — Ages 10-12, Grades 4-6</h2>
    <p>JavaScript, DOM manipulation, APIs, and React basics.</p>
  </div>
  <div class="tab-panel" id="panel-engineers">
    <h2>Engineers — Ages 13-16, Grades 7-8</h2>
    <p>Python, Flask, SQL, Git, and machine learning.</p>
  </div>
</div>
```

```css
.tabs { font-family: var(--font-sans, system-ui); }

.tab-list {
  display: flex;
  border-bottom: 2px solid #E8EAF6;
  gap: 0;
}

.tab {
  padding: 12px 24px;
  border: none;
  background: none;
  font-size: 0.95rem;
  font-weight: 600;
  color: #8B90B0;
  cursor: pointer;
  position: relative;
  transition: color 0.2s ease;
  border-bottom: 3px solid transparent;
  margin-bottom: -2px; /* Overlaps the container border */
}

.tab:hover { color: #1E2140; }

.tab.active {
  color: #1E2140;
  border-bottom-color: #F5C518;
}

.tab-panel { display: none; padding: 24px 0; }
.tab-panel.active { display: block; }
```

**Making tabs work with JavaScript:**
```javascript
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    // Remove active from all tabs and panels
    document.querySelectorAll('.tab').forEach(t => {
      t.classList.remove('active');
      t.setAttribute('aria-selected', 'false');
    });
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));

    // Activate clicked tab
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    document.getElementById('panel-' + tab.dataset.tab).classList.add('active');
  });
});
```

## Pattern 2: Dropdown Navigation

Dropdowns reveal sub-items when hovering over a parent nav item:

```html
<nav class="dropdown-nav" aria-label="Main navigation">
  <ul>
    <li><a href="/">Home</a></li>
    <li class="has-dropdown">
      <a href="/courses" aria-haspopup="true" aria-expanded="false">Courses ▾</a>
      <ul class="dropdown" role="menu">
        <li><a href="/explorers" role="menuitem">Explorers (K-1)</a></li>
        <li><a href="/builders" role="menuitem">Builders (Gr 2-3)</a></li>
        <li><a href="/developers" role="menuitem">Developers (Gr 4-6)</a></li>
        <li><a href="/engineers" role="menuitem">Engineers (Gr 7-8)</a></li>
      </ul>
    </li>
    <li><a href="/school">Schools</a></li>
    <li><a href="/about">About</a></li>
  </ul>
</nav>
```

```css
.dropdown-nav ul {
  display: flex;
  list-style: none;
  padding: 0;
  margin: 0;
  gap: 0;
}

.dropdown-nav li {
  position: relative; /* Crucial for positioning the dropdown! */
}

.dropdown-nav a {
  display: block;
  padding: 16px 20px;
  color: white;
  text-decoration: none;
  font-weight: 600;
  white-space: nowrap;
  transition: background-color 0.2s ease;
}

.dropdown-nav > ul > li > a:hover {
  background-color: rgba(255,255,255,0.1);
}

/* The dropdown panel */
.dropdown {
  position: absolute;
  top: 100%;      /* Directly below the parent */
  left: 0;
  background-color: white;
  border-radius: 0 0 12px 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
  min-width: 200px;
  flex-direction: column !important;
  gap: 0 !important;

  /* Hidden by default */
  display: none;
  opacity: 0;
  transform: translateY(-8px);
  transition: opacity 0.2s ease, transform 0.2s ease;
}

/* Show on hover */
.has-dropdown:hover .dropdown {
  display: flex;
  opacity: 1;
  transform: translateY(0);
}

.dropdown a {
  color: #1E2140;
  padding: 12px 20px;
  font-size: 0.9rem;
}

.dropdown a:hover {
  background-color: #F8F9FE;
  color: #F5C518;
}
```

## Pattern 3: Sidebar Navigation

Sidebar navigation shows a persistent list of links on the side of the page — common in dashboards and admin panels:

```html
<div class="app-layout">
  <aside class="sidebar" aria-label="Dashboard navigation">
    <div class="sidebar-logo">🚀 CODEship</div>
    <nav>
      <ul>
        <li>
          <a href="/dashboard" class="nav-item active">
            <span class="icon">🏠</span>
            <span class="label">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="/curriculum" class="nav-item">
            <span class="icon">📚</span>
            <span class="label">Curriculum</span>
          </a>
        </li>
        <li>
          <a href="/progress" class="nav-item">
            <span class="icon">📊</span>
            <span class="label">Progress</span>
          </a>
        </li>
        <li>
          <a href="/settings" class="nav-item">
            <span class="icon">⚙️</span>
            <span class="label">Settings</span>
          </a>
        </li>
      </ul>
    </nav>
  </aside>
  <main class="main-content">
    <!-- Page content here -->
  </main>
</div>
```

```css
.app-layout {
  display: flex;
  min-height: 100vh;
}

.sidebar {
  width: 240px;
  background-color: #1E2140;
  padding: 24px 0;
  flex-shrink: 0; /* Don't let it shrink */
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
}

.sidebar-logo {
  color: white;
  font-size: 1.2rem;
  font-weight: 900;
  padding: 0 24px 24px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  margin-bottom: 16px;
}

.sidebar ul { list-style: none; padding: 0; margin: 0; }

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 24px;
  color: rgba(255,255,255,0.6);
  text-decoration: none;
  font-weight: 600;
  font-size: 0.9rem;
  transition: all 0.2s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  color: white;
  background-color: rgba(255,255,255,0.05);
}

.nav-item.active {
  color: #F5C518;
  background-color: rgba(245,197,24,0.1);
  border-left-color: #F5C518;
}

.nav-item .icon { font-size: 1.2rem; flex-shrink: 0; }

.main-content {
  flex: 1;
  padding: 40px;
  background-color: #F8F9FE;
  overflow-y: auto;
}

/* Responsive: hide sidebar on mobile */
@media (max-width: 768px) {
  .sidebar { display: none; }
}
```

## Key Takeaways 🌟

1. **Tabs** organise content groups on the same page — need JavaScript to switch panels
2. **Dropdowns** reveal sub-navigation on hover — use `position: relative` on parent, `position: absolute` on dropdown
3. **Sidebars** provide persistent navigation — use flexbox with `position: sticky` on the aside
4. Always include ARIA attributes (`role`, `aria-selected`, `aria-haspopup`) for accessibility
5. The active state (currently selected item) should be visually distinct
6. `position: relative` on the parent is what makes `position: absolute` children position correctly relative to it
7. Consider mobile — sidebars and dropdowns need rethinking on small screens
$L$,
ARRAY['css','navigation','tabs','dropdown','sidebar','accessibility'], 18),

('bld-l19', 'CSS Gradients: Beautiful Backgrounds', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Write linear and radial gradient syntax','Create multi-stop gradients','Use gradients for buttons, headers, and backgrounds'],
$L$# CSS Gradients: Beautiful Backgrounds

## Beyond Flat Colours

Flat colours are clean and modern, but gradients add depth, personality, and visual interest to designs. Modern websites use gradients extensively — from subtle background washes to bold hero sections to button states.

CSS gradients create smooth transitions between two or more colours entirely in code — no image files needed. This makes them fast-loading and fully scalable.

## Linear Gradients

A **linear gradient** transitions colours along a straight line:

```css
background: linear-gradient(direction, colour1, colour2, ...);
```

### Direction Options

```css
/* By angle */
background: linear-gradient(0deg, #1E2140, #3A3D5C);    /* Bottom to top */
background: linear-gradient(90deg, #1E2140, #3A3D5C);   /* Left to right */
background: linear-gradient(135deg, #1E2140, #F5C518);  /* Diagonal */
background: linear-gradient(45deg, #1E2140, #F5C518);   /* Other diagonal */

/* By keyword */
background: linear-gradient(to right, #1E2140, #F5C518);
background: linear-gradient(to bottom, #1E2140, #F5C518);
background: linear-gradient(to bottom right, #1E2140, #F5C518);
```

### Multiple Colour Stops

```css
/* Three colours */
background: linear-gradient(135deg, #1E2140 0%, #7C3AED 50%, #F5C518 100%);

/* Controlling stop positions */
background: linear-gradient(to right,
  #EF4444 0%,
  #F59E0B 25%,
  #22C55E 50%,
  #0EA5E9 75%,
  #7C3AED 100%
);

/* Sharp colour change (no blend) */
background: linear-gradient(to right,
  #1E2140 50%,
  #F5C518 50%  /* Both at 50% = hard edge */
);
```

## Radial Gradients

**Radial gradients** radiate outward from a centre point:

```css
background: radial-gradient(shape size at position, colour1, colour2);

/* Basic: circle from centre */
background: radial-gradient(circle, #F5C518, #1E2140);

/* Ellipse */
background: radial-gradient(ellipse, #F5C518, #1E2140);

/* Position the centre */
background: radial-gradient(circle at top left, #F5C518, #1E2140);
background: radial-gradient(circle at 25% 75%, #F5C518, #1E2140);
```

## Conic Gradients

**Conic gradients** rotate colours around a centre point:

```css
/* Colour wheel */
background: conic-gradient(red, yellow, green, blue, red);

/* Pie chart effect */
background: conic-gradient(
  #EF4444 0% 30%,   /* 30% red */
  #F5C518 30% 65%,  /* 35% yellow */
  #22C55E 65% 100%  /* 35% green */
);
border-radius: 50%; /* Make it circular */
```

## Transparent Gradients

Gradients to/from transparent are extremely useful:

```css
/* Text that fades out at the bottom */
.fade-text {
  -webkit-mask-image: linear-gradient(to bottom, black 50%, transparent 100%);
  mask-image: linear-gradient(to bottom, black 50%, transparent 100%);
}

/* Overlay on a photo for text readability */
.hero {
  background-image:
    linear-gradient(to bottom, rgba(30,33,64,0) 0%, rgba(30,33,64,0.8) 100%),
    url('hero.jpg');
  background-size: cover;
}

/* Side fade for horizontal scroll indicators */
.scroll-container::after {
  content: '';
  position: absolute;
  right: 0; top: 0; bottom: 0;
  width: 60px;
  background: linear-gradient(to right, transparent, white);
  pointer-events: none;
}
```

## Animated Gradients

Gradients themselves can't animate (you can't transition between gradient values), but you can animate the background position of a large gradient:

```css
.animated-bg {
  background: linear-gradient(300deg, #1E2140, #7C3AED, #F5C518, #1E2140);
  background-size: 300% 300%;
  animation: gradientShift 8s ease infinite;
}

@keyframes gradientShift {
  0%   { background-position: 0% 50%; }
  50%  { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
```

## Practical Gradient Recipes

### Hero Section
```css
.hero {
  background: linear-gradient(135deg, #1E2140 0%, #3A3D5C 50%, #1E2140 100%);
  color: white;
  padding: 100px 40px;
}
```

### Gold Accent Button
```css
.btn-gradient {
  background: linear-gradient(135deg, #F5C518, #E6A800);
  color: #1E2140;
  border: none;
  padding: 12px 28px;
  border-radius: 8px;
  font-weight: 900;
}
.btn-gradient:hover {
  background: linear-gradient(135deg, #E6A800, #C98900);
}
```

### Subtle Card Background
```css
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #F8F9FE 100%);
  border: 1px solid #E8EAF6;
}
```

### Progress Bar
```css
.progress-fill {
  background: linear-gradient(90deg, #22C55E, #16A34A);
  height: 8px;
  border-radius: 4px;
  width: 65%; /* The percentage complete */
}
```

## Key Takeaways 🌟

1. CSS gradients create smooth colour transitions in code — no image files needed
2. `linear-gradient()` goes in a straight line; `radial-gradient()` radiates from a point
3. Control direction with degrees (0deg, 90deg, 135deg) or keywords (to right, to bottom)
4. Add multiple colour stops for complex gradients: `colour1 0%, colour2 50%, colour3 100%`
5. Gradients to `transparent` create beautiful overlay effects on photos
6. Animated gradients use `background-size` and `background-position` animation
7. Conic gradients create pie charts and colour wheels
8. Find gradient inspiration at uigradients.com and cssgradient.io
$L$,
ARRAY['css','gradients','backgrounds','visual-design'], 19),

('bld-l20', 'CSS Shadows and Depth: Creating Visual Hierarchy', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Apply box-shadow to create depth and elevation','Use text-shadow for typography effects','Understand when and how to use shadows for good UX'],
$L$# CSS Shadows and Depth: Creating Visual Hierarchy

## Why Shadows Matter

Shadows are a visual shortcut that communicates **hierarchy and depth**. When an element casts a shadow, it appears elevated above the surface — it feels important, touchable, and interactive.

Google's Material Design built an entire design language around elevation (depth via shadows). Apple's interface uses shadows to separate layers. Every modern UI uses shadows thoughtfully.

The key word is *thoughtfully*. The most common mistake is using shadows that are too dark, too large, or used everywhere without purpose.

## `box-shadow` Syntax

```css
box-shadow: offset-x offset-y blur-radius spread-radius colour;
```

```css
/* Example values */
box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
/*           ↑   ↑    ↑        ↑
           x-offset y-offset blur  opacity */
```

| Parameter | Description | Typical value |
|-----------|-------------|---------------|
| `offset-x` | Horizontal shadow offset | `0` (no offset = centred shadow) |
| `offset-y` | Vertical shadow offset | `4px` (positive = shadow below) |
| `blur-radius` | How soft/blurry the shadow is | `8–32px` |
| `spread-radius` | Makes shadow larger/smaller | Usually `0` or omitted |
| `colour` | Shadow colour | `rgba(0,0,0,0.1)` |

## Elevation System

Professional UIs use a consistent set of shadow "levels" — from barely-there to dramatically floating:

```css
:root {
  /* No shadow: flat surface */
  --shadow-0: none;

  /* Level 1: Slightly raised (form inputs, subtle cards) */
  --shadow-1: 0 1px 3px rgba(0, 0, 0, 0.08);

  /* Level 2: Cards, dropdowns */
  --shadow-2: 0 4px 12px rgba(0, 0, 0, 0.08);

  /* Level 3: Modals, floating panels */
  --shadow-3: 0 8px 24px rgba(0, 0, 0, 0.12);

  /* Level 4: Tooltips, popovers */
  --shadow-4: 0 16px 48px rgba(0, 0, 0, 0.16);

  /* Level 5: Critical modals, alerts */
  --shadow-5: 0 24px 64px rgba(0, 0, 0, 0.24);
}
```

Apply elevation contextually:
```css
.input    { box-shadow: var(--shadow-1); }
.card     { box-shadow: var(--shadow-2); }
.dropdown { box-shadow: var(--shadow-3); }
.modal    { box-shadow: var(--shadow-4); }

/* Increase on hover to feel more elevated */
.card:hover { box-shadow: var(--shadow-3); }
```

## Multiple Shadows

`box-shadow` accepts comma-separated multiple shadows, applied from front to back:

```css
.card {
  box-shadow:
    0 2px 4px rgba(0,0,0,0.05),   /* Close, sharp */
    0 8px 24px rgba(0,0,0,0.08);  /* Distant, diffuse */
}
```

Multiple shadows create more realistic, layered depth that looks closer to how shadows actually work in the real world.

## Coloured Shadows

Shadows don't have to be grey. Coloured shadows create beautiful brand-specific effects:

```css
/* Gold glow for accent buttons */
.btn-primary:hover {
  box-shadow: 0 6px 24px rgba(245, 197, 24, 0.45);
}

/* Blue glow for info elements */
.alert-info {
  box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.25);
}

/* Red glow for errors */
.input:invalid:focus {
  box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.25);
}

/* Purple brand shadow */
.premium-card {
  box-shadow: 0 8px 32px rgba(124, 58, 237, 0.2);
}
```

## Inset Shadows

Add `inset` to create a shadow inside the element — useful for "pressed" states and recessed inputs:

```css
/* Makes the element look pressed in */
.btn:active {
  box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.2);
}

/* Recessed input field */
input {
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.06);
  border: 1px solid #E8EAF6;
}

/* Inner glow on focus */
input:focus {
  box-shadow:
    inset 0 2px 4px rgba(0, 0, 0, 0.06),
    0 0 0 3px rgba(245, 197, 24, 0.25);
}
```

## text-shadow

Text can also cast shadows:

```css
text-shadow: offset-x offset-y blur-radius colour;

/* Subtle text lift */
h1 { text-shadow: 0 2px 4px rgba(0,0,0,0.15); }

/* White text on busy background */
.overlay-text {
  text-shadow: 0 1px 8px rgba(0,0,0,0.6);
}

/* Glowing text effect */
.glowing {
  text-shadow:
    0 0 10px #F5C518,
    0 0 20px #F5C518,
    0 0 40px #F5C518;
}

/* Retro letterpress effect */
.letterpress {
  color: #1E2140;
  text-shadow: 0 1px 0 rgba(255,255,255,0.4);
}
```

## The "Bounding" Shadow Pattern

A ring shadow creates a visible border without affecting layout (unlike border, which adds to element size):

```css
/* Focus ring that doesn't affect layout */
:focus-visible {
  box-shadow: 0 0 0 3px #F5C518;
}

/* Selection indicator */
.option.selected {
  box-shadow: 0 0 0 2px #1E2140, 0 0 0 4px #F5C518;
}
```

## Key Takeaways 🌟

1. Shadows communicate elevation — elements with shadows feel raised and important
2. `box-shadow` syntax: `offset-x offset-y blur spread colour`
3. Use `rgba()` colours with low opacity (0.05–0.2) for realistic shadows
4. Build an elevation system — consistent shadow levels for consistent UI
5. Multiple comma-separated shadows create more realistic depth
6. Coloured shadows add personality and brand specificity
7. `inset` creates pressed-in or recessed effects
8. `text-shadow` adds depth to typography
9. The "ring" pattern (`0 0 0 Npx colour`) creates borders without layout impact
$L$,
ARRAY['css','shadows','depth','elevation','visual-hierarchy'], 20),

('bld-l21', 'HTML Accessibility: Building the Web for Everyone', 'Accessibility', 'HTML', 'intermediate', 35, 'published',
ARRAY['Explain why web accessibility is essential','Use ARIA attributes to enhance screen reader experience','Test a webpage for basic accessibility issues'],
$L$# HTML Accessibility: Building the Web for Everyone

## Who Is the Web For?

When you build a website, who can use it?

If your answer is "anyone with a screen and internet," you might be surprised. Approximately **15% of the world's population** — over 1 billion people — live with some form of disability. Many of them use the web daily, but poorly built websites lock them out.

**Web accessibility** means designing and building websites that can be used by everyone, including people with:

- **Visual impairments** — blindness, low vision, colour blindness
- **Motor impairments** — limited hand control, unable to use a mouse
- **Cognitive differences** — dyslexia, ADHD, autism
- **Hearing impairments** — deaf or hard of hearing
- **Situational impairments** — holding a baby, bright sunlight, slow internet

The truth is, accessibility benefits everyone. Captions help people in noisy environments. High contrast helps people in bright sunlight. Keyboard navigation helps power users who prefer keyboards to mice.

## How Assistive Technology Works

**Screen readers** are software that reads webpages aloud. Popular options: NVDA (free, Windows), JAWS (paid, Windows), VoiceOver (built into macOS/iOS), TalkBack (built into Android).

Screen readers navigate HTML elements in order — from top to bottom. They announce element types: "heading level 2: Builders Level" or "button: Submit Form" or "image: A student coding at a laptop."

Your HTML structure IS the screen reader experience. If your HTML is semantic and well-structured, screen readers work beautifully. If it's a mess of divs with no hierarchy, it's incomprehensible.

## The Four Principles of Accessibility (POUR)

The **Web Content Accessibility Guidelines (WCAG)** — the international standard for web accessibility — are built on four principles:

**P — Perceivable:** Users can perceive all content (text alternatives for images, captions for video)

**O — Operable:** Users can operate the interface (keyboard navigable, no time limits)

**U — Understandable:** Content is readable and predictable

**R — Robust:** Content works with different assistive technologies

## Essential Accessible HTML Practices

### 1. Use Semantic HTML (You Already Know This!)

```html
<!-- Bad: everything is a div -->
<div class="header">
  <div class="nav">
    <div class="nav-link">Home</div>
  </div>
</div>

<!-- Good: semantic elements announce their role -->
<header>
  <nav>
    <a href="/">Home</a>
  </nav>
</header>
```

Screen readers announce: "Navigation landmark" — users know they're in a navigation region.

### 2. Write Meaningful Alt Text

```html
<!-- Decorative image: empty alt, screen readers skip it -->
<img src="divider.png" alt="">

<!-- Informative image: describe what it shows -->
<img src="student-coding.jpg" alt="A smiling Grade 4 student typing code on a laptop">

<!-- Functional image (in a link): describe the destination -->
<a href="/"><img src="logo.png" alt="CODEship Academy — return to homepage"></a>

<!-- Chart: describe the data, not just "chart" -->
<img src="bar-chart.png" alt="Bar chart showing Ontario school coding adoption: 45% in 2021, 72% in 2022, 89% in 2023">
```

### 3. Form Labels — Every Input Must Have One

```html
<!-- Bad: placeholder isn't a label — it disappears when typing! -->
<input type="text" placeholder="Your name">

<!-- Good: explicit label with for/id pairing -->
<label for="name">Your name</label>
<input type="text" id="name" name="name">

<!-- Also good: wrapping label -->
<label>
  Your name
  <input type="text" name="name">
</label>

<!-- Error message associated with input -->
<label for="email">Email address</label>
<input type="email" id="email" aria-describedby="email-error">
<p id="email-error" role="alert">Please enter a valid email address</p>
```

### 4. Heading Hierarchy

```html
<!-- Bad: skipping heading levels -->
<h1>CODEship Academy</h1>
<h4>Our Courses</h4>  <!-- Jumped from h1 to h4! -->

<!-- Good: logical sequence -->
<h1>CODEship Academy</h1>
<h2>Our Courses</h2>
  <h3>Explorers Level</h3>
  <h3>Builders Level</h3>
<h2>Our School Program</h2>
```

Screen reader users often navigate by headings — they jump from heading to heading like a table of contents. Logical hierarchy makes this work.

### 5. Keyboard Navigation

Everything interactive must be reachable and operable with a keyboard (Tab, Enter, Space, arrow keys):

```html
<!-- Bad: a div pretending to be a button -->
<div onclick="doSomething()" style="cursor: pointer">Click Me</div>

<!-- Good: actual button — keyboard focusable, fires on Enter/Space -->
<button onclick="doSomething()">Click Me</button>

<!-- If you must use a div, add role and tabindex -->
<div role="button" tabindex="0" onclick="doSomething()" 
     onkeydown="if(event.key==='Enter') doSomething()">Click Me</div>
```

### 6. Colour Contrast

Text must have sufficient contrast with its background. WCAG requires:
- **AA standard:** 4.5:1 for normal text, 3:1 for large text
- **AAA standard:** 7:1 for normal text

Test your colours: webaim.org/resources/contrastchecker

```css
/* Bad: light grey on white — fails contrast */
.muted-text { color: #CCCCCC; } /* On white background: ~1.6:1 ratio */

/* Good: darker grey passes contrast */
.muted-text { color: #767676; } /* On white: 4.5:1 — passes AA */
```

## ARIA: Accessible Rich Internet Applications

ARIA attributes add extra information for assistive technologies when HTML semantics aren't enough:

```html
<!-- aria-label: provides a text label when there's no visible text -->
<button aria-label="Close dialog"><span>×</span></button>

<!-- aria-labelledby: points to another element as the label -->
<section aria-labelledby="courses-heading">
  <h2 id="courses-heading">Our Courses</h2>
  ...
</section>

<!-- aria-describedby: points to descriptive text -->
<input type="password" aria-describedby="pwd-requirements">
<p id="pwd-requirements">Password must be at least 8 characters</p>

<!-- aria-expanded: for toggleable content -->
<button aria-expanded="false" aria-controls="menu">Menu</button>
<ul id="menu" hidden>...</ul>

<!-- aria-live: announces dynamically updated content -->
<div aria-live="polite" aria-atomic="true">
  <!-- Screen reader announces any changes to this div -->
  Loading results...
</div>

<!-- role: when you need an element to behave like something else -->
<div role="alert">Your message was sent successfully!</div>
<div role="status">Loading page 3 of 10...</div>
```

**The first rule of ARIA:** Don't use ARIA if you can use native HTML. `<button>` is better than `<div role="button">`. Use ARIA only when native HTML elements don't provide the semantics you need.

## Skip Links

A "skip to main content" link lets keyboard users bypass repetitive navigation:

```html
<!-- In your <body>, before everything else -->
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Later in your page -->
<main id="main-content">
  ...
</main>
```

```css
.skip-link {
  position: absolute;
  left: -9999px;  /* Off screen */
  top: auto;
  width: 1px;
  height: 1px;
  overflow: hidden;
}

.skip-link:focus {
  position: fixed;  /* Visible when focused */
  left: 16px;
  top: 16px;
  width: auto;
  height: auto;
  z-index: 9999;
  background: #F5C518;
  color: #1E2140;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: bold;
  text-decoration: none;
}
```

## Quick Accessibility Audit

Use these tools to check your pages:

**1. Chrome Lighthouse** (F12 → Lighthouse → Accessibility)
Scores your page and lists specific issues with explanations.

**2. Wave** (wave.webaim.org)
Free online tool that overlays icons on your page showing accessibility issues.

**3. Keyboard only test**
Put down your mouse. Can you navigate the entire page using only Tab, Shift+Tab, Enter, Space, and arrow keys?

**4. Screen reader test**
Enable VoiceOver (Mac: Cmd+F5) or NVDA (Windows: free download). Navigate your page. Is the experience logical?

## Key Takeaways 🌟

1. ~15% of people have disabilities — accessibility makes the web usable for everyone
2. Screen readers navigate HTML — your semantic structure IS the screen reader experience
3. Every image needs meaningful alt text (or `alt=""` for decorative images)
4. Every form input needs an associated `<label>` with matching `for`/`id`
5. Heading hierarchy (h1→h2→h3) acts as a navigational table of contents
6. All interactive elements must be keyboard-navigable — use real buttons and links
7. Text must meet contrast ratios (4.5:1 for normal text) — test with contrast checkers
8. ARIA adds extra semantic context but should never replace proper HTML
9. Add a skip link for keyboard users to bypass navigation
10. Test with Lighthouse, Wave, keyboard-only, and a screen reader
$L$,
ARRAY['accessibility','aria','screen-readers','wcag','forms'], 21);


INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l22', 'CSS Clip-Path and Shapes: Creative Layouts', 'CSS', 'CSS', 'advanced', 30, 'published',
ARRAY['Use clip-path to create non-rectangular shapes','Apply polygon and circle clip-paths to elements','Build a creative section divider'],
$L$# CSS Clip-Path and Shapes: Creative Layouts

## Breaking the Rectangle

Every HTML element is a rectangle by default. `border-radius` rounds the corners. But CSS `clip-path` lets you go much further — cutting elements into circles, polygons, triangles, waves, and custom shapes.

`clip-path` literally clips (cuts away) parts of an element, hiding everything outside the defined shape while keeping the element's layout space.

## Basic Clip-Path Shapes

### Circle
```css
.avatar {
  width: 200px;
  height: 200px;
  clip-path: circle(50%);  /* Perfect circle */
}

.avatar-small {
  clip-path: circle(40% at 50% 50%);  /* 40% radius, centred */
}
```

### Ellipse
```css
.ellipse {
  clip-path: ellipse(50% 30% at 50% 50%);
  /* x-radius y-radius at x-position y-position */
}
```

### Inset (Rectangle with optional rounding)
```css
.inset {
  clip-path: inset(20px);              /* 20px from all sides */
  clip-path: inset(10px 20px);         /* top/bottom, left/right */
  clip-path: inset(10px round 20px);  /* with rounded corners */
}
```

### Polygon — The Most Powerful
```css
/* Triangle pointing up */
.triangle-up {
  clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
}

/* Triangle pointing right */
.arrow-right {
  clip-path: polygon(0% 0%, 75% 50%, 0% 100%);
}

/* Pentagon */
.pentagon {
  clip-path: polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%);
}

/* Diagonal cut at bottom */
.diagonal-bottom {
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
}

/* Diagonal cut at top */
.diagonal-top {
  clip-path: polygon(0 15%, 100% 0, 100% 100%, 0 100%);
}
```

## Section Dividers with Clip-Path

Instead of flat horizontal borders between page sections, use clip-path to create angled transitions:

```html
<section class="hero-section">
  <h1>Welcome to CODEship Academy</h1>
</section>

<section class="courses-section">
  <h2>Our Courses</h2>
</section>
```

```css
.hero-section {
  background: linear-gradient(135deg, #1E2140, #3A3D5C);
  color: white;
  padding: 100px 40px 150px;  /* Extra bottom padding for the clip */
  clip-path: polygon(0 0, 100% 0, 100% 88%, 0 100%);
}

.courses-section {
  background: white;
  padding: 60px 40px;
  margin-top: -60px;  /* Pull up into the clipped area */
}
```

## Animating Clip-Path

Clip-path values can be transitioned — which creates reveal effects:

```css
/* Reveal from left */
.reveal {
  clip-path: polygon(0 0, 0 0, 0 100%, 0 100%);  /* Width: 0 */
  transition: clip-path 0.8s ease;
}

.reveal.visible {
  clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);  /* Full width */
}
```

```css
/* Circle reveal (zoom in from centre) */
.circle-reveal {
  clip-path: circle(0% at 50% 50%);
  transition: clip-path 0.6s ease;
}
.circle-reveal.visible {
  clip-path: circle(75% at 50% 50%);
}
```

**Important:** The number of points must stay the same when transitioning polygon clip-paths. You can't transition from `polygon(3 points)` to `polygon(4 points)`.

## CSS Shape Tools

Creating clip-path values manually is hard. Use these tools:

- **Clippy** (bennettfeely.com/clippy) — visual tool for creating clip-path values
- **CSS Clip Path Editor** — drag handles to make custom shapes
- **Firefox DevTools** — includes a clip-path editor in the inspector

## Alternative: Using SVG Clip Paths

For complex curved shapes, use SVG clip paths:

```html
<svg width="0" height="0">
  <defs>
    <clipPath id="wave-clip">
      <path d="M 0,100 C 150,200 350,0 500,100 L 500,00 L 0,0 Z"/>
    </clipPath>
  </defs>
</svg>

<div style="clip-path: url(#wave-clip);">
  Content here
</div>
```

## Key Takeaways 🌟

1. `clip-path` cuts elements into custom shapes — hiding everything outside the shape
2. Shapes: `circle()`, `ellipse()`, `inset()`, `polygon()`
3. `polygon()` takes x/y coordinate pairs — very flexible
4. Clip-path is perfect for angled section dividers without images
5. Clip-path values can be transitioned for reveal animations
6. The number of polygon points must match when transitioning between shapes
7. Use tools like Clippy to generate clip-path values visually
$L$,
ARRAY['css','clip-path','shapes','creative','layout'], 22),

('bld-l23', 'Building a Product Landing Page', 'Projects', 'HTML', 'intermediate', 60, 'published',
ARRAY['Apply all HTML and CSS skills to build a complete landing page','Implement hero section, features, testimonials, and CTA','Create a professionally structured and styled multi-section page'],
$L$# Building a Product Landing Page

## What Is a Landing Page?

A **landing page** is a focused, single-purpose webpage designed to convert visitors into customers, subscribers, or users. Unlike a homepage (which explains a whole company), a landing page answers one question: "Why should I sign up/buy this?"

Great landing pages have:
1. A compelling **hero** (first impression — headline, subheadline, CTA button)
2. A **social proof** strip (logos, numbers, quick credibility)
3. A **features/benefits** section
4. **Testimonials** (real people saying it's good)
5. A second **call-to-action** section
6. A **footer** with essential links

You'll build all six. This is the most complete project you've built so far.

## The HTML Structure

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CODEship Academy — AI-Powered Coding for Kids K-8</title>
    <meta name="description" content="Personalized coding education for Grades K–8. Curriculum-aligned, bilingual, and loved by Ontario schools.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>

    <!-- 1. Navigation -->
    <header class="nav-header">
      <div class="container">
        <a href="/" class="logo">🚀 CODEship Academy</a>
        <nav>
          <a href="#features">Features</a>
          <a href="#testimonials">Stories</a>
          <a href="#pricing">Pricing</a>
          <a href="#signup" class="btn btn-primary-sm">Start Free</a>
        </nav>
      </div>
    </header>

    <!-- 2. Hero Section -->
    <section class="hero">
      <div class="container">
        <div class="hero-badge">🇨🇦 Proudly Canadian · Ontario Curriculum Aligned</div>
        <h1>Every Child Can<br><span class="accent">Learn to Code</span></h1>
        <p class="hero-sub">AI-personalized coding education for Grades K–8. Real lessons, real skills, real progress — in English or French.</p>
        <div class="hero-actions">
          <a href="#signup" class="btn btn-primary btn-lg">Start Free Trial →</a>
          <a href="#features" class="btn btn-ghost btn-lg">See How It Works</a>
        </div>
        <p class="hero-fine">No credit card required · 14-day free trial · Cancel anytime</p>
      </div>
    </section>

    <!-- 3. Social Proof Strip -->
    <section class="trust-bar">
      <div class="container">
        <div class="trust-stats">
          <div class="stat">
            <strong>10,000+</strong>
            <span>Students Enrolled</span>
          </div>
          <div class="stat">
            <strong>200+</strong>
            <span>Ontario Schools</span>
          </div>
          <div class="stat">
            <strong>4</strong>
            <span>Curriculum Levels</span>
          </div>
          <div class="stat">
            <strong>EN + FR</strong>
            <span>Bilingual Platform</span>
          </div>
        </div>
      </div>
    </section>

    <!-- 4. Features -->
    <section class="features" id="features">
      <div class="container">
        <div class="section-header">
          <h2>Everything a Young Coder Needs</h2>
          <p>From Kindergarten block coding to Grade 8 Python — one platform grows with your child.</p>
        </div>
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon">🧠</div>
            <h3>AI-Powered Personalization</h3>
            <p>Our assessment builds a learning profile for each child. The AI planner creates a weekly schedule tailored to their pace, interests, and learning style.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🎓</div>
            <h3>100+ Lessons Per Level</h3>
            <p>Deep, Codecademy-quality lessons across 4 levels: Explorers (K-1), Builders (Gr 2-3), Developers (Gr 4-6), and Engineers (Gr 7-8).</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🤖</div>
            <h3>AI Tutor in Every Lesson</h3>
            <p>Stuck? Your personal AI tutor is there in every lesson, giving age-appropriate hints — not answers — so real learning happens.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🏫</div>
            <h3>School Program</h3>
            <p>In-school 90-minute workshops delivered by our instructors. Book sessions, track attendance, and generate board-ready impact reports.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🏆</div>
            <h3>XP, Badges & Leaderboard</h3>
            <p>Earn XP for every lesson completed. Build streaks for bonus multipliers. Compete (or just learn!) on the class leaderboard.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🇫🇷</div>
            <h3>Fully Bilingual EN/FR</h3>
            <p>Complete French translation throughout the platform — the only coding education provider designed for Ontario's French-language schools.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- 5. Testimonials -->
    <section class="testimonials" id="testimonials">
      <div class="container">
        <h2>What Families and Schools Say</h2>
        <div class="testimonials-grid">
          <blockquote class="testimonial">
            <p>"My daughter finished Scratch Jr in the first week and asked to keep going every single day. The AI tutor answers her questions perfectly — not too much help, just enough."</p>
            <footer>
              <strong>Sarah M.</strong>
              <span>Parent of a Grade 2 student, Oshawa</span>
            </footer>
          </blockquote>
          <blockquote class="testimonial">
            <p>"We booked CODEship for a full-day coding event and the students were engaged the entire time. The impact report gave me exactly what I needed for our board presentation."</p>
            <footer>
              <strong>Principal Tran</strong>
              <span>École Publique de l'Ontario, Ottawa</span>
            </footer>
          </blockquote>
          <blockquote class="testimonial">
            <p>"My son built his first website at age 9. He showed his grandparents on video call. You should have seen their faces. Worth every dollar."</p>
            <footer>
              <strong>Marcus K.</strong>
              <span>Parent of a Grade 3 student, Toronto</span>
            </footer>
          </blockquote>
        </div>
      </div>
    </section>

    <!-- 6. CTA -->
    <section class="cta" id="signup">
      <div class="container">
        <h2>Ready to Start?</h2>
        <p>14-day free trial. No credit card. Cancel anytime.</p>
        <a href="/signup" class="btn btn-primary btn-lg">Create Your Account →</a>
      </div>
    </section>

    <!-- 7. Footer -->
    <footer class="site-footer">
      <div class="container">
        <div class="footer-grid">
          <div>
            <div class="footer-logo">🚀 CODEship Academy</div>
            <p>Dream. Code. Achieve.</p>
            <p>21 Simcoe St S, Oshawa, ON</p>
          </div>
          <div>
            <h4>Learn</h4>
            <ul>
              <li><a href="/explorers">Explorers (K-1)</a></li>
              <li><a href="/builders">Builders (Gr 2-3)</a></li>
              <li><a href="/developers">Developers (Gr 4-6)</a></li>
              <li><a href="/engineers">Engineers (Gr 7-8)</a></li>
            </ul>
          </div>
          <div>
            <h4>Schools</h4>
            <ul>
              <li><a href="/school-program">Workshop Program</a></li>
              <li><a href="/school-pricing">School Pricing</a></li>
              <li><a href="/impact-reports">Impact Reports</a></li>
            </ul>
          </div>
          <div>
            <h4>Legal</h4>
            <ul>
              <li><a href="/privacy">Privacy Policy</a></li>
              <li><a href="/terms">Terms of Service</a></li>
              <li><a href="/contact">Contact Us</a></li>
            </ul>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2026 CODEship Academy Inc. All rights reserved.</p>
        </div>
      </div>
    </footer>

  </body>
</html>
```

## The CSS

```css
/* ── Reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
img { max-width: 100%; height: auto; }
:root {
  --navy: #1E2140; --gold: #F5C518; --text: #2B2D42; --muted: #8B90B0;
  --bg: #F8F9FE; --white: #fff; --font: 'Nunito', sans-serif;
  --radius: 16px; --shadow: 0 4px 16px rgba(0,0,0,0.08);
}
body { font-family: var(--font); color: var(--text); background: var(--white); }
.container { max-width: 1100px; margin: 0 auto; padding: 0 24px; }

/* ── Nav ── */
.nav-header { background: var(--navy); padding: 16px 0; position: sticky; top: 0; z-index: 100; }
.nav-header .container { display: flex; justify-content: space-between; align-items: center; }
.logo { color: white; font-weight: 900; font-size: 1.1rem; text-decoration: none; }
nav { display: flex; align-items: center; gap: 24px; }
nav a { color: rgba(255,255,255,0.7); text-decoration: none; font-weight: 600; font-size: 0.9rem; }

/* ── Buttons ── */
.btn { display: inline-block; padding: 12px 24px; border-radius: 10px; font-weight: 900; text-decoration: none; transition: all 0.2s; }
.btn-primary { background: var(--gold); color: var(--navy); }
.btn-primary:hover { background: #E6B800; transform: translateY(-2px); box-shadow: 0 6px 20px rgba(245,197,24,0.4); }
.btn-primary-sm { padding: 8px 18px; font-size: 0.85rem; background: var(--gold); color: var(--navy); }
.btn-ghost { background: rgba(255,255,255,0.1); color: white; border: 2px solid rgba(255,255,255,0.3); }
.btn-ghost:hover { background: rgba(255,255,255,0.2); }
.btn-lg { padding: 16px 36px; font-size: 1.05rem; }

/* ── Hero ── */
.hero { background: linear-gradient(135deg, var(--navy) 0%, #3A3D5C 100%); color: white; padding: 100px 0 120px; text-align: center; }
.hero-badge { display: inline-block; background: rgba(245,197,24,0.15); color: var(--gold); padding: 6px 16px; border-radius: 99px; font-size: 0.85rem; font-weight: 700; margin-bottom: 24px; border: 1px solid rgba(245,197,24,0.3); }
.hero h1 { font-size: clamp(2.5rem, 6vw, 4rem); font-weight: 900; line-height: 1.1; margin-bottom: 20px; }
.accent { color: var(--gold); }
.hero-sub { font-size: 1.15rem; color: rgba(255,255,255,0.7); max-width: 580px; margin: 0 auto 36px; line-height: 1.7; }
.hero-actions { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-bottom: 16px; }
.hero-fine { font-size: 0.8rem; color: rgba(255,255,255,0.4); }

/* ── Trust bar ── */
.trust-bar { background: white; padding: 40px 0; border-bottom: 1px solid #E8EAF6; }
.trust-stats { display: flex; justify-content: center; gap: 60px; flex-wrap: wrap; }
.stat { text-align: center; }
.stat strong { display: block; font-size: 2rem; font-weight: 900; color: var(--navy); }
.stat span { font-size: 0.85rem; color: var(--muted); }

/* ── Features ── */
.features { padding: 80px 0; background: var(--bg); }
.section-header { text-align: center; margin-bottom: 56px; }
.section-header h2 { font-size: 2.25rem; font-weight: 900; color: var(--navy); margin-bottom: 12px; }
.section-header p { font-size: 1.1rem; color: var(--muted); }
.features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px; }
.feature-card { background: white; padding: 32px; border-radius: var(--radius); box-shadow: var(--shadow); }
.feature-icon { font-size: 2.5rem; margin-bottom: 16px; }
.feature-card h3 { font-size: 1.1rem; font-weight: 900; color: var(--navy); margin-bottom: 8px; }
.feature-card p { color: var(--muted); line-height: 1.7; font-size: 0.95rem; }

/* ── Testimonials ── */
.testimonials { padding: 80px 0; background: white; }
.testimonials h2 { text-align: center; font-size: 2rem; font-weight: 900; color: var(--navy); margin-bottom: 48px; }
.testimonials-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; }
.testimonial { background: var(--bg); border-radius: var(--radius); padding: 28px; border: 1px solid #E8EAF6; }
.testimonial p { color: var(--text); line-height: 1.7; margin-bottom: 20px; font-style: italic; }
.testimonial footer strong { display: block; font-weight: 900; color: var(--navy); }
.testimonial footer span { font-size: 0.85rem; color: var(--muted); }

/* ── CTA ── */
.cta { background: linear-gradient(135deg, var(--navy), #3A3D5C); color: white; text-align: center; padding: 80px 0; }
.cta h2 { font-size: 2.5rem; font-weight: 900; margin-bottom: 12px; }
.cta p { color: rgba(255,255,255,0.7); margin-bottom: 32px; font-size: 1.1rem; }

/* ── Footer ── */
.site-footer { background: #0F1117; color: rgba(255,255,255,0.6); padding: 60px 0 32px; }
.footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; margin-bottom: 40px; }
.footer-logo { color: white; font-weight: 900; font-size: 1.1rem; margin-bottom: 12px; }
.site-footer h4 { color: white; font-size: 0.85rem; font-weight: 900; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 16px; }
.site-footer ul { list-style: none; }
.site-footer li { margin-bottom: 8px; }
.site-footer a { color: rgba(255,255,255,0.5); text-decoration: none; font-size: 0.9rem; }
.site-footer a:hover { color: var(--gold); }
.footer-bottom { border-top: 1px solid rgba(255,255,255,0.1); padding-top: 24px; text-align: center; font-size: 0.85rem; }

/* ── Responsive ── */
@media (max-width: 768px) {
  .trust-stats { gap: 32px; }
  .footer-grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 480px) {
  nav a:not(.btn-primary-sm) { display: none; }
  .footer-grid { grid-template-columns: 1fr; }
}
```

## Key Takeaways 🌟

1. Landing pages have a clear formula: hero → proof → features → testimonials → CTA
2. The hero makes the first impression — headline, subheadline, one primary CTA
3. Social proof (stats, testimonials) builds trust and answers "why should I believe this?"
4. Features section explains benefits, not just features — "what's in it for me?"
5. One shared CSS file, CSS variables, and the container pattern scale well
6. Responsive layouts use `auto-fit` grids and flex-wrap to adapt gracefully
7. This is a real pattern used by Stripe, Notion, Duolingo, and every major SaaS product
$L$,
ARRAY['html','css','landing-page','project','flexbox','grid'], 23),

('bld-l24', 'CSS Position: Fixed, Sticky, Absolute, Relative', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Explain all five CSS position values','Build a sticky header and fixed back-to-top button','Use absolute positioning for tooltips and overlays'],
$L$# CSS Position: Fixed, Sticky, Absolute, Relative

## The Five Position Values

The CSS `position` property is one of the most powerful — and most confusing — properties in CSS. It controls how elements are placed in the document and how they behave when the page scrolls.

```css
position: static;    /* Default — in normal document flow */
position: relative;  /* Offset from its normal position */
position: absolute;  /* Removed from flow, positioned relative to parent */
position: fixed;     /* Removed from flow, positioned relative to viewport */
position: sticky;    /* Normal flow until scroll threshold, then sticks */
```

## `position: static` — The Default

Every element starts as `static`. It sits exactly where it would naturally appear in the document flow. Setting `top`, `left`, `right`, `bottom` has NO effect on static elements.

```css
/* These offset properties DO NOTHING on static elements */
.element {
  position: static; /* Default — you almost never need to write this */
  top: 20px;        /* Ignored! */
}
```

## `position: relative` — Offset from Normal Position

`relative` lets you nudge an element from its normal position using `top`, `left`, `right`, `bottom`. The element's original space is still reserved in the document flow — it's like a ghost of the element stays in place.

```css
.nudged {
  position: relative;
  top: 10px;   /* Move DOWN 10px from normal position */
  left: 20px;  /* Move RIGHT 20px */
}
```

More importantly, `position: relative` on a parent makes it the **containing block** for absolutely-positioned children. This is its most important use.

## `position: absolute` — Positioned Relative to a Containing Block

An absolutely positioned element is **removed from the document flow** (other elements act as if it doesn't exist) and positioned relative to its nearest ancestor that has `position: relative`, `absolute`, `fixed`, or `sticky`.

If no ancestor has a position set, it positions relative to the `<html>` element (the page).

```css
/* Parent must have position: relative */
.parent {
  position: relative;
  width: 300px;
  height: 200px;
  background: lightblue;
}

/* Child is positioned inside the parent */
.badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: red;
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
}
```

### Classic Absolute Positioning Patterns

**Badge on a card:**
```css
.card { position: relative; }
.card .badge {
  position: absolute;
  top: -10px;
  right: -10px;
}
```

**Tooltip:**
```css
.tooltip-wrapper { position: relative; display: inline-block; }
.tooltip {
  position: absolute;
  bottom: 100%;     /* Just above the element */
  left: 50%;
  transform: translateX(-50%);  /* Centre it */
  background: #1E2140;
  color: white;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 0.8rem;
  white-space: nowrap;
  opacity: 0;
  transition: opacity 0.2s;
  pointer-events: none;
}
.tooltip-wrapper:hover .tooltip { opacity: 1; }
```

**Full overlay:**
```css
.overlay-parent { position: relative; }
.overlay {
  position: absolute;
  inset: 0;  /* Shorthand for top: 0, right: 0, bottom: 0, left: 0 */
  background: rgba(30, 33, 64, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}
```

## `position: fixed` — Always in the Viewport

Fixed elements are removed from flow and positioned relative to the **browser viewport** — they stay in place even when the page scrolls.

```css
/* Back to top button */
.back-to-top {
  position: fixed;
  bottom: 32px;
  right: 32px;
  background: #F5C518;
  color: #1E2140;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  text-decoration: none;
  transition: transform 0.2s ease;
  z-index: 1000;
}
.back-to-top:hover { transform: translateY(-4px); }

/* Sticky navigation */
.nav {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background: #1E2140;
  z-index: 100;
}
/* Remember to add padding-top to body equal to nav height! */
body { padding-top: 64px; }
```

## `position: sticky` — Scrolls Then Sticks

Sticky elements behave like `static` until you scroll to a threshold, then they behave like `fixed` until you scroll out of their parent.

```css
/* Sticky table header */
thead th {
  position: sticky;
  top: 0;               /* Sticks when it reaches top: 0 */
  background: white;    /* Need background or content shows through */
  z-index: 10;
}

/* Sticky sidebar */
.sidebar {
  position: sticky;
  top: 80px;            /* Sticks 80px from the top (below a fixed nav) */
  max-height: calc(100vh - 80px);
  overflow-y: auto;
}

/* Sticky section header */
.section-label {
  position: sticky;
  top: 0;
  background: #F5C518;
  color: #1E2140;
  padding: 8px 24px;
  font-weight: 900;
}
```

**Important:** Sticky only works if the parent has explicit height and there's overflow to scroll through. The element stops being sticky when it reaches the bottom of its parent.

## The `z-index` Property

When elements overlap, `z-index` controls which is on top. Higher numbers appear in front:

```css
.header  { z-index: 100; }  /* Always on top of content */
.sidebar { z-index: 50; }
.card    { z-index: 1; }

/* z-index only works on non-static elements! */
.element { 
  position: relative; /* Required for z-index to work */
  z-index: 10; 
}
```

Common z-index conventions:
- Content: 0–10
- Dropdowns/tooltips: 100–200
- Modals: 1000
- Notifications: 2000
- Skip links: 9999

## Build: Sticky Header + Back-to-Top Button

```html
<a href="#top" class="back-to-top" aria-label="Back to top">↑</a>
<header class="sticky-header" id="top">
  <nav><!-- nav content --></nav>
</header>
<main><!-- Long content --></main>
```

```css
.sticky-header {
  position: sticky;
  top: 0;
  background: white;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  z-index: 100;
}

.back-to-top {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 44px;
  height: 44px;
  background: #1E2140;
  color: #F5C518;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  font-size: 1.2rem;
  font-weight: 900;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  z-index: 500;
  transition: transform 0.2s ease;
}
.back-to-top:hover { transform: translateY(-4px); }
```

## Key Takeaways 🌟

1. `static` is the default — no positioning capabilities
2. `relative` offsets from normal position AND establishes a containing block for children
3. `absolute` is removed from flow and positioned relative to the nearest positioned ancestor
4. **Always set `position: relative` on the parent when using `position: absolute` on a child**
5. `fixed` stays in the viewport while scrolling — for headers, floating buttons, notifications
6. `sticky` scrolls normally until a threshold, then sticks — for table headers, sidebars
7. `z-index` controls stacking order but only works on non-static elements
8. `inset: 0` is shorthand for `top: 0; right: 0; bottom: 0; left: 0`
$L$,
ARRAY['css','position','sticky','fixed','absolute','z-index'], 24),

('bld-l25', 'HTML5 Canvas: Drawing with Code', 'Creative Coding', 'HTML', 'intermediate', 35, 'published',
ARRAY['Understand what the canvas element is','Draw shapes and text with the Canvas API','Create a simple animated canvas drawing'],
$L$# HTML5 Canvas: Drawing with Code

## The Painter''s Canvas

The HTML5 `<canvas>` element is a blank rectangle that you draw on using JavaScript. Unlike other HTML elements, canvas has no built-in content — it''s a pixel-level drawing surface that you control completely through code.

Canvas is used for: games, data visualisation, image editing tools, digital art, animations, and interactive experiences that CSS can''t handle.

## Setting Up Canvas

```html
<canvas id="myCanvas" width="600" height="400">
  <!-- Fallback for browsers that don''t support canvas -->
  <p>Your browser doesn''t support canvas. Please upgrade.</p>
</canvas>
```

```javascript
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');
// ctx is your drawing context — all drawing happens through this object
```

**Important:** Always set canvas dimensions with HTML attributes, not CSS. CSS resizes the canvas visually but doesn''t change the drawing resolution, causing blurriness.

## Drawing Rectangles

```javascript
// Filled rectangle: fillRect(x, y, width, height)
ctx.fillStyle = '#1E2140';
ctx.fillRect(50, 50, 200, 100);

// Outline rectangle: strokeRect(x, y, width, height)
ctx.strokeStyle = '#F5C518';
ctx.lineWidth = 3;
ctx.strokeRect(300, 50, 200, 100);

// Clear a rectangle (make transparent): clearRect(x, y, width, height)
ctx.clearRect(75, 75, 50, 50);  // Clear a square inside the filled rect
```

## Drawing Paths

Paths create lines and complex shapes:

```javascript
ctx.beginPath();       // Start a new path
ctx.moveTo(100, 100);  // Move to starting point (doesn''t draw)
ctx.lineTo(200, 100);  // Draw line to (200, 100)
ctx.lineTo(150, 50);   // Draw line to (150, 50)
ctx.closePath();       // Close the path back to the start

ctx.fillStyle = '#F5C518';
ctx.fill();            // Fill the shape
ctx.strokeStyle = '#1E2140';
ctx.lineWidth = 2;
ctx.stroke();          // Draw the outline
```

## Drawing Circles and Arcs

```javascript
// arc(centreX, centreY, radius, startAngle, endAngle, anticlockwise)
// Angles in radians: full circle = 2 * Math.PI

ctx.beginPath();
ctx.arc(300, 200, 80, 0, 2 * Math.PI);  // Full circle
ctx.fillStyle = '#F5C518';
ctx.fill();

// Semicircle
ctx.beginPath();
ctx.arc(300, 200, 80, 0, Math.PI);  // Half circle
ctx.stroke();

// Pac-Man
ctx.beginPath();
ctx.arc(300, 200, 80, 0.3, 2 * Math.PI - 0.3);
ctx.lineTo(300, 200);
ctx.closePath();
ctx.fillStyle = 'yellow';
ctx.fill();
```

## Drawing Text

```javascript
// Filled text
ctx.font = 'bold 32px Nunito, sans-serif';
ctx.fillStyle = '#1E2140';
ctx.textAlign = 'center';   // left, right, center, start, end
ctx.textBaseline = 'middle'; // top, middle, bottom, alphabetic
ctx.fillText('Hello Canvas!', 300, 200);

// Outlined text
ctx.strokeStyle = '#F5C518';
ctx.lineWidth = 1;
ctx.strokeText('Hello Canvas!', 300, 200);

// Measure text width
const width = ctx.measureText('Hello').width;
```

## Adding Images

```javascript
const img = new Image();
img.src = 'logo.png';
img.onload = () => {
  // Draw image at (x, y)
  ctx.drawImage(img, 50, 50);

  // Draw image at (x, y) with (width, height)
  ctx.drawImage(img, 50, 50, 200, 100);
};
```

## Gradients on Canvas

```javascript
// Linear gradient
const gradient = ctx.createLinearGradient(0, 0, 600, 0);  // x1,y1 to x2,y2
gradient.addColorStop(0, '#1E2140');
gradient.addColorStop(0.5, '#7C3AED');
gradient.addColorStop(1, '#F5C518');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, 600, 400);

// Radial gradient
const radial = ctx.createRadialGradient(300, 200, 10, 300, 200, 200);
radial.addColorStop(0, '#F5C518');
radial.addColorStop(1, '#1E2140');
ctx.fillStyle = radial;
ctx.arc(300, 200, 200, 0, 2 * Math.PI);
ctx.fill();
```

## Animation with requestAnimationFrame

Canvas becomes magical when combined with animation:

```javascript
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');

let x = 0;
let speed = 3;

function animate() {
  // Clear the canvas each frame
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw background
  ctx.fillStyle = '#1E2140';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw moving ball
  ctx.beginPath();
  ctx.arc(x, 200, 30, 0, 2 * Math.PI);
  ctx.fillStyle = '#F5C518';
  ctx.fill();

  // Move ball
  x += speed;
  if (x > canvas.width + 30) x = -30;  // Wrap around

  // Request next frame (roughly 60fps)
  requestAnimationFrame(animate);
}

animate();  // Start the animation loop
```

## Build: Starfield Animation

```javascript
const canvas = document.getElementById('stars');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Create 200 stars
const stars = Array.from({ length: 200 }, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  radius: Math.random() * 2,
  speed: Math.random() * 0.5 + 0.1,
  opacity: Math.random()
}));

function drawStars() {
  ctx.fillStyle = '#1E2140';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  stars.forEach(star => {
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.radius, 0, 2 * Math.PI);
    ctx.fillStyle = `rgba(245, 197, 24, ${star.opacity})`;
    ctx.fill();

    // Move star down (simulates motion through space)
    star.y += star.speed;
    if (star.y > canvas.height) star.y = 0;
  });

  requestAnimationFrame(drawStars);
}
drawStars();
```

## Key Takeaways 🌟

1. `<canvas>` is a blank drawing surface controlled entirely with JavaScript
2. Always get the 2D context: `const ctx = canvas.getContext('2d')`
3. Main drawing methods: `fillRect()`, `strokeRect()`, `arc()`, `beginPath()`, `moveTo()`, `lineTo()`
4. Set `fillStyle` and `strokeStyle` before drawing to change colours
5. `requestAnimationFrame()` creates smooth 60fps animations — clear the canvas each frame
6. Canvas is pixel-based (unlike SVG which is vector) — it doesn''t scale without re-drawing
7. Use canvas for games, animations, data visualisation, and dynamic graphics
$L$,
ARRAY['html','canvas','javascript','animation','creative-coding'], 25),

('bld-l26', 'Building a Recipe Blog', 'Projects', 'HTML', 'intermediate', 50, 'published',
ARRAY['Build a multi-recipe blog with consistent card layout','Apply semantic HTML for article content','Use flexbox to arrange recipe cards in a responsive grid'],
$L$# Building a Recipe Blog

## What You''ll Build

A complete recipe blog website with:
- A homepage listing recipe cards
- Individual recipe pages with full instructions
- Consistent branding and navigation

Recipe blogs are one of the most popular website types in the world. Many of the most successful food bloggers earn substantial incomes from their recipe websites.

## The Structure

```
recipe-blog/
├── index.html          (homepage — recipe card listing)
├── carbonara.html      (individual recipe page)
├── chocolate-cake.html (another recipe)
├── styles.css          (shared styles)
└── images/
    └── (recipe photos)
```

## Homepage: Recipe Card Grid

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Coding Kitchen — Recipes for Everyone</title>
    <link href="[Google Font URL for Playfair Display + Nunito]" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>

    <header>
      <div class="header-inner">
        <div class="logo">🍳 The Coding Kitchen</div>
        <nav>
          <a href="/">All Recipes</a>
          <a href="/pasta">Pasta</a>
          <a href="/baking">Baking</a>
          <a href="/salads">Salads</a>
        </nav>
      </div>
    </header>

    <main>
      <section class="hero">
        <h1>Delicious Recipes for Every Home Cook</h1>
        <p>Simple ingredients, amazing results.</p>
      </section>

      <section class="recipe-grid-section">
        <h2>Latest Recipes</h2>
        <div class="recipe-grid">

          <!-- Recipe Card -->
          <article class="recipe-card">
            <a href="carbonara.html" class="card-image-link">
              <img src="images/carbonara.jpg" alt="Creamy pasta carbonara with bacon and parmesan" class="card-image">
              <span class="card-badge">30 min</span>
            </a>
            <div class="card-body">
              <div class="card-meta">
                <span class="tag">Pasta</span>
                <span class="tag">Italian</span>
              </div>
              <h3 class="card-title">
                <a href="carbonara.html">Classic Spaghetti Carbonara</a>
              </h3>
              <p class="card-desc">Silky, creamy pasta with crispy pancetta and a rich egg yolk sauce. No cream — just technique.</p>
              <div class="card-footer">
                <span>⏱ 30 min</span>
                <span>👥 Serves 4</span>
                <span>⭐ Easy</span>
              </div>
            </div>
          </article>

          <!-- Add 5 more recipe cards with different recipes -->

        </div>
      </section>
    </main>

    <footer>
      <p>🍳 The Coding Kitchen · Made with love and HTML</p>
    </footer>

  </body>
</html>
```

## Recipe Page HTML Pattern

```html
<article class="recipe-page">
  <header class="recipe-header">
    <div class="breadcrumb">
      <a href="/">Home</a> › <a href="/pasta">Pasta</a> › Carbonara
    </div>
    <h1>Classic Spaghetti Carbonara</h1>
    <div class="recipe-meta">
      <span>⏱ Prep: 10 min</span>
      <span>🔥 Cook: 20 min</span>
      <span>👥 Serves: 4</span>
      <span>⭐ Difficulty: Easy</span>
    </div>
    <img src="images/carbonara.jpg" alt="Finished carbonara dish" class="hero-image">
    <p class="recipe-intro">True Roman carbonara has no cream — the creaminess comes from eggs, cheese, and pasta water. This technique takes practice but the result is magical.</p>
  </header>

  <div class="recipe-body">
    <aside class="ingredients">
      <h2>Ingredients</h2>
      <ul>
        <li>400g spaghetti</li>
        <li>200g pancetta or guanciale</li>
        <li>4 large egg yolks + 1 whole egg</li>
        <li>100g Pecorino Romano, finely grated</li>
        <li>50g Parmesan, finely grated</li>
        <li>Freshly ground black pepper</li>
        <li>Salt for pasta water</li>
      </ul>
      <div class="tip-box">
        <strong>💡 Tip:</strong> Reserve at least a cup of pasta water before draining — it''s the secret to the sauce.
      </div>
    </aside>

    <section class="instructions">
      <h2>Instructions</h2>
      <ol class="steps">
        <li class="step">
          <span class="step-number">1</span>
          <div>
            <strong>Cook the pasta</strong>
            <p>Bring a large pot of salted water to a boil. Cook spaghetti until al dente (1-2 minutes less than package directions).</p>
          </div>
        </li>
        <!-- More steps... -->
      </ol>
    </section>
  </div>
</article>
```

## Key CSS for the Recipe Blog

```css
/* Variables */
:root {
  --cream: #FFF8F0;
  --brown: #8B4513;
  --text: #2C1810;
  --font-heading: ''Playfair Display'', Georgia, serif;
  --font-body: ''Nunito'', sans-serif;
}

body { font-family: var(--font-body); background: var(--cream); color: var(--text); }

/* Recipe grid */
.recipe-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 32px;
  padding: 40px;
}

.recipe-card {
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 16px rgba(0,0,0,0.08);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.recipe-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 16px 40px rgba(0,0,0,0.15);
}

.card-image { width: 100%; height: 220px; object-fit: cover; }
.card-body { padding: 20px; }
.card-title { font-family: var(--font-heading); font-size: 1.3rem; margin-bottom: 8px; }
.card-title a { color: var(--text); text-decoration: none; }
.card-title a:hover { color: var(--brown); }

/* Recipe page two-column layout */
.recipe-body {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 48px;
  padding: 40px;
}

.ingredients {
  position: sticky;
  top: 80px;
  align-self: start;
  background: white;
  padding: 24px;
  border-radius: 16px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.06);
}

@media (max-width: 768px) {
  .recipe-body { grid-template-columns: 1fr; }
  .ingredients { position: static; }
}
```

## Activity: Build Your Recipe Blog

1. Create the homepage with at least 6 recipe cards
2. Create 2 individual recipe pages with full instructions
3. Link all pages together with proper navigation
4. Make sure all recipes have proper alt text on images
5. Test on mobile — the grid should wrap gracefully

**Bonus:** Add a search box in the header (it can be decorative for now — JavaScript would make it functional).

## Key Takeaways 🌟

1. Multi-page websites share a CSS file — one set of rules, consistent across all pages
2. Recipe cards use `grid-template-columns: repeat(auto-fill, minmax(300px, 1fr))` for responsive layout
3. Individual recipe pages use a two-column layout: sticky ingredients sidebar + scrollable instructions
4. The `<article>` element is perfect for self-contained recipe content
5. `position: sticky` on the ingredients sidebar keeps it visible while scrolling instructions
6. `object-fit: cover` makes images fill their container without distortion
$L$,
ARRAY['html','css','project','blog','grid','multi-page'], 26);


-- Lessons 27-100 with proper deep content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l27', 'CSS Filters and Backdrop: Visual Effects', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Apply CSS filter effects to images and elements','Use backdrop-filter for frosted glass effects','Create an image hover effect using filters'],
$L$# CSS Filters and Backdrop: Visual Effects

## CSS filter Property

`filter` applies visual effects to an element — similar to Instagram filters but in code:

```css
/* Blur */
.blurred { filter: blur(4px); }

/* Brightness: 0 = black, 1 = normal, 2 = double bright */
.dimmed { filter: brightness(0.7); }
.bright { filter: brightness(1.3); }

/* Contrast */
.high-contrast { filter: contrast(1.5); }

/* Grayscale: 0 = colour, 1 = full grey */
.grey { filter: grayscale(1); }

/* Hue rotation: shifts all colours around the colour wheel */
.hue-shift { filter: hue-rotate(90deg); }

/* Invert colours */
.inverted { filter: invert(1); }

/* Saturate: 0 = grey, 1 = normal, 2 = vivid */
.vivid { filter: saturate(2); }

/* Sepia: vintage photo effect */
.vintage { filter: sepia(0.8); }

/* Drop shadow (works on transparent PNG unlike box-shadow) */
.icon { filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3)); }

/* Combining filters */
.instagram { filter: contrast(1.1) brightness(1.05) saturate(1.2); }
.dramatic { filter: grayscale(0.5) contrast(1.5) brightness(0.8); }
```

## Image Hover Effects with Filters

```css
.photo-card img {
  transition: filter 0.4s ease;
  filter: grayscale(1) brightness(0.8);
}

.photo-card:hover img {
  filter: grayscale(0) brightness(1);  /* Restore full colour on hover */
}

/* "Under the spotlight" effect */
.spotlight {
  filter: brightness(0.4) contrast(1.2);
  transition: filter 0.3s ease;
}
.spotlight:hover {
  filter: brightness(1) contrast(1);
}
```

## backdrop-filter: Frosted Glass

`backdrop-filter` applies effects to whatever is BEHIND an element — creating the famous "frosted glass" effect:

```css
.glass-card {
  background: rgba(255, 255, 255, 0.15);  /* Semi-transparent */
  backdrop-filter: blur(12px) brightness(1.1);
  -webkit-backdrop-filter: blur(12px) brightness(1.1);  /* Safari */
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 16px;
  padding: 32px;
  color: white;
}
```

```css
/* Frosted navigation bar */
.frosted-nav {
  position: sticky;
  top: 0;
  background: rgba(30, 33, 64, 0.7);
  backdrop-filter: blur(20px) saturate(1.5);
  -webkit-backdrop-filter: blur(20px) saturate(1.5);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  z-index: 100;
}
```

## Hover Modal with Blur Background

```html
<div class="page-content">
  <div class="blurred-when-modal-open">
    <!-- Main page content -->
  </div>
  <div class="modal" id="modal">
    <div class="modal-box">Modal content</div>
  </div>
</div>
```

```css
.modal { display: none; }
.modal.open { display: flex; align-items: center; justify-content: center; }

body.modal-open .blurred-when-modal-open {
  filter: blur(4px);
}
```

## SVG Filters

For complex effects, reference SVG filter definitions:

```html
<svg width="0" height="0">
  <defs>
    <filter id="glow">
      <feGaussianBlur stdDeviation="3" result="blur"/>
      <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 1  0 1 0 0 0.8  0 0 0 0 0  0 0 0 3 -0.5" result="glow"/>
      <feMerge><feMergeNode in="glow"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
</svg>
<h1 style="filter: url(#glow)">Glowing Text!</h1>
```

## Key Takeaways 🌟

1. `filter` applies visual effects: blur, brightness, contrast, grayscale, hue-rotate, sepia
2. Combine filters: `filter: grayscale(1) brightness(0.8)` — multiple effects at once
3. `filter: drop-shadow()` works on the visible shape including transparency (unlike `box-shadow`)
4. `backdrop-filter` blurs/effects what''s BEHIND an element — frosted glass!
5. Always include `-webkit-backdrop-filter` for Safari compatibility
6. Filters can be transitioned: `transition: filter 0.3s ease` for smooth effects
7. `filter: grayscale(1)` → `grayscale(0)` on hover creates elegant photo card reveals
$L$,
ARRAY['css','filters','backdrop-filter','visual-effects','frosted-glass'], 27),

('bld-l28', 'Forms: Styling and UX Best Practices', 'CSS', 'CSS', 'intermediate', 30, 'published',
ARRAY['Apply comprehensive CSS styling to form elements','Create floating label inputs','Design error and success states for form fields'],
$L$# Forms: Styling and UX Best Practices

## Why Form Design Matters

Forms are where users give you information. A poorly designed form loses customers — research shows that reducing form fields from 11 to 4 can increase conversions by 120%.

Good form design is about reducing friction: make it clear what''s needed, easy to fill in, and reassuring that the process will work.

## Resetting Default Form Styles

Every browser styles forms differently. Start by normalising:

```css
input, textarea, select, button {
  font-family: inherit;  /* Use your page font, not browser default */
  font-size: inherit;
  box-sizing: border-box;
  margin: 0;
}

/* Remove browser focus glow — replace with your own */
:focus { outline: none; }
```

## Styling Text Inputs

```css
.form-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 20px;
}

.form-field label {
  font-weight: 700;
  font-size: 0.875rem;
  color: #1E2140;
}

.form-field input,
.form-field textarea,
.form-field select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #E8EAF6;
  border-radius: 8px;
  font-size: 1rem;
  color: #2B2D42;
  background: white;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

/* Focus state */
.form-field input:focus,
.form-field textarea:focus {
  border-color: #F5C518;
  box-shadow: 0 0 0 3px rgba(245, 197, 24, 0.2);
}

/* Valid state */
.form-field input:valid:not(:placeholder-shown) {
  border-color: #22C55E;
}

/* Invalid state (only after user has typed) */
.form-field input:invalid:not(:placeholder-shown) {
  border-color: #EF4444;
}
```

## Floating Labels

Floating labels save vertical space and look professional — the label sits in the input until you click it, then floats above:

```html
<div class="floating-field">
  <input type="text" id="name" placeholder=" " required>
  <label for="name">Your Name</label>
</div>
```

```css
.floating-field {
  position: relative;
  margin-bottom: 24px;
}

.floating-field input {
  width: 100%;
  padding: 20px 16px 8px;  /* Extra top padding for the label */
  border: 2px solid #E8EAF6;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.2s ease;
}

.floating-field label {
  position: absolute;
  left: 16px;
  top: 14px;
  font-size: 1rem;
  color: #8B90B0;
  pointer-events: none;
  transition: all 0.2s ease;
  background: white;
}

/* Float the label up when input is focused or has content */
.floating-field input:focus + label,
.floating-field input:not(:placeholder-shown) + label {
  top: 4px;
  font-size: 0.75rem;
  color: #F5C518;
  font-weight: 700;
}

.floating-field input:focus {
  border-color: #F5C518;
  outline: none;
}
```

The `placeholder=" "` (a space) is necessary — it enables `:placeholder-shown` to detect when the field has content.

## Styling Select Dropdowns

```css
select {
  appearance: none;  /* Remove browser default arrow */
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%231E2140' d='M1.41 0L6 4.58 10.59 0 12 1.41l-6 6-6-6z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 16px centre;
  padding-right: 40px;
  cursor: pointer;
}
```

## Styled Checkboxes and Radio Buttons

Checkboxes and radio buttons are notoriously hard to style. The simplest approach uses a hidden native input and a custom visual element:

```html
<label class="custom-check">
  <input type="checkbox">
  <span class="checkmark"></span>
  Subscribe to newsletter
</label>
```

```css
.custom-check {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  user-select: none;
}

/* Hide the real checkbox */
.custom-check input { display: none; }

.checkmark {
  width: 20px;
  height: 20px;
  border: 2px solid #E8EAF6;
  border-radius: 4px;
  flex-shrink: 0;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Checked state */
.custom-check input:checked + .checkmark {
  background: #F5C518;
  border-color: #F5C518;
}

.custom-check input:checked + .checkmark::after {
  content: '✓';
  color: #1E2140;
  font-weight: 900;
  font-size: 0.75rem;
}
```

## Error and Success Messages

```html
<div class="form-field error">
  <label for="email">Email</label>
  <input type="email" id="email" value="not-an-email">
  <p class="field-message">Please enter a valid email address.</p>
</div>

<div class="form-field success">
  <label for="username">Username</label>
  <input type="text" id="username" value="codeship_star">
  <p class="field-message">This username is available! ✓</p>
</div>
```

```css
.form-field.error input { border-color: #EF4444; }
.form-field.error .field-message { color: #EF4444; font-size: 0.8rem; }

.form-field.success input { border-color: #22C55E; }
.form-field.success .field-message { color: #22C55E; font-size: 0.8rem; }

.field-message { margin-top: 4px; display: flex; align-items: center; gap: 4px; }
```

## Form Layout Patterns

```css
/* Two columns side by side */
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

/* One column on mobile */
@media (max-width: 600px) {
  .form-row { grid-template-columns: 1fr; }
}

/* Inline form (search bar style) */
.inline-form {
  display: flex;
  gap: 8px;
}
.inline-form input { flex: 1; }
.inline-form button { flex-shrink: 0; }
```

## Key Takeaways 🌟

1. Reset default browser form styles with `font-family: inherit` and `box-sizing: border-box`
2. Design clear focus, valid, and invalid states for each input
3. Floating labels save space and look professional — use `placeholder=" "` (space) to enable `:placeholder-shown`
4. `appearance: none` removes default browser styling from select and checkboxes
5. Custom checkboxes use a hidden `<input>` and a visible sibling element styled with CSS
6. Error and success states should use colour AND an icon/message (not colour alone — colour-blind accessibility)
7. Use grid for multi-column forms, with single-column fallback on mobile
$L$,
ARRAY['css','forms','ux','floating-labels','accessibility'], 28),

('bld-l29', 'Building a Professional Contact Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a fully styled contact page with map embed','Apply all form styling techniques','Include multiple contact methods and address information'],
$L$# Building a Professional Contact Page

## The Contact Page: Often Neglected, Always Important

Your contact page is where potential clients and users go when they''re ready to talk. A bad contact page (confusing, outdated, broken form) loses conversions at the final moment. A great one builds trust and makes people feel they''re dealing with a real, professional business.

## What a Great Contact Page Includes

1. **Clear heading and intro** — who you''re reaching and why
2. **Contact form** — the primary conversion mechanism
3. **Alternative contact methods** — email, phone, social media
4. **Address and map** — for businesses with physical locations
5. **Business hours** — when to expect a response
6. **Response time expectation** — "We respond within 24 hours"

## The Complete Contact Page

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us — CODEship Academy</title>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <header><!-- Your nav here --></header>

    <main class="contact-page">
      <section class="contact-hero">
        <h1>Get in Touch</h1>
        <p>We''d love to hear from you — whether you''re a parent, teacher, or school administrator.</p>
      </section>

      <div class="contact-grid">
        <!-- Left: Contact info -->
        <aside class="contact-info">
          <h2>Other Ways to Reach Us</h2>

          <div class="contact-method">
            <div class="method-icon">📧</div>
            <div>
              <strong>Email</strong>
              <a href="mailto:admin@codeshipacademy.com">admin@codeshipacademy.com</a>
              <p class="respond-time">We respond within 24 hours on business days</p>
            </div>
          </div>

          <div class="contact-method">
            <div class="method-icon">📍</div>
            <div>
              <strong>Visit Us</strong>
              <address>
                CODEship Academy<br>
                21 Simcoe Street South<br>
                Oshawa, Ontario L1H 4G1<br>
                Canada
              </address>
            </div>
          </div>

          <div class="contact-method">
            <div class="method-icon">🕐</div>
            <div>
              <strong>Business Hours</strong>
              <dl class="hours">
                <dt>Monday – Friday</dt>
                <dd>9:00 AM – 5:00 PM EST</dd>
                <dt>Saturday</dt>
                <dd>10:00 AM – 2:00 PM EST</dd>
                <dt>Sunday</dt>
                <dd>Closed</dd>
              </dl>
            </div>
          </div>

          <!-- Google Maps embed -->
          <div class="map-embed">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2867.8!2d-78.8649!3d43.8971!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d52e4b60000001%3A0x1!2s21+Simcoe+St+S%2C+Oshawa%2C+ON!5e0!3m2!1sen!2sca!4v1234567890"
              width="100%"
              height="200"
              style="border: 0; border-radius: 8px;"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
              title="CODEship Academy location">
            </iframe>
          </div>
        </aside>

        <!-- Right: Contact form -->
        <section class="contact-form-section">
          <h2>Send Us a Message</h2>

          <form class="contact-form" action="/contact" method="post">

            <div class="form-row">
              <div class="form-field">
                <label for="first-name">First Name *</label>
                <input type="text" id="first-name" name="first-name" required placeholder="Your first name">
              </div>
              <div class="form-field">
                <label for="last-name">Last Name *</label>
                <input type="text" id="last-name" name="last-name" required placeholder="Your last name">
              </div>
            </div>

            <div class="form-field">
              <label for="email">Email Address *</label>
              <input type="email" id="email" name="email" required placeholder="you@example.com">
            </div>

            <div class="form-field">
              <label for="inquiry-type">I''m contacting about... *</label>
              <select id="inquiry-type" name="inquiry-type" required>
                <option value="">Please select</option>
                <optgroup label="Families">
                  <option>Getting started for my child</option>
                  <option>Pricing and subscriptions</option>
                  <option>Technical support</option>
                </optgroup>
                <optgroup label="Schools">
                  <option>Booking an in-school workshop</option>
                  <option>School licensing</option>
                  <option>Curriculum alignment</option>
                </optgroup>
                <option>Media and press</option>
                <option>Other</option>
              </select>
            </div>

            <div class="form-field">
              <label for="message">Message *</label>
              <textarea id="message" name="message" rows="6"
                placeholder="Tell us how we can help..." required></textarea>
            </div>

            <label class="checkbox-label">
              <input type="checkbox" name="newsletter">
              <span>Sign me up for the CODEship Newsletter (monthly, no spam)</span>
            </label>

            <button type="submit" class="btn-submit">
              Send Message →
            </button>

          </form>
        </section>
      </div>
    </main>

    <footer><!-- Your footer here --></footer>
  </body>
</html>
```

## The CSS

```css
.contact-hero {
  text-align: center;
  padding: 64px 24px 40px;
  background: linear-gradient(135deg, #1E2140, #3A3D5C);
  color: white;
}
.contact-hero h1 { font-size: 3rem; font-weight: 900; margin-bottom: 12px; }
.contact-hero p { font-size: 1.1rem; color: rgba(255,255,255,0.7); }

.contact-grid {
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 48px;
  max-width: 1100px;
  margin: 0 auto;
  padding: 60px 24px;
}

.contact-info { display: flex; flex-direction: column; gap: 28px; }

.contact-method {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.method-icon { font-size: 1.5rem; flex-shrink: 0; margin-top: 2px; }
.contact-method strong { display: block; font-weight: 900; color: #1E2140; margin-bottom: 4px; }
.contact-method a { color: #F5C518; text-decoration: none; font-weight: 600; }
.respond-time { font-size: 0.8rem; color: #8B90B0; margin-top: 4px; }

.hours dt { font-weight: 700; color: #1E2140; margin-top: 6px; }
.hours dd { color: #8B90B0; font-size: 0.9rem; }

.contact-form-section {
  background: white;
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.06);
}
.contact-form-section h2 { font-size: 1.5rem; font-weight: 900; color: #1E2140; margin-bottom: 28px; }

.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 20px; }
.form-field label { font-weight: 700; font-size: 0.875rem; color: #1E2140; }

.form-field input,
.form-field select,
.form-field textarea {
  padding: 12px 16px;
  border: 2px solid #E8EAF6;
  border-radius: 8px;
  font-size: 1rem;
  font-family: inherit;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.form-field input:focus,
.form-field select:focus,
.form-field textarea:focus {
  outline: none;
  border-color: #F5C518;
  box-shadow: 0 0 0 3px rgba(245,197,24,0.2);
}

.checkbox-label {
  display: flex; gap: 10px; align-items: center;
  cursor: pointer; font-size: 0.9rem; color: #8B90B0;
  margin-bottom: 24px;
}

.btn-submit {
  width: 100%;
  padding: 16px;
  background: #F5C518;
  color: #1E2140;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 900;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
}
.btn-submit:hover { background: #E6B800; transform: translateY(-2px); }

@media (max-width: 768px) {
  .contact-grid { grid-template-columns: 1fr; }
  .form-row { grid-template-columns: 1fr; }
}
```

## Key Takeaways 🌟

1. Great contact pages include a form, alternative contact methods, and a map
2. `<address>` is the semantic element for contact/location information
3. `<optgroup>` organises select options into logical groups
4. Google Maps `<iframe>` embeds are free and easy — find embed code in Google Maps → Share → Embed
5. The two-column layout (contact info + form) is a professional, tested pattern
6. Response time expectations ("within 24 hours") reduce user anxiety and increase trust
7. Always test forms — nothing is more embarrassing than a broken contact form on a professional site
$L$,
ARRAY['html','css','forms','project','contact-page','maps'], 29),

('bld-l30', 'Introduction to Scratch: Your Next Level Up', 'Scratch', 'Scratch', 'beginner', 30, 'published',
ARRAY['Navigate the full Scratch interface on scratch.mit.edu','Understand the difference between Scratch and Scratch Jr','Create a basic animated project in Scratch'],
$L$# Introduction to Scratch: Your Next Level Up

## From Scratch Jr to Scratch

You''ve mastered Scratch Jr — and built some impressive projects with it. Now it''s time to move to its bigger sibling: **Scratch**.

Scratch is the full-featured version created by MIT for ages 8+. It runs in your browser at scratch.mit.edu and is completely free.

## How Scratch Differs from Scratch Jr

| Feature | Scratch Jr | Scratch |
|---------|-----------|---------|
| Age range | 5-7 | 8-16 |
| Variables | No | Yes |
| Lists | No | Yes |
| Loops with conditions | Limited | Full while/until |
| Multiple sprites | Yes | Yes, more complex |
| Custom blocks | No | Yes |
| Score keeping | No | Yes |
| File size | Small | Larger projects possible |
| User community | Limited | Millions of projects to remix |

## The Scratch Interface

**Stage (top right):** Where your project runs. Default size: 480×360 pixels.

**Sprite list (bottom right):** All sprites (characters/objects) in your project. Click one to select it and edit its code.

**Code blocks palette (left):** Colour-coded categories of blocks.

**Scripts/Code area (centre):** Drag blocks here to build your programs.

**Backdrop editor:** The background of your stage.

## Block Categories

**Motion:** Move, rotate, go to position, point in direction, bounce off edge  
**Looks:** Change costume, say/think speech bubbles, show/hide, set size, visual effects  
**Sound:** Play sound, set volume, stop sounds  
**Events:** When flag clicked, when key pressed, when sprite clicked, when backdrop switches  
**Control:** If/then/else, repeat, wait, forever, stop, create clone  
**Sensing:** Touching? Touching colour? Distance to? Key pressed? Ask and answer  
**Operators:** Math (+, -, ×, ÷), comparisons (>, <, =), logic (and, or, not), random number, join text  
**Variables:** Make a Variable, set, change, show/hide variable  
**My Blocks:** Create your own reusable blocks (like functions)

## Your First Scratch Program

**Goal:** Make a sprite walk across the screen, say something, and animate.

```
When 🏁 clicked:
  go to x: -200, y: 0
  Forever:
    next costume
    move 3 steps
    if touching edge? then
      turn 180 degrees
      set rotation style: left-right
    wait 0.05 seconds
```

**How to build it:**
1. Click the cat sprite in the sprite list
2. Go to Events → drag "when green flag clicked"
3. Go to Motion → drag "go to x: y:" — set x to -200, y to 0
4. Go to Control → drag "forever" loop
5. Go to Looks → drag "next costume" inside the loop
6. Go to Motion → drag "move 3 steps"
7. Go to Control → drag "if...then" block
8. Go to Sensing → drag "touching edge" into the if condition
9. Go to Motion → drag "turn 180 degrees"
10. Go to Motion → drag "set rotation style: left-right"
11. Go to Control → drag "wait 0.05 seconds"

Press the green flag to watch it run!

## Coordinates in Scratch

Scratch uses a coordinate system:
- **x-axis:** -240 (far left) to +240 (far right)
- **y-axis:** -180 (bottom) to +180 (top)
- **(0, 0)** is the exact centre of the stage

```
         y: 180
            |
x:-240 -----+------ x:240
            |
         y:-180
```

Use "go to x: y:" to place sprites precisely.

## The Green Flag and Stop Button

🏁 **Green flag** = Start the project (runs all "when green flag clicked" scripts)  
🛑 **Red stop button** = Stop all scripts immediately

You can also click individual sprites to trigger "when this sprite clicked" events.

## Saving Your Project

- **Online (recommended):** Sign in to scratch.mit.edu → your project saves to your account automatically
- **Offline:** File → Save to your computer → creates an `.sb3` file

## Sharing Your Project

Once saved online: Share → Copy the link to send to friends and family. Anyone can see and remix your project!

## The Scratch Community

Scratch has over 100 million registered users and 100+ million shared projects. You can:
- Remix other people''s projects (always allowed — it''s built-in)
- Comment on and love projects
- Follow creators you like
- Join Scratch Studios (collections of projects on a theme)

## Key Takeaways 🌟

1. Scratch is the full-featured version of Scratch Jr for ages 8+
2. Key additions: variables, lists, condition-based loops, complex sensing
3. The Stage is 480×360 pixels with centre at (0, 0)
4. The four main areas: Stage, Sprite list, Block palette, Scripts area
5. The green flag runs all "when flag clicked" scripts; the red button stops everything
6. Save your work online by creating a free scratch.mit.edu account
7. You can remix any public Scratch project — it''s a collaborative community
$L$,
ARRAY['scratch','introduction','animation','beginner'], 30);

-- Lessons 31-100: Writing comprehensive Scratch and advanced CSS content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l31', 'Scratch: Variables and Score Tracking', 'Scratch', 'Scratch', 'intermediate', 35, 'published',
ARRAY['Create and use Scratch variables','Build a score system in a game','Use variables to track lives and game state'],
$L$# Scratch: Variables and Score Tracking

## What Is a Variable?

A **variable** is a named container for storing information that can change. Think of it like a labelled box: you put something in, you can look at it later, and you can replace what''s inside.

In games, variables track:
- Score (increases when you catch/hit something)
- Lives (decreases when you make a mistake)
- Level (increases when you complete a stage)
- Time (counts down or up)
- Speed (increases as the game gets harder)

## Creating Variables in Scratch

1. Click the **Variables** category (orange) in the block palette
2. Click **"Make a Variable"**
3. Name it (e.g., "Score")
4. Choose **"For all sprites"** (shared between all sprites) or **"For this sprite only"**
5. Click OK

A new set of blocks appears: **set [Score] to [ ]**, **change [Score] by [ ]**, **show variable [Score]**, **hide variable [Score]**

The variable also appears on the stage as a display (you can drag it anywhere or right-click to change the display style).

## Building a Complete Score System

**Project: Catch the Star**
- A star falls from the top of the screen
- Click it before it falls off for +10 points
- Miss it: -1 life
- Game ends when lives reach 0

### Setting Up

Create these variables:
- `Score` — tracks points
- `Lives` — tracks remaining lives  
- `GameOver` — 0 = playing, 1 = game over
- `Level` — increases every 50 points

### Initialise on Game Start (on Stage or a control sprite):

```scratch
When 🏁 clicked:
  set [Score] to [0]
  set [Lives] to [3]
  set [GameOver] to [0]
  set [Level] to [1]
  broadcast [GameStart]
```

### Star Sprite Logic:

```scratch
When I receive [GameStart]:
  show
  Forever:
    if [GameOver] = [1] then
      stop this script
    end
    go to x: (pick random -200 to 200) y: (180)
    repeat until <<y position> < (-180)>:
      change y by (-3 - Level)  ← Falls faster as level increases!
      if <mouse down?> and <touching [mouse-pointer v]?> then
        change [Score] by [10]
        if [Score] > [Level * 50] then
          change [Level] by [1]
        end
        go to x: (pick random -200 to 200) y: (180)  ← Reset position
      end
    end
    ← If we get here, star fell off bottom (missed!)
    change [Lives] by [-1]
    if [Lives] < [1] then
      set [GameOver] to [1]
      broadcast [GameOver]
    end
```

### Game Over Handler (on Stage):

```scratch
When I receive [GameOver]:
  stop [other scripts in stage v]
  switch backdrop to [gameover v]
  say [Game Over! Score: ] + Score
```

## Operators with Variables

```scratch
← Maths
set [Speed] to ((Score / 10) + 2)  ← Speed increases with score

← Comparisons  
if [Lives] < [2] then
  ← Flash red warning!
end

← Text joining
say (join [Score: ] [Score])  ← Shows "Score: 42"
```

## Variable Display Styles

Right-click a variable display on the stage for three options:
- **Normal readout:** Shows name and value (default)
- **Large readout:** Just the number, very big
- **Slider:** Drag to change the value (great for testing!)

## Activity: Add a Timer

Add a countdown timer to any game you''ve built:

```scratch
← In a separate timer sprite or on stage:
When 🏁 clicked:
  set [Timer] to [30]
  repeat until <[Timer] = [0]> or <[GameOver] = [1]>:
    wait [1] seconds
    change [Timer] by [-1]
  end
  if [Timer] = [0] then
    broadcast [GameOver]
  end
```

## Key Takeaways 🌟

1. Variables store information that changes: score, lives, level, speed, timer
2. Create variables in the Variables (orange) block category
3. Use `set [var] to [value]` to assign a value; `change [var] by [amount]` to increment/decrement
4. Variables display on the stage automatically — right-click to change display style
5. Use `if [Lives] < [1] then` to detect game-over conditions
6. Variables work across sprites when set to "For all sprites"
7. Combining variables with operators enables complex game logic: difficulty scaling, level progression
$L$,
ARRAY['scratch','variables','game-design','score','lives'], 31),

('bld-l32', 'Scratch: Broadcasting Messages Between Sprites', 'Scratch', 'Scratch', 'intermediate', 30, 'published',
ARRAY['Use broadcast to coordinate multiple sprites','Understand when to use broadcast vs sensing','Build a multi-sprite scene using messages'],
$L$# Scratch: Broadcasting Messages Between Sprites

## The Problem of Coordination

Imagine a game with three sprites: a player, an enemy, and a score counter. When the player touches the enemy, you need ALL of them to respond simultaneously:
- Player: stop moving and play a hurt animation
- Enemy: disappear temporarily
- Score: subtract a life

How do you tell all three at once? **Broadcasting**.

## How Broadcasting Works

**Broadcasting** is like making an announcement over a loudspeaker — any sprite that''s "listening" can hear it and respond.

1. One sprite **broadcasts** a message: "Player hurt!"
2. ALL sprites have their code checked for "when I receive [Player hurt]"
3. Any that have that block immediately run the attached code

Multiple sprites can respond to the same broadcast. One sprite can broadcast and also receive its own broadcast.

## The Blocks

**Sending:**
```scratch
broadcast [MessageName v]
← Sends message, keeps running your current script

broadcast [MessageName v] and wait
← Sends message, PAUSES until all receivers finish their scripts
```

**Receiving:**
```scratch
when I receive [MessageName v]
← Runs the attached code when that message arrives
```

**Creating new messages:** Click the dropdown in any broadcast block → New message → type the name.

## Common Messages to Use

Good message names are descriptive:
- `GameStart` — when the game begins
- `GameOver` — when the game ends
- `PlayerDied` — when the player loses a life
- `LevelComplete` — when a level is finished
- `SpawnEnemy` — tell an enemy to appear
- `PlayMusic` — tell a music sprite to start
- `ShowMenu` — tell a menu sprite to appear

## Building a Multi-Scene Story

Broadcasts shine in interactive stories where different scenes play in sequence:

```scratch
← Stage (backdrop handler)
When 🏁 clicked:
  switch backdrop to [scene1 v]
  broadcast [StartScene1]

When I receive [Scene1Complete]:
  switch backdrop to [scene2 v]
  broadcast [StartScene2]

When I receive [Scene2Complete]:
  switch backdrop to [scene3 v]
  broadcast [StartScene3]
```

```scratch
← Character sprite
When I receive [StartScene1]:
  go to x: (-200) y: (0)
  show
  say [Hmm, where am I?] for (2) seconds
  say [I need to find the exit!] for (2) seconds
  glide (2) secs to x: (200) y: (0)
  broadcast [Scene1Complete]  ← Tell the stage we''re done!
```

## Broadcast vs Sensing: When to Use Each

| Use broadcast when... | Use sensing when... |
|----------------------|---------------------|
| You want multiple sprites to respond | You just need to know about one sprite |
| Triggering a sequence of events | Checking collision (touching?) |
| Communicating specific events | Continuously monitoring distance |
| Changing game state (start, over, level) | Local sprite decisions |

Example:
```scratch
← Don''t do this (sensing to coordinate):
Forever:
  if <touching [player v]?> then
    broadcast [PlayerCollided]  ← Unnecessary! Use local collision directly
  end

← Do this instead:
← On the player sprite directly:
Forever:
  if <touching [enemy v]?> then
    change [Lives] by [-1]
    play sound [hurt v]
  end
```

## Activity: The Space Rescue Game

Build a 3-scene interactive adventure using broadcasts:

**Scene 1:** Your rocket is floating in space
- Click the rocket → it flies to the right
- When it reaches the edge → `broadcast [Scene2Start]`

**Scene 2:** You discover a planet
- The planet appears (was hidden)
- A alien walks out and says hello
- Click the alien to "befriend" it → `broadcast [Scene3Start]`

**Scene 3:** Flying home together
- Both sprites appear and fly together
- A "You win!" message appears

This structure — using broadcasts to sequence scenes — is exactly how game developers build level transitions and cutscenes in real games.

## Key Takeaways 🌟

1. Broadcasting sends a named message that ALL sprites with a matching "when I receive" block respond to
2. `broadcast and wait` pauses until all receivers complete; plain `broadcast` continues immediately
3. Use descriptive message names: `GameStart`, `PlayerDied`, `LevelComplete`
4. Broadcasts are best for coordinating events across multiple sprites
5. For simple local sprite decisions, use sensing (touching?) directly
6. Multi-scene stories and game state management are perfect broadcast use cases
7. One sprite can broadcast and receive the same message — careful of infinite loops!
$L$,
ARRAY['scratch','broadcast','coordination','game-design','multi-sprite'], 32),

('bld-l33', 'Scratch: Build a Complete Platform Game', 'Scratch', 'Scratch', 'intermediate', 60, 'published',
ARRAY['Build a side-scrolling platform game from scratch','Implement gravity, jumping, and platform collision','Add enemies, score, and lives to a complete game'],
$L$# Scratch: Build a Complete Platform Game

## The King of Game Genres

Platform games — where a character runs, jumps, and navigates platforms — are the most iconic game genre. Mario, Donkey Kong, Sonic, Celeste. You''re going to build one.

This is the most complex project in the Builders level. Take your time, build piece by piece, and test constantly.

## Core Mechanics

Every platform game needs:
1. **Player movement** — left/right walking
2. **Gravity** — constant downward pull
3. **Jumping** — upward force that gravity overcomes
4. **Platform collision** — landing on platforms
5. **Death/reset** — falling off screen

## The Physics: Gravity and Jumping

Platform games simulate physics with variables:

```
yVelocity = speed moving up/down
- If yVelocity is positive: moving up
- If yVelocity is negative: moving down (falling)
- Gravity: subtract a small amount from yVelocity each frame
- Jump: set yVelocity to a large positive number
```

## Step 1: Set Up Variables

Create these variables:
- `yVelocity` — vertical speed
- `onGround` — 0 or 1 (is player on ground?)
- `Score`
- `Lives`
- `GameOver`

## Step 2: Player Sprite Code

```scratch
When 🏁 clicked:
  set [yVelocity] to [0]
  set [onGround] to [0]
  set [Score] to [0]
  set [Lives] to [3]
  set [GameOver] to [0]
  go to x: (-180) y: (-50)
  Forever:
    ← Handle left/right movement
    if <key [left arrow v] pressed?> then
      change x by (-4)
      point in direction (-90)
      next costume
    end
    if <key [right arrow v] pressed?> then
      change x by (4)
      point in direction (90)
      next costume
    end
    
    ← Handle jumping
    if <<key [space v] pressed?> and <[onGround] = [1]>> then
      set [yVelocity] to [12]
      set [onGround] to [0]
    end
    
    ← Apply gravity
    change [yVelocity] by (-0.8)
    change y by [yVelocity]
    
    ← Floor collision (simplest platform)
    if <(y position) < (-150)> then
      set y to (-150)
      set [yVelocity] to [0]
      set [onGround] to [1]
    end
    
    ← Fell off bottom — lose life
    if <(y position) < (-180)> then
      change [Lives] by (-1)
      go to x: (-180) y: (-50)
      set [yVelocity] to [0]
      if <[Lives] < [1]> then
        broadcast [GameOver]
        stop this script
      end
    end
    
    ← Coin/goal collision
    if <touching [Coin v]?> then
      change [Score] by [10]
      ← Tell coin to reset position
      broadcast [CoinCollected]
    end
```

## Step 3: Platforms

Create platform sprites (long thin rectangles). For each platform:

**The player needs to detect platforms and land on top:**

```scratch
← Add inside the player''s Forever loop, after applying yVelocity:

if <<touching [Platform1 v]?> and <[yVelocity] < [0]>> then
  ← Only land when falling (yVelocity negative)
  set [yVelocity] to [0]
  set [onGround] to [1]
  ← Snap to top of platform
  repeat until <not <touching [Platform1 v]?>>
    change y by [1]
  end
end
```

Create 3-5 platforms at different heights, duplicate this code for each.

## Step 4: Coins/Collectibles

```scratch
← Coin sprite:
When 🏁 clicked:
  show
  go to x: (100) y: (-80)

When I receive [CoinCollected]:
  ← Move to new position (respawn)
  go to x: (pick random -200 to 200) y: (pick random -100 to 150)
```

## Step 5: Simple Enemy

```scratch
← Enemy sprite:
When 🏁 clicked:
  go to x: (50) y: (-120)
  Forever:
    ← Pace back and forth
    glide (2) secs to x: (150) y: (-120)
    glide (2) secs to x: (-50) y: (-120)

← Touch detection happens on the player:
← Inside player''s Forever loop:
if <touching [Enemy v]?> then
  change [Lives] by (-1)
  go to x: (-180) y: (-50)
end
```

## Step 6: Win Condition

```scratch
← Flag/Goal sprite:
When 🏁 clicked:
  go to x: (220) y: (-100)
  show

← On player:
if <touching [Goal v]?> then
  broadcast [LevelComplete]
  stop this script
end
```

## Step 7: Game Over and Win Screens

```scratch
← On Stage:
When I receive [GameOver]:
  stop [other scripts in stage v]
  switch backdrop to [gameOver v]
  
When I receive [LevelComplete]:
  stop [other scripts in stage v]  
  switch backdrop to [win v]
```

## Polishing Your Game

Once the core mechanics work, add polish:
- Walk animation (next costume in the movement code)
- Jump animation (different costume mid-air)
- Coin spin animation (constantly switching costumes)
- Sound effects (jump sound, collect sound, hurt sound)
- Background music (forever loop on a sound sprite)
- Particle effects (small star sprites that appear when collecting coins)

## Playtesting Checklist

Before calling your game finished:
- [ ] Can you complete the level?
- [ ] Does dying work? Do you respawn correctly?
- [ ] Does game over work?
- [ ] Is the difficulty balanced? (Too hard? Too easy?)
- [ ] Do sounds play at the right moments?
- [ ] Does the game look good?

## Key Takeaways 🌟

1. Platform physics use a `yVelocity` variable — gravity subtracts from it each frame, jumping sets it high
2. Only land on platforms when `yVelocity < 0` (falling) to prevent sticking going up
3. Death detection: if `y position < -180`, respawn the player
4. Broadcasts coordinate game state: GameStart, GameOver, LevelComplete, CoinCollected
5. Build complexity incrementally: movement first, then gravity, then platforms, then enemies
6. Test after EVERY addition — a broken game is hard to debug after many changes
7. The "snap to surface" technique (moving up 1px at a time until not touching) is how real collision works
$L$,
ARRAY['scratch','platform-game','gravity','physics','game-design'], 33),

('bld-l34', 'Scratch: Cloning Sprites for Multiple Objects', 'Scratch', 'Scratch', 'intermediate', 30, 'published',
ARRAY['Use clone blocks to create multiple copies of a sprite','Control individual clones with their own behaviours','Build a falling objects game using clones'],
$L$# Scratch: Cloning Sprites for Multiple Objects

## The Problem Clones Solve

Imagine making a game where 50 stars fall from the sky. Without clones, you''d need 50 separate sprites, each programmed individually. Changing the behaviour means changing 50 sprites.

**Clones** let you create multiple copies of ONE sprite, each with its own independent behaviour. Change the code once — all clones behave differently.

## How Cloning Works

1. A "parent" sprite runs code that creates clones
2. Each clone is a copy of the sprite at the moment of cloning
3. Clones respond to "when I start as a clone" — their own private script
4. Delete clones when done with `delete this clone`

## The Three Clone Blocks

```scratch
create clone of [myself v]
← Creates a new copy of this sprite. The clone immediately runs any 
   "when I start as a clone" scripts.

when I start as a clone
← Attached code only runs on CLONES, not on the original sprite.
   This is where you put clone-specific behaviour.

delete this clone
← Removes this specific clone. Does not affect other clones.
   Original sprite is never deleted this way.
```

## Your First Clone Example: Bullet Shooter

```scratch
← Player sprite (spaceship)
when [space v] key pressed:
  create clone of [Bullet v]

← Bullet sprite
when 🏁 clicked:
  hide  ← Hide the original bullet (only clones should be visible)

when I start as a clone:
  show
  go to x: (x position of [Player v]) y: (y position of [Player v])
  Forever:
    change y by [10]  ← Move upward
    if <touching [Enemy v]?> then
      broadcast [EnemyHit]
      delete this clone
    end
    if <(y position) > [180]> then
      delete this clone  ← Gone off the top — delete it
    end
```

## Falling Objects Game with Clones

**Design:** Random objects fall from the top. The player catches or avoids them.

```scratch
← "Spawner" sprite (can be invisible):
when 🏁 clicked:
  Forever:
    create clone of [FallingObject v]
    wait (pick random 0.5 to 2) seconds  ← Random spawn rate

← FallingObject sprite:
when 🏁 clicked:
  hide

when I start as a clone:
  show
  ← Randomise starting position
  go to x: (pick random -220 to 220) y: (180)
  ← Randomise appearance
  set size to (pick random 50 to 100)%
  
  repeat until <(y position) < (-180)>:
    change y by (-4)  ← Fall speed
    
    if <touching [Player v]?> then
      change [Score] by [10]
      delete this clone
    end
  end
  ← Reached the bottom without being caught
  change [Misses] by [1]
  delete this clone
```

## Using Clone Variables

Clones share the global variables but you can give each clone unique properties using a technique called "stamp variables":

```scratch
← Before creating a clone, set a temporary variable to the clone''s intended value

set [CloneType] to [1]  ← This value is "baked in" when clone is created
create clone of [myself v]

set [CloneType] to [2]
create clone of [myself v]

when I start as a clone:
  if <[CloneType] = [1]> then
    set colour effect to [0]    ← Gold star
  else
    set colour effect to [120]  ← Green star
  end
```

## Controlling Clone Count

Too many clones can slow Scratch down. Scratch has a limit of about 300 clones total. Manage this:

```scratch
← Safe spawn pattern
if <[number of clones] < [20]> then
  create clone of [myself v]
end
```

Or always delete clones promptly when they''re no longer needed (off screen, touched player, etc.)

## Activity: Asteroid Dodge

Build a dodge game using clones:

**Goal:** Move the player left and right to dodge falling asteroids. Survive for 30 seconds to win.

**Asteroids:**
- Clone spawner creates a new asteroid every 1-2 seconds
- Each asteroid starts at a random x position at the top
- Falls at a random speed (2-5 pixels per step)
- Gets deleted when off-screen or touching player (= game over)

**Challenge:** Make asteroids fall faster every 10 seconds (use a `Difficulty` variable that increases over time)

## Key Takeaways 🌟

1. Clones create multiple independent copies of ONE sprite — much more efficient than many sprites
2. The original sprite should usually be `hide` — only clones are visible
3. `when I start as a clone` is the entry point for clone-specific code
4. Always `delete this clone` when a clone is no longer needed
5. Clones share global variables but set unique properties through variables set just before creating
6. The spawn-and-drift pattern (random position → fall → delete on exit) is the foundation of countless games
7. Scratch allows about 300 total clones — delete old ones to keep performance smooth
$L$,
ARRAY['scratch','clones','game-design','falling-objects','performance'], 34);

-- Lessons 35-100 completing the Builders curriculum with proper content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l35', 'Scratch: Making a Quiz Game with Score', 'Scratch', 'Scratch', 'intermediate', 40, 'published',
ARRAY['Build a multi-question quiz in Scratch','Use variables for question index and score','Display questions and validate answers'],
$L$# Scratch: Making a Quiz Game with Score

## Quiz Games Are Programming Fundamentals

Building a quiz game teaches you some of the most important programming concepts:
- Arrays (lists) to store questions and answers
- Loops to cycle through questions
- Conditionals to check if answers are correct
- Variables to track score and progress

## Setting Up Your Quiz Data

In Scratch, use **Lists** to store questions and answers.

Create these lists (Variables → Make a List):
- `Questions` — your question text
- `Answers` — the correct answer for each question
- `PlayerAnswers` — what the player typed (we''ll fill this as they play)

```scratch
← On the Stage, when 🏁 clicked:
add [What is the capital of Canada?] to [Questions v]
add [Ottawa] to [Answers v]

add [How many sides does a hexagon have?] to [Questions v]
add [6] to [Answers v]

add [What language is used to style websites?] to [Questions v]
add [CSS] to [Answers v]

add [What does HTML stand for?] to [Questions v]
add [HyperText Markup Language] to [Answers v]

add [Who invented the World Wide Web?] to [Questions v]
add [Tim Berners-Lee] to [Answers v]

set [QuestionNumber] to [1]
set [Score] to [0]
broadcast [NextQuestion]
```

## The Question Display Sprite

Create a sprite to display questions and accept answers:

```scratch
when I receive [NextQuestion]:
  ← Check if we''ve finished all questions
  if <[QuestionNumber] > (length of [Questions v])> then
    broadcast [QuizComplete]
    stop this script
  end
  
  ← Show the question
  ask (item (QuestionNumber) of [Questions v]) and wait
  
  ← Check the answer (case-insensitive by converting to lowercase)
  if <(answer) = (item (QuestionNumber) of [Answers v])> then
    say [Correct! ✓ +10 points] for (1.5) seconds
    change [Score] by [10]
    play sound [correct v]
  else
    say (join [Not quite! The answer was ] (item (QuestionNumber) of [Answers v])) for (2) seconds
    play sound [wrong v]
  end
  
  change [QuestionNumber] by [1]
  broadcast [NextQuestion]
```

## Quiz Complete Screen

```scratch
when I receive [QuizComplete]:
  stop [other scripts v]
  
  if <[Score] > [40]> then
    say (join [Amazing! You scored ] (join [Score] [/50! 🏆])) for (5) seconds
  else if <[Score] > [20]> then
    say (join [Good job! You scored ] (join [Score] [/50! Keep practicing.])) for (5) seconds
  else
    say (join [You scored ] (join [Score] [/50. Review and try again!])) for (5) seconds
  end
```

## Adding Multiple Choice

Instead of typed answers, give the player 4 options using sprites as buttons:

```scratch
← Create 4 Button sprites (A, B, C, D)
← Store all 4 options in a list for the current question

← Set up options for each question
set [CorrectPosition] to (pick random 1 to 4)
← Place correct answer at random button
← Place wrong answers (distractors) at other buttons

← When a button is clicked:
when this sprite clicked:
  if <[MyPosition] = [CorrectPosition]> then
    broadcast [CorrectAnswer]
  else
    broadcast [WrongAnswer]
  end
```

## Timing Questions

Add a timer bar that counts down for each question:

```scratch
← Timer Bar sprite (a long rectangle)
when I receive [NextQuestion]:
  set size to [100]%  ← Full width
  repeat [30]:  ← 30 frames = about 1 second at 30fps
    change size by (-3)  ← Shrink each frame
    wait (0.033) seconds
  end
  ← Time ran out!
  broadcast [TimeUp]
```

## Key Takeaways 🌟

1. Lists (arrays) store your questions and answers in order
2. The `ask [] and wait` block captures user input into the `answer` variable
3. Compare `answer` to the item in your Answers list at the current index
4. A loop with a `QuestionNumber` index cycles through all questions
5. Broadcast `NextQuestion` at the end of each answer to advance
6. Multiple choice is more engaging than free text — randomise the correct answer position!
7. Timer bars create urgency — use `change size by` to shrink a bar sprite
$L$,
ARRAY['scratch','quiz','lists','arrays','game-design'], 35),

('bld-l36', 'Scratch: Animation Techniques', 'Scratch', 'Scratch', 'intermediate', 30, 'published',
ARRAY['Create smooth animations with costume sequences','Use glide and animation together','Build a walking cycle and talking animation'],
$L$# Scratch: Animation Techniques

## Animation Is Storytelling with Movement

Animation in Scratch works exactly like a flipbook — you cycle through a series of slightly different images (costumes) quickly enough that the eye perceives smooth motion.

The key variables: **how many costumes** you have and **how fast** you cycle through them.

## The Walk Cycle

A standard walk cycle needs a minimum of 4 frames:
1. Right foot forward
2. Midstride
3. Left foot forward  
4. Midstride back

In Scratch, the cat sprite already has two costumes (cat-a and cat-b) — a basic 2-frame walk cycle.

```scratch
← Basic walk cycle
when [right arrow v] key pressed:
  repeat [4]:
    move [4] steps
    next costume
    wait [0.05] seconds
  end

← Smooth continuous walk
when 🏁 clicked:
  Forever:
    if <key [right arrow v] pressed?> then
      move [4] steps
      next costume
      wait [0.08] seconds
    else
      ← Standing: always use costume 1
      switch costume to [cat-a v]
    end
```

## Talking Animations

The classic cartoon "mouth moving while talking" effect:

```scratch
← Talking: alternate between open and closed mouth costumes

define talk for [seconds] seconds
  set [TalkTimer] to [0]
  repeat until <[TalkTimer] > [seconds * 10]>:
    switch costume to [mouth-open v]
    wait [0.1] seconds
    switch costume to [mouth-closed v]
    wait [0.1] seconds
    change [TalkTimer] by [1]
  end
  switch costume to [mouth-closed v]  ← End on closed mouth

when 🏁 clicked:
  say [Hello! I''m your coding guide.] for [2] seconds
  talk for [2] seconds  ← Mouth animates for 2 seconds
```

## Sprite Expressions (Emotion Costumes)

Design costumes for different emotions:
- Neutral (default)
- Happy 😊
- Surprised 😮
- Sad 😢
- Thinking 🤔

```scratch
when I receive [PlayerWon]:
  switch costume to [happy v]
  say [Amazing! You did it! 🎉] for [3] seconds
  switch costume to [neutral v]

when I receive [PlayerLost]:
  switch costume to [sad v]
  say [Oh no! Let''s try again.] for [2] seconds
  switch costume to [neutral v]
```

## Smooth Movement with Glide

`glide` creates smooth movement between two points:

```scratch
← Instead of: go to x: (200) y: (100)  ← Instant jump
← Use: glide (1) secs to x: (200) y: (100)  ← Smooth movement

← Moving in a pattern
when 🏁 clicked:
  Forever:
    glide [1.5] secs to x: [150] y: [80]
    glide [1.5] secs to x: [-50] y: [-100]
    glide [1.5] secs to x: [-200] y: [100]
    glide [1.5] secs to x: [0] y: [0]
```

## Visual Effects for Emphasis

```scratch
← Bounce effect when picking up an item
when I receive [ItemCollected]:
  repeat [5]:
    change size by [10]
  end
  repeat [5]:
    change size by [-10]
  end

← Spin effect
repeat [36]:
  turn [10] degrees
end

← Fade out and respawn
repeat [25]:
  change [ghost v] effect by [4]  ← 0=visible, 100=invisible
end
hide
go to x: (0) y: (0)
clear graphic effects
show

← Flash/blink
repeat [6]:
  hide
  wait [0.1] seconds
  show
  wait [0.1] seconds
end
```

## Sprite Scaling for Depth

Making sprites smaller as they move "away" and larger as they come "closer" creates a 3D depth illusion:

```scratch
← "Walking into the scene"
when 🏁 clicked:
  set size to [30]%
  go to x: [0] y: [-30]
  glide [2] secs to x: [0] y: [-100]
  set size to [100]%
```

## Creating a Scene with Multiple Animated Sprites

For a short animated film:

1. **Background sprite:** switch backdrops at scene transitions
2. **Character sprites:** walk, talk, emote
3. **Effect sprites:** weather, particles, lighting
4. **Music/sound sprite:** plays appropriate music for each scene
5. **Director sprite:** broadcasts scene changes in sequence

Use `broadcast and wait` to sequence scenes:

```scratch
← Director sprite
when 🏁 clicked:
  broadcast [Scene1] and wait   ← Wait for scene 1 to finish
  broadcast [Scene2] and wait   ← Then scene 2
  broadcast [Credits] and wait  ← Then credits
```

## Key Takeaways 🌟

1. Animation is cycling through costumes quickly — like a digital flipbook
2. A walk cycle needs at least 2 costumes; 4 looks much smoother
3. `next costume` cycles forward; `switch costume to [name]` goes to a specific one
4. `glide (n) secs to x: y:` creates smooth movement; `go to x: y:` is instant
5. Visual effects (ghost, colour, size) add polish and emotion
6. A bouncing/scaling effect creates satisfying "pickup" animations
7. Multiple animated sprites + broadcasts = complete animated short films in Scratch!
$L$,
ARRAY['scratch','animation','costumes','glide','effects'], 36),

('bld-l37', 'Scratch: Building an Interactive Story', 'Scratch', 'Scratch', 'intermediate', 45, 'published',
ARRAY['Build a branching interactive story with choices','Use variables to track story state and choices','Create a different ending based on player decisions'],
$L$# Scratch: Building an Interactive Story

## Choose Your Own Adventure

Remember those books where you choose what happens next? "If you open the door, go to page 47. If you run away, go to page 83." That''s a **branching narrative**, and you can build one in Scratch.

This project teaches one of the most important programming patterns: **state management** — tracking where the player has been and what choices they''ve made to determine what happens next.

## Story Design First: Write Before You Code

Before touching Scratch, write your story on paper:

```
START: You''re lost in a forest
  └─ Choice A: Follow the bird song
  │    └─ You find a stream → Choice: Drink or Follow upstream
  │         └─ Drink → Feeling refreshed, continue
  │         └─ Follow → Discover a village → GOOD ENDING
  └─ Choice B: Climb a tree to look around
       └─ You spot smoke → Choice: Go to the smoke or stay hidden
            └─ Go to smoke → Friendly camp → GOOD ENDING
            └─ Stay hidden → Night falls, game over → BAD ENDING
```

Draw this as a flowchart. Every branch is a choice, every leaf is an ending.

## Converting Your Story to Scratch Variables

Use variables to track the story state:
- `Chapter` — which scene we''re in (1, 2, 3...)
- `PlayerChoice` — what the player chose at each fork
- `Endings` — which ending they get

## Story Manager Sprite

A single "story manager" sprite orchestrates everything using a long series of broadcasts:

```scratch
← Story Manager
when 🏁 clicked:
  set [Chapter] to [1]
  broadcast [ShowScene] and wait
  
  ← Chapter 1 results in Chapter 2 or Chapter 3 based on choice
  if <[PlayerChoice] = [A]> then
    set [Chapter] to [2]
  else
    set [Chapter] to [3]
  end
  broadcast [ShowScene] and wait
  
  ← And so on for each branch...
```

## Scene Display Sprite

```scratch
when I receive [ShowScene]:
  ← Switch to appropriate backdrop
  switch backdrop to (join [scene] [Chapter])
  
  if <[Chapter] = [1]> then
    say [You''re lost in the forest. It''s getting dark.] for [3] seconds
    say [You hear birdsong to the left and see smoke to the right.] for [3] seconds
    ← Show choice buttons
    broadcast [ShowChoices]
  end
  
  if <[Chapter] = [2]> then
    say [You follow the birdsong and find a clear stream!] for [2] seconds
    ← Continue with chapter 2 choices...
  end
```

## Choice Button Sprites

Create clickable button sprites for player choices:

```scratch
← Button A sprite
when I receive [ShowChoices]:
  show
  go to x: (-100) y: (-130)
  say [A: Follow the birdsong]

when this sprite clicked:
  set [PlayerChoice] to [A]
  hide
  broadcast [ChoiceMade]

← Button B sprite
when I receive [ShowChoices]:
  show
  go to x: (100) y: (-130)
  say [B: Head toward the smoke]

when this sprite clicked:
  set [PlayerChoice] to [B]
  hide
  broadcast [ChoiceMade]
```

```scratch
← Story Manager handles choice:
when I receive [ChoiceMade]:
  ← Advance to next chapter based on current chapter and choice
  if <[Chapter] = [1]> and <[PlayerChoice] = [A]> then
    set [Chapter] to [2-A]
  end
  ← etc.
  broadcast [ShowScene]
```

## Adding an Inventory System

Track what the player has picked up:

```scratch
← Create a list: Inventory

when I receive [PickUpTorch]:
  add [torch] to [Inventory v]
  say [You picked up a torch!] for [1] seconds

← Later in the story:
if <[Inventory v] contains [torch]?> then
  say [Your torch lights the cave — you can see the treasure!] for [2] seconds
  broadcast [GoodEnding]
else
  say [It''s too dark in the cave. You turn back.] for [2] seconds
  broadcast [NeutralEnding]
end
```

## Making Multiple Endings

```scratch
← Ending handler sprite
when I receive [GoodEnding]:
  switch backdrop to [goodending v]
  say [You found the village and made new friends! 🎉] for [4] seconds
  say [THE END — You got the best ending!] for [3] seconds
  
when I receive [BadEnding]:
  switch backdrop to [badending v]
  say [Night fell and the forest got very cold...] for [2] seconds
  say [THE END — Try making different choices!] for [3] seconds
  broadcast [ShowRestartButton]
```

## Keeping Score of Choices

Track "good" vs "bad" decisions to influence the ending:

```scratch
set [GoodPoints] to [0]

← Each good decision:
change [GoodPoints] by [1]

← At the ending:
if <[GoodPoints] > [3]> then
  broadcast [BestEnding]
else if <[GoodPoints] > [1]> then
  broadcast [OkayEnding]
else
  broadcast [BadEnding]
end
```

## Key Takeaways 🌟

1. Plan your story on paper FIRST — every branch and ending, before touching Scratch
2. Variables track story state: which chapter, what choices were made, what items collected
3. Broadcast + state variables create branching narratives: "if Chapter=2 and Choice=A, go to Chapter 3"
4. Choice button sprites show/hide using broadcasts and set choice variables when clicked
5. An inventory list (items collected) can affect what options are available later
6. Multiple endings based on accumulated "good" decisions create replayability
7. This branching structure is exactly how visual novels, RPGs, and interactive films are programmed
$L$,
ARRAY['scratch','interactive-story','branching-narrative','state-management','lists'], 37),

('bld-l38', 'CSS Grid: Advanced Layout Patterns', 'CSS', 'CSS', 'advanced', 35, 'published',
ARRAY['Build asymmetric magazine layouts with CSS Grid','Use grid-template-areas for complex arrangements','Combine grid and flexbox within the same layout'],
$L$# CSS Grid: Advanced Layout Patterns

## Going Beyond Simple Grids

You know the basics of CSS Grid. Now let''s build the complex layouts that make designers excited — the ones that used to require Photoshop mockups and now live entirely in CSS.

## Pattern 1: The Holy Grail Layout

Header + three-column body (sidebar, main, aside) + footer — perfect for dashboards:

```css
.holy-grail {
  display: grid;
  grid-template-areas:
    "header  header  header"
    "sidebar main    aside"
    "footer  footer  footer";
  grid-template-columns: 240px 1fr 200px;
  grid-template-rows: auto 1fr auto;
  min-height: 100vh;
  gap: 0;
}

header  { grid-area: header; }
.sidebar { grid-area: sidebar; }
main    { grid-area: main; }
aside   { grid-area: aside; }
footer  { grid-area: footer; }

/* On mobile: stack everything */
@media (max-width: 768px) {
  .holy-grail {
    grid-template-areas:
      "header"
      "main"
      "sidebar"
      "aside"
      "footer";
    grid-template-columns: 1fr;
  }
}
```

## Pattern 2: Masonry-style Card Grid

Different sized cards creating a dynamic layout:

```css
.masonry {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-auto-rows: 100px;
  gap: 16px;
}

/* Cards that span different amounts */
.card-small { grid-row: span 2; }  /* 200px tall */
.card-medium { grid-row: span 3; } /* 300px tall */
.card-large { grid-row: span 4; }  /* 400px tall */
.card-wide { grid-column: span 2; }/* 2 columns wide */
.card-featured { grid-column: span 2; grid-row: span 3; } /* Large feature card */
```

## Pattern 3: Photography Portfolio Grid

```css
.portfolio {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-auto-rows: 250px;
  gap: 8px;
}

/* Feature photo takes up top-left 2×2 */
.portfolio .featured {
  grid-column: 1 / 3;
  grid-row: 1 / 3;
}

/* Vertical panoramic */
.portfolio .vertical {
  grid-row: span 2;
}

/* Wide landscape */
.portfolio .horizontal {
  grid-column: span 2;
}

.portfolio img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
```

## Pattern 4: Content + Sidebar Blog

```css
.blog-layout {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 48px;
  max-width: 1100px;
  margin: 0 auto;
  padding: 40px 24px;
}

/* Sidebar stays visible as you scroll */
.blog-sidebar {
  position: sticky;
  top: 80px;
  align-self: start;
  height: fit-content;
}

/* The sidebar itself can use grid internally */
.blog-sidebar {
  display: grid;
  gap: 24px;
}
```

## Pattern 5: Auto-Fit Responsive Grid

The most powerful pattern — creates as many columns as will fit:

```css
/* Auto-fit: fills as many as possible, expanding to fill */
.auto-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 24px;
}

/* Auto-fill: creates empty tracks to maintain column count */
.auto-fill-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 24px;
}
```

The difference:
- `auto-fit`: 3 items on a wide screen → all three expand to fill the space
- `auto-fill`: 3 items on a wide screen → three filled, rest are empty (can leave gaps)

Usually `auto-fit` is what you want.

## Pattern 6: Overlapping Elements

Grid lets elements intentionally overlap:

```css
.overlap-layout {
  display: grid;
  grid-template-columns: 1fr 1fr;
}

.background-image {
  grid-column: 1 / 3;  /* Spans both columns */
  grid-row: 1;
}

.text-card {
  grid-column: 2;  /* Only second column */
  grid-row: 1;     /* SAME row — overlap! */
  z-index: 1;
  align-self: end;
  margin: 24px;
  background: white;
  padding: 24px;
  border-radius: 16px;
}
```

## Combining Grid and Flexbox

The pattern: Grid for page structure, Flexbox inside components:

```css
/* Grid handles the big picture */
.page {
  display: grid;
  grid-template-columns: 240px 1fr;
  grid-template-rows: 64px 1fr;
}

/* Flexbox handles component internals */
.navbar {
  /* Sits in the header grid cell */
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card {
  /* Each card is a flex container */
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.card .card-footer {
  margin-top: auto; /* Push footer to bottom */
  display: flex;
  justify-content: space-between;
}
```

## Key Takeaways 🌟

1. `grid-template-areas` creates readable named layout regions — a map of your page
2. The Holy Grail layout: header/sidebar+main+aside/footer is the foundation of most dashboards
3. `grid-row: span N` and `grid-column: span N` create cards of different sizes
4. `repeat(auto-fit, minmax(min, max))` creates self-adapting responsive grids
5. Elements can intentionally overlap by sharing the same grid row and column
6. Grid and Flexbox are complementary — Grid for page structure, Flexbox inside components
7. `position: sticky; align-self: start; height: fit-content` creates the perfect sticky sidebar pattern
$L$,
ARRAY['css','grid','layout','advanced','masonry','responsive'], 38);


-- Lessons 39-100: Completing all Builders lessons with proper content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l39', 'Building a Photo Gallery Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a CSS Grid photo gallery with hover effects','Apply aspect-ratio and object-fit for uniform images','Create a lightbox overlay effect'],
$L$# Building a Photo Gallery Page

## The Photo Gallery: A Design Classic

Photo galleries are one of the most common web design requests. Every photographer, artist, school, and organisation wants a place to showcase images. You''re going to build one that would impress any client.

## Key Techniques

**`object-fit: cover`** makes images fill their containers without distortion.
**`aspect-ratio`** makes all grid cells the same proportions.
**`:hover` with transforms** creates the reveal effect.
**CSS Grid with `auto-fill`** creates the responsive layout.

## The Gallery HTML

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Photography Gallery</title>
    <link rel="stylesheet" href="gallery.css">
  </head>
  <body>
    <header>
      <h1>My Photography</h1>
      <p>A collection of moments</p>
      <!-- Filter buttons -->
      <nav class="filter-nav">
        <button class="filter-btn active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="nature">Nature</button>
        <button class="filter-btn" data-filter="city">City</button>
        <button class="filter-btn" data-filter="people">People</button>
      </nav>
    </header>

    <main class="gallery" id="gallery">
      <!-- Gallery items -->
      <figure class="gallery-item" data-category="nature">
        <a href="images/forest.jpg" class="lightbox-trigger">
          <img src="images/forest.jpg" alt="Sunlight filtering through autumn forest" loading="lazy">
          <figcaption>
            <h3>Autumn Forest</h3>
            <p>Oshawa Conservation Area · October 2024</p>
          </figcaption>
        </a>
      </figure>

      <!-- Add 11 more items with different categories -->
      <!-- Mix of nature, city, people -->
    </main>

    <!-- Lightbox overlay -->
    <div class="lightbox" id="lightbox" role="dialog" aria-label="Photo viewer">
      <button class="lightbox-close" aria-label="Close photo viewer">×</button>
      <img src="" alt="" class="lightbox-image">
      <div class="lightbox-caption"></div>
    </div>

  </body>
</html>
```

## The Gallery CSS

```css
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Nunito', sans-serif; background: #0a0a0a; color: white; }

/* Header */
header {
  text-align: center;
  padding: 60px 24px 40px;
}
header h1 { font-size: 3rem; font-weight: 900; margin-bottom: 8px; }
header p { color: rgba(255,255,255,0.5); margin-bottom: 32px; }

/* Filter buttons */
.filter-nav { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.filter-btn {
  padding: 8px 20px;
  border: 2px solid rgba(255,255,255,0.3);
  background: transparent;
  color: rgba(255,255,255,0.7);
  border-radius: 99px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 700;
  transition: all 0.2s ease;
  font-family: inherit;
}
.filter-btn:hover, .filter-btn.active {
  background: #F5C518;
  border-color: #F5C518;
  color: #1E2140;
}

/* Gallery Grid */
.gallery {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 8px;
  padding: 24px;
}

/* Gallery Item */
.gallery-item {
  position: relative;
  aspect-ratio: 4/3;
  overflow: hidden;
  border-radius: 8px;
}

.gallery-item a {
  display: block;
  width: 100%;
  height: 100%;
  text-decoration: none;
}

/* Image fills the entire item */
.gallery-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.4s ease;
  display: block;
}

/* Caption overlay - hidden by default */
.gallery-item figcaption {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 50%);
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 20px;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.gallery-item figcaption h3 {
  font-size: 1.1rem;
  font-weight: 900;
  margin-bottom: 4px;
  transform: translateY(8px);
  transition: transform 0.3s ease;
}

.gallery-item figcaption p {
  font-size: 0.8rem;
  color: rgba(255,255,255,0.7);
  transform: translateY(8px);
  transition: transform 0.3s ease 0.05s;
}

/* Hover effects */
.gallery-item:hover img { transform: scale(1.05); }
.gallery-item:hover figcaption { opacity: 1; }
.gallery-item:hover figcaption h3,
.gallery-item:hover figcaption p { transform: translateY(0); }

/* Featured/large items */
.gallery-item.featured {
  grid-column: span 2;
  aspect-ratio: 16/9;
}

/* Lightbox */
.lightbox {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.95);
  z-index: 1000;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 16px;
  padding: 24px;
}
.lightbox.open { display: flex; }

.lightbox-image {
  max-width: 90vw;
  max-height: 80vh;
  object-fit: contain;
  border-radius: 8px;
}

.lightbox-close {
  position: absolute;
  top: 24px;
  right: 24px;
  background: rgba(255,255,255,0.1);
  border: none;
  color: white;
  font-size: 2rem;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  cursor: pointer;
  line-height: 1;
  transition: background 0.2s ease;
}
.lightbox-close:hover { background: rgba(255,255,255,0.2); }
```

## The Lightbox JavaScript

```javascript
// Open lightbox when gallery item is clicked
document.querySelectorAll('.lightbox-trigger').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const img = link.querySelector('img');
    const caption = link.closest('figure').querySelector('figcaption');

    document.querySelector('.lightbox-image').src = link.href;
    document.querySelector('.lightbox-image').alt = img.alt;
    document.querySelector('.lightbox-caption').textContent = caption?.querySelector('h3')?.textContent || '';
    document.getElementById('lightbox').classList.add('open');
  });
});

// Close lightbox
document.querySelector('.lightbox-close').addEventListener('click', () => {
  document.getElementById('lightbox').classList.remove('open');
});

// Close when clicking outside the image
document.getElementById('lightbox').addEventListener('click', (e) => {
  if (e.target === e.currentTarget) {
    e.currentTarget.classList.remove('open');
  }
});

// Close with Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') document.getElementById('lightbox')?.classList.remove('open');
});

// Filter functionality
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    document.querySelectorAll('.gallery-item').forEach(item => {
      if (filter === 'all' || item.dataset.category === filter) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    });
  });
});
```

## Key Takeaways 🌟

1. `aspect-ratio: 4/3` creates uniform grid cells regardless of image dimensions
2. `object-fit: cover` fills the cell without distortion
3. Absolutely positioned `figcaption` with `opacity: 0` → `opacity: 1` on hover creates the reveal
4. Translate + opacity transition creates a "slide up and fade in" caption effect
5. The lightbox uses `position: fixed; inset: 0` to cover the entire viewport
6. `loading="lazy"` on images defers loading until they''re near the viewport — major performance win
7. Filter buttons use `data-category` attributes matched against `data-filter` on items
$L$,
ARRAY['css','grid','gallery','lightbox','hover','object-fit'], 39),

('bld-l40', 'Web Typography: Pairing Fonts Like a Designer', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Choose and pair fonts effectively','Apply typographic hierarchy with scale and weight','Use variable fonts for flexible typography'],
$L$# Web Typography: Pairing Fonts Like a Designer

## Typography Is Communication

Before a reader processes a single word, they''ve received an impression from the typefaces on the page. Fonts communicate:

- **Personality:** A bold, geometric sans-serif feels modern and confident; a classic serif feels trustworthy and established
- **Hierarchy:** Larger, heavier text is more important
- **Mood:** Rounded fonts feel friendly; angular fonts feel precise

Great typography is invisible — readers absorb it without thinking about it. Bad typography creates friction.

## The Anatomy of Type

Understanding basic typographic terms:

**Serif:** Small decorative strokes at the ends of letterforms (Times New Roman, Georgia, Playfair Display). Traditional, trustworthy, readable for long text in print.

**Sans-serif:** No decorative strokes (Arial, Helvetica, Inter, Nunito). Modern, clean, reads well on screens.

**Monospace:** Every character is the same width (Courier New, Fira Code). Used for code because columns align perfectly.

**Display:** Decorative typefaces designed for large headlines, not body text.

## The Font Pairing Formula

The safest and most effective formula for font pairing:

**Contrasting pair:** One serif + one sans-serif

```css
/* Classic newspaper/magazine feel */
--font-heading: 'Playfair Display', Georgia, serif;
--font-body: 'Source Sans Pro', Arial, sans-serif;

/* Modern tech product */
--font-heading: 'Space Grotesk', sans-serif;
--font-body: 'Inter', sans-serif;

/* Warm, friendly (like CODEship) */
--font-heading: 'Nunito', sans-serif;
--font-body: 'Nunito', sans-serif;  /* Same font, different weights! */

/* Premium, editorial */
--font-heading: 'Cormorant Garamond', serif;
--font-body: 'Jost', sans-serif;

/* Bold, statement brand */
--font-heading: 'Anton', sans-serif;  /* Very condensed, impact */
--font-body: 'Mulish', sans-serif;
```

**The simplest pair:** Use ONE font family with different weights. Nunito at weight 900 for headings, weight 400 for body. No clash possible.

## Font Loading Performance

Google Fonts are free but can slow pages down if not loaded efficiently:

```html
<!-- Optimised Google Fonts loading -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<!-- Only request the weights you actually use! -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Nunito:wght@400;600;800&display=swap" rel="stylesheet">
```

- `rel="preconnect"` tells the browser to pre-connect to Google''s servers before the fonts are needed
- `&display=swap` shows fallback fonts immediately, then swaps to the Google Font when loaded (prevents invisible text)
- Only request weights you use — don''t load all 9 weights if you only need 400 and 700

## Implementing a Professional Type Scale

```css
:root {
  --font-heading: 'Playfair Display', Georgia, serif;
  --font-body: 'Nunito', system-ui, sans-serif;

  /* Modular scale: 1.333 ratio (perfect fourth) */
  --text-xs:   0.75rem;    /* 12px */
  --text-sm:   0.875rem;   /* 14px */
  --text-base: 1rem;       /* 16px */
  --text-md:   1.125rem;   /* 18px */
  --text-lg:   1.333rem;   /* ~21px */
  --text-xl:   1.777rem;   /* ~28px */
  --text-2xl:  2.369rem;   /* ~38px */
  --text-3xl:  3.157rem;   /* ~51px */
}

h1 {
  font-family: var(--font-heading);
  font-size: var(--text-3xl);
  font-weight: 900;
  line-height: 1.1;
  letter-spacing: -0.02em; /* Tight tracking on large headlines */
  color: var(--colour-primary);
}

h2 {
  font-family: var(--font-heading);
  font-size: var(--text-2xl);
  font-weight: 700;
  line-height: 1.2;
}

h3 {
  font-family: var(--font-body);  /* Subheadings in body font */
  font-size: var(--text-xl);
  font-weight: 800;
}

p {
  font-family: var(--font-body);
  font-size: var(--text-base);
  line-height: 1.7;          /* Generous line height for reading comfort */
  color: var(--colour-text);
  max-width: 65ch;           /* ~65 characters per line — optimal reading width */
}

/* Lead/intro paragraph */
.lead {
  font-size: var(--text-lg);
  line-height: 1.6;
  font-weight: 600;
  color: var(--colour-text-muted);
}

/* Caption text */
figcaption, .caption {
  font-size: var(--text-sm);
  color: var(--colour-text-muted);
  font-style: italic;
}
```

## Variable Fonts

**Variable fonts** are single font files that contain the entire design space — you can set weight, width, italics to any value:

```css
/* Regular font: separate files for each weight */
@font-face { src: url('font-400.woff2'); font-weight: 400; }
@font-face { src: url('font-700.woff2'); font-weight: 700; }
@font-face { src: url('font-900.woff2'); font-weight: 900; }

/* Variable font: ONE file covers all weights! */
@font-face {
  src: url('font-variable.woff2') format('woff2-variations');
  font-weight: 100 900;  /* Can be ANY value in this range */
}

/* Now you can set any weight: */
h1 { font-weight: 850; }  /* Not possible with regular fonts! */
.caption { font-weight: 350; }
```

Variable fonts load faster (one file vs many) and enable creative effects:

```css
/* Animated weight change on hover */
.heading {
  font-weight: 400;
  transition: font-weight 0.3s ease;
}
.heading:hover {
  font-weight: 900;  /* Gets bolder on hover! */
}
```

## Real Font Pairing Examples

**CODEship Academy:**
```css
--font-main: 'Nunito', sans-serif;
/* Weights used: 400 (body), 600 (semibold), 700 (bold), 900 (black) */
```

**Stripe (payments company):**
```css
/* Sohne for headings, Sohne Book for body */
/* Both from the same type family — perfectly harmonious */
```

**The New York Times:**
```css
/* NYT Cheltenham serif for headings */
/* NYT Franklin Gothic sans-serif for captions and UI */
```

## Key Takeaways 🌟

1. Serif for headings + sans-serif for body is the safest, most effective font pairing
2. One font at multiple weights is foolproof — no clash possible
3. Optimise font loading: `preconnect`, `display=swap`, only load weights you use
4. A modular scale (1.333× ratio) creates harmonious, proportional font sizes
5. Body text: 1.6-1.8 line height, 60-70 characters per line for maximum readability
6. Variable fonts contain an entire design space in ONE file — more flexible and often faster
7. Great typography is invisible — readers absorb content without thinking about the font
$L$,
ARRAY['css','typography','fonts','google-fonts','variable-fonts','design'], 40);

-- Complete remaining lessons 41-100 with proper educational content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('bld-l41', 'HTML: Embedding Maps and External Content', 'HTML', 'HTML', 'intermediate', 25, 'published', ARRAY['Embed Google Maps using iframe','Use the picture element for responsive images','Embed YouTube videos and other external content'], $L$# HTML: Embedding Maps and External Content

## The <iframe> Element

An `<iframe>` (inline frame) embeds another webpage inside your page. It''s how you include Google Maps, YouTube videos, social media feeds, and other external content.

```html
<iframe
  src="URL-of-what-to-embed"
  width="600"
  height="400"
  title="Descriptive title for accessibility"
  loading="lazy"
  allowfullscreen>
</iframe>
```

The `title` attribute is required for accessibility. The `loading="lazy"` defers loading until the iframe is near the viewport.

## Google Maps

Find an embed code in Google Maps:
1. Search for a location
2. Click **Share → Embed a map**
3. Copy the `<iframe>` code

```html
<div class="map-container">
  <iframe
    src="https://www.google.com/maps/embed?pb=..."
    width="100%"
    height="400"
    style="border: 0; border-radius: 12px;"
    allowfullscreen
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"
    title="Our location on Google Maps">
  </iframe>
</div>
```

Make maps responsive:
```css
.map-container {
  position: relative;
  padding-bottom: 56.25%; /* 16:9 aspect ratio */
  height: 0;
  overflow: hidden;
}
.map-container iframe {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
}
```

## YouTube Videos

```html
<div class="video-wrapper">
  <iframe
    src="https://www.youtube.com/embed/VIDEO_ID?rel=0&modestbranding=1"
    title="Video title"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen
    loading="lazy">
  </iframe>
</div>
```

Find the VIDEO_ID in any YouTube URL: `youtube.com/watch?v=**VIDEO_ID**`

Parameters:
- `rel=0` — don''t show related videos from other channels
- `modestbranding=1` — minimal YouTube branding
- `autoplay=1` — play automatically (use carefully — annoying if unexpected!)

## The <picture> Element for Art Direction

Show different images based on screen size:

```html
<picture>
  <!-- Mobile: square crop, loads first on small screens -->
  <source media="(max-width: 600px)" srcset="hero-square.webp" type="image/webp">
  <source media="(max-width: 600px)" srcset="hero-square.jpg">
  
  <!-- Desktop: wide crop -->
  <source media="(min-width: 601px)" srcset="hero-wide.webp" type="image/webp">
  <source media="(min-width: 601px)" srcset="hero-wide.jpg">
  
  <!-- Fallback for browsers that don''t support picture -->
  <img src="hero-wide.jpg" alt="CODEship Academy students coding together">
</picture>
```

The browser picks the first `<source>` whose `media` query matches, then uses its `srcset`.

## srcset for Resolution Switching

Serve larger images to high-resolution screens:

```html
<img
  src="image.jpg"
  srcset="image-400.jpg 400w, image-800.jpg 800w, image-1200.jpg 1200w"
  sizes="(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw"
  alt="Description">
```

`sizes` tells the browser how wide the image will display at different screen widths, so it can pick the right `srcset` source.

## Embedding Social Media

Most platforms provide embed codes. Instagram, Twitter/X, TikTok all have "Share → Embed" options:

```html
<!-- Note: these often require a JavaScript snippet too -->
<!-- Follow the platform''s specific embedding instructions -->

<!-- Twitter/X example (simplified) -->
<blockquote class="twitter-tweet">
  <a href="https://twitter.com/user/status/12345">Tweet link</a>
</blockquote>
<script async src="https://platform.twitter.com/widgets.js"></script>
```

**Privacy consideration:** Embedding third-party content (social media, analytics) often loads their tracking cookies. Mention this in your privacy policy if your site embeds external content.

## Key Takeaways 🌟

1. `<iframe>` embeds external content — maps, videos, other pages
2. Always add `title=""` to iframes for accessibility
3. Use `loading="lazy"` on iframes below the fold for performance
4. Responsive iframes use the padding-bottom hack or `aspect-ratio`
5. `<picture>` enables art direction — different images for different screens
6. `srcset` serves different resolution images to different screen densities
7. Third-party embeds can affect privacy — disclose in your privacy policy
$L$,
ARRAY['html','iframe','maps','youtube','picture','responsive-images'], 41),

('bld-l42', 'Building a School Project Presentation Page', 'Projects', 'HTML', 'intermediate', 50, 'published', ARRAY['Build a structured presentation page suitable for school','Apply semantic HTML for academic content','Create print styles for the page'], $L$# Building a School Project Presentation Page

## The Digital Poster Board

School projects used to mean cutting and gluing onto cardboard. Your generation gets to build websites instead — which are more impressive, easier to update, and reach a global audience.

This project builds a professional presentation page that would impress any teacher (and could actually be submitted as a digital project).

## Structure for a Research Project Page

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Solar System — Science Project by [Your Name]</title>
    <link rel="stylesheet" href="project.css">
    <link rel="stylesheet" href="print.css" media="print">
  </head>
  <body>
    <header class="project-header">
      <div class="class-info">
        <span>Grade 8 Science</span>
        <span>Mrs. Thompson</span>
        <span><time datetime="2024-11-15">November 15, 2024</time></span>
      </div>
      <h1>The Solar System: Our Cosmic Neighbourhood</h1>
      <p class="student-name">By [Your Name]</p>
      <nav class="project-nav">
        <a href="#introduction">Introduction</a>
        <a href="#planets">The Planets</a>
        <a href="#discoveries">Recent Discoveries</a>
        <a href="#conclusion">Conclusion</a>
        <a href="#sources">Sources</a>
      </nav>
    </header>

    <main>
      <section id="introduction">
        <h2>Introduction</h2>
        <p class="lead">The solar system is our cosmic neighbourhood...</p>
        <figure>
          <img src="solar-system.jpg" alt="Diagram of the solar system showing all eight planets orbiting the sun">
          <figcaption>Fig. 1: The solar system (not to scale). Source: NASA</figcaption>
        </figure>
      </section>

      <section id="planets">
        <h2>The Eight Planets</h2>
        <table class="data-table">
          <caption>Key facts about each planet</caption>
          <thead>
            <tr>
              <th scope="col">Planet</th>
              <th scope="col">Distance from Sun</th>
              <th scope="col">Year Length</th>
              <th scope="col">Moons</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>Mercury</td><td>57.9 million km</td><td>88 Earth days</td><td>0</td></tr>
            <tr><td>Venus</td><td>108.2 million km</td><td>225 Earth days</td><td>0</td></tr>
            <!-- Add all 8 planets -->
          </tbody>
        </table>
      </section>

      <section id="discoveries">
        <h2>Recent Discoveries</h2>
        <article class="discovery">
          <h3>James Webb Space Telescope (2022)</h3>
          <p>The JWST has revolutionised our understanding of distant galaxies...</p>
        </article>
      </section>

      <section id="conclusion">
        <h2>Conclusion</h2>
        <p>Through this research, I learned that...</p>
      </section>

      <section id="sources">
        <h2>Sources</h2>
        <ol class="bibliography">
          <li>NASA. (2024). <cite>Solar System Exploration</cite>. <a href="https://solarsystem.nasa.gov">solarsystem.nasa.gov</a></li>
          <li>Williams, M. (2023). <cite>Our Solar System: A Guide</cite>. Universe Today.</li>
        </ol>
      </section>
    </main>

    <footer>
      <p>Submitted for Grade 8 Science · <time datetime="2024-11-15">November 2024</time></p>
    </footer>
  </body>
</html>
```

## Print CSS

Make your page look great when printed (or saved as PDF):

```css
/* print.css — only applied when printing */
@media print {
  /* Hide navigation and interactive elements */
  nav, .project-nav { display: none; }
  
  /* Use paper-friendly colours */
  body { background: white; color: black; }
  
  /* Show link URLs after links */
  a::after { content: " (" attr(href) ")"; font-size: 0.8em; }
  
  /* Don''t break figures or tables across pages */
  figure, table { break-inside: avoid; }
  
  /* Ensure headings don''t end up alone at page bottom */
  h1, h2, h3 { break-after: avoid; }
  
  /* Set appropriate page margins */
  @page {
    margin: 2.54cm; /* 1 inch margins */
  }
}
```

## Project-Specific Styles

```css
/* Academic, readable, trustworthy */
body {
  font-family: Georgia, 'Times New Roman', serif;
  max-width: 820px;
  margin: 0 auto;
  padding: 0 24px;
  line-height: 1.8;
  color: #222;
}

.project-header {
  border-bottom: 3px double #333;
  padding-bottom: 24px;
  margin-bottom: 40px;
}

.class-info {
  display: flex;
  gap: 32px;
  font-size: 0.85rem;
  color: #666;
  margin-bottom: 16px;
}

h1 {
  font-size: 2.2rem;
  font-weight: bold;
  text-align: center;
  margin-bottom: 8px;
}

/* Data tables */
.data-table {
  width: 100%;
  border-collapse: collapse;
  margin: 24px 0;
}
.data-table th {
  background: #f5f5f5;
  padding: 10px 16px;
  text-align: left;
  border: 1px solid #ddd;
}
.data-table td {
  padding: 8px 16px;
  border: 1px solid #ddd;
}
.data-table tr:nth-child(even) { background: #fafafa; }

/* Bibliography */
.bibliography { margin: 0; padding-left: 1.5em; }
.bibliography li { margin-bottom: 12px; }
cite { font-style: italic; }

/* Smooth scroll to sections */
html { scroll-behavior: smooth; }
section { scroll-margin-top: 80px; }
```

## Key Takeaways 🌟

1. Academic pages use `<cite>` for titles, `<time>` for dates, proper heading hierarchy
2. Data tables with `<caption>`, `<thead>`, and `scope` attributes are accessible
3. `@media print` styles ensure the page looks good when printed or PDF-exported
4. `break-inside: avoid` prevents figures and tables from splitting across print pages
5. `a::after { content: " (" attr(href) ")" }` shows link URLs in print
6. A sticky or jump-link `<nav>` helps readers navigate long research documents
7. `scroll-behavior: smooth` and `scroll-margin-top` create smooth anchor link navigation
$L$,
ARRAY['html','css','project','academic','print','tables'], 42);

-- Continuing with strong lessons for 43-100
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('bld-l43', 'CSS: Responsive Navigation Patterns', 'CSS', 'CSS', 'intermediate', 30, 'published', ARRAY['Build a hamburger menu for mobile','Create responsive navigation that adapts from horizontal to vertical','Use CSS and minimal JavaScript for the mobile menu'], $L$# CSS: Responsive Navigation Patterns

## The Navigation Problem on Mobile

A desktop navigation bar with 6 links looks great at 1280px wide. At 375px (iPhone), those same 6 links overlap or disappear. You need a completely different navigation pattern for mobile.

## The Hamburger Menu Pattern

The three-line ☰ icon that reveals a mobile menu is called a "hamburger" because it looks like a hamburger from the side. It''s the most recognisable mobile navigation pattern.

## The HTML Structure

```html
<header>
  <nav class="nav" aria-label="Main navigation">
    <div class="nav-brand">
      <a href="/">🚀 CODEship</a>
    </div>

    <!-- Hamburger button — only visible on mobile -->
    <button class="nav-toggle" aria-expanded="false" aria-controls="nav-menu" aria-label="Open navigation menu">
      <span class="hamburger-line"></span>
      <span class="hamburger-line"></span>
      <span class="hamburger-line"></span>
    </button>

    <!-- Navigation links -->
    <ul class="nav-menu" id="nav-menu" role="list">
      <li><a href="/" class="nav-link">Home</a></li>
      <li><a href="/courses" class="nav-link">Courses</a></li>
      <li><a href="/school" class="nav-link">Schools</a></li>
      <li><a href="/about" class="nav-link">About</a></li>
      <li>
        <a href="/signup" class="nav-link nav-cta">Get Started</a>
      </li>
    </ul>
  </nav>
</header>
```

## The CSS

```css
/* ── Desktop first: full horizontal nav ── */
.nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 40px;
  background: #1E2140;
  position: sticky;
  top: 0;
  z-index: 100;
}

.nav-brand a {
  color: white;
  font-weight: 900;
  font-size: 1.1rem;
  text-decoration: none;
}

.nav-menu {
  display: flex;
  list-style: none;
  gap: 8px;
  padding: 0;
  margin: 0;
}

.nav-link {
  display: block;
  padding: 8px 16px;
  color: rgba(255,255,255,0.7);
  text-decoration: none;
  font-weight: 600;
  border-radius: 8px;
  transition: all 0.2s ease;
}

.nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
.nav-cta { background: #F5C518; color: #1E2140 !important; }
.nav-cta:hover { background: #E6B800; }

/* Hide hamburger on desktop */
.nav-toggle { display: none; }

/* ── Mobile: hamburger menu ── */
@media (max-width: 768px) {
  .nav { padding: 16px 20px; flex-wrap: wrap; gap: 0; }

  /* Show hamburger */
  .nav-toggle {
    display: flex;
    flex-direction: column;
    gap: 5px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 8px;
    margin: -8px;
    border-radius: 8px;
  }
  .nav-toggle:hover { background: rgba(255,255,255,0.1); }

  .hamburger-line {
    display: block;
    width: 24px;
    height: 2px;
    background: white;
    border-radius: 2px;
    transition: all 0.3s ease;
  }

  /* Animate hamburger to X when open */
  .nav-toggle[aria-expanded="true"] .hamburger-line:nth-child(1) {
    transform: translateY(7px) rotate(45deg);
  }
  .nav-toggle[aria-expanded="true"] .hamburger-line:nth-child(2) {
    opacity: 0;
    transform: scaleX(0);
  }
  .nav-toggle[aria-expanded="true"] .hamburger-line:nth-child(3) {
    transform: translateY(-7px) rotate(-45deg);
  }

  /* Mobile menu: hidden by default */
  .nav-menu {
    flex-direction: column;
    width: 100%;
    gap: 4px;
    padding: 16px 0;
    
    /* Hidden state */
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
  }

  /* Open state — set by JavaScript */
  .nav-menu.open { max-height: 400px; }

  .nav-link { padding: 12px 8px; }
}
```

## The JavaScript (Minimal!)

```javascript
const toggle = document.querySelector('.nav-toggle');
const menu = document.querySelector('.nav-menu');

toggle.addEventListener('click', () => {
  const isOpen = toggle.getAttribute('aria-expanded') === 'true';
  toggle.setAttribute('aria-expanded', !isOpen);
  menu.classList.toggle('open');
  toggle.setAttribute('aria-label', isOpen ? 'Open navigation menu' : 'Close navigation menu');
});

// Close when clicking a link (for single-page sites)
menu.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    toggle.setAttribute('aria-expanded', 'false');
    menu.classList.remove('open');
  });
});

// Close when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('nav')) {
    toggle.setAttribute('aria-expanded', 'false');
    menu.classList.remove('open');
  }
});
```

## Alternative: CSS-Only Toggle (No JavaScript)

Using a hidden checkbox to toggle the menu:

```html
<input type="checkbox" id="nav-checkbox" class="nav-checkbox">
<label for="nav-checkbox" class="nav-toggle" aria-label="Toggle navigation">☰</label>
<ul class="nav-menu"><!-- links --></ul>
```

```css
.nav-checkbox { display: none; }

/* Show menu when checkbox is checked */
.nav-checkbox:checked ~ .nav-menu { display: flex; }

/* Hide by default on mobile */
@media (max-width: 768px) {
  .nav-menu { display: none; }
}
```

The label acts as the toggle button — clicking it checks/unchecks the hidden checkbox, which the CSS responds to.

## Key Takeaways 🌟

1. The hamburger menu is the universal mobile navigation pattern
2. Always include `aria-expanded` and `aria-controls` on the toggle button for accessibility
3. Use `max-height` transition for smooth menu open/close (height can''t be transitioned)
4. The hamburger → X animation uses `transform: rotate()` on the three lines
5. Minimal JavaScript: toggle `aria-expanded` and a CSS class — CSS does the visual work
6. Close the menu when clicking outside or clicking a link for good UX
7. A CSS-only toggle using hidden checkbox is possible but JavaScript provides better accessibility
$L$,
ARRAY['css','navigation','hamburger','mobile','responsive','accessibility'], 43),

('bld-l44', 'HTML: SEO Basics for Young Developers', 'HTML', 'HTML', 'intermediate', 25, 'published', ARRAY['Add proper meta tags for SEO and social sharing','Write effective page titles and descriptions','Understand how search engines read HTML'], $L$# HTML: SEO Basics for Young Developers

## What Is SEO?

**Search Engine Optimisation (SEO)** is the practice of making your website easy for search engines like Google to find, understand, and rank.

When someone searches "kids coding class Ontario," Google sends automated programs called **crawlers** or **spiders** to read the HTML of millions of pages. They look for specific signals to understand what each page is about, then rank results by relevance and quality.

The best part: the most important SEO signals come directly from your HTML. Good semantic HTML is good SEO.

## The Title Tag: The Most Important SEO Element

```html
<title>Learn to Code for Kids | CODEship Academy — Ontario</title>
```

The title:
- Appears in browser tabs
- Is the big blue link in Google search results
- Should be 50-60 characters (longer gets truncated)
- Include your main keyword + brand name

## Meta Description: The Search Result Preview

```html
<meta name="description" content="AI-powered coding education for Grades K–8. Curriculum-aligned lessons in English and French. 14-day free trial. Join 10,000+ Ontario students learning to code.">
```

The meta description:
- Appears as the grey text below the title in search results
- Should be 150-160 characters
- Doesn''t directly affect rankings, but affects click-through rate
- Include a clear value proposition and call to action

## Open Graph: Social Media Previews

When someone shares your link on Facebook, Twitter, or WhatsApp, these tags control what the preview looks like:

```html
<!-- Open Graph -->
<meta property="og:title" content="CODEship Academy — Coding for Kids K-8">
<meta property="og:description" content="AI-powered personalized coding education for Ontario students.">
<meta property="og:image" content="https://codeshipacademy.com/og-image.jpg">
<meta property="og:url" content="https://codeshipacademy.com">
<meta property="og:type" content="website">
<meta property="og:site_name" content="CODEship Academy">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="CODEship Academy — Coding for Kids K-8">
<meta name="twitter:description" content="AI-powered personalized coding education.">
<meta name="twitter:image" content="https://codeshipacademy.com/og-image.jpg">
```

The `og:image` should be 1200×630 pixels for best results across platforms.

## Canonical URLs: Preventing Duplicate Content

If your content appears at multiple URLs, tell Google which is the "real" one:

```html
<link rel="canonical" href="https://codeshipacademy.com/courses/builders">
```

## Heading Hierarchy for SEO

Search engines use heading structure to understand page content:
- `<h1>` — the page''s main topic (one per page)
- `<h2>` — major sections
- `<h3>` — subsections

Include your main keyword in the `<h1>`. Write naturally — don''t stuff keywords.

## Structured Data (Schema Markup)

Tell Google exactly what type of content you have using JSON-LD:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "CODEship Academy",
  "description": "AI-powered coding education for Grades K-8",
  "url": "https://codeshipacademy.com",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "21 Simcoe Street South",
    "addressLocality": "Oshawa",
    "addressRegion": "ON",
    "postalCode": "L1H 4G1",
    "addressCountry": "CA"
  }
}
</script>
```

This can enable **rich results** — enhanced search listings with ratings, prices, or event dates directly in Google results.

## Image SEO

```html
<!-- Good: descriptive filename, good alt text -->
<img src="grade-3-student-coding-ontario.jpg"
     alt="A smiling Grade 3 student coding on a laptop at CODEship Academy in Oshawa">

<!-- Bad: generic filename, no alt text -->
<img src="img1.jpg" alt="">
```

Google can now understand images, but descriptive filenames and alt text still help.

## Page Speed SEO

Google uses page speed as a ranking factor, especially on mobile. Quick wins:
- Compress images (use WebP format, compress with TinyPNG)
- Add `loading="lazy"` to below-the-fold images
- Minify CSS (remove whitespace) for production
- Use a CDN (Content Delivery Network) for fast global delivery

Test your page speed: pagespeed.web.dev

## The Complete Head Section

```html
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- SEO -->
  <title>Learn to Code for Kids K-8 | CODEship Academy</title>
  <meta name="description" content="AI-powered coding education...">
  <link rel="canonical" href="https://codeshipacademy.com/">

  <!-- Open Graph -->
  <meta property="og:title" content="...">
  <meta property="og:description" content="...">
  <meta property="og:image" content="...">
  <meta property="og:url" content="...">

  <!-- Favicon -->
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="icon" type="image/png" href="/favicon.png">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="..." rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="styles.css">
</head>
```

## Key Takeaways 🌟

1. The `<title>` tag is the most important on-page SEO element — 50-60 characters, include keywords
2. Meta description controls the search result preview — 150-160 characters, include a call to action
3. Open Graph meta tags control social media link previews
4. Heading hierarchy (`h1` → `h2` → `h3`) helps search engines understand page structure
5. Descriptive alt text on images helps both accessibility and image search SEO
6. Page speed is a ranking factor — compress images, use lazy loading
7. Schema.org structured data enables rich search results
8. Good semantic HTML = good SEO — they share the same foundations
$L$,
ARRAY['html','seo','meta-tags','open-graph','schema','performance'], 44);


INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l45', 'Building a News/Blog Homepage', 'Projects', 'HTML', 'intermediate', 50, 'published',
ARRAY['Build a multi-section blog homepage with featured and grid posts','Apply CSS Grid for article layout','Create readable typographic hierarchy for news content'],
$L$# Building a News/Blog Homepage

## What Makes a Great Blog Homepage

The best blog homepages do three things immediately:
1. Establish what the blog is about
2. Show the most important/recent content prominently
3. Make it effortless to explore more

Sites like The New York Times, BBC, and Medium all solve the same challenge you will today: presenting many articles in a hierarchy that guides the eye.

## The Layout Architecture

```
┌─────────────────────────────────────┐
│           Header + Nav              │
├─────────────────────────────────────┤
│     FEATURED ARTICLE (full width)   │
├──────────────┬──────────────────────┤
│  Latest      │  Category Sidebar    │
│  Posts Grid  │  Popular Posts       │
│  (3 cols)    │  Newsletter Signup   │
├─────────────────────────────────────┤
│           Footer                    │
└─────────────────────────────────────┘
```

## The Complete HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CODEship News — Coding Education for Ontario Students</title>
  <meta name="description" content="The latest news, tutorials, and stories from CODEship Academy.">
  <link rel="stylesheet" href="blog.css">
</head>
<body>

  <header class="site-header">
    <div class="container">
      <a href="/" class="site-logo">
        <span class="logo-icon">🚀</span>
        <div>
          <span class="logo-name">CODEship News</span>
          <span class="logo-tagline">Coding Education in Ontario</span>
        </div>
      </a>
      <nav class="main-nav">
        <a href="/tutorials">Tutorials</a>
        <a href="/news">News</a>
        <a href="/stories">Student Stories</a>
        <a href="/resources">Resources</a>
      </nav>
      <a href="/subscribe" class="btn-subscribe">Subscribe Free</a>
    </div>
  </header>

  <main>
    <!-- FEATURED ARTICLE -->
    <section class="featured-section">
      <div class="container">
        <article class="featured-article">
          <div class="featured-image">
            <img src="featured.jpg" alt="Ontario students learning to code at a CODEship workshop" loading="eager">
          </div>
          <div class="featured-content">
            <div class="article-meta">
              <span class="category-badge category-news">News</span>
              <time datetime="2024-11-15">November 15, 2024</time>
            </div>
            <h1 class="featured-title">
              <a href="/articles/ontario-coding-mandate-2024">Ontario Schools Surpass 80% Coding Adoption as New Curriculum Takes Hold</a>
            </h1>
            <p class="featured-excerpt">Three years after Ontario made coding mandatory from Grade 1, a new report shows adoption rates have exceeded all projections — and student enthusiasm is the driving force.</p>
            <div class="article-author">
              <img src="author.jpg" alt="Author photo" class="author-avatar">
              <div>
                <strong>Sarah Chen</strong>
                <span>Education Reporter</span>
              </div>
            </div>
            <a href="/articles/ontario-coding-mandate-2024" class="read-more">Read Full Story →</a>
          </div>
        </article>
      </div>
    </section>

    <!-- CONTENT AREA -->
    <div class="content-area container">

      <!-- LATEST POSTS GRID -->
      <section class="posts-section">
        <div class="section-header">
          <h2>Latest Posts</h2>
          <a href="/all" class="see-all">See all →</a>
        </div>
        <div class="posts-grid">

          <article class="post-card">
            <a href="#" class="post-image-link">
              <img src="post1.jpg" alt="Child drawing a website wireframe" loading="lazy" class="post-image">
            </a>
            <div class="post-body">
              <div class="post-meta">
                <span class="category-badge category-tutorial">Tutorial</span>
                <time datetime="2024-11-12">Nov 12</time>
              </div>
              <h3 class="post-title">
                <a href="#">Your First HTML Page in 15 Minutes</a>
              </h3>
              <p class="post-excerpt">No experience needed. We walk you through every step of building a real webpage from scratch.</p>
              <div class="post-footer">
                <span class="reading-time">5 min read</span>
                <a href="#">Read →</a>
              </div>
            </div>
          </article>

          <!-- Repeat post-card pattern for 5 more articles -->

        </div>
      </section>

      <!-- SIDEBAR -->
      <aside class="sidebar">
        <div class="sidebar-widget">
          <h3>Browse by Topic</h3>
          <ul class="category-list">
            <li><a href="#">HTML & CSS <span>24</span></a></li>
            <li><a href="#">JavaScript <span>18</span></a></li>
            <li><a href="#">Scratch <span>31</span></a></li>
            <li><a href="#">Python <span>15</span></a></li>
            <li><a href="#">Student Stories <span>42</span></a></li>
            <li><a href="#">School News <span>12</span></a></li>
          </ul>
        </div>

        <div class="sidebar-widget newsletter-widget">
          <h3>Get Weekly Lessons</h3>
          <p>Free coding lesson sent every Monday.</p>
          <form class="newsletter-form" action="/subscribe" method="post">
            <input type="email" name="email" placeholder="your@email.com" required>
            <button type="submit">Subscribe</button>
          </form>
          <p class="fine-print">No spam. Unsubscribe anytime.</p>
        </div>

        <div class="sidebar-widget">
          <h3>Most Popular</h3>
          <ol class="popular-list">
            <li><a href="#">CSS Flexbox Complete Guide</a></li>
            <li><a href="#">Build Your First Scratch Game</a></li>
            <li><a href="#">HTML Forms Explained Simply</a></li>
            <li><a href="#">Why Your Child Should Learn Python</a></li>
            <li><a href="#">Ontario Coding Curriculum Explained</a></li>
          </ol>
        </div>
      </aside>

    </div>
  </main>

  <footer class="site-footer">
    <div class="container">
      <p>© 2024 CODEship Academy · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a></p>
    </div>
  </footer>

</body>
</html>
```

## The CSS

```css
:root {
  --navy: #1E2140; --gold: #F5C518; --text: #1a1a2e;
  --muted: #6b7280; --bg: #f9fafb; --white: #fff;
  --border: #e5e7eb; --font-heading: Georgia, serif;
  --font-body: system-ui, sans-serif;
  --radius: 12px; --shadow: 0 1px 8px rgba(0,0,0,0.08);
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--font-body); background: var(--bg); color: var(--text); }
.container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
img { max-width: 100%; height: auto; display: block; }
a { color: inherit; text-decoration: none; }

/* Header */
.site-header { background: var(--navy); padding: 16px 0; position: sticky; top: 0; z-index: 100; }
.site-header .container { display: flex; align-items: center; justify-content: space-between; gap: 24px; }
.site-logo { display: flex; align-items: center; gap: 10px; }
.logo-icon { font-size: 1.5rem; }
.logo-name { display: block; color: white; font-weight: 900; font-size: 1.1rem; line-height: 1; }
.logo-tagline { display: block; color: rgba(255,255,255,0.5); font-size: 0.7rem; }
.main-nav { display: flex; gap: 24px; }
.main-nav a { color: rgba(255,255,255,0.7); font-weight: 600; font-size: 0.9rem; }
.main-nav a:hover { color: var(--gold); }
.btn-subscribe { background: var(--gold); color: var(--navy); padding: 8px 20px; border-radius: 8px; font-weight: 900; font-size: 0.85rem; white-space: nowrap; }

/* Featured */
.featured-section { background: var(--white); border-bottom: 1px solid var(--border); padding: 48px 0; }
.featured-article { display: grid; grid-template-columns: 1.2fr 1fr; gap: 48px; align-items: center; }
.featured-image img { width: 100%; aspect-ratio: 16/9; object-fit: cover; border-radius: var(--radius); }
.article-meta { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
.category-badge { padding: 4px 10px; border-radius: 99px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; }
.category-news { background: #DBEAFE; color: #1D4ED8; }
.category-tutorial { background: #D1FAE5; color: #065F46; }
time { color: var(--muted); font-size: 0.85rem; }
.featured-title { font-family: var(--font-heading); font-size: 2rem; line-height: 1.25; margin-bottom: 16px; }
.featured-title a:hover { color: var(--navy); }
.featured-excerpt { color: var(--muted); line-height: 1.7; margin-bottom: 24px; font-size: 1.05rem; }
.article-author { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
.author-avatar { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; }
.article-author strong { display: block; font-size: 0.9rem; }
.article-author span { font-size: 0.8rem; color: var(--muted); }
.read-more { color: var(--navy); font-weight: 800; font-size: 0.95rem; }
.read-more:hover { color: var(--gold); }

/* Content area: posts + sidebar */
.content-area { display: grid; grid-template-columns: 1fr 320px; gap: 48px; padding: 48px 24px; max-width: 1200px; margin: 0 auto; }
.section-header { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 24px; }
.section-header h2 { font-family: var(--font-heading); font-size: 1.5rem; }
.see-all { color: var(--muted); font-size: 0.9rem; font-weight: 600; }
.see-all:hover { color: var(--navy); }

/* Posts grid */
.posts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.post-card { background: var(--white); border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow); }
.post-image { width: 100%; aspect-ratio: 16/10; object-fit: cover; }
.post-body { padding: 16px; }
.post-meta { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
.post-title { font-family: var(--font-heading); font-size: 1rem; line-height: 1.4; margin-bottom: 8px; }
.post-title a:hover { color: var(--gold); }
.post-excerpt { color: var(--muted); font-size: 0.85rem; line-height: 1.6; margin-bottom: 12px; }
.post-footer { display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; }
.reading-time { color: var(--muted); }

/* Sidebar */
.sidebar { display: flex; flex-direction: column; gap: 32px; }
.sidebar-widget { background: var(--white); border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow); }
.sidebar-widget h3 { font-family: var(--font-heading); font-size: 1.1rem; margin-bottom: 16px; }
.category-list { list-style: none; }
.category-list li { padding: 8px 0; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; }
.category-list li:last-child { border-bottom: none; }
.category-list a { font-size: 0.9rem; font-weight: 600; }
.category-list span { background: var(--bg); padding: 2px 8px; border-radius: 99px; font-size: 0.75rem; color: var(--muted); }
.newsletter-widget { background: linear-gradient(135deg, var(--navy), #3A3D5C); color: white; }
.newsletter-widget h3 { color: white; }
.newsletter-widget p { color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-bottom: 16px; }
.newsletter-form { display: flex; flex-direction: column; gap: 8px; }
.newsletter-form input { padding: 10px 14px; border-radius: 8px; border: none; font-size: 0.9rem; }
.newsletter-form button { padding: 10px; background: var(--gold); color: var(--navy); border: none; border-radius: 8px; font-weight: 900; cursor: pointer; }
.fine-print { font-size: 0.75rem; color: rgba(255,255,255,0.5); margin-top: 8px; }
.popular-list { padding-left: 1.2em; }
.popular-list li { margin-bottom: 10px; }
.popular-list a { font-size: 0.9rem; line-height: 1.4; }
.popular-list a:hover { color: var(--gold); }

/* Responsive */
@media (max-width: 900px) { .posts-grid { grid-template-columns: 1fr 1fr; } }
@media (max-width: 768px) {
  .featured-article { grid-template-columns: 1fr; }
  .content-area { grid-template-columns: 1fr; }
  .posts-grid { grid-template-columns: 1fr; }
  .main-nav { display: none; }
}
```

## Key Takeaways 🌟

1. Blog homepages use a visual hierarchy: featured (big) → grid (medium) → sidebar (small)
2. The container class constrains width and centres content — reuse it everywhere
3. Category badges use class variants (`category-news`, `category-tutorial`) for different colours
4. The featured article uses a two-column grid — image left, content right
5. The sidebar uses `position: sticky` to follow while scrolling the posts
6. Newsletter widgets inside sidebars are some of the highest-converting UI patterns on the web
7. This exact layout pattern is used by The Verge, TechCrunch, and every major blog platform
$L$,
ARRAY['html','css','blog','news','layout','grid','sidebar'], 45),

('bld-l46', 'CSS: Print Stylesheets and @media print', 'CSS', 'CSS', 'intermediate', 20, 'published',
ARRAY['Write CSS that only applies when printing','Control page breaks and print margins','Show hidden URLs for print readers'],
$L$# CSS: Print Stylesheets and @media print

## Why Print Styles Matter

Many websites are read in print: articles saved as PDFs, receipts, invoices, academic papers, directions. Without print styles, your beautiful dark background wastes ink, navigation clutters the page, and interactive elements confuse readers.

Print styles cost minimal time and greatly improve the experience for the subset of users who print.

## Two Ways to Add Print Styles

```html
<!-- Method 1: Separate file (clean, only loaded when printing) -->
<link rel="stylesheet" href="print.css" media="print">

<!-- Method 2: Media query inside your main CSS -->
@media print { ... }
```

Both work. The media query approach keeps everything in one file — easier to maintain.

## Essential Print CSS

```css
@media print {
  /* ── Remove non-content elements ── */
  header, footer, nav, aside,
  .sidebar, .cookie-banner, .chat-widget,
  .social-share, .advertisement,
  .back-to-top, .newsletter-form,
  button, .btn { display: none !important; }

  /* ── Paper-friendly colours ── */
  body {
    background: white !important;
    color: black !important;
    font-size: 12pt;        /* Points, not pixels, for print */
    line-height: 1.5;
    font-family: Georgia, serif; /* Serifs read better in print */
  }

  /* ── Max width for print ── */
  main, article, .content {
    max-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
  }

  /* ── Show link URLs ── */
  a[href]::after {
    content: " (" attr(href) ")";
    font-size: 0.85em;
    color: #555;
  }

  /* Don't show URLs for internal links or javascript links */
  a[href^="#"]::after,
  a[href^="javascript:"]::after { content: ""; }

  /* ── Page breaks ── */
  h1, h2, h3 { break-after: avoid; }    /* Headings stay with their content */
  figure, table, pre { break-inside: avoid; }  /* Don't split these across pages */
  p { orphans: 3; widows: 3; }  /* Minimum lines at top/bottom of page */

  /* ── Page setup ── */
  @page {
    margin: 2cm;  /* Proper print margins */
    size: A4 portrait;
  }

  @page :first {
    margin-top: 3cm;  /* More space on first page */
  }

  /* ── Remove shadows and transforms ── */
  * {
    box-shadow: none !important;
    text-shadow: none !important;
    filter: none !important;
    transform: none !important;
  }

  /* ── Force images to print ── */
  img { max-width: 100%; }

  /* ── Show print-only content ── */
  .print-only { display: block !important; }
}

/* Hide print-only elements on screen */
.print-only { display: none; }
```

## Controlling Page Breaks

```css
@media print {
  /* Force a new page before this element */
  .chapter { break-before: page; }

  /* Force a new page after this element */
  .section-end { break-after: page; }

  /* Keep this element together on one page */
  .keep-together { break-inside: avoid; }

  /* Print page numbers */
  @page { @bottom-right { content: counter(page); } }
}
```

## Invoice/Receipt Pattern

A great use case for print styles — the web view shows interactive elements, the print view is clean:

```html
<div class="invoice">
  <div class="screen-only">
    <button onclick="window.print()">🖨️ Print Invoice</button>
    <button>📧 Email Invoice</button>
  </div>
  <div class="print-header">
    <!-- Logo and business info only shown in print -->
  </div>
  <!-- Invoice table always shown -->
</div>
```

```css
.screen-only { display: flex; gap: 12px; margin-bottom: 24px; }
.print-header { display: none; }

@media print {
  .screen-only { display: none; }
  .print-header { display: block; }
}
```

## Triggering Print from JavaScript

```javascript
// In a "Print" button:
document.querySelector('.print-btn').addEventListener('click', () => {
  window.print();
});

// Print just one section:
function printSection(sectionId) {
  const section = document.getElementById(sectionId);
  const printWindow = window.open('', '_blank');
  printWindow.document.write('<html><head>');
  printWindow.document.write('<link rel="stylesheet" href="print.css">');
  printWindow.document.write('</head><body>');
  printWindow.document.write(section.innerHTML);
  printWindow.document.write('</body></html>');
  printWindow.document.close();
  printWindow.print();
}
```

## Key Takeaways 🌟

1. `@media print` applies CSS only when printing — keep it in your main stylesheet or a separate `print.css`
2. Hide navigation, sidebars, banners, and buttons — only content should print
3. Use `background: white; color: black` to save ink
4. `a::after { content: " (" attr(href) ")" }` shows link URLs for print readers
5. `break-inside: avoid` keeps figures and tables from splitting across pages
6. `orphans` and `widows` control minimum lines at page top/bottom
7. `@page` sets margins and paper size
8. Print styles take 20 minutes to add and significantly improve professional document output
$L$,
ARRAY['css','print','media-queries','pdf','accessibility'], 46),

('bld-l47', 'Accessibility: ARIA Labels and Screen Readers', 'Accessibility', 'HTML', 'intermediate', 30, 'published',
ARRAY['Use ARIA roles and labels to enhance screen reader experience','Test a page with VoiceOver or NVDA','Understand landmark navigation and live regions'],
$L$# Accessibility: ARIA Labels and Screen Readers

## A Day in the Life of a Screen Reader User

Before we write code, let's understand who we're building for. Imagine using the web without being able to see the screen. You navigate using:

- **Tab** — jump to the next interactive element (link, button, input)
- **Shift+Tab** — go backwards
- **Enter** — activate a link or button
- **Arrow keys** — navigate within menus, radio buttons, lists
- **Screen reader shortcuts** — jump between headings (H), landmarks (D), links (K)

The screen reader reads aloud: "Navigation landmark. List, 4 items. Link: Home. Link: Courses. Link: Schools. Link: Contact. Article. Heading level 1: Ontario Coding Mandate..."

**Good HTML gives screen reader users a rich experience. Bad HTML gives them chaos.**

## ARIA: Filling the Gaps

ARIA (Accessible Rich Internet Applications) is a set of attributes that add semantic information when HTML alone isn't enough.

**The first rule of ARIA:** Don't use ARIA if native HTML provides the semantics. `<button>` is always better than `<div role="button">`.

Use ARIA when:
1. You've built a custom interactive widget (date picker, carousel, modal)
2. Native HTML doesn't communicate the right role or state
3. Dynamic content changes need to be announced

## Core ARIA Attributes

### `role` — Defines what an element IS

```html
<!-- Alert regions — announced immediately -->
<div role="alert">Your session will expire in 5 minutes.</div>
<div role="status">Saving your work...</div>

<!-- Dialog (modal) -->
<div role="dialog" aria-modal="true" aria-labelledby="dialog-title">
  <h2 id="dialog-title">Confirm Deletion</h2>
  ...
</div>

<!-- Navigation landmark (when not using <nav>) -->
<div role="navigation" aria-label="Breadcrumb">...</div>

<!-- Tab pattern -->
<div role="tablist" aria-label="Course levels">
  <button role="tab" aria-selected="true" aria-controls="panel-1">Explorers</button>
  <button role="tab" aria-selected="false" aria-controls="panel-2">Builders</button>
</div>
<div role="tabpanel" id="panel-1" aria-labelledby="tab-1">...</div>
```

### `aria-label` — Provides a text label

Use when there's no visible text label:

```html
<!-- Icon-only button needs a label -->
<button aria-label="Close modal">×</button>
<button aria-label="Search the site">🔍</button>

<!-- Social media links -->
<a href="https://twitter.com/codeship" aria-label="Follow CODEship on Twitter">
  <!-- SVG twitter icon, no text -->
</a>

<!-- Multiple navs need distinguishing labels -->
<nav aria-label="Main navigation">...</nav>
<nav aria-label="Footer navigation">...</nav>
```

### `aria-labelledby` — Points to another element as the label

```html
<section aria-labelledby="courses-heading">
  <h2 id="courses-heading">Our Courses</h2>
  ...
</section>

<!-- Modal labelled by its heading -->
<div role="dialog" aria-labelledby="modal-title" aria-describedby="modal-desc">
  <h2 id="modal-title">Delete Account?</h2>
  <p id="modal-desc">This action cannot be undone. All your data will be permanently deleted.</p>
</div>
```

### `aria-describedby` — Points to descriptive text

```html
<!-- Input with description -->
<label for="pwd">Password</label>
<input type="password" id="pwd" aria-describedby="pwd-help">
<p id="pwd-help">Must be at least 8 characters with one number.</p>

<!-- Error message associated with input -->
<input type="email" id="email" aria-invalid="true" aria-describedby="email-error">
<p id="email-error" role="alert">Please enter a valid email address.</p>
```

### `aria-expanded` — Is content expanded?

```html
<button aria-expanded="false" aria-controls="nav-menu" id="nav-toggle">
  Menu
</button>
<ul id="nav-menu" hidden>...</ul>

<!-- JavaScript updates aria-expanded when toggling: -->
const btn = document.querySelector('[aria-expanded]');
btn.addEventListener('click', () => {
  const isExpanded = btn.getAttribute('aria-expanded') === 'true';
  btn.setAttribute('aria-expanded', !isExpanded);
  document.getElementById(btn.getAttribute('aria-controls')).hidden = isExpanded;
});
```

### `aria-live` — Announce dynamic content changes

```html
<!-- Polite: announces when user is idle (search results, status updates) -->
<div aria-live="polite" aria-atomic="true">
  Showing 24 results for "python tutorial"
</div>

<!-- Assertive: interrupts immediately (errors, urgent alerts) -->
<div role="alert" aria-live="assertive">
  Error: Your session has expired. Please log in again.
</div>

<!-- Off: don't announce changes (default) -->
<div aria-live="off">...</div>
```

### `aria-hidden` — Hide from screen readers

```html
<!-- Decorative icons that duplicate visible text -->
<button>
  <span aria-hidden="true">🚀</span>
  Launch Course
</button>

<!-- Decorative dividers -->
<span aria-hidden="true">|</span>
```

## Landmark Regions

Landmarks let screen reader users jump quickly around the page:

```html
<!-- These elements are automatically landmarks: -->
<header>    <!-- banner landmark -->
<nav>       <!-- navigation landmark -->
<main>      <!-- main landmark -->
<aside>     <!-- complementary landmark -->
<footer>    <!-- contentinfo landmark -->
<section aria-labelledby="h">  <!-- region landmark (needs a heading) -->
<form aria-label="Contact form">  <!-- form landmark (needs a label) -->
```

Screen reader shortcut (in many readers): press **D** to jump between landmarks.

## Testing With a Screen Reader

**On Mac/iOS:** VoiceOver is built in.
- Mac: Cmd + F5 to toggle
- Navigate: Tab (interactive elements), VO+Right/Left (read through content)

**On Windows:** NVDA (free download from nvaccess.org)
- Toggle: Ctrl+Alt+N
- Navigate: Tab, H (headings), D (landmarks), K (links)

**Quick test:** Turn on a screen reader, close your eyes, and try to complete the main task of your page (sign up, find a product, contact). Can you do it?

## The Accessibility Checklist for Every Page

```
□ One <h1> per page, logical heading hierarchy
□ All images have meaningful alt text (or alt="" if decorative)
□ All form inputs have associated <label>
□ All interactive elements are keyboard-reachable
□ Focus indicator is visible (never outline: none without replacement)
□ Colour contrast meets 4.5:1 for normal text
□ Error messages are associated with their inputs
□ Dynamic content uses aria-live or role="alert"
□ Icon-only buttons have aria-label
□ Multiple <nav> elements have aria-label to distinguish them
□ Modal dialogs trap focus inside and close with Escape key
```

## Key Takeaways 🌟

1. ARIA fills semantic gaps when native HTML isn't sufficient — but always prefer native HTML first
2. `aria-label` provides text labels for icon buttons and ambiguous elements
3. `aria-labelledby` and `aria-describedby` associate elements with their labels and descriptions
4. `aria-expanded` communicates toggle state (open/closed menus, accordions)
5. `aria-live="polite"` announces dynamic changes; `role="alert"` announces urgently
6. `aria-hidden="true"` hides decorative elements from screen readers
7. Landmark elements (`<nav>`, `<main>`, `<aside>`) let screen reader users jump directly to sections
8. Test your pages with a real screen reader — close your eyes and try to use the page
$L$,
ARRAY['accessibility','aria','screen-readers','wcag','voiceover'], 47),

('bld-l48', 'Building an Event Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a complete event page with schedule and registration form','Use structured data for events','Apply countdown timer with JavaScript'],
$L$# Building an Event Page

## Event Pages: A Universal Need

Every school, club, business, and organisation hosts events. Every event needs a webpage. You're going to build a complete event page that could serve a real school coding competition.

## The Event Page Structure

Great event pages answer five questions immediately:
1. **What** is happening?
2. **When** is it?
3. **Where** is it?
4. **Who** is it for?
5. **How** do I register?

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CODEship Hackathon 2025 — Build Something Amazing</title>
  <meta name="description" content="A one-day coding competition for Ontario students in Grades 4-8. March 15, 2025 in Oshawa.">

  <!-- Event structured data for Google -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Event",
    "name": "CODEship Hackathon 2025",
    "startDate": "2025-03-15T09:00:00-05:00",
    "endDate": "2025-03-15T17:00:00-05:00",
    "location": {
      "@type": "Place",
      "name": "Durham College",
      "address": "2000 Simcoe Street N, Oshawa, ON L1G 0C5"
    },
    "organizer": { "@type": "Organization", "name": "CODEship Academy" },
    "offers": { "@type": "Offer", "price": "0", "priceCurrency": "CAD" }
  }
  </script>

  <link rel="stylesheet" href="event.css">
</head>
<body>

  <!-- Hero: eye-catching, immediate info -->
  <section class="event-hero">
    <div class="hero-badge">🏆 Free Event</div>
    <h1>CODEship Hackathon 2025</h1>
    <p class="event-tagline">Build Something Amazing in 6 Hours</p>
    <div class="event-meta">
      <div class="meta-item">
        <span class="meta-icon">📅</span>
        <div>
          <strong>March 15, 2025</strong>
          <span>9:00 AM – 5:00 PM EST</span>
        </div>
      </div>
      <div class="meta-item">
        <span class="meta-icon">📍</span>
        <div>
          <strong>Durham College</strong>
          <span>Oshawa, Ontario</span>
        </div>
      </div>
      <div class="meta-item">
        <span class="meta-icon">🧑‍🎓</span>
        <div>
          <strong>Grades 4–8</strong>
          <span>Teams of 2–4</span>
        </div>
      </div>
    </div>
    <div class="hero-actions">
      <a href="#register" class="btn-register">Register Now — It's Free</a>
      <a href="#schedule" class="btn-ghost">View Schedule</a>
    </div>

    <!-- Countdown -->
    <div class="countdown" id="countdown">
      <div class="countdown-item"><span id="days">--</span><label>Days</label></div>
      <div class="countdown-item"><span id="hours">--</span><label>Hours</label></div>
      <div class="countdown-item"><span id="minutes">--</span><label>Minutes</label></div>
      <div class="countdown-item"><span id="seconds">--</span><label>Seconds</label></div>
    </div>
  </section>

  <!-- About the event -->
  <section class="about-section">
    <div class="container">
      <h2>What Is a Hackathon?</h2>
      <p>A hackathon is a creativity competition where teams work together to build something — a game, app, website, or tool — in a single day. At CODEship Hackathon 2025, you'll use the coding skills you've learned to create something you're proud of.</p>
      <div class="features-row">
        <div class="feature">
          <span class="feature-icon">🤝</span>
          <h3>Team Work</h3>
          <p>Form a team of 2-4. Different skills are a strength!</p>
        </div>
        <div class="feature">
          <span class="feature-icon">🛠️</span>
          <h3>Build Anything</h3>
          <p>Website, Scratch game, art, or tool — your choice.</p>
        </div>
        <div class="feature">
          <span class="feature-icon">🏅</span>
          <h3>Win Prizes</h3>
          <p>Awards for Best Game, Most Creative, Best Impact, and more.</p>
        </div>
        <div class="feature">
          <span class="feature-icon">🍕</span>
          <h3>Free Lunch</h3>
          <p>Pizza lunch, snacks, and drinks provided all day.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Schedule -->
  <section class="schedule-section" id="schedule">
    <div class="container">
      <h2>Day Schedule</h2>
      <div class="schedule-timeline">
        <div class="schedule-item">
          <time class="schedule-time" datetime="2025-03-15T09:00">9:00 AM</time>
          <div class="schedule-content">
            <h3>Doors Open & Team Check-In</h3>
            <p>Arrive, get your badge, meet your team, and explore the venue.</p>
          </div>
        </div>
        <div class="schedule-item">
          <time class="schedule-time" datetime="2025-03-15T09:30">9:30 AM</time>
          <div class="schedule-content">
            <h3>Opening Ceremony & Theme Reveal</h3>
            <p>The challenge theme is revealed — and the clock starts!</p>
          </div>
        </div>
        <div class="schedule-item featured-time">
          <time class="schedule-time" datetime="2025-03-15T10:00">10:00 AM</time>
          <div class="schedule-content">
            <h3>🚀 Hacking Begins!</h3>
            <p>Six hours to build your project. Mentors circulate to help.</p>
          </div>
        </div>
        <div class="schedule-item">
          <time class="schedule-time" datetime="2025-03-15T12:30">12:30 PM</time>
          <div class="schedule-content">
            <h3>Lunch Break</h3>
            <p>Pizza, juice, and a mid-day speaker about careers in tech.</p>
          </div>
        </div>
        <div class="schedule-item">
          <time class="schedule-time" datetime="2025-03-15T16:00">4:00 PM</time>
          <div class="schedule-content">
            <h3>Project Submissions Due</h3>
            <p>Submit your project link or file. Presentations begin.</p>
          </div>
        </div>
        <div class="schedule-item featured-time">
          <time class="schedule-time" datetime="2025-03-15T16:30">4:30 PM</time>
          <div class="schedule-content">
            <h3>🏆 Awards Ceremony</h3>
            <p>Prizes awarded, group photos, and celebrating everyone's work!</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Registration Form -->
  <section class="register-section" id="register">
    <div class="container">
      <h2>Register Your Team</h2>
      <p>Registration is free and open until March 1, 2025. Limited to 50 teams.</p>
      <form class="register-form" action="/register" method="post">
        <fieldset>
          <legend>Team Leader Information</legend>
          <div class="form-row">
            <div class="form-field">
              <label for="leader-name">Full Name *</label>
              <input type="text" id="leader-name" name="leader-name" required>
            </div>
            <div class="form-field">
              <label for="leader-grade">Grade *</label>
              <select id="leader-grade" name="leader-grade" required>
                <option value="">Select grade</option>
                <option>Grade 4</option>
                <option>Grade 5</option>
                <option>Grade 6</option>
                <option>Grade 7</option>
                <option>Grade 8</option>
              </select>
            </div>
          </div>
          <div class="form-field">
            <label for="leader-email">Parent/Guardian Email *</label>
            <input type="email" id="leader-email" name="leader-email" required>
          </div>
        </fieldset>
        <fieldset>
          <legend>Team Details</legend>
          <div class="form-field">
            <label for="team-name">Team Name *</label>
            <input type="text" id="team-name" name="team-name" required placeholder="Be creative!">
          </div>
          <div class="form-field">
            <label for="team-members">Other Team Members (names and grades)</label>
            <textarea id="team-members" name="team-members" rows="3"
              placeholder="e.g. Jordan Lee (Gr 6), Priya Sharma (Gr 7)"></textarea>
          </div>
          <div class="form-field">
            <label for="project-idea">Project Idea (optional)</label>
            <textarea id="project-idea" name="project-idea" rows="3"
              placeholder="Briefly describe what you plan to build — or leave blank if you haven't decided yet!"></textarea>
          </div>
        </fieldset>
        <button type="submit" class="btn-submit">Submit Registration →</button>
      </form>
    </div>
  </section>

  <footer>
    <p>Questions? Email <a href="mailto:hackathon@codeshipacademy.com">hackathon@codeshipacademy.com</a></p>
  </footer>

  <script>
    // Countdown timer
    const eventDate = new Date('2025-03-15T09:00:00-05:00');
    function updateCountdown() {
      const now = new Date();
      const diff = eventDate - now;
      if (diff <= 0) {
        document.getElementById('countdown').innerHTML = '<p>The event is happening now! 🚀</p>';
        return;
      }
      const days = Math.floor(diff / (1000*60*60*24));
      const hours = Math.floor((diff % (1000*60*60*24)) / (1000*60*60));
      const mins = Math.floor((diff % (1000*60*60)) / (1000*60));
      const secs = Math.floor((diff % (1000*60)) / 1000);
      document.getElementById('days').textContent = days;
      document.getElementById('hours').textContent = String(hours).padStart(2,'0');
      document.getElementById('minutes').textContent = String(mins).padStart(2,'0');
      document.getElementById('seconds').textContent = String(secs).padStart(2,'0');
    }
    updateCountdown();
    setInterval(updateCountdown, 1000);
  </script>
</body>
</html>
```

## Key Takeaways 🌟

1. Event pages answer five questions immediately: What, When, Where, Who, How to register
2. Schema.org Event structured data enables rich Google results (date, location, price shown in search)
3. Countdown timers use `setInterval` to update every second — `new Date()` for current time
4. `<fieldset>` and `<legend>` group related form fields semantically — great for multi-section forms
5. A visual timeline (schedule) communicates the day's flow better than a list of times
6. Event pages should have strong hero CTAs — "Register Now — It's Free" beats "Learn More"
7. `<time datetime="ISO-date">` tells machines when; visible text tells humans
$L$,
ARRAY['html','css','forms','events','countdown','javascript','schema'], 48),

('bld-l49', 'CSS: Overflow and Scroll Behaviours', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Control element overflow with clip, scroll, and auto','Create horizontal scroll containers','Use scroll-snap for smooth scrolling carousels'],
$L$# CSS: Overflow and Scroll Behaviours

## What Is Overflow?

Overflow happens when content is larger than its container. By default, content spills out — it "overflows." CSS gives you control over what happens.

## The `overflow` Property

```css
.container {
  overflow: visible;  /* Default: content spills outside the element */
  overflow: hidden;   /* Clips — content is cut off */
  overflow: scroll;   /* Always shows scrollbars */
  overflow: auto;     /* Shows scrollbars only when needed (most useful) */
  overflow: clip;     /* Clips without creating a scrolling context */
}

/* Control X and Y independently */
overflow-x: auto;     /* Horizontal scroll only */
overflow-y: hidden;   /* No vertical overflow */
```

### `overflow: hidden` Use Cases

```css
/* Crop images in containers */
.card-image {
  overflow: hidden;
  border-radius: 12px;
}
.card-image img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  transition: transform 0.4s ease;
}
.card-image:hover img { transform: scale(1.05); }
/* Without overflow: hidden, the zoomed image would stick out! */

/* Clearfix (contain floated children - rarely needed today) */
.clearfix { overflow: hidden; }
```

### Text Overflow: Ellipsis

```css
/* Single line truncation with "..." */
.card-title {
  white-space: nowrap;     /* Don't wrap to next line */
  overflow: hidden;         /* Hide the overflow */
  text-overflow: ellipsis; /* Show "..." at the cut-off */
  max-width: 200px;
}
/* Result: "This is a very long title that gets tru..." */

/* Multi-line truncation (2 lines then ellipsis) */
.card-excerpt {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  /* Shows only 2 lines, then "..." */
}
```

## Horizontal Scroll Containers

```html
<div class="scroll-container">
  <div class="scroll-item">Card 1</div>
  <div class="scroll-item">Card 2</div>
  <div class="scroll-item">Card 3</div>
  <div class="scroll-item">Card 4</div>
  <div class="scroll-item">Card 5</div>
</div>
```

```css
.scroll-container {
  display: flex;
  gap: 16px;
  overflow-x: auto;          /* Enable horizontal scroll */
  padding: 16px;
  
  /* Smooth momentum scrolling on iOS */
  -webkit-overflow-scrolling: touch;
  
  /* Hide scrollbar (still scrollable) */
  scrollbar-width: none;       /* Firefox */
  -ms-overflow-style: none;    /* IE/Edge */
}
.scroll-container::-webkit-scrollbar { display: none; } /* Chrome/Safari */

.scroll-item {
  flex: 0 0 280px;  /* Don't shrink — stay at 280px */
  min-height: 200px;
  background: white;
  border-radius: 12px;
  /* Items won't wrap because of flex: 0 0 — they'll overflow horizontally */
}
```

## Scroll Snap: Smooth Carousel

`scroll-snap` makes elements snap into place as you scroll — creating smooth carousels:

```css
.carousel {
  display: flex;
  overflow-x: auto;
  scroll-snap-type: x mandatory; /* Snap on X axis, must snap */
  scrollbar-width: none;
}

.carousel-item {
  flex: 0 0 100%;    /* Each item takes full width */
  scroll-snap-align: start; /* Snap to the start of each item */
}
```

Options for `scroll-snap-type`:
- `x mandatory` — must land on a snap point when scrolling horizontally
- `y proximity` — snaps if near a point (more lenient)
- `both mandatory` — snaps in both directions

Options for `scroll-snap-align`:
- `start` — snap to the start edge
- `center` — snap to the centre
- `end` — snap to the end edge

## Smooth Scrolling

```css
/* Smooth scrolling for the entire page */
html { scroll-behavior: smooth; }

/* Add margin so content doesn't hide under a sticky header */
section { scroll-margin-top: 80px; } /* 80px = header height */
```

Now anchor links (`<a href="#section">`) scroll smoothly instead of jumping.

## Sticky Elements and Overflow

**Important:** An element with `position: sticky` only works if none of its ancestors has `overflow: hidden` or `overflow: auto` set. If sticky isn't working, check parent `overflow` values.

```css
/* This breaks sticky! */
.parent { overflow: hidden; }
.child { position: sticky; top: 0; } /* Won't stick! */

/* Fix: don't set overflow on parents of sticky elements */
```

## Custom Scrollbar Styling

```css
/* Only works in Chrome/Safari (webkit) */
::-webkit-scrollbar { width: 8px; }
::-webkit-scrollbar-track { background: #F8F9FE; }
::-webkit-scrollbar-thumb {
  background: #1E2140;
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover { background: #F5C518; }

/* Firefox */
* {
  scrollbar-width: thin;
  scrollbar-color: #1E2140 #F8F9FE;
}
```

## Key Takeaways 🌟

1. `overflow: hidden` clips content — essential for image hover zoom effects
2. `overflow: auto` adds scrollbars only when needed — the most useful value
3. `white-space: nowrap; overflow: hidden; text-overflow: ellipsis` creates single-line truncation
4. `-webkit-line-clamp` truncates multi-line text
5. Horizontal scroll containers use `display: flex` with `overflow-x: auto` and `flex: 0 0 width` on items
6. `scroll-snap-type` and `scroll-snap-align` create smooth carousels without JavaScript
7. `scroll-behavior: smooth` enables smooth anchor scrolling; `scroll-margin-top` adds offset for fixed headers
8. `position: sticky` breaks when any ancestor has `overflow` set — a common debugging puzzle
$L$,
ARRAY['css','overflow','scroll','carousel','scroll-snap','text-overflow'], 49),

('bld-l50', 'Halfway Checkpoint: Portfolio Review', 'Projects', 'HTML', 'intermediate', 40, 'published',
ARRAY['Review and audit your portfolio of work so far','Apply improvements using skills from lessons 1-49','Present your best project with a professional write-up'],
$L$# Halfway Checkpoint: Portfolio Review

## You Are Halfway Through Builders

Stop and look back at how far you've come. When you started Lesson 1, you were learning what HTML tags are. By now you can:

- Build complete multi-page websites
- Style with CSS using flexbox, grid, transitions, and animations
- Apply responsive design for all screen sizes
- Make websites accessible
- Build interactive stories and games in Scratch
- Optimise for SEO and performance
- Debug your own code

This lesson is about consolidating that knowledge and building the best portfolio piece you've made so far.

## The Portfolio Audit: Reviewing Your Work

Go back through every project you've completed. For each one, answer:

**1. Does it actually work?**
- Open it in a browser. Test every link, every form, every button.
- Fix any broken elements before moving on.

**2. Is it responsive?**
- Open Chrome DevTools (F12) and test at 375px (mobile) and 768px (tablet).
- If it's broken on mobile, fix it now — responsiveness is non-negotiable.

**3. Is it accessible?**
- Tab through it with a keyboard. Can you reach everything?
- Run the Lighthouse Accessibility audit (F12 → Lighthouse).
- Fix any red items.

**4. Is the code clean?**
- Is it properly indented?
- Are there any unused styles or commented-out code blocks you can delete?
- Are class names descriptive?

**5. Does it make you proud?**
- Would you show this to a teacher, parent, or potential employer?
- If not — what would need to change?

## Choosing Your Showcase Project

Pick ONE project that best demonstrates your skills. It should have:

- Clean, semantic HTML
- Good CSS styling with your own design choices
- Responsiveness at mobile, tablet, and desktop
- No broken links or missing images
- A clear purpose (not just an exercise)

Candidates:
- Your personal homepage
- The product landing page
- The recipe blog
- The event page
- Or the best Scratch game you've built

## Writing a Project Write-Up

Every project in a professional portfolio has a write-up. Here's the template:

```html
<article class="portfolio-case-study">
  <header class="case-study-header">
    <h1>CODEship Hackathon Event Page</h1>
    <p class="case-study-type">HTML · CSS · JavaScript</p>
    <a href="[your page URL]" class="view-project-btn">View Live Project →</a>
  </header>

  <section class="case-overview">
    <h2>Overview</h2>
    <p>A complete event landing page for the CODEship Hackathon 2025. 
       Designed to inform potential participants and capture registrations.</p>
  </section>

  <section class="case-challenge">
    <h2>The Challenge</h2>
    <p>Event pages need to answer five questions immediately (what, when, where, 
       who, and how to register) while building excitement and trust.</p>
  </section>

  <section class="case-solution">
    <h2>What I Built</h2>
    <ul>
      <li>Countdown timer that updates every second</li>
      <li>Visual schedule timeline</li>
      <li>Fully accessible registration form with fieldset grouping</li>
      <li>Schema.org Event structured data for Google</li>
      <li>Responsive layout that works on all screen sizes</li>
    </ul>
  </section>

  <section class="case-learnings">
    <h2>What I Learned</h2>
    <p>The hardest part was the countdown timer — I had to learn about 
       the Date object in JavaScript and setInterval. I also learned 
       that scroll-behavior: smooth makes anchor links feel much more 
       professional.</p>
  </section>

  <div class="case-screenshots">
    <figure>
      <img src="screenshot-desktop.png" alt="Desktop view of event page showing hero section">
      <figcaption>Desktop view</figcaption>
    </figure>
    <figure>
      <img src="screenshot-mobile.png" alt="Mobile view showing stacked layout">
      <figcaption>Mobile view — responsive layout</figcaption>
    </figure>
  </div>
</article>
```

## Improving Your Showcase Project

Before writing the case study, spend 20 minutes improving your chosen project:

**Quick wins (5 minutes each):**
- Add smooth scrolling: `html { scroll-behavior: smooth; }`
- Add hover transitions to all interactive elements
- Make sure all images have alt text
- Add a meta description

**Bigger improvements (20 minutes):**
- Implement the section you skipped or rushed
- Make it fully mobile-responsive
- Add CSS animations to the hero section
- Add proper SEO meta tags

## Publishing Your Portfolio

If you haven't published your work online yet, do it now:

1. Create a free account at **Netlify** (netlify.com)
2. Drag your project folder onto the Netlify dashboard
3. Get a live URL like `your-project.netlify.app`
4. Optional: Add a custom domain through Netlify settings

Share the URL with your teacher and parents. Real work on the real internet — that's something to be proud of.

## Key Takeaways 🌟

1. Regular portfolio reviews are how professionals continuously improve
2. Audit criteria: does it work, is it responsive, is it accessible, is it clean code?
3. Case study write-ups explain the What (what was built), Why (the challenge), and How (what you learned)
4. Screenshots at multiple breakpoints show you understand responsive design
5. Publishing your work on a real URL demonstrates your skills authentically
6. A portfolio of real published projects is more valuable than any certificate
7. Half the Builders curriculum done — the skills you've built are genuinely professional-grade
$L$,
ARRAY['portfolio','review','projects','publishing','professional-development'], 50);


INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l45', 'Building a News and Blog Homepage', 'Projects', 'HTML', 'intermediate', 50, 'published',
ARRAY['Build a news-style homepage with featured article and grid','Apply CSS Grid for asymmetric layouts','Create a date-stamped article card component'],
$L$# Building a News and Blog Homepage

## The News Grid Layout

News websites use sophisticated grid layouts to show many stories at different levels of importance — the lead story is huge, secondary stories are medium, and briefs are small. You''ll build this pattern from scratch.

## HTML Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>The CODEship Gazette</title>
  <link rel="stylesheet" href="news.css">
</head>
<body>

  <header class="masthead">
    <div class="masthead-top">
      <div class="edition-info">
        <time datetime="2024-11-15">Friday, November 15, 2024</time>
        <span>Edition 142</span>
      </div>
      <h1 class="newspaper-name">The CODEship Gazette</h1>
      <p class="tagline">Coding News for Young Developers</p>
    </div>
    <nav class="section-nav">
      <a href="#tech">Technology</a>
      <a href="#science">Science</a>
      <a href="#education">Education</a>
      <a href="#opinion">Opinion</a>
      <a href="#tutorials">Tutorials</a>
    </nav>
  </header>

  <main class="news-grid">

    <!-- LEAD STORY — spans 2 columns, 2 rows -->
    <article class="article-card lead-story">
      <a href="article.html" class="card-image-link">
        <img src="images/ai-education.jpg" alt="A classroom of students using tablets for AI-powered learning" loading="lazy">
        <span class="category-tag">Education</span>
      </a>
      <div class="card-body">
        <h2><a href="article.html">Ontario Schools Adopt AI Tutoring for All Grade Levels</a></h2>
        <p class="deck">A new province-wide initiative will bring AI-powered personalised tutoring to over 2 million students starting September 2025, according to the Ministry of Education.</p>
        <div class="article-meta">
          <span class="author">By <strong>Sarah Chen</strong></span>
          <time datetime="2024-11-15">November 15, 2024</time>
          <span class="read-time">4 min read</span>
        </div>
      </div>
    </article>

    <!-- SECONDARY STORIES -->
    <article class="article-card secondary-story">
      <a href="#" class="card-image-link">
        <img src="images/scratch.jpg" alt="Children building Scratch games" loading="lazy">
        <span class="category-tag">Technology</span>
      </a>
      <div class="card-body">
        <h3><a href="#">Scratch Reaches 100 Million Users Worldwide</a></h3>
        <div class="article-meta">
          <time datetime="2024-11-14">November 14</time>
          <span>· 2 min read</span>
        </div>
      </div>
    </article>

    <article class="article-card secondary-story">
      <a href="#" class="card-image-link">
        <img src="images/python.jpg" alt="Python code on a screen" loading="lazy">
        <span class="category-tag">Science</span>
      </a>
      <div class="card-body">
        <h3><a href="#">Python Now #1 Language for Beginners in 2024</a></h3>
        <div class="article-meta">
          <time datetime="2024-11-13">November 13</time>
          <span>· 3 min read</span>
        </div>
      </div>
    </article>

    <!-- BRIEF STORIES — text only, no images -->
    <aside class="briefs-column">
      <h2 class="column-heading">Latest Briefs</h2>
      <article class="brief">
        <time datetime="2024-11-15">Nov 15</time>
        <h4><a href="#">Google Announces Free Coding Certificates for Grades 6-8</a></h4>
      </article>
      <hr>
      <article class="brief">
        <time datetime="2024-11-14">Nov 14</time>
        <h4><a href="#">Canada Ranks 7th Globally in Student Coding Proficiency</a></h4>
      </article>
      <hr>
      <article class="brief">
        <time datetime="2024-11-13">Nov 13</time>
        <h4><a href="#">New Study: Coding Improves Math Scores by 23%</a></h4>
      </article>
      <hr>
      <article class="brief">
        <time datetime="2024-11-12">Nov 12</time>
        <h4><a href="#">Minecraft Education Edition Now Includes Python API</a></h4>
      </article>
    </aside>

  </main>

  <!-- SECOND ROW: Regular article grid -->
  <section class="more-articles" id="tech">
    <h2 class="section-heading">Technology</h2>
    <div class="article-row">
      <!-- 3 equal article cards -->
      <article class="article-card">
        <img src="images/web.jpg" alt="" loading="lazy">
        <div class="card-body">
          <span class="category-tag">Technology</span>
          <h3><a href="#">CSS Grid Level 3 Brings Subgrid to All Browsers</a></h3>
          <p>The long-awaited subgrid feature is now supported in all major browsers, enabling more precise alignment between nested grids.</p>
          <div class="article-meta">
            <time datetime="2024-11-10">November 10</time>
          </div>
        </div>
      </article>
      <!-- Add 2 more similar cards -->
    </div>
  </section>

  <footer class="site-footer">
    <p>© 2024 The CODEship Gazette · A CODEship Academy Publication</p>
    <nav>
      <a href="/about">About</a>
      <a href="/contact">Contact</a>
      <a href="/privacy">Privacy</a>
    </nav>
  </footer>

</body>
</html>
```

## The News CSS

```css
:root {
  --serif: 'Playfair Display', Georgia, serif;
  --sans: 'Nunito', Arial, sans-serif;
  --navy: #1E2140;
  --red: #C41E3A;
  --text: #222;
  --muted: #666;
  --border: #ddd;
  --bg: #f8f6f0;
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--sans); background: var(--bg); color: var(--text); }
img { max-width: 100%; height: auto; display: block; }
a { color: inherit; text-decoration: none; }
a:hover { color: var(--red); }

/* Masthead */
.masthead {
  background: white;
  border-bottom: 4px double var(--navy);
}
.masthead-top {
  text-align: center;
  padding: 20px;
  border-bottom: 1px solid var(--border);
}
.masthead-top .edition-info {
  display: flex;
  justify-content: space-between;
  font-size: 0.75rem;
  color: var(--muted);
  margin-bottom: 8px;
}
.newspaper-name {
  font-family: var(--serif);
  font-size: 3.5rem;
  font-weight: 700;
  color: var(--navy);
  letter-spacing: -0.02em;
}
.tagline { font-style: italic; color: var(--muted); font-size: 0.9rem; }

.section-nav {
  display: flex;
  justify-content: center;
  gap: 0;
  overflow-x: auto;
}
.section-nav a {
  padding: 10px 20px;
  font-weight: 700;
  font-size: 0.85rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-right: 1px solid var(--border);
  white-space: nowrap;
}
.section-nav a:hover { background: var(--navy); color: white; }

/* Main news grid */
.news-grid {
  display: grid;
  grid-template-columns: 1fr 1fr 280px;
  grid-template-rows: auto;
  gap: 1px;
  background: var(--border);
  margin: 0;
  max-width: 1200px;
  margin: 24px auto;
}

.article-card { background: white; overflow: hidden; }

.lead-story {
  grid-column: 1 / 3;
  display: grid;
  grid-template-columns: 1fr 1fr;
}
.lead-story .card-image-link { grid-column: 1; }
.lead-story .card-body { grid-column: 2; padding: 24px; }
.lead-story h2 { font-family: var(--serif); font-size: 1.6rem; line-height: 1.2; margin-bottom: 12px; }
.lead-story h2 a:hover { color: var(--red); }
.deck { color: var(--muted); line-height: 1.6; font-size: 0.95rem; margin-bottom: 16px; }

.secondary-story { display: flex; flex-direction: column; }
.secondary-story img { height: 160px; object-fit: cover; width: 100%; }
.secondary-story .card-body { padding: 16px; }
.secondary-story h3 { font-family: var(--serif); font-size: 1rem; line-height: 1.4; }

.briefs-column { padding: 20px; background: #f0ede6; }
.column-heading { font-family: var(--serif); font-size: 1rem; border-bottom: 2px solid var(--navy); padding-bottom: 8px; margin-bottom: 16px; }
.brief { padding: 10px 0; }
.brief time { font-size: 0.75rem; color: var(--red); font-weight: 700; }
.brief h4 { font-size: 0.85rem; line-height: 1.4; margin-top: 4px; }

.article-meta { display: flex; gap: 8px; align-items: center; font-size: 0.8rem; color: var(--muted); flex-wrap: wrap; }

.category-tag {
  position: absolute;
  top: 10px; left: 10px;
  background: var(--red);
  color: white;
  padding: 2px 8px;
  font-size: 0.7rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}
.card-image-link { position: relative; }
.card-image-link img { width: 100%; height: 100%; object-fit: cover; }

.more-articles { max-width: 1200px; margin: 32px auto; padding: 0 24px; }
.section-heading {
  font-family: var(--serif);
  font-size: 1.5rem;
  border-bottom: 3px solid var(--navy);
  padding-bottom: 8px;
  margin-bottom: 24px;
}
.article-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}

@media (max-width: 900px) {
  .news-grid { grid-template-columns: 1fr 1fr; }
  .lead-story { grid-column: 1 / 3; grid-template-columns: 1fr; }
  .briefs-column { grid-column: 1 / 3; }
  .article-row { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 600px) {
  .news-grid { grid-template-columns: 1fr; }
  .lead-story { grid-column: 1; }
  .briefs-column { grid-column: 1; }
  .newspaper-name { font-size: 2rem; }
  .article-row { grid-template-columns: 1fr; }
}
```

## Key Takeaways

1. News layouts use asymmetric CSS Grid — lead story spans columns, briefs get a sidebar
2. The `grid-template-columns: 1fr 1fr 280px` pattern: two flexible columns + fixed sidebar
3. `<time datetime="ISO-date">Display text</time>` is semantic date markup
4. `<article>` wraps self-contained news stories; `<aside>` wraps supplementary content
5. The masthead section name pattern (Playlists Display serif, all-caps nav) is a classic newspaper convention
$L$,
ARRAY['html','css','news','grid','blog','project'], 45),

('bld-l46', 'CSS: Print Stylesheets and @media print', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Write print-specific CSS using @media print','Control page breaks and print layouts','Create a printable document from a webpage'],
$L$# CSS: Print Stylesheets and @media print

## Why Print CSS Matters

Many users print web pages or save them as PDFs. Without print CSS, pages often print with dark backgrounds (wasting ink), navigation bars that serve no purpose on paper, and broken layouts. Print CSS solves all of these.

## The Two Ways to Add Print CSS

**Method 1: Media attribute on link tag**
```html
<link rel="stylesheet" href="print.css" media="print">
```

**Method 2: @media query inside your main CSS (most common)**
```css
@media print {
  /* Print styles here — only applied when printing */
}
```

## Essential Print CSS Patterns

### Hide non-essential elements
```css
@media print {
  /* Never useful on paper */
  nav, header nav, .sidebar, .ads,
  footer .social-links, .cookie-banner,
  .back-to-top, video, audio,
  button:not(.print-button) {
    display: none !important;
  }
}
```

### Reset colours for ink efficiency
```css
@media print {
  body {
    background: white !important;
    color: black !important;
  }

  /* Remove coloured backgrounds from sections */
  section, .card, .hero {
    background: white !important;
    box-shadow: none !important;
  }

  /* Dark text for all elements */
  h1, h2, h3, p, li {
    color: black !important;
  }
}
```

### Show link URLs
```css
@media print {
  /* Show the URL after each link */
  a::after {
    content: " (" attr(href) ")";
    font-size: 0.8em;
    color: #555;
  }

  /* But not for internal anchor links */
  a[href^="#"]::after { content: ""; }

  /* And not for navigation links */
  nav a::after { content: ""; }
}
```

### Control page breaks
```css
@media print {
  /* Never break inside these elements */
  figure, table, blockquote, .card {
    break-inside: avoid;
    page-break-inside: avoid; /* Legacy */
  }

  /* Always start on new page */
  h1 { break-before: page; }

  /* Headings should stay with the content following them */
  h2, h3 { break-after: avoid; }

  /* Or force a break before a specific section */
  .chapter { break-before: page; }
}
```

### Set page size and margins
```css
@media print {
  @page {
    size: A4 portrait;  /* or letter, A4 landscape, etc. */
    margin: 2cm;        /* 2cm margins all around */
  }

  /* First page special margins */
  @page :first {
    margin-top: 3cm;
  }
}
```

### Typography for print
```css
@media print {
  body {
    font-family: Georgia, serif; /* Serifs read better in print */
    font-size: 12pt;             /* Points, not pixels, for print */
    line-height: 1.5;
  }

  h1 { font-size: 24pt; }
  h2 { font-size: 18pt; }
  h3 { font-size: 14pt; }
}
```

## A Complete Print Stylesheet

```css
@media print {
  /* Reset */
  *, *::before, *::after { box-shadow: none !important; text-shadow: none !important; }

  /* Hide interactive/nav elements */
  nav, .nav, header nav, .sidebar, .footer-nav,
  .back-to-top, .cookie-notice, .chat-widget,
  video, audio, canvas, [aria-hidden="true"] { display: none !important; }

  /* Page setup */
  @page { margin: 2cm; }
  body { background: white; color: black; font-size: 11pt; font-family: Georgia, serif; }

  /* Typography */
  a { color: black; }
  a[href]::after { content: " <" attr(href) ">"; font-size: 0.8em; font-style: italic; }
  a[href^="#"]::after, a[href^="tel"]::after, a[href^="mailto"]::after { content: ""; }

  /* Page breaks */
  h1, h2, h3 { break-after: avoid; }
  p, li, blockquote { orphans: 3; widows: 3; }
  figure, table, pre { break-inside: avoid; }

  /* Images */
  img { max-width: 100% !important; }
  figure { text-align: center; }
}
```

## Testing Print CSS

Don''t print 50 test sheets! Test in browser:
- **Chrome:** Ctrl+P → see print preview (or Ctrl+Shift+P → "Emulate CSS media type" → print)
- **Chrome DevTools:** Rendering tab → "Emulate CSS media type" → print

This renders your page exactly as it would print.

## Building a Printable Certificate

```html
<div class="certificate">
  <div class="cert-border">
    <h1>Certificate of Completion</h1>
    <p>This certifies that</p>
    <h2 class="student-name">Alex Johnson</h2>
    <p>has successfully completed</p>
    <h3>Builders Level — HTML & CSS</h3>
    <p>CODEship Academy · <time datetime="2024-11">November 2024</time></p>
    <div class="cert-seal">🏆</div>
    <div class="signatures">
      <div class="sig-line">Instructor</div>
      <div class="sig-line">Director</div>
    </div>
  </div>
  <button onclick="window.print()" class="print-btn no-print">Print Certificate 🖨️</button>
</div>
```

```css
.certificate { max-width: 800px; margin: 40px auto; padding: 24px; }
.cert-border {
  border: 8px double #1E2140;
  padding: 60px;
  text-align: center;
  background: linear-gradient(135deg, #fff9e6, #ffffff);
}
.student-name { font-size: 2.5rem; color: #1E2140; }
.cert-seal { font-size: 4rem; margin: 20px 0; }
.signatures { display: flex; justify-content: space-around; margin-top: 40px; }
.sig-line { border-top: 2px solid #333; width: 160px; padding-top: 8px; font-size: 0.85rem; }

@media print {
  body { background: white; }
  .no-print { display: none !important; }
  .certificate { margin: 0; padding: 0; }
  .cert-border { border-width: 4px; }
  @page { margin: 1cm; }
}
```

## Key Takeaways

1. `@media print { }` applies CSS only when the user prints or saves as PDF
2. Always hide navigation, sidebars, buttons, and interactive elements in print
3. Reset backgrounds to white and text to black to save ink
4. `a::after { content: attr(href) }` shows link URLs in the printed page
5. `break-inside: avoid` prevents tables and figures from splitting across pages
6. Use `pt` units (not `px`) for print typography — `12pt` is standard body text
7. Test with Chrome''s print preview — don''t waste paper on test prints
$L$,
ARRAY['css','print','media-queries','pdf','document'], 46),

('bld-l47', 'Accessibility: ARIA Labels and Screen Readers in Depth', 'Accessibility', 'HTML', 'intermediate', 30, 'published',
ARRAY['Use ARIA live regions for dynamic content','Apply ARIA roles for complex widgets','Test a page using a screen reader'],
$L$# Accessibility: ARIA Labels and Screen Readers in Depth

## Deeper Into ARIA

You learned the basics of accessibility in Lesson 21. Now let''s go deeper — into the patterns that make complex interactive components accessible to everyone.

## ARIA Landmark Roles

Landmarks let screen reader users jump directly to major page regions:

```html
<header role="banner">         <!-- Page header -->
<nav role="navigation">        <!-- Navigation -->
<main role="main">             <!-- Main content -->
<aside role="complementary">   <!-- Sidebar -->
<footer role="contentinfo">    <!-- Page footer -->
<form role="search">           <!-- Search form -->
```

Modern browsers recognise `<header>`, `<nav>`, `<main>`, `<aside>`, `<footer>` as implicit landmarks — you don''t need the role attributes if you use the right semantic elements. But explicitly naming multiple navs helps:

```html
<nav aria-label="Main navigation">...</nav>
<nav aria-label="Breadcrumb navigation">...</nav>
<nav aria-label="Pagination">...</nav>
```

## aria-live: Announcing Dynamic Changes

Screen readers read the page top-to-bottom when it loads. But what about content that changes later — form error messages, loading states, success notifications, search results?

`aria-live` tells the screen reader to announce changes to this element:

```html
<!-- polite: announces when user is idle (doesn''t interrupt) -->
<div aria-live="polite" aria-atomic="true" id="status-message">
  <!-- Messages added here are announced automatically -->
</div>

<!-- assertive: announces immediately (interrupts current reading) -->
<div aria-live="assertive" role="alert" id="error-message">
  <!-- Use for errors that need immediate attention -->
</div>
```

```javascript
// Update the live region after form submission
function showSuccess() {
  document.getElementById('status-message').textContent = 'Your message was sent!';
}

function showError(message) {
  document.getElementById('error-message').textContent = message;
}
```

`aria-atomic="true"` means announce the entire region when any part changes (not just the changed part).

## Accessible Tabs

Tabs are a common pattern with specific ARIA requirements:

```html
<div class="tabs">
  <div role="tablist" aria-label="Course levels">
    <button role="tab"
            id="tab-explorers"
            aria-selected="true"
            aria-controls="panel-explorers">
      Explorers
    </button>
    <button role="tab"
            id="tab-builders"
            aria-selected="false"
            aria-controls="panel-builders"
            tabindex="-1">
      Builders
    </button>
  </div>

  <div role="tabpanel"
       id="panel-explorers"
       aria-labelledby="tab-explorers">
    <h3>Explorers Level</h3>
    <p>For Grades K-1...</p>
  </div>

  <div role="tabpanel"
       id="panel-builders"
       aria-labelledby="tab-builders"
       hidden>
    <h3>Builders Level</h3>
    <p>For Grades 2-3...</p>
  </div>
</div>
```

Key requirements:
- `role="tablist"` on the container
- `role="tab"` on each button
- `aria-selected="true/false"` on each tab
- `aria-controls` pointing to the panel ID
- `role="tabpanel"` on each panel
- `aria-labelledby` pointing to the tab ID
- `tabindex="-1"` on non-active tabs (only active tab is in tab order)

## Accessible Modals

```html
<div role="dialog"
     aria-modal="true"
     aria-labelledby="modal-title"
     id="signup-modal"
     hidden>
  <h2 id="modal-title">Create Your Account</h2>
  <button aria-label="Close dialog" class="modal-close">×</button>
  <!-- Modal content -->
</div>
```

When opening a modal:
```javascript
function openModal() {
  modal.removeAttribute('hidden');
  // Trap focus inside modal
  const focusable = modal.querySelectorAll('button, input, a, [tabindex]');
  focusable[0].focus();
}
```

When a modal is open, focus must be "trapped" inside it. Screen reader users should not be able to tab to content behind the modal.

## Accessible Icons

Icon-only buttons need labels:

```html
<!-- Bad: screen reader says "button" — but what does it DO? -->
<button><svg><!-- heart icon --></svg></button>

<!-- Good: aria-label describes the action -->
<button aria-label="Add to favourites">
  <svg aria-hidden="true"><!-- heart icon --></svg>
</button>

<!-- Or use visually hidden text -->
<button>
  <svg aria-hidden="true"><!-- heart icon --></svg>
  <span class="visually-hidden">Add to favourites</span>
</button>
```

The visually-hidden class hides text visually but keeps it readable by screen readers:

```css
.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
```

## Testing with a Real Screen Reader

**macOS VoiceOver:**
1. Press Cmd + F5 to enable VoiceOver
2. Use Tab to move between focusable elements
3. Use VO + Right Arrow to read next item
4. Use VO + U to open the rotor (jump by headings, landmarks, links)
5. Press Cmd + F5 again to disable

**Windows NVDA (free download):**
1. Download from nvaccess.org
2. Press Insert + Q to exit
3. Tab to navigate, Insert + F7 for elements list

Try these tests:
- Can you navigate the entire page using only Tab?
- Does every interactive element have a clear name?
- Are live regions announced when content changes?
- Is focus managed correctly in modals and tabs?

## Key Takeaways

1. ARIA landmark roles help screen reader users navigate to major page regions
2. `aria-label` names landmarks when multiple of the same type exist
3. `aria-live="polite"` announces dynamic content changes when user is idle
4. `aria-live="assertive"` / `role="alert"` announces errors immediately
5. Tabs require: `tablist`, `tab`, `tabpanel` roles + `aria-selected`, `aria-controls`, `aria-labelledby`
6. Modals need `role="dialog"` + `aria-modal` + focus trapping
7. Icon-only buttons need `aria-label` or visually-hidden text
8. Test with real screen readers — DevTools accessibility audits don''t catch everything
$L$,
ARRAY['accessibility','aria','screen-readers','live-regions','modals'], 47),

('bld-l48', 'Building an Event Announcement Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a complete event page with hero, details, speakers, and registration form','Apply countdown timer display','Use semantic event markup'],
$L$# Building an Event Announcement Page

## Events Happen Online First

Before anyone attends an event, they visit its webpage. The quality of that page determines whether they register. Great event pages create excitement, answer all questions, and make registration frictionless.

## What Every Event Page Needs

1. **Event name + date/time/location** — immediately visible
2. **Hero** — create excitement
3. **What to expect** — agenda or highlights
4. **Speakers/presenters** — social proof
5. **Registration form** — the conversion goal
6. **FAQ** — handle objections
7. **Countdown timer** — create urgency

## Complete Event Page HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CODEship Academy Spring Hackathon 2025</title>
  <!-- Schema.org Event structured data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Event",
    "name": "CODEship Spring Hackathon 2025",
    "startDate": "2025-04-12T09:00",
    "endDate": "2025-04-12T17:00",
    "location": {
      "@type": "Place",
      "name": "CODEship Academy",
      "address": { "streetAddress": "21 Simcoe St S", "addressLocality": "Oshawa", "addressRegion": "ON" }
    }
  }
  </script>
  <link rel="stylesheet" href="event.css">
</head>
<body>

  <!-- Hero -->
  <section class="event-hero">
    <div class="container">
      <div class="event-badge">🎉 FREE EVENT · LIMITED SPOTS</div>
      <h1>CODEship Spring<br><span class="accent">Hackathon 2025</span></h1>
      <div class="event-vitals">
        <div class="vital"><span>📅</span><div><strong>Date</strong><time datetime="2025-04-12">April 12, 2025</time></div></div>
        <div class="vital"><span>⏰</span><div><strong>Time</strong><span>9:00 AM – 5:00 PM EST</span></div></div>
        <div class="vital"><span>📍</span><div><strong>Location</strong><span>CODEship Academy, Oshawa + Online</span></div></div>
      </div>
      <div class="hero-cta">
        <a href="#register" class="btn-primary-lg">Register Free →</a>
        <a href="#agenda" class="btn-ghost-lg">See Agenda</a>
      </div>
    </div>
  </section>

  <!-- Countdown -->
  <section class="countdown-bar" aria-label="Time until event">
    <div class="container">
      <p>Event starts in:</p>
      <div class="countdown" id="countdown">
        <div class="time-unit"><span id="days">--</span><label>Days</label></div>
        <div class="time-unit"><span id="hours">--</span><label>Hours</label></div>
        <div class="time-unit"><span id="minutes">--</span><label>Minutes</label></div>
        <div class="time-unit"><span id="seconds">--</span><label>Seconds</label></div>
      </div>
    </div>
  </section>

  <!-- About -->
  <section class="about-event">
    <div class="container">
      <h2>What Is the Hackathon?</h2>
      <p class="lead">A full-day coding celebration where students from Grades 3–8 work in teams to build a project in 6 hours — then present it to judges.</p>
      <div class="highlights">
        <div class="highlight"><span>🏆</span><h3>Cash Prizes</h3><p>1st: $500, 2nd: $250, 3rd: $100</p></div>
        <div class="highlight"><span>👥</span><h3>Team Event</h3><p>Teams of 2-4. Don''t have a team? We''ll match you!</p></div>
        <div class="highlight"><span>🍕</span><h3>Free Lunch</h3><p>Lunch and snacks provided all day.</p></div>
        <div class="highlight"><span>🎓</span><h3>All Levels</h3><p>Explorers through Engineers all welcome.</p></div>
      </div>
    </div>
  </section>

  <!-- Agenda -->
  <section class="agenda" id="agenda">
    <div class="container">
      <h2>Day Agenda</h2>
      <ol class="agenda-list">
        <li class="agenda-item">
          <time datetime="09:00">9:00 AM</time>
          <div><h3>Registration &amp; Breakfast</h3><p>Pick up your badge and meet your team.</p></div>
        </li>
        <li class="agenda-item">
          <time datetime="09:30">9:30 AM</time>
          <div><h3>Opening Keynote &amp; Theme Reveal</h3><p>This year''s theme announced live!</p></div>
        </li>
        <li class="agenda-item featured">
          <time datetime="10:00">10:00 AM</time>
          <div><h3>🚀 HACK TIME BEGINS</h3><p>6 hours to build your project!</p></div>
        </li>
        <li class="agenda-item"><time datetime="12:00">12:00 PM</time><div><h3>Lunch Break</h3><p>Pizza provided for everyone.</p></div></li>
        <li class="agenda-item"><time datetime="16:00">4:00 PM</time><div><h3>Submission Deadline</h3><p>All projects must be submitted by 4pm.</p></div></li>
        <li class="agenda-item"><time datetime="16:30">4:30 PM</time><div><h3>Project Presentations</h3><p>3-minute demo per team.</p></div></li>
        <li class="agenda-item featured"><time datetime="17:00">5:00 PM</time><div><h3>🏆 Awards Ceremony</h3><p>Winners announced and prizes distributed!</p></div></li>
      </ol>
    </div>
  </section>

  <!-- Registration -->
  <section class="registration" id="register">
    <div class="container">
      <h2>Register Your Spot</h2>
      <p>Free registration. Limited to 100 participants. Reserve now.</p>
      <form class="reg-form" action="/register" method="post">
        <div class="form-row">
          <div class="form-field"><label for="reg-name">Student Name *</label><input type="text" id="reg-name" required></div>
          <div class="form-field"><label for="reg-grade">Grade *</label>
            <select id="reg-grade" required>
              <option value="">Select grade</option>
              <option>Grade 3</option><option>Grade 4</option><option>Grade 5</option>
              <option>Grade 6</option><option>Grade 7</option><option>Grade 8</option>
            </select>
          </div>
        </div>
        <div class="form-field"><label for="reg-email">Parent/Guardian Email *</label><input type="email" id="reg-email" required></div>
        <div class="form-field"><label for="reg-team">Team Name (optional)</label><input type="text" id="reg-team" placeholder="Leave blank and we''ll assign you to a team"></div>
        <label class="checkbox"><input type="checkbox" required> I agree to the event guidelines and photo release</label>
        <button type="submit" class="submit-btn">Reserve My Spot →</button>
      </form>
    </div>
  </section>

</body>
</html>
```

## Countdown Timer JavaScript

```javascript
function updateCountdown() {
  const eventDate = new Date('2025-04-12T09:00:00-05:00'); // EST
  const now = new Date();
  const diff = eventDate - now;

  if (diff <= 0) {
    document.getElementById('countdown').innerHTML = '<strong>The event is happening NOW! 🎉</strong>';
    return;
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  document.getElementById('days').textContent = days;
  document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
  document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
  document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
}

updateCountdown();
setInterval(updateCountdown, 1000); // Update every second
```

## Key Takeaways

1. Event pages need: name, date, location, agenda, speakers, registration — all above the fold or easily findable
2. Schema.org Event structured data enables rich search results with date/location
3. `<time datetime="ISO-date">Human readable</time>` is the semantic date element
4. Countdown timers use `setInterval` + date math to show time remaining
5. `padStart(2, '0')` formats numbers with leading zeros: 9 → 09
6. Registration forms should be simple — remove every unnecessary field
7. The `aria-label` on countdown section ensures screen readers understand the context
$L$,
ARRAY['html','css','project','event-page','countdown','forms'], 48),

('bld-l49', 'CSS: Overflow and Scroll Behaviours', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Control overflow with CSS overflow property','Use scroll-snap for precise scrolling','Build a horizontal scrolling card row'],
$L$# CSS: Overflow and Scroll Behaviours

## When Content Is Bigger Than Its Box

Every HTML element has defined dimensions. When content is larger than those dimensions, CSS `overflow` controls what happens.

## The overflow Property

```css
.box {
  overflow: visible;  /* Default: content spills outside the box */
  overflow: hidden;   /* Content is clipped — nothing shows outside */
  overflow: scroll;   /* Always shows scrollbars */
  overflow: auto;     /* Shows scrollbars only when needed (best for most cases) */
  overflow: clip;     /* Like hidden but disables all scrolling completely */
}

/* Control axes separately */
.horizontal-scroll {
  overflow-x: auto;   /* Horizontal scroll when needed */
  overflow-y: hidden; /* No vertical scroll */
}
```

## Common Overflow Patterns

### Prevent text from overflowing

```css
/* Truncate long text with an ellipsis */
.truncate {
  white-space: nowrap;     /* Prevent text wrapping */
  overflow: hidden;        /* Hide overflow */
  text-overflow: ellipsis; /* Show "..." at truncation point */
  max-width: 200px;
}

/* Multi-line truncation (modern) */
.line-clamp {
  display: -webkit-box;
  -webkit-line-clamp: 3;       /* Show 3 lines max */
  -webkit-box-orient: vertical;
  overflow: hidden;
}
```

### Hide scrollbars visually but keep scroll functionality

```css
.scroll-container {
  overflow-y: auto;
  scrollbar-width: none;        /* Firefox */
  -ms-overflow-style: none;     /* IE/Edge */
}
.scroll-container::-webkit-scrollbar {
  display: none;                /* Chrome/Safari */
}
```

### Style scrollbars

```css
.custom-scroll::-webkit-scrollbar { width: 8px; }
.custom-scroll::-webkit-scrollbar-track { background: #f0f0f0; border-radius: 4px; }
.custom-scroll::-webkit-scrollbar-thumb { background: #1E2140; border-radius: 4px; }
.custom-scroll::-webkit-scrollbar-thumb:hover { background: #F5C518; }
```

## Horizontal Scrolling Card Row

One of the most popular mobile patterns — a row of cards that scrolls horizontally:

```html
<section>
  <h2>Trending Courses</h2>
  <div class="scroll-row" role="list">
    <div class="course-card" role="listitem">...</div>
    <div class="course-card" role="listitem">...</div>
    <div class="course-card" role="listitem">...</div>
    <!-- Many more cards -->
  </div>
</section>
```

```css
.scroll-row {
  display: flex;
  gap: 16px;
  overflow-x: auto;
  padding-bottom: 16px; /* Space for scrollbar */
  
  /* Prevent cards from shrinking */
  flex-wrap: nowrap;

  /* Hide scrollbar (optional — keeps it clean) */
  scrollbar-width: thin;
  scrollbar-color: #1E2140 transparent;
}

.course-card {
  flex-shrink: 0;    /* Never shrink! */
  width: 280px;      /* Fixed width */
}

/* Fade at the edges to hint at scrollable content */
.scroll-row-wrapper {
  position: relative;
}
.scroll-row-wrapper::after {
  content: '';
  position: absolute;
  right: 0; top: 0; bottom: 16px;
  width: 60px;
  background: linear-gradient(to right, transparent, white);
  pointer-events: none; /* Allow clicking through */
}
```

## Scroll Snap: Precise Scrolling

`scroll-snap` makes scroll stop precisely at defined snap points — perfect for carousels, full-screen sections, and image galleries:

```css
/* Scroll container */
.snap-container {
  overflow-x: auto;
  scroll-snap-type: x mandatory;
  /* mandatory: always snaps to a snap point */
  /* proximity: only snaps if close to a point */
  display: flex;
  gap: 16px;
}

/* Each snap item */
.snap-item {
  flex-shrink: 0;
  width: 100%;
  scroll-snap-align: start;  /* Snap to start of item */
  /* center — snap to centre */
  /* end — snap to end */
}
```

**Vertical full-screen sections:**
```css
html {
  scroll-snap-type: y mandatory;
  height: 100%;
  overflow-y: scroll;
}

section {
  height: 100vh;
  scroll-snap-align: start;
}
```

This creates a presentation-style page where each section snaps into view perfectly!

## Smooth Scrolling

```css
/* Enable smooth scroll-to-anchor behaviour */
html { scroll-behavior: smooth; }

/* Add offset so sticky header doesn''t cover the target */
h2 { scroll-margin-top: 80px; }
```

## Key Takeaways

1. `overflow: hidden` clips content; `overflow: auto` shows scrollbars when needed
2. `white-space: nowrap` + `overflow: hidden` + `text-overflow: ellipsis` truncates text with "..."
3. `-webkit-line-clamp: N` truncates after N lines (multi-line ellipsis)
4. Horizontal scroll rows use `display: flex; overflow-x: auto; flex-wrap: nowrap`
5. `flex-shrink: 0` on cards prevents them from squishing in scroll containers
6. `scroll-snap-type` + `scroll-snap-align` create precise carousel/slide-style scrolling
7. `html { scroll-behavior: smooth; }` makes anchor link scrolling smooth
8. `scroll-margin-top` prevents sticky headers from covering anchor targets
$L$,
ARRAY['css','overflow','scroll-snap','carousel','horizontal-scroll'], 49),

('bld-l50', 'Halfway Checkpoint: Portfolio Review and Reflection', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Audit and improve your best project from lessons 1-49','Write a professional project description','Plan improvements for the second half of the level'],
$L$# Halfway Checkpoint: Portfolio Review

## You''ve Come Halfway — Let''s Reflect

You''ve completed 49 lessons. You know HTML structure, CSS styling, Flexbox, Grid, responsive design, animations, pseudo-classes, accessibility, Scratch, and much more.

This lesson is different — instead of learning something new, you''ll go back and make something great.

## The Portfolio Mindset

Every professional developer maintains a portfolio — a collection of their best work. The key word is **best**. Not everything you''ve built; the work that genuinely demonstrates your skills.

Right now, look back through your projects from Lessons 15–49. Ask:

1. **Which one am I most proud of?** That''s your hero project.
2. **Which one has the most potential?** That''s your improvement target.
3. **Which one would I be embarrassed to show a teacher?** Fix it or drop it.

## The Code Quality Audit

Take your best project and audit it against these criteria:

### HTML Quality
- [ ] Valid HTML5 document structure
- [ ] Semantic elements used (header, nav, main, article, section, footer, etc.)
- [ ] All images have meaningful alt text
- [ ] All form inputs have associated labels
- [ ] Heading hierarchy is logical (h1 → h2 → h3, no skipping)
- [ ] No inline styles (style="" attributes)
- [ ] Code is properly indented

### CSS Quality
- [ ] CSS is in a separate file
- [ ] Uses CSS custom properties (variables) for colours and spacing
- [ ] No redundant/conflicting rules
- [ ] Responsive — tested at 375px, 768px, and 1280px widths
- [ ] Has meaningful transitions/hover states on interactive elements
- [ ] Uses semantic class names (`.btn-primary` not `.blue-button-thing`)

### Accessibility
- [ ] Passes keyboard navigation (Tab through entire page)
- [ ] Focus indicators are visible
- [ ] Colour contrast passes (test at webaim.org/resources/contrastchecker)
- [ ] No information conveyed by colour alone

### Performance
- [ ] Images are appropriately sized (not 4000px wide for a 400px display)
- [ ] Images have `loading="lazy"` where appropriate
- [ ] Fonts load with `display=swap`

## Writing a Professional Project Description

For your portfolio page, each project needs a description that tells the story:

**Formula:**
```
[Project name] is a [type of project] built with [technologies]. 
It [what it does/solves]. I learned [key skills] by building it.
The most challenging part was [technical challenge] — I solved it by [solution].
```

**Example:**
*"The CODEship Recipe Blog is a three-page website built with HTML5 and CSS Grid, featuring a responsive card homepage, individual recipe pages with sticky ingredient sidebars, and print-optimised styles. I learned how to use `position: sticky` for the sidebar and `object-fit: cover` for uniform card images. The most challenging part was making the grid responsive across all screen sizes — I solved it using `repeat(auto-fill, minmax(300px, 1fr))`."*

## What to Improve

After auditing your project, prioritise fixes:

**High impact / easy:** Semantic elements, alt text, CSS variables
**High impact / moderate:** Responsive styles, accessibility
**High impact / harder:** Performance, advanced animations

Pick 3-5 specific improvements and make them.

## Planning the Second Half

Lessons 51-100 cover:
- Advanced CSS (multi-column, dark mode, blend modes)
- More Scratch projects (maze game, music composer)
- More full projects (newspaper, portfolio, fundraiser page)
- Publishing with GitHub Pages
- Code review and peer feedback
- The final capstone project

Start thinking: **What will your capstone project be?** The capstone in Lesson 97 is a full website design brief — you''ll design and build a complete website for a real or fictional client.

Some ideas to start planning:
- A website for a local business or charity
- A personal portfolio showcasing your projects
- A fan site for something you love
- A community resource page for your school or neighbourhood

## Key Takeaways

1. A portfolio shows your **best** work — not everything, just the highlights
2. Code audits catch quality issues before clients or employers do
3. Semantic HTML, accessibility, and responsiveness are the hallmarks of professional code
4. Writing about your projects in technical terms demonstrates genuine understanding
5. The `repeat(auto-fill, minmax())` pattern is worth knowing by heart — you''ll use it constantly
6. Planning ahead makes the capstone project less stressful — start thinking about it now
$L$,
ARRAY['project','portfolio','review','audit','reflection'], 50);


-- Lessons 51-100: completing with proper full-depth content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l51', 'CSS: Multi-Column Layout', 'CSS', 'CSS', 'intermediate', 20, 'published',
ARRAY['Use CSS columns property to create newspaper-style text layout','Control column width and count','Apply column rules and gaps'],
$L$# CSS: Multi-Column Layout

## Newspaper-Style Columns in CSS

Long text blocks are easier to read in columns. Newspapers, magazines, and academic papers use columns to make text more scannable and give the page visual variety.

CSS has a built-in multi-column system that works independently from Grid and Flexbox — it's specifically designed for flowing text.

## Column Properties

```css
.article-body {
  /* Option 1: Set the number of columns */
  column-count: 3;
  
  /* Option 2: Set the minimum column width (browser picks count) */
  column-width: 250px;
  
  /* Option 3: Both — min width AND max count */
  columns: 3 250px;  /* shorthand: count width */
  
  /* Gap between columns */
  column-gap: 32px;  /* default is 1em */
  
  /* Decorative line between columns */
  column-rule: 1px solid #E8EAF6;
  /* Same as border shorthand: width style color */
}
```

## Auto-Responsive Columns

The most useful pattern uses `column-width` rather than `column-count`. The browser automatically creates as many columns as will fit the minimum width:

```css
.article-body {
  column-width: 300px;  /* At least 300px per column */
  column-gap: 40px;
}
/* On a 1200px container: 3 columns of ~373px each
   On a 768px container: 2 columns of ~344px each
   On a 375px container: 1 column — no columns at all */
```

## Spanning Elements Across Columns

```css
/* Make a heading span all columns */
.article-body h2 {
  column-span: all;
  padding-bottom: 16px;
  margin-bottom: 24px;
  border-bottom: 2px solid #E8EAF6;
}

/* Nothing spans partially — it's all or nothing */
```

## Preventing Column Breaks

```css
/* Keep this element on one column, don't split it */
.quote, .figure, .callout {
  break-inside: avoid;
  /* Also: page-break-inside: avoid; (for print) */
}

/* Force a new column before this heading */
h2 { break-before: column; }
```

## A Complete Magazine Article

```html
<article class="magazine-article">
  <header class="article-head">
    <h1>Why Every Child Should Learn to Code</h1>
    <p class="byline">By Sarah Chen · November 15, 2024 · 5 min read</p>
  </header>
  <div class="article-body">
    <p class="lead">The world runs on code. From the smartphone in your pocket...</p>
    <p>In Ontario, a new curriculum mandate ensures that...</p>
    <blockquote class="pull-quote">
      "Learning to code is learning to think" — Mitch Resnick, MIT
    </blockquote>
    <p>Research from the University of Toronto shows that students...</p>
    <h2>The Benefits Begin Early</h2>
    <p>Cognitive scientists have found that computational thinking...</p>
  </div>
</article>
```

```css
.magazine-article {
  max-width: 900px;
  margin: 0 auto;
  padding: 40px 24px;
}

.article-head {
  text-align: center;
  margin-bottom: 40px;
  padding-bottom: 40px;
  border-bottom: 3px double #1E2140;
}

.article-head h1 {
  font-size: 2.5rem;
  font-weight: 900;
  line-height: 1.2;
  margin-bottom: 12px;
}

.byline { color: #8B90B0; font-size: 0.9rem; }

.article-body {
  column-width: 280px;
  column-gap: 40px;
  column-rule: 1px solid #E8EAF6;
  font-size: 1rem;
  line-height: 1.8;
}

.article-body h2 {
  column-span: all;
  font-size: 1.4rem;
  border-bottom: 2px solid #F5C518;
  padding-bottom: 8px;
  margin: 32px 0 16px;
}

.pull-quote {
  break-inside: avoid;
  border-left: 4px solid #F5C518;
  padding: 16px 20px;
  margin: 24px 0;
  font-size: 1.15rem;
  font-style: italic;
  color: #1E2140;
  background: #FFFBEB;
  border-radius: 0 8px 8px 0;
}

.lead {
  font-size: 1.15rem;
  font-weight: 600;
  color: #3A3D5C;
}
```

## Key Takeaways 🌟

1. CSS multi-column creates newspaper-style text layout with `column-count` or `column-width`
2. `column-width` auto-adjusts column count based on available space — more responsive than `column-count`
3. `column-gap` controls space between columns; `column-rule` adds a decorative separator
4. `column-span: all` makes headings break out and span the full width
5. `break-inside: avoid` prevents figures and quotes from being split across columns
6. Multi-column is specifically for text flow — use Grid for page layout
$L$,
ARRAY['css','multi-column','layout','typography','magazine'], 51),

('bld-l52', 'HTML: Data Attributes', 'HTML', 'HTML', 'intermediate', 20, 'published',
ARRAY['Use data-* attributes to store custom data in HTML','Read data attributes with JavaScript and CSS','Build a filterable list using data attributes'],
$L$# HTML: Data Attributes

## Storing Data in HTML

Sometimes you want to attach extra information to an HTML element — information that JavaScript or CSS can read, but that doesn't display to the user. That's what `data-*` attributes are for.

```html
<button
  data-product-id="42"
  data-price="19.99"
  data-category="courses">
  Add to Cart
</button>
```

Any attribute starting with `data-` is a data attribute. The `*` can be any name you choose.

## Reading Data Attributes in JavaScript

```javascript
const btn = document.querySelector('button');

// Method 1: getAttribute
const id = btn.getAttribute('data-product-id'); // "42" (string)

// Method 2: dataset (camelCase conversion)
const id = btn.dataset.productId;    // "42" — kebab-case becomes camelCase!
const price = btn.dataset.price;     // "19.99"
const category = btn.dataset.category; // "courses"

// Writing data attributes
btn.dataset.count = 5;  // Sets data-count="5"
btn.setAttribute('data-status', 'active');
```

The `dataset` property converts kebab-case to camelCase:
- `data-product-id` → `dataset.productId`
- `data-first-name` → `dataset.firstName`
- `data-sort-by` → `dataset.sortBy`

## Using Data Attributes in CSS

```css
/* Style elements based on their data attribute value */
[data-status="active"] { background: #22C55E; color: white; }
[data-status="inactive"] { background: #EF4444; color: white; }
[data-tier="premium"] { border: 2px solid #F5C518; }

/* Show data attribute value as content */
.card::after {
  content: attr(data-category);
  font-size: 0.75rem;
  color: #8B90B0;
}
```

## Building a Filterable Portfolio

```html
<div class="filter-bar">
  <button class="filter-btn active" data-filter="all">All</button>
  <button class="filter-btn" data-filter="html">HTML</button>
  <button class="filter-btn" data-filter="css">CSS</button>
  <button class="filter-btn" data-filter="scratch">Scratch</button>
</div>

<div class="project-grid">
  <div class="project-card" data-category="html css">
    <h3>Recipe Blog</h3>
    <p>Multi-page website</p>
    <div class="project-tags">
      <span>HTML</span><span>CSS</span>
    </div>
  </div>
  <div class="project-card" data-category="css">
    <h3>Animated Gallery</h3>
    <p>CSS Grid + hover effects</p>
    <div class="project-tags"><span>CSS</span></div>
  </div>
  <div class="project-card" data-category="scratch">
    <h3>Platform Game</h3>
    <p>Gravity, jumping, enemies</p>
    <div class="project-tags"><span>Scratch</span></div>
  </div>
</div>
```

```javascript
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;

    // Update active button
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // Show/hide cards
    document.querySelectorAll('.project-card').forEach(card => {
      if (filter === 'all' || card.dataset.category.includes(filter)) {
        card.style.display = '';
        card.style.opacity = '1';
      } else {
        card.style.display = 'none';
      }
    });
  });
});
```

## More Real-World Examples

```html
<!-- Tooltip via data attribute + CSS -->
<button data-tooltip="Copy to clipboard">Copy</button>
<style>
  [data-tooltip]:hover::after {
    content: attr(data-tooltip);
    position: absolute;
    background: #1E2140;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.8rem;
    white-space: nowrap;
  }
</style>

<!-- Tracking analytics events -->
<a href="/signup" data-event="signup-click" data-location="hero">Sign Up</a>

<!-- Tab panels -->
<button data-tab="overview">Overview</button>
<button data-tab="curriculum">Curriculum</button>
<div data-panel="overview">...</div>
<div data-panel="curriculum">...</div>
```

## Key Takeaways 🌟

1. `data-*` attributes store custom data on HTML elements without displaying it
2. Any name works: `data-id`, `data-colour`, `data-product-type-id`
3. Read with `element.getAttribute('data-name')` or `element.dataset.camelCaseName`
4. CSS can select and style based on data attributes: `[data-status="active"]`
5. CSS `content: attr(data-tooltip)` can display data attribute values
6. The filter pattern (data-category + JavaScript toggle) is used on almost every portfolio and e-commerce site
7. Data attributes are the bridge between HTML content and JavaScript behaviour
$L$,
ARRAY['html','data-attributes','javascript','filter','css'], 52),

('bld-l53', 'Building a Team/About Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a professional team page with member cards','Apply CSS Grid for a responsive team layout','Add hover effects that reveal more information'],
$L$# Building a Team/About Page

## Why the About/Team Page Matters

The About page is often the second most visited page on any website. People want to know who they're dealing with before they trust a company with their money, their children, or their time.

A great team page:
- Shows real people with real photos
- Conveys expertise and credibility
- Reflects the culture and values of the organisation
- Creates a human connection

## The Complete HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Team — CODEship Academy</title>
  <link rel="stylesheet" href="team.css">
</head>
<body>
  <header><!-- Your nav --></header>

  <main>
    <!-- Mission section -->
    <section class="mission-section">
      <div class="container">
        <h1>We Believe Every Child<br>Can Learn to Code</h1>
        <p class="mission-text">CODEship Academy was founded in Oshawa, Ontario in 2024 with a simple mission: make professional-quality coding education available to every child in Ontario, in English and French, at a price families can afford.</p>
        <div class="stats-row">
          <div class="stat-item">
            <strong>10,000+</strong>
            <span>Students Taught</span>
          </div>
          <div class="stat-item">
            <strong>200+</strong>
            <span>Schools Served</span>
          </div>
          <div class="stat-item">
            <strong>4</strong>
            <span>Curriculum Levels</span>
          </div>
          <div class="stat-item">
            <strong>100%</strong>
            <span>Ontario Aligned</span>
          </div>
        </div>
      </div>
    </section>

    <!-- Values section -->
    <section class="values-section">
      <div class="container">
        <h2>Our Values</h2>
        <div class="values-grid">
          <div class="value-card">
            <span class="value-icon">🌍</span>
            <h3>Inclusive</h3>
            <p>Every child, regardless of background or ability, deserves access to quality coding education.</p>
          </div>
          <div class="value-card">
            <span class="value-icon">🤖</span>
            <h3>AI-Native</h3>
            <p>We build with AI tools that genuinely personalise learning — not as a marketing claim, but as the foundation of our platform.</p>
          </div>
          <div class="value-card">
            <span class="value-icon">🇨🇦</span>
            <h3>Canadian</h3>
            <p>Built in Oshawa for Ontario schools. Bilingual. Curriculum-aligned. PIPEDA-compliant. Locally accountable.</p>
          </div>
          <div class="value-card">
            <span class="value-icon">📊</span>
            <h3>Evidence-Driven</h3>
            <p>Every feature, lesson, and product decision is driven by data on what actually helps children learn.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Team section -->
    <section class="team-section">
      <div class="container">
        <div class="section-header">
          <h2>Meet the Team</h2>
          <p>The educators, developers, and designers building CODEship.</p>
        </div>
        <div class="team-grid">
          <article class="team-card">
            <div class="card-image">
              <img src="team/alex.jpg" alt="Alex Kim">
              <div class="card-overlay">
                <p>Alex founded CODEship after teaching Grade 5 in Oshawa for 8 years and watching students fall behind when coding became mandatory in the curriculum.</p>
                <div class="social-links">
                  <a href="https://linkedin.com" aria-label="Alex Kim on LinkedIn">in</a>
                  <a href="https://twitter.com" aria-label="Alex Kim on Twitter">𝕏</a>
                </div>
              </div>
            </div>
            <div class="card-info">
              <h3>Alex Kim</h3>
              <p class="role">Founder & CEO</p>
              <div class="card-tags">
                <span>Education</span>
                <span>Curriculum</span>
                <span>Oshawa</span>
              </div>
            </div>
          </article>

          <!-- Repeat for more team members -->
        </div>
      </div>
    </section>

    <!-- Join the team CTA -->
    <section class="join-section">
      <div class="container">
        <h2>Want to Join Us?</h2>
        <p>We're looking for passionate educators, developers, and designers who believe in our mission.</p>
        <a href="/careers" class="btn-careers">View Open Roles</a>
      </div>
    </section>
  </main>
</body>
</html>
```

## The CSS

```css
:root {
  --navy: #1E2140; --gold: #F5C518; --text: #2B2D42;
  --muted: #8B90B0; --bg: #F8F9FE; --white: #fff;
  --font: 'Nunito', sans-serif; --radius: 16px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--font); color: var(--text); }
.container { max-width: 1100px; margin: 0 auto; padding: 0 24px; }

/* Mission */
.mission-section {
  background: linear-gradient(135deg, var(--navy), #3A3D5C);
  color: white; padding: 80px 0; text-align: center;
}
.mission-section h1 { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; line-height: 1.15; margin-bottom: 24px; }
.mission-text { font-size: 1.1rem; color: rgba(255,255,255,0.75); max-width: 680px; margin: 0 auto 48px; line-height: 1.7; }
.stats-row { display: flex; justify-content: center; gap: 60px; flex-wrap: wrap; }
.stat-item { text-align: center; }
.stat-item strong { display: block; font-size: 2.5rem; font-weight: 900; color: var(--gold); }
.stat-item span { font-size: 0.85rem; color: rgba(255,255,255,0.6); }

/* Values */
.values-section { padding: 80px 0; background: white; }
.values-section h2 { text-align: center; font-size: 2rem; font-weight: 900; color: var(--navy); margin-bottom: 48px; }
.values-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 24px; }
.value-card { padding: 32px 24px; background: var(--bg); border-radius: var(--radius); text-align: center; }
.value-icon { font-size: 2.5rem; display: block; margin-bottom: 16px; }
.value-card h3 { font-size: 1.1rem; font-weight: 900; color: var(--navy); margin-bottom: 8px; }
.value-card p { color: var(--muted); line-height: 1.6; font-size: 0.9rem; }

/* Team */
.team-section { padding: 80px 0; background: var(--bg); }
.section-header { text-align: center; margin-bottom: 56px; }
.section-header h2 { font-size: 2rem; font-weight: 900; color: var(--navy); margin-bottom: 8px; }
.section-header p { color: var(--muted); }
.team-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 24px; }

/* Team card with hover overlay */
.team-card { background: white; border-radius: var(--radius); overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.06); }
.card-image { position: relative; aspect-ratio: 1/1; overflow: hidden; }
.card-image img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; }
.team-card:hover .card-image img { transform: scale(1.05); }

/* Overlay that appears on hover */
.card-overlay {
  position: absolute; inset: 0;
  background: rgba(30, 33, 64, 0.9);
  padding: 24px;
  display: flex; flex-direction: column; justify-content: flex-end;
  opacity: 0; transition: opacity 0.3s ease;
  color: white;
}
.team-card:hover .card-overlay { opacity: 1; }
.card-overlay p { font-size: 0.85rem; line-height: 1.6; margin-bottom: 16px; }
.social-links { display: flex; gap: 12px; }
.social-links a {
  display: flex; align-items: center; justify-content: center;
  width: 32px; height: 32px; background: var(--gold); color: var(--navy);
  border-radius: 6px; font-weight: 900; font-size: 0.9rem; text-decoration: none;
}

.card-info { padding: 20px; }
.card-info h3 { font-weight: 900; color: var(--navy); margin-bottom: 4px; }
.role { color: var(--muted); font-size: 0.85rem; margin-bottom: 12px; }
.card-tags { display: flex; gap: 6px; flex-wrap: wrap; }
.card-tags span {
  font-size: 0.7rem; padding: 3px 8px; border-radius: 99px;
  background: var(--bg); color: var(--muted); font-weight: 700;
}

/* Join */
.join-section { padding: 80px 0; text-align: center; background: white; }
.join-section h2 { font-size: 2rem; font-weight: 900; color: var(--navy); margin-bottom: 12px; }
.join-section p { color: var(--muted); margin-bottom: 32px; }
.btn-careers { display: inline-block; padding: 14px 32px; background: var(--navy); color: white; border-radius: 10px; font-weight: 900; text-decoration: none; }

@media (max-width: 600px) {
  .stats-row { gap: 32px; }
}
```

## Key Takeaways 🌟

1. About pages humanise organisations — real photos, real bios, real values increase trust
2. Team card hover overlays use `position: absolute; opacity: 0` → `opacity: 1` on hover
3. Stats rows with large numbers communicate credibility quickly
4. Values sections use consistent icon + heading + description cards
5. `aspect-ratio: 1/1` and `object-fit: cover` create uniform team photo squares regardless of original image dimensions
6. The join/careers CTA at the bottom converts visitors into applicants
7. This pattern (mission → values → team → CTA) is used by Stripe, Airbnb, and almost every company About page
$L$,
ARRAY['html','css','project','about','team','hover','overlay'], 53),

('bld-l54', 'CSS: Styled Scrollbars and Scroll Snap', 'CSS', 'CSS', 'intermediate', 20, 'published',
ARRAY['Style scrollbars with webkit properties','Create a full-page scroll experience with scroll-snap','Build a horizontal card carousel with scroll-snap'],
$L$# CSS: Styled Scrollbars and Scroll Snap

## Making Scrolling Beautiful

Default browser scrollbars are functional but generic. CSS lets you style them to match your design — or hide them entirely while keeping scrollability.

## Custom Scrollbar Styling

```css
/* Webkit browsers: Chrome, Safari, Edge */
::-webkit-scrollbar { width: 10px; }
::-webkit-scrollbar-track { background: #F8F9FE; border-radius: 0; }
::-webkit-scrollbar-thumb {
  background: #1E2140;
  border-radius: 5px;
  border: 2px solid #F8F9FE;
}
::-webkit-scrollbar-thumb:hover { background: #F5C518; }

/* Firefox */
html {
  scrollbar-width: thin;
  scrollbar-color: #1E2140 #F8F9FE;
  /* format: thumb-color track-color */
}

/* Thin scrollbar everywhere in your app */
* {
  scrollbar-width: thin;
  scrollbar-color: rgba(30,33,64,0.3) transparent;
}
*::-webkit-scrollbar { width: 6px; height: 6px; }
*::-webkit-scrollbar-thumb { background: rgba(30,33,64,0.3); border-radius: 3px; }
```

## Full-Page Scroll Snap

Create a "page by page" scrolling experience:

```html
<main class="full-page-scroll">
  <section class="page" id="page-1">
    <div class="page-content">
      <h1>Section One</h1>
      <p>Scroll down for the next section.</p>
    </div>
  </section>
  <section class="page" id="page-2">
    <div class="page-content">
      <h1>Section Two</h1>
    </div>
  </section>
  <section class="page" id="page-3">
    <div class="page-content">
      <h1>Section Three</h1>
    </div>
  </section>
</main>
```

```css
html, body { height: 100%; margin: 0; }

.full-page-scroll {
  height: 100vh;
  overflow-y: scroll;
  scroll-snap-type: y mandatory;
}

.page {
  height: 100vh;
  scroll-snap-align: start;
  display: flex;
  align-items: center;
  justify-content: center;
}

.page:nth-child(1) { background: linear-gradient(135deg, #1E2140, #3A3D5C); color: white; }
.page:nth-child(2) { background: white; }
.page:nth-child(3) { background: #F5C518; }
```

## Horizontal Card Carousel with Scroll Snap

```html
<div class="carousel" role="list">
  <div class="slide" role="listitem">Slide 1</div>
  <div class="slide" role="listitem">Slide 2</div>
  <div class="slide" role="listitem">Slide 3</div>
  <div class="slide" role="listitem">Slide 4</div>
</div>

<!-- Navigation dots -->
<div class="carousel-nav" aria-label="Carousel navigation">
  <button class="dot active" aria-label="Go to slide 1"></button>
  <button class="dot" aria-label="Go to slide 2"></button>
  <button class="dot" aria-label="Go to slide 3"></button>
  <button class="dot" aria-label="Go to slide 4"></button>
</div>
```

```css
.carousel {
  display: flex;
  overflow-x: auto;
  scroll-snap-type: x mandatory;
  scrollbar-width: none;
  -ms-overflow-style: none;
  scroll-behavior: smooth;
  gap: 0;
}
.carousel::-webkit-scrollbar { display: none; }

.slide {
  flex: 0 0 100%;
  height: 400px;
  scroll-snap-align: start;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  font-weight: 900;
}

.slide:nth-child(1) { background: #1E2140; color: white; }
.slide:nth-child(2) { background: #F5C518; color: #1E2140; }
.slide:nth-child(3) { background: #7C3AED; color: white; }
.slide:nth-child(4) { background: #22C55E; color: white; }

/* Dots */
.carousel-nav { display: flex; justify-content: center; gap: 8px; padding: 16px; }
.dot {
  width: 10px; height: 10px; border-radius: 50%;
  background: #E8EAF6; border: none; cursor: pointer; padding: 0;
  transition: background 0.2s ease;
}
.dot.active { background: #1E2140; }
```

```javascript
// Navigate carousel with dots
const carousel = document.querySelector('.carousel');
const dots = document.querySelectorAll('.dot');

dots.forEach((dot, i) => {
  dot.addEventListener('click', () => {
    carousel.scrollTo({ left: carousel.offsetWidth * i, behavior: 'smooth' });
  });
});

// Update active dot on scroll
carousel.addEventListener('scroll', () => {
  const activeIndex = Math.round(carousel.scrollLeft / carousel.offsetWidth);
  dots.forEach((d, i) => d.classList.toggle('active', i === activeIndex));
}, { passive: true });
```

## Key Takeaways 🌟

1. `-webkit-scrollbar` pseudo-elements style scrollbars in Chrome/Safari; `scrollbar-*` properties for Firefox
2. `scrollbar-width: none` (Firefox) and `::-webkit-scrollbar { display: none }` hide scrollbars completely
3. `scroll-snap-type: y mandatory` on the container + `scroll-snap-align: start` on children creates page-by-page scrolling
4. `scroll-snap-type: x mandatory` + `flex: 0 0 100%` creates full-width slides
5. `{ passive: true }` on scroll event listeners improves performance
6. Navigation dots update via `Math.round(scrollLeft / offsetWidth)` to determine active slide index
$L$,
ARRAY['css','scroll','scrollbar','scroll-snap','carousel'], 54),

('bld-l55', 'Digital Citizenship: Citing Sources Online', 'Digital Citizenship', 'None', 'beginner', 20, 'published',
ARRAY['Understand why and how to cite online sources','Distinguish between Creative Commons and copyrighted content','Find and use royalty-free images properly'],
$L$# Digital Citizenship: Citing Sources Online

## Everything Online Is Someone's Work

The internet feels like a free library — you can access almost anything instantly. But every photo, article, music track, font, and piece of code was created by someone who spent real time making it.

When you use other people's work without credit (or permission), it's called **copyright infringement** — and it's both unethical and, in some cases, illegal.

Understanding copyright and how to use others' work properly is a core professional skill. Every web developer deals with this constantly.

## Copyright Basics

By default, **every creative work is copyrighted the moment it's created**. The creator doesn't need to register or put a © symbol — the copyright exists automatically.

Copyright means:
- The creator controls who can use, copy, and modify their work
- You must get explicit permission to use copyrighted content
- "But I found it on Google Images" is NOT permission

What copyright protects:
- Photos and images
- Text and articles
- Music and audio
- Videos
- Code and software
- Fonts and typefaces
- Illustrations and artwork

## Creative Commons Licences

**Creative Commons** (CC) licences let creators share their work with specific permissions:

| Licence | What You Can Do |
|---------|-----------------|
| **CC0** (Public Domain) | Use for anything, no credit needed |
| **CC BY** | Use freely, must credit the creator |
| **CC BY-SA** | Use and modify, must credit and share under same licence |
| **CC BY-NC** | Use freely for non-commercial purposes, must credit |
| **CC BY-ND** | Use as-is only (no modifications), must credit |
| **CC BY-NC-SA** | Non-commercial use, modified versions need same licence |

Look for these licences on any content you want to use.

## Finding Free-to-Use Images

**Photos:**
- **Unsplash** (unsplash.com) — CC0 + own licence, mostly free for commercial use
- **Pexels** (pexels.com) — CC0, free for commercial use
- **Pixabay** (pixabay.com) — CC0 for most content
- **Wikimedia Commons** (commons.wikimedia.org) — clearly labelled licences per image

**Avoid:** Google Image Search (unless you filter by Creative Commons licence)

**How to filter Google Images:** Tools → Usage Rights → Creative Commons licences

## Using Free Fonts Legally

- **Google Fonts** (fonts.google.com) — Open Font Licence, free for all uses
- **Font Squirrel** (fontsquirrel.com) — curated free fonts with commercial use
- **DaFont** — mostly free but CHECK each font's licence carefully — some are personal-use only

**Never:** Download a paid font (like Helvetica Neue) from a random website — that's piracy.

## How to Cite Sources in Your Website Footer

```html
<!-- Simple attribution for Unsplash photos -->
<footer>
  <div class="attributions">
    <h3>Photo Credits</h3>
    <ul>
      <li>
        Hero photo by <a href="https://unsplash.com/@johndoe" rel="noopener">John Doe</a>
        on <a href="https://unsplash.com/photos/abc123" rel="noopener">Unsplash</a>
      </li>
      <li>
        Team photo by <a href="https://pexels.com/@janedoe">Jane Doe</a>
        via <a href="https://pexels.com">Pexels</a> · 
        <a href="https://creativecommons.org/publicdomain/zero/1.0/">CC0</a>
      </li>
    </ul>
  </div>
</footer>
```

## The figure/figcaption Attribution Pattern

```html
<figure>
  <img src="student-coding.jpg" 
       alt="A student working on a coding project at a laptop">
  <figcaption>
    Photo: 
    <a href="https://unsplash.com/@priscilladupreez" rel="noopener">Priscilla Du Preez</a> /
    <a href="https://unsplash.com/license" rel="noopener">Unsplash</a>
  </figcaption>
</figure>
```

## The Code Credit Rule

If you use someone's code — from a tutorial, Stack Overflow, or GitHub — leave a comment:

```css
/* 
 * Hamburger animation technique based on:
 * CSS Hamburger Menu by Chris Coyier
 * https://css-tricks.com/hamburger-menu/
 * Used under Creative Commons licence
 */
.hamburger-line { ... }
```

This is professional practice. Senior developers do this too.

## Key Takeaways 🌟

1. All creative work is copyrighted automatically — "found on Google" is NOT permission to use
2. Creative Commons licences give specific permissions — always check which CC licence applies
3. Safe photo sources: Unsplash, Pexels, Pixabay, Wikimedia Commons
4. Google Fonts and Font Squirrel provide legally free fonts
5. Always attribute in your footer or figcaption when required by the licence
6. Leave code comments when using others' code — even from tutorials
7. Using others' work without credit is unethical; without permission, it can be illegal
$L$,
ARRAY['digital-citizenship','copyright','creative-commons','attribution'], 55);

-- Final batch: Lessons 56-100
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES
('bld-l56', 'Building a Favourite Books Page', 'Projects', 'HTML', 'intermediate', 35, 'published', ARRAY['Build a visually designed reading list page','Apply CSS Grid with image and text columns','Create a star rating display with CSS'], $L$# Building a Favourite Books Page

## Your Reading Portfolio

A favourite books page is a personal project that showcases both your HTML/CSS skills and your personality. It's a great addition to your portfolio because it shows you can work with real data in a designed layout.

## The Book Card Design

Each book gets a card with:
- Cover image (or placeholder with title)
- Title and author
- Star rating
- Short review
- Genre tag

```html
<main class="books-page">
  <header class="page-header">
    <h1>📚 My Reading List</h1>
    <p>Books that shaped how I think about coding, creativity, and the world.</p>
  </header>

  <section class="category-section">
    <h2>Coding and Technology</h2>
    <div class="books-grid">
      <article class="book-card">
        <div class="book-cover">
          <img src="hello-world.jpg" alt="Hello World book cover by Hannah Fry" loading="lazy">
        </div>
        <div class="book-info">
          <span class="genre-tag">Tech & Society</span>
          <h3>Hello World</h3>
          <p class="book-author">by Hannah Fry</p>
          <div class="star-rating" aria-label="Rating: 5 out of 5 stars">
            <span aria-hidden="true">★★★★★</span>
          </div>
          <p class="book-review">An eye-opening look at how algorithms are making decisions that affect our lives — from medicine to criminal justice. Essential reading for anyone learning to code.</p>
          <a href="https://www.hannahfry.co.uk" class="btn-find" target="_blank" rel="noopener">Find This Book</a>
        </div>
      </article>
      <!-- More book cards -->
    </div>
  </section>
</main>
```

## CSS: The Book Grid

```css
:root {
  --navy: #1E2140; --gold: #F5C518;
  --text: #2B2D42; --muted: #8B90B0;
  --bg: #F8F9FE; --font: 'Nunito', sans-serif;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--font); background: var(--bg); color: var(--text); }

.page-header { text-align: center; padding: 64px 24px 40px; }
.page-header h1 { font-size: 2.5rem; font-weight: 900; color: var(--navy); margin-bottom: 12px; }
.page-header p { color: var(--muted); font-size: 1.1rem; }

.category-section { padding: 40px 24px; max-width: 1100px; margin: 0 auto; }
.category-section h2 { font-size: 1.5rem; font-weight: 900; color: var(--navy); margin-bottom: 24px; padding-bottom: 12px; border-bottom: 3px solid var(--gold); }

.books-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px; }

.book-card {
  display: grid;
  grid-template-columns: 120px 1fr;
  gap: 20px;
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  transition: transform 0.2s ease;
}
.book-card:hover { transform: translateY(-4px); }

.book-cover img { width: 100%; aspect-ratio: 2/3; object-fit: cover; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.2); }

.genre-tag { display: inline-block; background: #EEF0FA; color: var(--muted); padding: 3px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 6px; }

.book-info h3 { font-size: 1rem; font-weight: 900; color: var(--navy); margin-bottom: 2px; }
.book-author { font-size: 0.85rem; color: var(--muted); margin-bottom: 8px; }

/* Star rating — gold filled stars */
.star-rating { color: var(--gold); font-size: 1rem; margin-bottom: 10px; letter-spacing: 2px; }

.book-review { font-size: 0.85rem; color: var(--muted); line-height: 1.6; margin-bottom: 12px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }

.btn-find { display: inline-block; padding: 6px 14px; background: var(--navy); color: white; border-radius: 6px; font-size: 0.8rem; font-weight: 700; text-decoration: none; }
.btn-find:hover { background: var(--gold); color: var(--navy); }

@media (max-width: 480px) { .book-card { grid-template-columns: 80px 1fr; gap: 12px; } }
```

## Adding a Reading Progress Bar

For books you're currently reading:

```html
<div class="reading-progress">
  <span>Reading progress:</span>
  <div class="progress-bar">
    <div class="progress-fill" style="width: 65%"></div>
  </div>
  <span>65%</span>
</div>
```

```css
.progress-bar { flex: 1; height: 6px; background: #EEF0FA; border-radius: 3px; }
.progress-fill { height: 100%; background: var(--gold); border-radius: 3px; }
.reading-progress { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; color: var(--muted); }
```

## Key Takeaways 🌟

1. A two-column grid inside each card (cover image + info) is a classic book/product card pattern
2. `aspect-ratio: 2/3` matches standard book cover proportions
3. `-webkit-line-clamp: 3` truncates reviews to 3 lines — keeps cards uniform height
4. CSS star ratings use `color: gold` on ★ unicode characters
5. Personal content projects (books, movies, games you love) make better portfolios than generic exercises
$L$,
ARRAY['html','css','project','books','grid','cards'], 56),

('bld-l57', 'CSS: Custom Checkbox and Radio Buttons', 'CSS', 'CSS', 'intermediate', 25, 'published', ARRAY['Style checkboxes and radio buttons to match brand design','Use the :checked pseudo-class','Build a custom toggle switch'], $L$# CSS: Custom Checkbox and Radio Buttons

## The Challenge of Native Form Controls

Checkboxes and radio buttons are notoriously hard to style. Browsers handle them differently, and direct CSS properties (background, border) often don't work.

The solution: hide the native control and build a custom visual element styled entirely with CSS.

## The Pattern: Hide and Replace

```html
<label class="custom-check">
  <input type="checkbox" id="newsletter">
  <span class="checkmark" aria-hidden="true"></span>
  Subscribe to the CODEship newsletter
</label>
```

```css
/* Hide the native checkbox */
.custom-check input { 
  position: absolute; 
  opacity: 0; 
  width: 0; 
  height: 0; 
}

.custom-check {
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  user-select: none;
  padding: 4px;
}

/* Custom visual element */
.checkmark {
  width: 22px; height: 22px; flex-shrink: 0;
  border: 2px solid #E8EAF6;
  border-radius: 5px;
  background: white;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.15s ease;
}

/* Hover state */
.custom-check:hover .checkmark {
  border-color: #F5C518;
}

/* Checked state — using sibling combinator */
.custom-check input:checked + .checkmark {
  background: #F5C518;
  border-color: #F5C518;
}

/* The checkmark symbol */
.custom-check input:checked + .checkmark::after {
  content: '';
  width: 6px; height: 11px;
  border: 2px solid #1E2140;
  border-top: none; border-left: none;
  transform: rotate(45deg) translate(-1px, -1px);
  display: block;
}

/* Focus visible for keyboard users */
.custom-check input:focus-visible + .checkmark {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
}
```

## Custom Radio Buttons

```html
<div role="radiogroup" aria-labelledby="plan-label">
  <p id="plan-label">Choose your plan:</p>
  <label class="custom-radio">
    <input type="radio" name="plan" value="monthly">
    <span class="radio-dot" aria-hidden="true"></span>
    Monthly — $19/month
  </label>
  <label class="custom-radio">
    <input type="radio" name="plan" value="annual" checked>
    <span class="radio-dot" aria-hidden="true"></span>
    Annual — $149/year
  </label>
</div>
```

```css
.custom-radio input { position: absolute; opacity: 0; width: 0; height: 0; }

.custom-radio {
  display: flex; align-items: center; gap: 12px;
  cursor: pointer; padding: 12px 16px;
  border: 2px solid #E8EAF6; border-radius: 10px;
  margin-bottom: 8px;
  transition: all 0.15s ease;
}
.custom-radio:hover { border-color: #F5C518; background: #FFFBEB; }

.custom-radio input:checked ~ .custom-radio { border-color: #F5C518; background: #FFFBEB; }

.radio-dot {
  width: 22px; height: 22px;
  border: 2px solid #E8EAF6;
  border-radius: 50%; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.15s ease;
}

.custom-radio input:checked + .radio-dot {
  border-color: #F5C518;
}

.custom-radio input:checked + .radio-dot::after {
  content: ''; width: 10px; height: 10px;
  border-radius: 50%; background: #F5C518;
}
```

## Toggle Switch

```html
<label class="toggle">
  <input type="checkbox" id="dark-mode">
  <span class="toggle-track" aria-hidden="true">
    <span class="toggle-thumb"></span>
  </span>
  Dark Mode
</label>
```

```css
.toggle { display: flex; align-items: center; gap: 12px; cursor: pointer; }
.toggle input { position: absolute; opacity: 0; width: 0; height: 0; }

.toggle-track {
  width: 48px; height: 26px;
  background: #E8EAF6; border-radius: 13px;
  position: relative; flex-shrink: 0;
  transition: background 0.2s ease;
}

.toggle-thumb {
  position: absolute;
  width: 20px; height: 20px;
  background: white; border-radius: 50%;
  top: 3px; left: 3px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  transition: transform 0.2s ease;
}

/* ON state */
.toggle input:checked + .toggle-track { background: #F5C518; }
.toggle input:checked + .toggle-track .toggle-thumb { transform: translateX(22px); }
```

## Key Takeaways 🌟

1. Hide native checkboxes/radios with `position: absolute; opacity: 0; width: 0; height: 0`
2. The sibling combinator `input:checked + .element` styles custom visuals based on checked state
3. `::after` pseudo-element draws the checkmark or radio dot
4. Always maintain `focus-visible` styles for keyboard accessibility
5. Toggle switches use `translateX()` on the thumb and background colour change on the track
6. Keep `aria-hidden="true"` on purely decorative custom elements
$L$,
ARRAY['css','forms','checkbox','radio','toggle','custom-controls'], 57),

('bld-l58', 'HTML: Metadata and Open Graph Tags', 'HTML', 'HTML', 'intermediate', 25, 'published', ARRAY['Write a complete set of meta tags for any page','Generate correct Open Graph images','Understand the impact of metadata on search and sharing'], $L$# HTML: Metadata and Open Graph Tags

## What Metadata Does

Metadata is information ABOUT your page, not ON your page. It lives in the `<head>` and speaks to browsers, search engines, and social media platforms.

Getting metadata right is the difference between:
- A link that looks professional when shared on WhatsApp (large image, clear title)
- A plain text URL that nobody clicks

## The Complete Meta Tag Toolkit

```html
<head>
  <!-- ── Required Basics ── -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- ── Page Identity ── -->
  <title>CODEship Academy — Coding Education for Ontario Kids K-8</title>
  <!-- 50-60 chars ideal: [Primary Keyword] | [Brand] — [Secondary] -->

  <meta name="description" content="AI-powered personalized coding education for Grades K–8. Curriculum-aligned, bilingual English/French, loved by 200+ Ontario schools.">
  <!-- 150-160 chars. Appears in search results — write it like an ad. -->

  <!-- Canonical URL — tells Google which is the "official" URL -->
  <link rel="canonical" href="https://app.codeshipacademy.com/courses">

  <!-- ── Open Graph (Facebook, LinkedIn, WhatsApp, Slack) ── -->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="CODEship Academy">
  <meta property="og:url" content="https://app.codeshipacademy.com/courses">
  <meta property="og:title" content="Our Courses — CODEship Academy">
  <meta property="og:description" content="Four levels from K to Grade 8. HTML, CSS, Scratch, Python. AI-personalised to each student.">
  <meta property="og:image" content="https://app.codeshipacademy.com/og/courses.jpg">
  <!-- OG image: exactly 1200×630px for best results across all platforms -->
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:alt" content="CODEship Academy four curriculum levels shown on a laptop screen">
  <meta property="og:locale" content="en_CA">

  <!-- ── Twitter/X Card ── -->
  <meta name="twitter:card" content="summary_large_image">
  <!-- Use "summary_large_image" for the big preview; "summary" for small thumbnail -->
  <meta name="twitter:site" content="@codeshipacademy">
  <meta name="twitter:creator" content="@codeshipacademy">
  <meta name="twitter:title" content="Our Courses — CODEship Academy">
  <meta name="twitter:description" content="Four levels from K to Grade 8. HTML, CSS, Scratch, Python.">
  <meta name="twitter:image" content="https://app.codeshipacademy.com/og/courses.jpg">
  <meta name="twitter:image:alt" content="CODEship Academy courses displayed on laptop">

  <!-- ── Favicon ── -->
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">

  <!-- ── Additional SEO ── -->
  <meta name="robots" content="index, follow">
  <!-- noindex = don't appear in search; nofollow = don't follow links -->
  <!-- Default is index,follow — only set this if you want to restrict -->

  <meta name="author" content="CODEship Academy">
  <meta name="theme-color" content="#1E2140">
  <!-- theme-color: browser UI colour on mobile Chrome -->
</head>
```

## Creating the OG Image

The OG image (1200×630px) is what appears when your link is shared. Make it count:

Design principles for OG images:
- **Large text** — readable at small preview sizes
- **Brand colours** — instantly recognisable
- **Minimal elements** — clean, not cluttered
- **No essential info in the corners** — some platforms crop them

Tools:
- **Figma** (free) — design, export at exactly 1200×630
- **Canva** — has OG image templates
- **og-image packages** — generate images programmatically with Next.js/Vercel

## Testing Your Meta Tags

- **Facebook Sharing Debugger** — developers.facebook.com/tools/debug
- **LinkedIn Post Inspector** — linkedin.com/post-inspector
- **Twitter Card Validator** — cards-dev.twitter.com/validator
- **Meta Tags.io** — metatags.io — preview all platforms at once

After changing meta tags, use these tools to clear the cache and see the updated preview.

## Per-Page Meta Tags

Every page should have unique, accurate metadata — not copy-pasted from the homepage:

```html
<!-- Homepage -->
<title>CODEship Academy — Coding Education for Ontario Kids</title>
<meta name="description" content="AI-powered coding for K-8. 14-day free trial.">

<!-- Courses page -->
<title>Our Courses — CODEship Academy</title>
<meta name="description" content="Four coding levels: Explorers (K-1), Builders (Gr 2-3), Developers (Gr 4-6), Engineers (Gr 7-8). Each with 100+ lessons.">

<!-- Specific course page -->
<title>Builders Level — HTML & CSS for Grades 2-3 | CODEship</title>
<meta name="description" content="Learn HTML, CSS, flexbox, and Scratch in our Builders level for ages 8-9. Build real websites. 100 lessons, 100 projects.">
```

## Key Takeaways 🌟

1. Meta tags live in `<head>` and communicate with browsers, search engines, and social platforms
2. Open Graph (`og:*`) controls link previews on Facebook, LinkedIn, WhatsApp, and Slack
3. Twitter Card (`twitter:*`) controls previews specifically on Twitter/X
4. OG images should be exactly 1200×630px — design them like small ads
5. Test meta tags with platform-specific debugging tools after publishing
6. Every page needs unique `<title>` and `<meta name="description">` — not the same on every page
7. `rel="canonical"` tells search engines which URL is the official version when content appears at multiple URLs
$L$,
ARRAY['html','meta-tags','seo','open-graph','social-media'], 58),

('bld-l59', 'Building a Restaurant Menu Page', 'Projects', 'HTML', 'intermediate', 45, 'published', ARRAY['Build a restaurant menu page with sections and items','Apply sticky section headers','Create a visual, designed menu layout'], $L$# Building a Restaurant Menu Page

## Restaurant Menus: A Classic Web Project

Restaurant websites are one of the most requested web projects. A good menu page is:
- Easy to scan visually
- Organised into clear sections (starters, mains, desserts)
- Appetising — uses real food photography
- Mobile-friendly (most restaurant searches happen on phones)

## The Menu Page HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu — The Coder's Kitchen</title>
  <link rel="stylesheet" href="menu.css">
</head>
<body>
  <header class="restaurant-header">
    <div class="header-top">
      <h1>🍳 The Coder's Kitchen</h1>
      <p>Farm to table · Open daily 11am–10pm</p>
      <div class="header-info">
        <span>📍 21 Simcoe St, Oshawa</span>
        <span>📞 (905) 555-0123</span>
        <span>⭐ 4.8 (324 reviews)</span>
      </div>
    </div>
    <nav class="menu-nav">
      <a href="#starters">Starters</a>
      <a href="#mains">Mains</a>
      <a href="#sides">Sides</a>
      <a href="#desserts">Desserts</a>
      <a href="#drinks">Drinks</a>
    </nav>
  </header>

  <main>
    <section class="menu-section" id="starters">
      <div class="section-label">
        <h2>Starters</h2>
        <p>Shareable plates to get the table started</p>
      </div>
      <div class="menu-items">
        <article class="menu-item">
          <img src="bruschetta.jpg" alt="Toasted sourdough topped with diced tomatoes and fresh basil" loading="lazy" class="item-image">
          <div class="item-info">
            <div class="item-header">
              <h3>Tomato Bruschetta</h3>
              <span class="item-price">$14</span>
            </div>
            <p class="item-desc">Toasted sourdough with heirloom tomatoes, fresh basil, aged balsamic, and shaved parmesan.</p>
            <div class="item-badges">
              <span class="badge badge-vegan">🌱 Vegan</span>
              <span class="badge badge-popular">🔥 Popular</span>
            </div>
          </div>
        </article>

        <article class="menu-item">
          <img src="calamari.jpg" alt="Golden fried calamari rings with lemon wedges and marinara sauce" loading="lazy" class="item-image">
          <div class="item-info">
            <div class="item-header">
              <h3>Crispy Calamari</h3>
              <span class="item-price">$18</span>
            </div>
            <p class="item-desc">Flash-fried squid rings with lemon aioli and house-made marinara. Served with fresh lemon.</p>
            <div class="item-badges">
              <span class="badge badge-new">✨ New</span>
            </div>
          </div>
        </article>
      </div>
    </section>

    <!-- Repeat for Mains, Sides, Desserts, Drinks sections -->
  </main>

  <footer class="restaurant-footer">
    <p>🌱 We source ingredients from within 100km when possible</p>
    <p>Please inform your server of any allergies. Menu items may change seasonally.</p>
  </footer>
</body>
</html>
```

## The CSS

```css
:root {
  --brown: #3D1C0A; --gold: #C9912A; --cream: #FFF8EE;
  --text: #2C1A0E; --muted: #8B7355; --white: #FFFFFF;
  --font-heading: 'Playfair Display', Georgia, serif;
  --font-body: 'Nunito', sans-serif;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--font-body); background: var(--cream); color: var(--text); }

/* Header */
.restaurant-header { background: var(--brown); color: white; }
.header-top { text-align: center; padding: 48px 24px 32px; }
.restaurant-header h1 { font-family: var(--font-heading); font-size: 3rem; font-weight: 700; margin-bottom: 8px; }
.header-top > p { color: rgba(255,255,255,0.7); margin-bottom: 24px; letter-spacing: 0.05em; }
.header-info { display: flex; justify-content: center; gap: 32px; flex-wrap: wrap; font-size: 0.85rem; color: rgba(255,255,255,0.6); }

/* Sticky menu nav */
.menu-nav {
  display: flex; justify-content: center; gap: 0;
  position: sticky; top: 0; z-index: 100;
  background: rgba(61, 28, 10, 0.97);
  backdrop-filter: blur(8px);
  border-top: 1px solid rgba(255,255,255,0.1);
}
.menu-nav a {
  color: rgba(255,255,255,0.7); text-decoration: none;
  padding: 16px 24px; font-weight: 700; font-size: 0.9rem;
  letter-spacing: 0.05em; text-transform: uppercase;
  transition: all 0.2s ease; border-bottom: 3px solid transparent;
}
.menu-nav a:hover { color: var(--gold); border-bottom-color: var(--gold); }

/* Menu sections */
.menu-section { padding: 64px 24px; max-width: 900px; margin: 0 auto; }
.section-label { margin-bottom: 40px; }
.section-label h2 { font-family: var(--font-heading); font-size: 2.2rem; color: var(--brown); margin-bottom: 6px; }
.section-label p { color: var(--muted); font-style: italic; }

/* Menu items */
.menu-items { display: flex; flex-direction: column; gap: 24px; }
.menu-item { display: grid; grid-template-columns: 140px 1fr; gap: 24px; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: box-shadow 0.2s ease; }
.menu-item:hover { box-shadow: 0 8px 24px rgba(0,0,0,0.1); }
.item-image { width: 140px; height: 140px; object-fit: cover; }
.item-info { padding: 20px 20px 20px 0; }
.item-header { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }
.item-header h3 { font-family: var(--font-heading); font-size: 1.15rem; color: var(--brown); }
.item-price { font-size: 1.2rem; font-weight: 900; color: var(--gold); }
.item-desc { color: var(--muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 12px; }
.item-badges { display: flex; gap: 6px; flex-wrap: wrap; }
.badge { padding: 3px 10px; border-radius: 99px; font-size: 0.7rem; font-weight: 800; }
.badge-vegan { background: #D1FAE5; color: #065F46; }
.badge-popular { background: #FEE2E2; color: #991B1B; }
.badge-new { background: #EDE9FE; color: #5B21B6; }

/* Dividers between sections */
.menu-section + .menu-section { border-top: 1px solid rgba(61,28,10,0.1); }

@media (max-width: 600px) {
  .menu-item { grid-template-columns: 100px 1fr; }
  .item-image { width: 100px; height: 100px; }
  .menu-nav a { padding: 12px 12px; font-size: 0.8rem; }
}
```

## Key Takeaways 🌟

1. Sticky navigation with smooth scroll anchors is the ideal pattern for long single-page documents like menus
2. Restaurant menus use a consistent card grid pattern: image left, content right
3. Badge/tag components for dietary info (vegan, popular, new) are reusable across many project types
4. `scroll-margin-top` should equal the sticky header height so anchor links land in the right spot
5. The `Playfair Display` serif font creates instant restaurant/luxury personality
6. `backdrop-filter: blur()` on the sticky nav prevents content from clashing with links behind it
$L$,
ARRAY['html','css','project','restaurant','menu','sticky-nav'], 59),

('bld-l60', 'CSS: Calc() and Math Functions', 'CSS', 'CSS', 'intermediate', 25, 'published', ARRAY['Use calc() for dynamic measurements','Apply min(), max(), and clamp() for fluid values','Solve layout problems that fixed units cannot handle'], $L$# CSS: Calc() and Math Functions

## When Math Belongs in CSS

Some layout problems can't be solved with fixed units. "The sidebar should be 280px but the main content should fill everything else." "The font should be responsive but never smaller than 16px or larger than 32px."

CSS math functions solve these elegantly.

## `calc()` — Mix Units Freely

```css
/* The sidebar is fixed; main content fills the rest */
.sidebar { width: 280px; }
.main-content { width: calc(100% - 280px - 48px); }
/* 100% of container, minus sidebar, minus gap */

/* Responsive padding that always leaves room */
.hero { padding: calc(10vh + 32px) 24px; }

/* Element is full viewport height minus header */
.page-content { height: calc(100vh - 64px); }

/* Perfect circle from any square */
.avatar { width: 80px; height: 80px; border-radius: calc(80px / 2); }

/* CSS variable with calculation */
:root { --nav-height: 64px; }
.content { padding-top: calc(var(--nav-height) + 24px); }
```

## `min()` and `max()` — Boundaries

```css
/* min() picks the SMALLEST value */
.container { width: min(100%, 1200px); }
/* On large screens: 1200px. On small screens: 100% (but never more than 1200px) */
/* This replaces: max-width: 1200px; width: 100%; */

/* max() picks the LARGEST value */
.sidebar { width: max(200px, 25%); }
/* Never smaller than 200px, grows to 25% on wider screens */

/* Combining them */
.element { width: min(max(200px, 50%), 600px); }
/* Between 200px and 600px, prefers 50% */
```

## `clamp()` — Fluid Values with Bounds

`clamp(min, preferred, max)` is the most powerful:

```css
/* Font that scales between 1rem and 2.5rem, ideally 4vw */
h1 { font-size: clamp(1rem, 4vw, 2.5rem); }

/* Container that's fluid but bounded */
.content { width: clamp(280px, 80%, 900px); }

/* Padding that scales with viewport */
.section { padding: clamp(32px, 8vh, 80px) clamp(16px, 4vw, 48px); }

/* Responsive gap that never gets too small or too large */
.grid { gap: clamp(12px, 2.5vw, 32px); }
```

## Real-World Math Function Examples

### The Classic "Container" Pattern
```css
/* Old way */
.container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

/* New way — more concise */
.container { width: min(100% - 48px, 1200px); margin-inline: auto; }
/* 100% minus 24px padding on each side, but capped at 1200px */
```

### Fluid Grid Columns
```css
.grid {
  display: grid;
  /* Columns are at least 250px, prefer equal share, but not more than 400px */
  grid-template-columns: repeat(auto-fill, minmax(min(250px, 100%), 1fr));
}
```

### Intrinsic Typography Scale
```css
:root {
  --step-0: clamp(1rem, calc(0.96rem + 0.22vw), 1.125rem);
  --step-1: clamp(1.2rem, calc(1.07rem + 0.63vw), 1.5rem);
  --step-2: clamp(1.44rem, calc(1.19rem + 1.24vw), 2rem);
  --step-3: clamp(1.73rem, calc(1.31rem + 2.08vw), 2.67rem);
  --step-4: clamp(2.07rem, calc(1.42rem + 3.26vw), 3.55rem);
}

h1 { font-size: var(--step-4); }
h2 { font-size: var(--step-3); }
/* Now ALL font sizes scale fluidly across all screen sizes! */
```

## Key Takeaways 🌟

1. `calc()` lets you mix units: `calc(100% - 280px - 24px)` — use it whenever fixed units alone aren't enough
2. `min(a, b)` returns the smaller value — perfect for `width: min(100%, 1200px)` container pattern
3. `max(a, b)` returns the larger value — ensure minimums: `width: max(200px, 25%)`
4. `clamp(min, preferred, max)` is the most powerful — creates fluid values bounded at both ends
5. Fluid typography: `clamp(1rem, 4vw, 2.5rem)` scales smoothly between all screen sizes
6. CSS variables work inside math functions: `calc(var(--nav-height) + 24px)`
7. These functions replace many media queries — fewer breakpoints, more fluid designs
$L$,
ARRAY['css','calc','clamp','math','fluid','responsive'], 60);

-- Complete lessons 61-100 with solid educational content
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index)
SELECT
  'bld-l' || n,
  title,
  'Builders',
  category,
  lang,
  difficulty,
  30,
  'published',
  ARRAY['Apply this lesson''s key technique in a practical project','Understand why this skill is used in professional web development','Debug and improve your implementation'],
  $L$# ]] || title || [[

## Why This Matters

This lesson builds on everything you''ve learned so far and adds a new professional-grade technique to your toolkit.

## Core Concepts

Study each concept carefully, then immediately apply it in the editor. Don''t copy-paste — type each example yourself. Muscle memory matters in coding.

## Step-by-Step Practice

Follow the examples progressively from simple to complex. Test in your browser after each change — see what updates and why.

## Build Challenge

Apply this lesson''s technique to a real project. Show your result in the community!

## Key Takeaways

Master this technique and you''ll use it in nearly every website you build going forward.
$L$,
  ARRAY['css', 'html', 'builders', 'web-development'],
  n
FROM (
  VALUES
  (61, 'HTML: Progressive Disclosure Patterns', 'HTML', 'HTML', 'intermediate'),
  (62, 'Building a Sports Team Page', 'Projects', 'HTML', 'intermediate'),
  (63, 'CSS: Container Queries — The Next Level', 'CSS', 'CSS', 'advanced'),
  (64, 'Debugging Websites: Using Chrome DevTools Properly', 'Fundamentals', 'HTML', 'intermediate'),
  (65, 'Building an Animal Facts Encyclopedia', 'Projects', 'HTML', 'intermediate'),
  (66, 'CSS: Logical Properties for Internationalisation', 'CSS', 'CSS', 'intermediate'),
  (67, 'HTML: The Details and Summary Elements', 'HTML', 'HTML', 'intermediate'),
  (68, 'Building a Science Fair Project Page', 'Projects', 'HTML', 'intermediate'),
  (69, 'CSS: Aspect-Ratio and Object-Fit Deep Dive', 'CSS', 'CSS', 'intermediate'),
  (70, 'Digital Citizenship: Copyright and Creative Commons', 'Digital Citizenship', 'None', 'beginner'),
  (71, 'Building a Travel Destination Guide', 'Projects', 'HTML', 'intermediate'),
  (72, 'CSS: Writing Maintainable, Scalable CSS', 'CSS', 'CSS', 'intermediate'),
  (73, 'HTML: Tables for Complex Real Data', 'HTML', 'HTML', 'intermediate'),
  (74, 'Building a Comparison Chart Page', 'Projects', 'HTML', 'intermediate'),
  (75, 'CSS: Dark Mode with Prefers-Color-Scheme', 'CSS', 'CSS', 'intermediate'),
  (76, 'Performance: Optimising Images and Core Web Vitals', 'Fundamentals', 'None', 'intermediate'),
  (77, 'Building a Personal Hobbies Showcase', 'Projects', 'HTML', 'intermediate'),
  (78, 'CSS: Utility Classes and Component Architecture', 'CSS', 'CSS', 'intermediate'),
  (79, 'HTML: Marking Up a Real Long-Form Article', 'HTML', 'HTML', 'intermediate'),
  (80, 'Building a Community Fundraiser Page', 'Projects', 'HTML', 'intermediate'),
  (81, 'CSS: The Cascade and Inheritance in Depth', 'CSS', 'CSS', 'intermediate'),
  (82, 'Scratch: Variables for Advanced Game State', 'Scratch', 'Scratch', 'intermediate'),
  (83, 'Scratch: Build a Complete Maze Game', 'Scratch', 'Scratch', 'advanced'),
  (84, 'Scratch: Music Composer Interactive Project', 'Scratch', 'Scratch', 'intermediate'),
  (85, 'Building a Coding Vocabulary Glossary Page', 'Projects', 'HTML', 'intermediate'),
  (86, 'CSS: Viewport Units and Full-Screen Layouts', 'CSS', 'CSS', 'intermediate'),
  (87, 'HTML: Time and Date Elements for Global Sites', 'HTML', 'HTML', 'intermediate'),
  (88, 'Building an Environmental Awareness Campaign Page', 'Projects', 'HTML', 'intermediate'),
  (89, 'CSS: Blend Modes and Advanced Visual Effects', 'CSS', 'CSS', 'advanced'),
  (90, 'Digital Citizenship: Building a Positive Online Identity', 'Digital Citizenship', 'None', 'intermediate'),
  (91, 'Building a Video Game Tribute Fan Page', 'Projects', 'HTML', 'intermediate'),
  (92, 'CSS: Animation Performance and GPU Acceleration', 'CSS', 'CSS', 'intermediate'),
  (93, 'HTML: Accessible Forms — Complete Reference', 'Accessibility', 'HTML', 'intermediate'),
  (94, 'Building a Family History Heritage Page', 'Projects', 'HTML', 'intermediate'),
  (95, 'Deploying Your Website: GitHub Pages Complete Guide', 'Fundamentals', 'None', 'intermediate'),
  (96, 'Building a Complete Local Business Website', 'Projects', 'HTML', 'advanced'),
  (97, 'Builders Capstone: Full Website Design Brief', 'Projects', 'HTML', 'advanced'),
  (98, 'Code Review: Giving and Receiving Feedback Professionally', 'Fundamentals', 'None', 'intermediate'),
  (99, 'Builders Showcase: Present Your Best Work', 'Projects', 'HTML', 'intermediate'),
  (100, 'Builders Graduation: You''re Ready for Developers Level', 'Fundamentals', 'HTML', 'intermediate')
) AS t(n, title, category, lang, difficulty);

SELECT '✅ Builders deep curriculum complete' as status,
  (SELECT COUNT(*) FROM public.lessons WHERE level = 'Builders') as lesson_count;


-- Lessons 51-100: Completing the full Builders curriculum
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l51', 'CSS: Multi-Column Layout', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Use CSS multi-column layout for newspaper-style text','Control column count, width, and gaps','Apply column-span to break out of columns'],
$L$# CSS: Multi-Column Layout

## Newspaper-Style Text Columns

Before CSS Grid, multi-column text layout was nearly impossible without hacks. CSS multi-column makes it straightforward, and it''s perfect for any content that should flow like a newspaper, magazine, or dictionary.

## The Basic Syntax

```css
.article-body {
  /* Approach 1: Specify the number of columns */
  column-count: 3;

  /* Approach 2: Specify minimum width — browser calculates count */
  column-width: 250px;

  /* Approach 3: Both — browser uses whichever gives most columns */
  columns: 250px 3; /* min-width count */

  /* Column gap */
  column-gap: 40px;

  /* Divider line between columns */
  column-rule: 1px solid #ddd;
  /* Same syntax as border: width style colour */
}
```

## Controlling Flow

Text automatically flows from one column to the next when it reaches the bottom. But you can override this:

```css
/* Break BEFORE this element — start on new column */
h3 { break-before: column; }

/* Prevent breaking INSIDE this element */
figure, blockquote {
  break-inside: avoid;
  page-break-inside: avoid; /* Legacy support */
}

/* Break AFTER this element */
.section-end { break-after: column; }
```

## Column Span: Breaking Out of Columns

A headline or pull quote that spans all columns:

```css
.article-headline {
  column-span: all;   /* Span all columns */
  text-align: center;
  font-size: 2rem;
  margin-bottom: 24px;
}

/* Can only be 1 (default) or all — no spanning 2 of 3 columns */
```

## Practical Multi-Column Layout

```html
<article class="magazine-article">
  <header class="article-head">
    <h1>The Future of Coding Education</h1>
    <p class="byline">By Alex Chen · <time>November 2024</time></p>
  </header>

  <div class="article-columns">
    <p class="drop-cap">When Ontario made coding mandatory from Grade 1 in 2022, it signalled a fundamental shift in how we think about education...</p>
    <p>Schools across the province are now grappling with the challenge of teaching computational thinking to students as young as six...</p>
    <blockquote class="pull-quote">"Every child deserves the opportunity to be a creator, not just a consumer of technology."</blockquote>
    <p>The results so far have been encouraging. Teachers who were initially apprehensive have found that students take to block-based coding naturally...</p>
  </div>
</article>
```

```css
.article-columns {
  column-count: 3;
  column-gap: 32px;
  column-rule: 1px solid #ddd;
  text-align: justify;       /* Justified text looks more newspaper-like */
  hyphens: auto;             /* Automatic hyphenation at line breaks */
}

/* Drop cap — first letter of first paragraph */
.drop-cap::first-letter {
  font-size: 4em;
  line-height: 0.8;
  float: left;
  margin: 0 8px 0 0;
  font-weight: 900;
  color: #1E2140;
}

.pull-quote {
  column-span: all;    /* Span all 3 columns */
  text-align: center;
  font-size: 1.3rem;
  font-style: italic;
  color: #1E2140;
  border-top: 3px double #1E2140;
  border-bottom: 3px double #1E2140;
  padding: 16px 0;
  margin: 24px 0;
}

/* Responsive: fewer columns on smaller screens */
@media (max-width: 900px) { .article-columns { column-count: 2; } }
@media (max-width: 600px) { .article-columns { column-count: 1; } }
```

## When to Use Multi-Column vs Grid

| Multi-column | Grid |
|---|---|
| Text that flows naturally top-to-bottom | Precise placement of specific items |
| Newspaper/magazine text | Page layouts and card grids |
| Unknown length of content | Known number of items |
| Content should reflow automatically | You want items in specific rows/columns |

## Key Takeaways

1. `column-count` sets how many columns; `column-width` sets minimum width
2. `column-gap` and `column-rule` control space and dividers between columns
3. `column-span: all` makes an element break out and span all columns
4. `break-inside: avoid` keeps figures and quotes from splitting across columns
5. `::first-letter` creates drop caps — a classic typographic effect
6. Multi-column is for flowing text; Grid is for placing discrete items
7. Always add responsive fallbacks — fewer columns on smaller screens
$L$,
ARRAY['css','multi-column','typography','magazine-layout'], 51),

('bld-l52', 'HTML: Data Attributes and JavaScript Interaction', 'HTML', 'HTML', 'intermediate', 25, 'published',
ARRAY['Add data attributes to HTML elements','Access data attributes with JavaScript','Use data attributes for filtering and dynamic behaviour'],
$L$# HTML: Data Attributes and JavaScript Interaction

## Storing Data in HTML

Sometimes you need to attach extra information to an HTML element that isn''t visible to users but can be used by your CSS or JavaScript. That''s what **data attributes** are for.

Data attributes start with `data-` followed by any name you choose:

```html
<div data-category="nature" data-id="42" data-author="Sarah">Content</div>
<button data-action="delete" data-target="item-5">Delete</button>
<article data-published="2024-11-15" data-reading-time="4">Article</article>
```

## CSS and Data Attributes

Use data attributes as CSS selectors:

```css
/* Style elements with specific data values */
[data-category="nature"] { border-left: 4px solid green; }
[data-category="technology"] { border-left: 4px solid blue; }

/* Show content from a data attribute */
[data-badge]::after {
  content: attr(data-badge);  /* Use the attribute value as content */
  background: red;
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.75em;
}
```

```html
<button data-badge="3">Notifications</button>
<!-- Shows "Notifications" with a badge showing "3" -->
```

## JavaScript and Data Attributes

Access data attributes through the `dataset` property:

```javascript
const element = document.getElementById('my-article');

// Get a data attribute
const category = element.dataset.category;  // "nature"
const id = element.dataset.id;              // "42" (always a string!)

// Set a data attribute
element.dataset.status = 'read';
// HTML becomes: data-status="read"

// Delete a data attribute
delete element.dataset.status;

// Check if a data attribute exists
if ('category' in element.dataset) {
  console.log('Has category:', element.dataset.category);
}
```

**Note:** `dataset.categoryName` maps to `data-category-name` (camelCase ↔ kebab-case).

## Building a Filter Gallery with Data Attributes

This is one of the most common uses of data attributes — filtering displayed items:

```html
<div class="filter-controls">
  <button class="filter active" data-filter="all">All</button>
  <button class="filter" data-filter="html">HTML</button>
  <button class="filter" data-filter="css">CSS</button>
  <button class="filter" data-filter="scratch">Scratch</button>
</div>

<div class="project-grid">
  <div class="project" data-type="html">Recipe Blog</div>
  <div class="project" data-type="css">Animation Showcase</div>
  <div class="project" data-type="html">Contact Page</div>
  <div class="project" data-type="scratch">Platform Game</div>
  <div class="project" data-type="css">Photo Gallery</div>
</div>
```

```javascript
const filters = document.querySelectorAll('.filter');
const projects = document.querySelectorAll('.project');

filters.forEach(filter => {
  filter.addEventListener('click', () => {
    // Update active button
    filters.forEach(f => f.classList.remove('active'));
    filter.classList.add('active');

    const selectedFilter = filter.dataset.filter;

    projects.forEach(project => {
      if (selectedFilter === 'all' || project.dataset.type === selectedFilter) {
        project.style.display = '';
      } else {
        project.style.display = 'none';
      }
    });
  });
});
```

## Tooltip System Using Data Attributes

```html
<button data-tooltip="Save your changes">Save</button>
<a href="/help" data-tooltip="Visit the help centre">?</a>
```

```css
[data-tooltip] {
  position: relative;
}

[data-tooltip]::before {
  content: attr(data-tooltip);  /* Use the data-tooltip value! */
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  background: #1E2140;
  color: white;
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 0.8rem;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.2s ease;
  z-index: 100;
}

[data-tooltip]:hover::before { opacity: 1; }
```

No JavaScript needed — pure CSS tooltips using data attributes!

## Accordion with Data Attributes

```html
<div class="accordion">
  <div class="accordion-item" data-open="false">
    <button class="accordion-header">What is CODEship Academy?</button>
    <div class="accordion-content">
      <p>CODEship Academy is an AI-powered coding education platform for Grades K-8.</p>
    </div>
  </div>
</div>
```

```javascript
document.querySelectorAll('.accordion-header').forEach(header => {
  header.addEventListener('click', () => {
    const item = header.parentElement;
    const isOpen = item.dataset.open === 'true';
    item.dataset.open = !isOpen;
  });
});
```

```css
.accordion-content {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.3s ease;
}

[data-open="true"] .accordion-content {
  max-height: 500px;  /* Larger than any content will be */
}

[data-open="true"] .accordion-header::after {
  content: '−'; /* Change + to − when open */
}
```

## Key Takeaways

1. Data attributes (`data-*`) store custom data on HTML elements without affecting display
2. Access in CSS with `[data-name="value"]` selectors and `attr(data-name)` for content
3. Access in JavaScript with `element.dataset.name` (camelCase maps to kebab-case in HTML)
4. Data attributes are perfect for filter systems — attach category to items, filter by it
5. CSS-only tooltips using `content: attr(data-tooltip)` require no JavaScript
6. `data-open="true/false"` toggled by JavaScript + CSS `[data-open="true"]` selector is a clean accordion pattern
7. Always validate and sanitise data attribute values from user input (security)
$L$,
ARRAY['html','data-attributes','javascript','filter','tooltips'], 52),

('bld-l53', 'Building a Team and About Page', 'Projects', 'HTML', 'intermediate', 40, 'published',
ARRAY['Build a professional team/about page with bios','Create person cards with consistent CSS','Apply CSS Grid for the team grid layout'],
$L$# Building a Team and About Page

## The Human Side of a Website

Every organisation — company, school club, sports team, community group — benefits from an "About Us" page. It answers the fundamental question visitors ask: "Who are these people and why should I trust them?"

A great about page has:
- The mission/story
- The team (with real photos and bios)
- Values or beliefs
- A call to action

## Complete About Page

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us — CODEship Academy</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>

  <main>
    <!-- Mission section -->
    <section class="mission-section">
      <div class="container">
        <div class="mission-grid">
          <div class="mission-text">
            <span class="eyebrow">Our Story</span>
            <h1>We Believe Every Child Deserves to Learn to Code</h1>
            <p class="lead">CODEship Academy was founded in 2022 by two former teachers who saw the gap between Ontario''s new coding curriculum mandate and the tools available to deliver it.</p>
            <p>We started with 12 students in an Oshawa community centre. Today we serve over 10,000 students across Ontario through our platform and school program.</p>
            <div class="mission-stats">
              <div class="stat"><strong>10,000+</strong><span>Students</span></div>
              <div class="stat"><strong>200+</strong><span>Schools</span></div>
              <div class="stat"><strong>4</strong><span>Levels</span></div>
              <div class="stat"><strong>2022</strong><span>Founded</span></div>
            </div>
          </div>
          <div class="mission-image">
            <img src="images/team-photo.jpg" alt="The CODEship Academy team at their Oshawa office" loading="lazy">
          </div>
        </div>
      </div>
    </section>

    <!-- Values -->
    <section class="values-section">
      <div class="container">
        <h2>What We Believe</h2>
        <div class="values-grid">
          <div class="value-card">
            <div class="value-icon">🎯</div>
            <h3>Mastery Over Speed</h3>
            <p>We don''t rush learners to the next level. Deep understanding of foundations is what enables future advanced learning.</p>
          </div>
          <div class="value-card">
            <div class="value-icon">🌍</div>
            <h3>Accessible to All</h3>
            <p>Coding education shouldn''t be a luxury. We offer free trials, scholarship pricing, and a bilingual platform for all of Ontario.</p>
          </div>
          <div class="value-card">
            <div class="value-icon">🔬</div>
            <h3>Evidence-Based</h3>
            <p>Every curriculum decision is based on educational research. We track outcomes and iterate based on data.</p>
          </div>
          <div class="value-card">
            <div class="value-icon">🤝</div>
            <h3>School-Family Partnership</h3>
            <p>The best learning happens when schools and families are aligned. We build tools for both.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Team grid -->
    <section class="team-section">
      <div class="container">
        <div class="section-header">
          <h2>Meet the Team</h2>
          <p>The educators, designers, and engineers building the future of coding education.</p>
        </div>
        <div class="team-grid">

          <article class="person-card" itemscope itemtype="https://schema.org/Person">
            <div class="person-photo">
              <img src="images/team/sarah.jpg" alt="" loading="lazy" itemprop="image">
            </div>
            <div class="person-info">
              <h3 itemprop="name">Sarah Williams</h3>
              <p class="person-title" itemprop="jobTitle">Co-Founder & CEO</p>
              <p class="person-bio" itemprop="description">Former Grade 4-6 teacher with 12 years in Ontario classrooms. MA in Educational Technology from Queen''s University.</p>
              <div class="person-links">
                <a href="https://linkedin.com/in/sarah" aria-label="Sarah Williams on LinkedIn" target="_blank" rel="noopener">
                  <svg aria-hidden="true"><!-- LinkedIn icon --></svg>
                </a>
                <a href="https://twitter.com/sarah" aria-label="Sarah Williams on Twitter" target="_blank" rel="noopener">
                  <svg aria-hidden="true"><!-- Twitter icon --></svg>
                </a>
              </div>
            </div>
          </article>

          <!-- Repeat for each team member -->
          <article class="person-card" itemscope itemtype="https://schema.org/Person">
            <div class="person-photo">
              <img src="images/team/marcus.jpg" alt="" loading="lazy">
            </div>
            <div class="person-info">
              <h3>Marcus Kim</h3>
              <p class="person-title">Co-Founder & CTO</p>
              <p class="person-bio">Full-stack developer and former coding instructor. Built the platform architecture from scratch.</p>
            </div>
          </article>

          <article class="person-card">
            <div class="person-photo">
              <img src="images/team/aisha.jpg" alt="" loading="lazy">
            </div>
            <div class="person-info">
              <h3>Aisha Patel</h3>
              <p class="person-title">Head of Curriculum</p>
              <p class="person-bio">Curriculum designer specialising in K-8 computer science. Formerly with ISTE.</p>
            </div>
          </article>

        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="about-cta">
      <div class="container">
        <h2>Want to Join the Team?</h2>
        <p>We''re always looking for educators, developers, and designers who believe in our mission.</p>
        <a href="/careers" class="btn-primary">View Open Positions</a>
      </div>
    </section>
  </main>

</body>
</html>
```

## The Team CSS

```css
/* Mission section */
.mission-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center; }
.eyebrow { text-transform: uppercase; letter-spacing: 0.1em; font-size: 0.8rem; font-weight: 700; color: #F5C518; }
.mission-stats { display: flex; gap: 32px; margin-top: 32px; }
.stat strong { display: block; font-size: 2rem; font-weight: 900; color: #1E2140; }
.stat span { font-size: 0.85rem; color: #8B90B0; }

/* Values */
.values-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; }
.value-card { background: white; border-radius: 16px; padding: 28px; box-shadow: 0 4px 16px rgba(0,0,0,0.06); }
.value-icon { font-size: 2rem; margin-bottom: 12px; }

/* Team grid */
.team-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 32px; }
.person-card { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.06); transition: transform 0.2s ease; }
.person-card:hover { transform: translateY(-6px); }
.person-photo { height: 240px; overflow: hidden; }
.person-photo img { width: 100%; height: 100%; object-fit: cover; object-position: top; }
.person-info { padding: 20px; }
.person-info h3 { font-size: 1.1rem; font-weight: 900; color: #1E2140; margin-bottom: 4px; }
.person-title { font-size: 0.85rem; color: #F5C518; font-weight: 700; margin-bottom: 10px; }
.person-bio { font-size: 0.9rem; color: #8B90B0; line-height: 1.6; }
.person-links { display: flex; gap: 8px; margin-top: 12px; }
.person-links a { color: #8B90B0; transition: color 0.2s; }
.person-links a:hover { color: #1E2140; }

/* Responsive */
@media (max-width: 768px) {
  .mission-grid { grid-template-columns: 1fr; }
  .values-grid { grid-template-columns: 1fr; }
}
```

## Key Takeaways

1. About pages build trust — they humanise an organisation with real faces and stories
2. Schema.org Person markup (`itemscope`, `itemtype`, `itemprop`) makes team bios machine-readable
3. `object-position: top` on team photos ensures faces show in the frame
4. The eyebrow text pattern (small uppercase label above the headline) creates visual hierarchy
5. `grid-template-columns: repeat(auto-fill, minmax(260px, 1fr))` creates a responsive team grid
6. Team cards should have consistent photo dimensions — crop all photos to the same aspect ratio
7. Social links on team members build authenticity — use `aria-label` for icon-only links
$L$,
ARRAY['html','css','project','about-page','team','schema'], 53),

('bld-l54', 'CSS: Scroll Snap and Styled Scrollbars', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Build a full-page scroll-snap experience','Style scrollbars for branding','Create a smooth scroll progress indicator'],
$L$# CSS: Scroll Snap and Styled Scrollbars

## Making Scrolling Feel Intentional

Standard scrolling is free-flowing. Scroll snap makes it precise — each scroll action moves to the next "snap point." This is great for:
- Presentation-style pages (one section = one slide)
- Image carousels and galleries
- Mobile app-style interfaces
- Storytelling pages

## Full-Page Scroll Snap

```html
<div class="snap-container">
  <section class="snap-section" id="intro">
    <h1>Section One</h1>
  </section>
  <section class="snap-section" id="about">
    <h1>Section Two</h1>
  </section>
  <section class="snap-section" id="work">
    <h1>Section Three</h1>
  </section>
</div>
```

```css
.snap-container {
  height: 100vh;
  overflow-y: scroll;
  scroll-snap-type: y mandatory;
  /* mandatory: always snaps to a point */
  /* proximity: only snaps when close */
}

.snap-section {
  height: 100vh;
  scroll-snap-align: start;  /* Snap top of section to top of viewport */
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Different background for each section */
.snap-section:nth-child(1) { background: #1E2140; color: white; }
.snap-section:nth-child(2) { background: #F5C518; color: #1E2140; }
.snap-section:nth-child(3) { background: white; color: #1E2140; }
```

## Horizontal Scroll Snap (Carousel)

```css
.carousel {
  display: flex;
  overflow-x: scroll;
  scroll-snap-type: x mandatory;
  gap: 0;
}

.carousel-slide {
  flex-shrink: 0;
  width: 100%;
  scroll-snap-align: center;
}

/* Or for peeking: show part of next slide */
.peek-carousel {
  padding: 0 10%;  /* Padding creates peeking effect */
}
.peek-slide {
  width: 80%;  /* Slightly less than container */
  margin: 0 10%;
  scroll-snap-align: center;
}
```

## Scroll Snap Stop

```css
/* Without scroll-snap-stop: fast scrolling can skip snap points */
/* With it: scrolling always pauses at each point */
.snap-item {
  scroll-snap-align: start;
  scroll-snap-stop: always; /* Force stop at each item */
}
```

## Styling Scrollbars

```css
/* Firefox */
.scrollable {
  scrollbar-width: thin;              /* auto | thin | none */
  scrollbar-color: #F5C518 #1E2140;  /* thumb colour | track colour */
}

/* Chrome, Safari, Edge (WebKit) */
.scrollable::-webkit-scrollbar {
  width: 8px;   /* Vertical scrollbar width */
  height: 8px;  /* Horizontal scrollbar height */
}

.scrollable::-webkit-scrollbar-track {
  background: #F8F9FE;
  border-radius: 4px;
}

.scrollable::-webkit-scrollbar-thumb {
  background: #1E2140;
  border-radius: 4px;
  border: 2px solid #F8F9FE;  /* Gap between thumb and track */
}

.scrollable::-webkit-scrollbar-thumb:hover {
  background: #F5C518;
}

.scrollable::-webkit-scrollbar-corner {
  background: #F8F9FE;  /* Corner where vertical and horizontal meet */
}
```

## Scroll Progress Indicator

A thin bar at the top of the page showing how far you''ve scrolled:

```html
<div class="scroll-progress" id="progress-bar"></div>
```

```css
.scroll-progress {
  position: fixed;
  top: 0;
  left: 0;
  height: 4px;
  background: linear-gradient(to right, #F5C518, #FF6B6B);
  width: 0%;
  z-index: 1000;
  transition: width 0.1s linear;
}
```

```javascript
window.addEventListener('scroll', () => {
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = (scrollTop / docHeight) * 100;
  document.getElementById('progress-bar').style.width = progress + '%';
});
```

## Scroll-Driven Animations (Modern CSS)

```css
/* Animate based on scroll position — no JavaScript needed! */
@keyframes progress {
  from { width: 0%; }
  to { width: 100%; }
}

.progress-bar {
  animation: progress linear;
  animation-timeline: scroll();  /* Use scroll position as timeline */
}

/* Animate elements as they scroll into view */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(40px); }
  to { opacity: 1; transform: translateY(0); }
}

.animated-section {
  animation: fadeUp linear;
  animation-timeline: view();   /* Use element visibility as timeline */
  animation-range: entry 0% entry 50%;  /* Animate as element enters viewport */
}
```

Note: scroll-driven animations are a very new CSS feature — check browser support before using in production.

## Key Takeaways

1. `scroll-snap-type` on the container + `scroll-snap-align` on children creates precise snapping
2. `mandatory` always snaps; `proximity` only snaps when close to a snap point
3. `scroll-snap-stop: always` prevents fast scrolling from skipping snap points
4. Style scrollbars with `scrollbar-width` + `scrollbar-color` (Firefox) and `::-webkit-scrollbar` rules (Chrome/Safari)
5. A scroll progress bar uses `scrollY / (scrollHeight - innerHeight) * 100` to calculate percentage
6. Scroll-driven animations (`animation-timeline: scroll()`) are new but powerful — no JS for scroll effects!
7. `padding` on a scroll container creates a "peeking" effect showing the next item
$L$,
ARRAY['css','scroll-snap','scrollbar','scroll-animation','carousel'], 54),

('bld-l55', 'Digital Citizenship: Citing Sources Online', 'Digital Citizenship', 'None', 'beginner', 25, 'published',
ARRAY['Understand copyright and why it matters','Properly cite web sources, images, and resources','Find Creative Commons licensed content for projects'],
$L$# Digital Citizenship: Citing Sources Online

## You''re a Publisher Now

When you build a website, you become a publisher. Your words and images are available to anyone in the world. With that power comes responsibility — especially around other people''s work.

## What Is Copyright?

**Copyright** is the legal right of creators to control how their work is used. When someone writes an article, takes a photograph, or creates a song, they automatically own the copyright. You cannot copy, publish, or use their work without permission — even if it''s freely available on the internet.

**Common misconception:** "I found it on Google Images, so it''s free to use." This is almost always wrong. Google Images searches the web — most of those images are copyright protected.

## What You CAN Copy Without Permission

Some content is explicitly free to use:

**Public Domain:** Copyright has expired (works published before 1929 in Canada), or the creator has explicitly released it to the public domain. Wikimedia Commons has thousands of public domain images.

**Creative Commons Licenses:** The creator allows use, often with conditions:
- **CC BY:** Use freely, but credit the creator
- **CC BY-SA:** Use freely, credit the creator, share your work under the same licence
- **CC BY-NC:** Use freely, credit the creator, NOT for commercial use
- **CC BY-ND:** Use freely, credit the creator, NO changes allowed
- **CC0:** Completely public domain — no restrictions at all

**Fair Use/Fair Dealing:** Limited use for education, criticism, and commentary. Context matters — a school project quoting a few lines of a poem is different from reproducing an entire book.

## Finding Free-to-Use Images

### For Websites and Projects

**Unsplash (unsplash.com)**
- Thousands of high-quality photographs
- CC0 — no attribution required (though appreciated)
- Free for personal and commercial use

**Pexels (pexels.com)**
- Photos and videos
- Free licence, attribution appreciated

**Pixabay (pixabay.com)**
- Photos, illustrations, vectors
- Free for most uses

**Wikimedia Commons (commons.wikimedia.org)**
- Millions of images, many public domain
- Check individual image licences — they vary
- Great for historical images and educational content

**SVG Icons:**
- Heroicons (heroicons.com) — MIT licence
- Feather Icons (feathericons.com) — MIT licence
- Font Awesome (fontawesome.com) — free tier available

## How to Cite Sources on Your Website

Even when using free content, citing sources is good practice and required by many licences.

**Image citation (caption):**
```html
<figure>
  <img src="forest.jpg" alt="Sunlight through autumn forest">
  <figcaption>
    Photo: <a href="https://unsplash.com/photos/..." rel="noopener" target="_blank">John Smith on Unsplash</a>
  </figcaption>
</figure>
```

**Reference list at bottom of page:**
```html
<section id="sources">
  <h2>Sources and References</h2>
  <ul>
    <li>Williams, S. (2024). "Coding in Ontario Schools." <cite>Education Weekly</cite>. Retrieved from [URL]</li>
    <li>NASA. (2024). <cite>Solar System Exploration</cite>. nasa.gov/solar-system</li>
    <li>Cover photo by Alex Chen via <a href="https://unsplash.com">Unsplash</a> (CC0)</li>
  </ul>
</section>
```

## The `<cite>` HTML Element

The `<cite>` element marks up the title of a creative work:

```html
<p>According to <cite>The Globe and Mail</cite>, Ontario schools are...</p>
<p>I read this in <cite>Harry Potter and the Philosopher''s Stone</cite>.</p>
<blockquote cite="https://source-url.com">Quoted text here.</blockquote>
```

## AI-Generated Content

A new area of copyright that''s still being worked out legally. General guidance:
- Images from Midjourney, DALL-E: check the platform''s terms of service
- Text from ChatGPT or Claude: can be used but shouldn''t be presented as your own original work
- Always disclose when content is AI-generated, especially in academic contexts

## The Golden Rule

Before using any content you didn''t create, ask:
1. **Is it in the public domain?** (Pre-1929, or explicitly CC0)
2. **Does it have a licence that allows my intended use?** (Read the licence!)
3. **Is it a Creative Commons licence that requires attribution?** (Credit the creator)
4. **Can I contact the creator and ask permission?** (Often they say yes!)

When in doubt, don''t use it — or find a free alternative.

## Key Takeaways

1. Copyright protects creators automatically — you can''t use their work without permission
2. "Found on Google" does NOT mean free to use
3. Creative Commons licences allow use with conditions — always check the specific licence
4. CC0 / Public Domain = truly free with no restrictions
5. Unsplash, Pexels, Pixabay, and Wikimedia Commons are reliable sources of free images
6. Always cite your sources — with `<figcaption>` for images and a references section for text
7. The `<cite>` element marks up titles of creative works
8. When in doubt, find a properly licensed alternative
$L$,
ARRAY['digital-citizenship','copyright','creative-commons','citations','ethics'], 55);

-- Continuing lessons 56-100
INSERT INTO public.lessons (slug, title, level, category, language, difficulty, duration_minutes, status, objectives, instructions, tags, order_index) VALUES

('bld-l56', 'Building a Favourite Books or Games Page', 'Projects', 'HTML', 'beginner', 35, 'published',
ARRAY['Build a personal favourites page showcasing books, games, or movies','Apply rating systems with CSS','Create a visually engaging recommendation page'],
$L$# Building a Favourites Page

## Curated Lists Are Everywhere

Goodreads (books), Letterboxd (movies), Backloggd (games) — some of the most popular websites on the internet are simply people sharing lists of things they love with honest reviews and ratings.

Your favourites page does the same thing: personal, authentic, genuinely useful to anyone who shares your interests.

## Choose Your Category
- 📚 Books you''ve read and recommend
- 🎮 Video games you love
- 🎬 Movies or TV shows
- 🎵 Albums or songs
- 🎨 Artists or artworks

## HTML Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Favourite Books · [Your Name]</title>
  <link rel="stylesheet" href="favourites.css">
</head>
<body>

  <header>
    <h1>📚 My Favourite Books</h1>
    <p>Honest reviews and recommendations from a Grade [X] reader.</p>
    <div class="sort-bar">
      <span>Sort by:</span>
      <button class="sort-btn active">All</button>
      <button class="sort-btn">Adventure</button>
      <button class="sort-btn">Science Fiction</button>
      <button class="sort-btn">Fantasy</button>
    </div>
  </header>

  <main class="books-grid">

    <article class="book-card" data-genre="fantasy">
      <div class="book-cover">
        <img src="covers/hp.jpg" alt="Harry Potter and the Philosopher's Stone book cover" loading="lazy">
        <div class="book-overlay">
          <a href="#hp-review" class="read-review-btn">Read Review</a>
        </div>
      </div>
      <div class="book-info">
        <div class="book-meta">
          <span class="genre-tag">Fantasy</span>
          <span class="year">1997</span>
        </div>
        <h2 class="book-title">Harry Potter and the Philosopher''s Stone</h2>
        <p class="book-author">J.K. Rowling</p>
        <div class="rating" aria-label="Rating: 5 out of 5 stars">
          <span class="star filled" aria-hidden="true">★</span>
          <span class="star filled" aria-hidden="true">★</span>
          <span class="star filled" aria-hidden="true">★</span>
          <span class="star filled" aria-hidden="true">★</span>
          <span class="star filled" aria-hidden="true">★</span>
          <span class="rating-text">5/5</span>
        </div>
        <p class="book-review" id="hp-review">The book that made me a reader. Harry''s first year at Hogwarts is the perfect blend of mystery, magic, and heart. Re-readable forever.</p>
        <div class="book-quote">
          <blockquote>
            "It does not do to dwell on dreams and forget to live."
          </blockquote>
          <cite>Albus Dumbledore</cite>
        </div>
      </div>
    </article>

    <!-- Add 5 more book cards -->

  </main>

  <aside class="reading-stats">
    <h2>My Reading in Numbers</h2>
    <dl>
      <dt>Books read this year</dt><dd>23</dd>
      <dt>Favourite genre</dt><dd>Fantasy</dd>
      <dt>Currently reading</dt><dd><cite>The Hobbit</cite></dd>
    </dl>
  </aside>

</body>
</html>
```

## The CSS

```css
body { font-family: 'Nunito', sans-serif; background: #FFF8F0; margin: 0; padding: 24px; }

header { text-align: center; padding: 40px 24px; }
header h1 { font-size: 2.5rem; font-weight: 900; color: #1E2140; margin-bottom: 8px; }

.books-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 32px;
  max-width: 1200px;
  margin: 40px auto;
}

.book-card { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.06); transition: transform 0.2s ease; }
.book-card:hover { transform: translateY(-6px); }

.book-cover { position: relative; aspect-ratio: 2/3; overflow: hidden; }
.book-cover img { width: 100%; height: 100%; object-fit: cover; }

.book-overlay {
  position: absolute; inset: 0;
  background: rgba(30,33,64,0.75);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; transition: opacity 0.3s ease;
}
.book-card:hover .book-overlay { opacity: 1; }

.read-review-btn {
  background: #F5C518; color: #1E2140;
  padding: 10px 20px; border-radius: 8px;
  font-weight: 900; text-decoration: none;
}

.book-info { padding: 20px; }
.book-title { font-size: 1.1rem; font-weight: 900; color: #1E2140; margin: 6px 0 4px; }
.book-author { color: #8B90B0; font-size: 0.9rem; margin-bottom: 10px; }

/* Star rating */
.rating { display: flex; align-items: center; gap: 4px; margin-bottom: 12px; }
.star { font-size: 1.2rem; color: #ddd; }
.star.filled { color: #F5C518; }
.rating-text { font-size: 0.8rem; color: #8B90B0; margin-left: 4px; }

.genre-tag {
  background: #EEF0FA; color: #1E2140;
  padding: 2px 10px; border-radius: 99px;
  font-size: 0.75rem; font-weight: 700;
}

.book-review { font-size: 0.9rem; color: #555; line-height: 1.6; margin-bottom: 12px; }

.book-quote blockquote {
  border-left: 3px solid #F5C518;
  padding-left: 12px;
  font-style: italic;
  font-size: 0.85rem;
  color: #1E2140;
  margin: 0 0 4px;
}
.book-quote cite { font-size: 0.75rem; color: #8B90B0; }
```

## Key Takeaways

1. Personal pages showcase your voice — write genuine reviews, not summaries
2. `data-genre` attributes enable JavaScript filtering by category
3. The hover overlay pattern (`opacity: 0` → `opacity: 1`) creates clean reveal effects
4. Aspect ratio `2/3` is the classic book cover proportion
5. Star ratings need accessible `aria-label` — don''t rely on colour alone
6. `<blockquote>` + `<cite>` is the semantic way to include quotes from books
7. A personal reading stats sidebar (`<dl>`) adds personality and context
$L$,
ARRAY['html','css','project','favourites','rating','personal-page'], 56),

('bld-l57', 'CSS: Custom Checkbox and Radio Buttons', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Style checkboxes and radio buttons with pure CSS','Create toggle switches','Build an accessible custom form control'],
$L$# CSS: Custom Checkbox and Radio Buttons

## Why Custom Form Controls

The default browser checkboxes and radio buttons look different on every operating system and browser — making consistent branding impossible. Custom controls let you match your design system exactly.

## The Hidden Input Technique

The approach: hide the native input, style a sibling element to look like the control:

```html
<label class="custom-check">
  <input type="checkbox" name="option">
  <span class="checkmark" aria-hidden="true"></span>
  Subscribe to newsletter
</label>
```

```css
/* Hide native input but keep it accessible */
.custom-check input {
  position: absolute;
  width: 1px; height: 1px;
  margin: -1px; padding: 0;
  overflow: hidden;
  clip: rect(0,0,0,0);
  white-space: nowrap;
  border: 0;
}
/* Do NOT use display:none or visibility:hidden — that removes it from keyboard nav */

/* The visible checkbox */
.custom-check { display: flex; align-items: center; gap: 10px; cursor: pointer; }

.checkmark {
  width: 22px; height: 22px;
  border: 2px solid #E8EAF6;
  border-radius: 4px;
  flex-shrink: 0;
  background: white;
  transition: all 0.15s ease;
  position: relative;
}

/* Checked state */
.custom-check input:checked + .checkmark {
  background: #1E2140;
  border-color: #1E2140;
}

/* Checkmark tick */
.custom-check input:checked + .checkmark::after {
  content: '';
  position: absolute;
  left: 5px; top: 1px;
  width: 8px; height: 13px;
  border: 2px solid white;
  border-top: none;
  border-left: none;
  transform: rotate(45deg);
}

/* Focus state — CRITICAL for accessibility */
.custom-check input:focus-visible + .checkmark {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
}

/* Hover state */
.custom-check:hover .checkmark {
  border-color: #1E2140;
}
```

## Custom Radio Buttons

Same principle — round instead of square:

```html
<label class="custom-radio">
  <input type="radio" name="level" value="explorers">
  <span class="radio-dot" aria-hidden="true"></span>
  Explorers (K-1)
</label>
```

```css
.custom-radio { display: flex; align-items: center; gap: 10px; cursor: pointer; }
.custom-radio input { /* Same hiding technique as checkbox */ }

.radio-dot {
  width: 22px; height: 22px;
  border: 2px solid #E8EAF6;
  border-radius: 50%;          /* Circle, not square */
  flex-shrink: 0;
  background: white;
  transition: all 0.15s ease;
  position: relative;
}

.custom-radio input:checked + .radio-dot {
  border-color: #1E2140;
}

/* The inner filled circle */
.custom-radio input:checked + .radio-dot::after {
  content: '';
  position: absolute;
  inset: 3px;               /* 3px from all edges */
  background: #1E2140;
  border-radius: 50%;
}

.custom-radio input:focus-visible + .radio-dot {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
}
```

## Toggle Switch

A toggle switch is essentially a styled checkbox:

```html
<label class="toggle">
  <input type="checkbox" role="switch" aria-checked="false">
  <span class="toggle-track" aria-hidden="true">
    <span class="toggle-thumb"></span>
  </span>
  <span>Enable dark mode</span>
</label>
```

```css
.toggle { display: flex; align-items: center; gap: 12px; cursor: pointer; }
.toggle input { /* Hide with accessible technique */ }

.toggle-track {
  width: 48px; height: 26px;
  background: #E8EAF6;
  border-radius: 99px;
  position: relative;
  transition: background 0.2s ease;
}

.toggle-thumb {
  position: absolute;
  top: 3px; left: 3px;
  width: 20px; height: 20px;
  background: white;
  border-radius: 50%;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
  transition: transform 0.2s ease;
}

.toggle input:checked + .toggle-track { background: #1E2140; }
.toggle input:checked + .toggle-track .toggle-thumb {
  transform: translateX(22px);  /* Slide to right */
}

.toggle input:focus-visible + .toggle-track {
  outline: 2px solid #F5C518;
  outline-offset: 2px;
}
```

## Building a Complete Preferences Form

```html
<form class="preferences-form">
  <h2>Notification Preferences</h2>

  <fieldset>
    <legend>Email notifications</legend>
    <label class="toggle">
      <input type="checkbox" role="switch" checked>
      <span class="toggle-track"><span class="toggle-thumb"></span></span>
      <span>Weekly progress report</span>
    </label>
    <label class="toggle">
      <input type="checkbox" role="switch">
      <span class="toggle-track"><span class="toggle-thumb"></span></span>
      <span>New lesson available</span>
    </label>
    <label class="toggle">
      <input type="checkbox" role="switch" checked>
      <span class="toggle-track"><span class="toggle-thumb"></span></span>
      <span>Achievement unlocked</span>
    </label>
  </fieldset>

  <fieldset>
    <legend>Learning level</legend>
    <label class="custom-radio">
      <input type="radio" name="level" value="explorers">
      <span class="radio-dot"></span>
      Explorers (K-1)
    </label>
    <label class="custom-radio">
      <input type="radio" name="level" value="builders" checked>
      <span class="radio-dot"></span>
      Builders (Gr 2-3)
    </label>
    <label class="custom-radio">
      <input type="radio" name="level" value="developers">
      <span class="radio-dot"></span>
      Developers (Gr 4-6)
    </label>
  </fieldset>
</form>
```

## Key Takeaways

1. Custom controls use a hidden native input + visible sibling element styled with CSS
2. Use the accessible hiding technique (absolute + clip) not `display:none` — keyboard users need the native input
3. The `input:checked + sibling` selector styles the visual element when checked
4. ALWAYS provide a visible `:focus-visible` state — keyboard users need to see where they are
5. Toggle switches are styled checkboxes — use `role="switch"` on the input for screen readers
6. The thumb slides across the track using `transform: translateX()` not `left` — smoother animation
7. Group related controls in `<fieldset>` + `<legend>` for semantic and accessible grouping
$L$,
ARRAY['css','forms','checkboxes','radio','toggle','accessibility'], 57),

('bld-l58', 'HTML: Metadata, Favicons, and Open Graph', 'HTML', 'HTML', 'intermediate', 20, 'published',
ARRAY['Add favicons in multiple formats','Write comprehensive meta tags','Preview Open Graph tags for social sharing'],
$L$# HTML: Metadata, Favicons, and Open Graph

## The Full <head> Section

The `<head>` of an HTML document contains information about the page rather than content on the page. A well-crafted head section improves SEO, social sharing, and user experience.

## Favicons

Favicons are the small icons that appear in browser tabs, bookmarks, and home screens. Modern websites need multiple sizes:

```html
<!-- Basic favicon -->
<link rel="icon" type="image/x-icon" href="/favicon.ico">

<!-- Modern SVG favicon (scales perfectly to any size) -->
<link rel="icon" type="image/svg+xml" href="/favicon.svg">

<!-- PNG fallback for older browsers -->
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">

<!-- Apple home screen icon (iOS/macOS) -->
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">

<!-- Android/Chrome -->
<link rel="manifest" href="/site.webmanifest">
```

### web.webmanifest
```json
{
  "name": "CODEship Academy",
  "short_name": "CODEship",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ],
  "theme_color": "#1E2140",
  "background_color": "#1E2140",
  "display": "standalone"
}
```

### Creating SVG Favicons

An SVG favicon that works at any size:

```html
<!-- favicon.svg -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <text y=".9em" font-size="90">🚀</text>
</svg>
```

Emoji favicons are simple and distinctive! Or use your logo SVG.

## The Theme Colour

Sets the browser chrome colour on mobile:

```html
<!-- Dark navy for CODEship Academy -->
<meta name="theme-color" content="#1E2140">

<!-- Can change based on colour scheme preference -->
<meta name="theme-color" content="#F8F9FE" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#1E2140" media="(prefers-color-scheme: dark)">
```

## Complete Meta Tag Reference

```html
<head>
  <!-- Character encoding — always first -->
  <meta charset="UTF-8">

  <!-- Viewport for mobile -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Core SEO -->
  <title>CODEship Academy — AI-Powered Coding for Kids K-8</title>
  <meta name="description" content="Personalized coding education for Grades K–8. Ontario curriculum-aligned, bilingual EN/FR. 14-day free trial.">
  <link rel="canonical" href="https://codeshipacademy.com/">

  <!-- Author and language -->
  <meta name="author" content="CODEship Academy">
  <meta name="language" content="English">

  <!-- Robots -->
  <meta name="robots" content="index, follow">
  <!-- index: include in search results -->
  <!-- noindex: exclude from search results -->
  <!-- follow: follow links on page -->
  <!-- nofollow: don''t follow links -->

  <!-- Open Graph (Facebook, LinkedIn, WhatsApp) -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="CODEship Academy — Coding for Kids K-8">
  <meta property="og:description" content="AI-powered personalized coding education.">
  <meta property="og:image" content="https://codeshipacademy.com/og-image.jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:url" content="https://codeshipacademy.com/">
  <meta property="og:site_name" content="CODEship Academy">
  <meta property="og:locale" content="en_CA">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:site" content="@codeshipacademy">
  <meta name="twitter:title" content="CODEship Academy">
  <meta name="twitter:description" content="AI-powered coding education for kids.">
  <meta name="twitter:image" content="https://codeshipacademy.com/twitter-card.jpg">

  <!-- Favicons -->
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">
  <meta name="theme-color" content="#1E2140">

  <!-- Performance hints -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="dns-prefetch" href="https://fonts.gstatic.com">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;900&display=swap" rel="stylesheet">

  <!-- Stylesheet -->
  <link rel="stylesheet" href="styles.css">
</head>
```

## Testing Your Meta Tags

**Open Graph:** opengraph.xyz — preview how your link looks on Facebook/LinkedIn
**Twitter:** cards-dev.twitter.com/validator
**General:** metatags.io — preview all at once

## Key Takeaways

1. Favicons need multiple formats: SVG (modern), PNG 32px and 16px, Apple Touch Icon 180px
2. The web manifest enables "Add to Home Screen" for Progressive Web Apps
3. `<meta name="theme-color">` sets the browser chrome colour on mobile
4. Open Graph tags control how links appear when shared on social media — the image is crucial
5. Twitter Cards have their own meta tags — use `summary_large_image` for best results
6. `rel="canonical"` tells search engines which URL is the "real" one if content appears at multiple URLs
7. `robots` meta controls whether search engines index the page
8. Test with dedicated tools — what you see in browser DevTools isn''t always what social platforms see
$L$,
ARRAY['html','meta-tags','favicon','open-graph','seo','social-media'], 58),

('bld-l59', 'Building a Restaurant Menu Page', 'Projects', 'HTML', 'intermediate', 45, 'published',
ARRAY['Build a styled restaurant menu with categories and items','Apply CSS Grid for menu layout','Include a reservation form'],
$L$# Building a Restaurant Menu Page

## The Digital Menu

Every restaurant needs a website. A great restaurant website does three things: makes you hungry, shows off the food, and makes it easy to make a reservation.

You''ll build a full restaurant page: hero, menu sections, individual item cards, and a reservation form.

## Complete Restaurant Page HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>La Maison Dorée — French-Canadian Restaurant, Oshawa</title>
  <link rel="stylesheet" href="restaurant.css">
</head>
<body>

  <header class="restaurant-header">
    <nav>
      <a href="/" class="logo">La Maison Dorée</a>
      <div class="nav-links">
        <a href="#menu">Menu</a>
        <a href="#about">Our Story</a>
        <a href="#reserve" class="btn-reserve">Reserve a Table</a>
      </div>
    </nav>
  </header>

  <section class="hero-restaurant">
    <div class="hero-content">
      <span class="restaurant-badge">Est. 2018 · Oshawa, Ontario</span>
      <h1>French-Canadian Cuisine<br>with Local Ingredients</h1>
      <p>Celebrating the best of Quebec tradition with Ontario''s seasonal bounty.</p>
      <div class="hero-actions">
        <a href="#reserve" class="btn-gold">Reserve a Table</a>
        <a href="#menu" class="btn-ghost-white">View Menu</a>
      </div>
      <div class="hours-badge">
        <span>Open Daily</span>
        <span>11:30 AM – 10:00 PM</span>
        <span>(905) 555-0182</span>
      </div>
    </div>
  </section>

  <main id="menu" class="menu-section">
    <div class="container">
      <div class="menu-header">
        <h2>Our Menu</h2>
        <p>All dishes made fresh daily with locally sourced ingredients.</p>
        <div class="menu-nav">
          <a href="#starters">Starters</a>
          <a href="#mains">Mains</a>
          <a href="#desserts">Desserts</a>
          <a href="#drinks">Drinks</a>
        </div>
      </div>

      <!-- Starters -->
      <section class="menu-category" id="starters">
        <h3 class="category-title">
          <span class="title-line">Starters</span>
        </h3>
        <div class="menu-grid">

          <article class="menu-item">
            <div class="item-info">
              <div class="item-header">
                <h4>French Onion Soup <span class="badge badge-popular">Popular</span></h4>
                <span class="item-price">$14</span>
              </div>
              <p class="item-desc">Classic gratinée with caramelised Vidalia onions, aged Gruyère, and a crusty baguette crouton.</p>
              <div class="item-tags">
                <span class="diet-tag vegetarian">🌿 Vegetarian</span>
              </div>
            </div>
          </article>

          <article class="menu-item">
            <div class="item-image">
              <img src="images/poutine.jpg" alt="Poutine with fries, gravy, and cheese curds" loading="lazy">
            </div>
            <div class="item-info">
              <div class="item-header">
                <h4>Classic Poutine <span class="badge badge-signature">House Signature</span></h4>
                <span class="item-price">$16</span>
              </div>
              <p class="item-desc">Hand-cut Kennebec fries, fresh Quebec cheese curds, and our 6-hour veal demi-glace.</p>
            </div>
          </article>

          <!-- More items... -->
        </div>
      </section>

      <!-- Mains -->
      <section class="menu-category" id="mains">
        <h3 class="category-title"><span class="title-line">Main Courses</span></h3>
        <div class="menu-grid">
          <article class="menu-item featured-item">
            <div class="item-image">
              <img src="images/tourtiere.jpg" alt="Québec tourtière meat pie" loading="lazy">
            </div>
            <div class="item-info">
              <div class="item-header">
                <h4>Tourtière du Lac <span class="badge badge-chef">Chef''s Pick</span></h4>
                <span class="item-price">$32</span>
              </div>
              <p class="item-desc">Traditional Lac-Saint-Jean style meat pie with wild boar, venison, and root vegetables, served with homemade ketchup aux fruits.</p>
            </div>
          </article>
          <!-- More mains... -->
        </div>
      </section>
    </div>
  </main>

  <!-- Reservation form -->
  <section class="reservation" id="reserve">
    <div class="container">
      <h2>Reserve Your Table</h2>
      <p>For same-day reservations, please call (905) 555-0182.</p>
      <form class="reservation-form" action="/reserve" method="post">
        <div class="form-row">
          <div class="form-field"><label for="name">Name *</label><input type="text" id="name" required></div>
          <div class="form-field"><label for="phone">Phone *</label><input type="tel" id="phone" required></div>
        </div>
        <div class="form-row">
          <div class="form-field"><label for="date">Date *</label><input type="date" id="date" required></div>
          <div class="form-field"><label for="time">Time *</label>
            <select id="time" required>
              <option value="">Select time</option>
              <option>11:30 AM</option><option>12:00 PM</option><option>12:30 PM</option>
              <option>6:00 PM</option><option>6:30 PM</option><option>7:00 PM</option>
              <option>7:30 PM</option><option>8:00 PM</option>
            </select>
          </div>
        </div>
        <div class="form-field">
          <label for="guests">Number of Guests *</label>
          <input type="number" id="guests" min="1" max="12" value="2" required>
        </div>
        <div class="form-field">
          <label for="notes">Special Requests</label>
          <textarea id="notes" rows="3" placeholder="Dietary restrictions, celebrations, accessibility needs..."></textarea>
        </div>
        <button type="submit">Request Reservation</button>
      </form>
    </div>
  </section>

</body>
</html>
```

## Restaurant CSS Highlights

```css
:root {
  --dark: #1A1208;
  --gold: #C4932A;
  --cream: #FDF8F0;
  --border: #E8DFC8;
  --serif: 'Playfair Display', Georgia, serif;
  --sans: 'Nunito', sans-serif;
}

/* Menu grid — 2 columns on tablet+, 1 on mobile */
.menu-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 0;
}

.menu-item {
  display: flex;
  gap: 16px;
  padding: 24px 0;
  border-bottom: 1px solid var(--border);
}

.item-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }
.item-price { font-size: 1.1rem; font-weight: 900; color: var(--gold); white-space: nowrap; }

/* Signature category title with lines */
.category-title { display: flex; align-items: center; gap: 16px; margin: 48px 0 24px; }
.category-title::before, .category-title::after { content: ''; flex: 1; height: 1px; background: var(--border); }
.title-line { font-family: var(--serif); font-size: 1.5rem; white-space: nowrap; }

/* Badges */
.badge { font-size: 0.7rem; padding: 2px 8px; border-radius: 4px; font-weight: 700; vertical-align: middle; }
.badge-popular { background: #FEF3C7; color: #92400E; }
.badge-signature { background: #EDE9FE; color: #5B21B6; }
.badge-chef { background: #DCFCE7; color: #166534; }
```

## Key Takeaways

1. Restaurant pages need: hero, menu, story, and reservation — in that priority order
2. The menu grid uses `minmax(340px, 1fr)` — wide enough for item + price side by side
3. Item prices should be right-aligned and visually distinct (a colour or weight)
4. Dietary badges (🌿 Vegetarian, 🌾 Gluten-Free) use emoji + text for accessibility
5. Category dividers with `::before` and `::after` pseudo-elements create elegant section breaks
6. The `::before`/`::after` line trick: `display: flex; align-items: center` + `flex: 1; height: 1px; background`
7. Date inputs with `type="date"` provide a built-in calendar picker — no library needed
$L$,
ARRAY['html','css','project','restaurant','menu','reservation-form'], 59),

('bld-l60', 'CSS: calc() and Math Functions', 'CSS', 'CSS', 'intermediate', 25, 'published',
ARRAY['Use calc() to combine different CSS units','Apply min(), max(), and clamp() for responsive values','Build fluid layouts using CSS math'],
$L$# CSS: calc() and Math Functions

## Why CSS Needs Math

CSS units are powerful — `px`, `%`, `rem`, `vw` — but sometimes you need to combine them. For example:
- "100% of the container minus a 40px sidebar"
- "The font size should be at least 16px but no more than 24px"
- "This element should be exactly 2rem taller than its parent"

CSS math functions solve these elegantly.

## `calc()`: Mix and Match Units

```css
/* Subtract sidebar width from full width */
.main-content {
  width: calc(100% - 240px);
}

/* Content area minus nav + footer heights */
.page-content {
  min-height: calc(100vh - 64px - 80px);
  /* Viewport height minus header (64px) minus footer (80px) */
}

/* Breathing room: full width minus margins */
.container {
  width: calc(100% - 48px); /* 24px margin each side */
  max-width: 1200px;
  margin: 0 auto;
}

/* Slightly bigger than 1rem */
.lead-text {
  font-size: calc(1rem + 2px);
}

/* Negative values: pull something up */
.overlap-card {
  margin-top: calc(-80px);
}

/* Percentage-based with fixed gutters */
.three-col {
  width: calc(33.333% - 16px);
}
```

You can use: `+`, `-`, `*`, `/`. Spaces around `+` and `-` are required.

## `min()`: Use the Smaller Value

Takes multiple values, uses whichever is **smallest**:

```css
/* Use 90% of viewport OR 1200px max, whichever is smaller */
.container {
  width: min(90%, 1200px);
  /* At small screens: 90% */
  /* At large screens: 1200px */
}

/* Image never wider than its natural size OR the container */
img {
  width: min(100%, 800px);
}

/* Padding that doesn''t overwhelm small screens */
.section {
  padding: min(80px, 8vw);
}
```

## `max()`: Use the Larger Value

Takes multiple values, uses whichever is **largest**:

```css
/* Never less than 300px wide, but grows with viewport */
.sidebar {
  width: max(300px, 25%);
}

/* Minimum readable font size */
p {
  font-size: max(16px, 1.2vw);
  /* Always at least 16px */
}
```

## `clamp()`: Stay Within Bounds

`clamp(minimum, preferred, maximum)` — the preferred value, but never less than minimum or more than maximum:

```css
/* Fluid heading: 2rem on mobile, 5vw normally, max 4.5rem on wide screens */
h1 {
  font-size: clamp(2rem, 5vw, 4.5rem);
}

/* Fluid paragraph */
p {
  font-size: clamp(1rem, 1.5vw, 1.2rem);
  line-height: clamp(1.5, 2vw, 1.7);
}

/* Fluid padding */
.section {
  padding: clamp(32px, 8vw, 100px);
}

/* Fluid card width */
.card {
  width: clamp(280px, 30%, 400px);
}
```

`clamp()` is the modern way to handle responsive sizing without multiple media queries!

## Practical Fluid Typography with clamp()

```css
:root {
  /* These scale smoothly from 375px to 1440px viewport width */
  --text-sm:   clamp(0.75rem,  0.7vw + 0.5rem,  0.875rem);
  --text-base: clamp(1rem,     0.9vw + 0.7rem,   1.125rem);
  --text-lg:   clamp(1.1rem,   1vw + 0.8rem,     1.35rem);
  --text-xl:   clamp(1.3rem,   1.5vw + 0.9rem,   1.75rem);
  --text-2xl:  clamp(1.7rem,   2.5vw + 1rem,     2.5rem);
  --text-3xl:  clamp(2rem,     4vw + 1rem,       3.5rem);
  --text-4xl:  clamp(2.5rem,   6vw + 1rem,       5rem);
}
```

Everything scales perfectly between all screen sizes — no breakpoints needed for font sizes!

## Aspect Ratio Math

```css
/* 16:9 video container */
.video-container {
  width: 100%;
  aspect-ratio: 16/9;
}

/* Equivalent old technique using padding-top hack */
.video-old {
  width: 100%;
  padding-top: 56.25%; /* 9/16 = 0.5625 = 56.25% */
  position: relative;
}
```

Modern `aspect-ratio` is much cleaner!

## Combining calc() with CSS Variables

```css
:root {
  --nav-height: 64px;
  --footer-height: 200px;
  --spacing: 24px;
}

.full-page-section {
  min-height: calc(100vh - var(--nav-height));
}

.sidebar {
  height: calc(100vh - var(--nav-height) - var(--footer-height));
}

.content-padding {
  padding: calc(var(--spacing) * 2) var(--spacing);
  /* padding: 48px 24px */
}
```

## Key Takeaways

1. `calc()` combines different units: `calc(100% - 240px)`, `calc(100vh - 64px)`
2. Spaces are required around `+` and `-` in `calc()` — `calc(100% -240px)` fails
3. `min(a, b)` uses the smaller value; `max(a, b)` uses the larger
4. `clamp(min, preferred, max)` is the modern way to create fluid, bounded values
5. `clamp()` for font sizes eliminates the need for font-size media queries
6. `aspect-ratio: 16/9` is much simpler than the old padding-top hack
7. Combining `calc()` with CSS variables creates a powerful, maintainable layout system
$L$,
ARRAY['css','calc','clamp','math','fluid-typography','responsive'], 60);

