-- ─────────────────────────────────────────────────────────────────────────────
-- CODEship Academy — School Portal Schema Extension
-- Run AFTER schema.sql in Supabase SQL Editor
-- ─────────────────────────────────────────────────────────────────────────────

-- Schools
create table if not exists public.schools (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  board           text,
  principal       text,
  contact_name    text,
  contact_email   text,
  contact_phone   text,
  address         text,
  city            text default 'Toronto',
  province        text default 'ON',
  postal_code     text,
  logo_url        text,
  notes           text,
  status          text default 'active' check (status in ('active','inactive','pending')),
  created_by      uuid references public.users(id),
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- Workshop Sessions (90-min in-school visits)
create table if not exists public.workshop_sessions (
  id              uuid primary key default gen_random_uuid(),
  school_id       uuid references public.schools(id) on delete cascade,
  teacher_id      uuid references public.users(id),
  title           text not null default '90-Minute Coding Workshop',
  grade_range     text not null,          -- e.g. "Grades 3-4"
  level           text not null,          -- Explorers / Builders / Developers / Engineers
  session_date    date not null,
  session_time    time not null default '10:00',
  duration_minutes integer default 90,
  capacity        integer default 30,
  location        text,                   -- e.g. "Library", "Room 201"
  instructor_name text,
  status          text default 'scheduled' check (status in ('scheduled','completed','cancelled','no-show')),
  notes           text,
  post_session_report text,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- Session Attendance
create table if not exists public.session_attendance (
  id              uuid primary key default gen_random_uuid(),
  session_id      uuid references public.workshop_sessions(id) on delete cascade,
  student_name    text not null,
  grade           text,
  attended        boolean default true,
  engagement_score integer check (engagement_score between 1 and 5),
  notes           text,
  created_at      timestamptz default now()
);

-- Certificates
create table if not exists public.certificates (
  id              uuid primary key default gen_random_uuid(),
  student_id      uuid references public.student_profiles(id) on delete cascade,
  level           text not null,
  issued_at       timestamptz default now(),
  pdf_url         text,
  share_token     text unique default encode(gen_random_bytes(16), 'hex'),
  downloaded_at   timestamptz,
  created_at      timestamptz default now()
);

-- Share Tokens (for public sharing of projects, quiz scores, certificates)
create table if not exists public.share_tokens (
  id              uuid primary key default gen_random_uuid(),
  token           text unique not null default encode(gen_random_bytes(16), 'hex'),
  type            text not null check (type in ('project','quiz_score','certificate','progress')),
  student_id      uuid references public.student_profiles(id) on delete cascade,
  content_id      uuid,
  content_title   text,
  metadata        jsonb default '{}',
  views           integer default 0,
  expires_at      timestamptz,
  created_at      timestamptz default now()
);

-- Email log (track sent emails to avoid duplicates)
create table if not exists public.email_log (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid references public.users(id) on delete cascade,
  type            text not null,   -- 'weekly_progress', 'milestone', 'welcome', etc.
  subject         text,
  sent_at         timestamptz default now(),
  metadata        jsonb default '{}'
);

-- Session packs (purchased blocks of sessions)
create table if not exists public.session_packs (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid references public.users(id) on delete cascade,
  pack_type       text not null,   -- '5_sessions', '10_sessions', '20_sessions'
  sessions_total  integer not null,
  sessions_used   integer default 0,
  price_paid      integer,         -- in cents
  stripe_payment_intent_id text,
  purchased_at    timestamptz default now(),
  expires_at      timestamptz generated always as (purchased_at + interval '1 year') stored
);

-- School licenses
create table if not exists public.school_licenses (
  id              uuid primary key default gen_random_uuid(),
  school_id       uuid references public.schools(id) on delete cascade,
  license_type    text default 'annual' check (license_type in ('monthly','annual','multi-year')),
  max_students    integer default 200,
  max_sessions    integer default 20,
  price           integer,         -- in cents per period
  stripe_subscription_id text,
  status          text default 'active',
  starts_at       date default current_date,
  ends_at         date,
  created_at      timestamptz default now()
);

-- ─── RLS Policies ─────────────────────────────────────────────────────────────

alter table public.schools enable row level security;
alter table public.workshop_sessions enable row level security;
alter table public.session_attendance enable row level security;
alter table public.certificates enable row level security;
alter table public.share_tokens enable row level security;
alter table public.email_log enable row level security;
alter table public.session_packs enable row level security;
alter table public.school_licenses enable row level security;

-- Schools: teachers and admins can view
create policy "schools_select" on public.schools for select
  using (auth.role() = 'authenticated');
create policy "schools_admin_all" on public.schools for all
  using (exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Workshop sessions: teachers can manage their own, admins see all
create policy "sessions_select" on public.workshop_sessions for select
  using (auth.role() = 'authenticated');
create policy "sessions_teacher_insert" on public.workshop_sessions for insert
  with check (teacher_id = auth.uid() or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));
create policy "sessions_teacher_update" on public.workshop_sessions for update
  using (teacher_id = auth.uid() or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Attendance: teachers can manage
create policy "attendance_select" on public.session_attendance for select
  using (auth.role() = 'authenticated');
create policy "attendance_insert" on public.session_attendance for insert
  with check (auth.role() = 'authenticated');
create policy "attendance_update" on public.session_attendance for update
  using (auth.role() = 'authenticated');

-- Certificates: students see their own, parents see children's
create policy "certs_select" on public.certificates for select
  using (
    student_id in (select id from public.student_profiles where user_id = auth.uid() or parent_id = auth.uid())
    or exists (select 1 from public.users where id = auth.uid() and role in ('admin','teacher'))
  );
create policy "certs_insert" on public.certificates for insert with check (auth.role() = 'authenticated');

-- Share tokens: owner can manage, public read by token handled at API level
create policy "share_tokens_owner" on public.share_tokens for all
  using (student_id in (select id from public.student_profiles where user_id = auth.uid() or parent_id = auth.uid()));

-- Email log: users see own logs
create policy "email_log_select" on public.email_log for select using (user_id = auth.uid());
create policy "email_log_insert" on public.email_log for insert with check (auth.role() = 'authenticated');

-- Session packs: users see own
create policy "session_packs_select" on public.session_packs for select using (user_id = auth.uid());

-- ─── Helpful views ────────────────────────────────────────────────────────────

create or replace view public.school_session_summary as
select
  s.id as school_id,
  s.name as school_name,
  s.city,
  count(ws.id) as total_sessions,
  count(ws.id) filter (where ws.status = 'completed') as completed_sessions,
  count(ws.id) filter (where ws.status = 'scheduled') as upcoming_sessions,
  sum(sa.count) as total_students_reached,
  max(ws.session_date) as last_session_date
from public.schools s
left join public.workshop_sessions ws on ws.school_id = s.id
left join (
  select session_id, count(*) as count
  from public.session_attendance
  where attended = true
  group by session_id
) sa on sa.session_id = ws.id
group by s.id, s.name, s.city;

-- ─── Sample school data ───────────────────────────────────────────────────────

insert into public.schools (name, board, city, province, contact_name, contact_email, status) values
('Oshawa Public Elementary', 'Durham District School Board', 'Oshawa', 'ON', 'Principal Chen', 'pchen@ddsb.ca', 'active'),
('Thornton Road Public School', 'Durham District School Board', 'Oshawa', 'ON', 'Principal Okafor', 'pokafor@ddsb.ca', 'active'),
('St. Thomas Aquinas Catholic School', 'Durham Catholic District School Board', 'Whitby', 'ON', 'Vice Principal Singh', 'vsingh@dcdsb.ca', 'active'),
('Pickering Village Public School', 'Durham District School Board', 'Ajax', 'ON', 'Principal Williams', 'pwilliams@ddsb.ca', 'pending'),
('Henry Street High School', 'Durham District School Board', 'Whitby', 'ON', 'Department Head Lee', 'hlee@ddsb.ca', 'active')
on conflict do nothing;

select '✅ School portal schema created' as status,
  (select count(*) from public.schools) as schools,
  (select count(*) from public.workshop_sessions) as sessions;
