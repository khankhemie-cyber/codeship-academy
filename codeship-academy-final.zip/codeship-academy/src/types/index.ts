// ─── ENUMS ────────────────────────────────────────────────────────────────────

export type UserRole = 'parent' | 'teacher' | 'student' | 'admin'
export type ContentStatus = 'draft' | 'published' | 'archived'
export type ContentType = 'lesson' | 'project' | 'quiz'
export type Difficulty = 'beginner' | 'intermediate' | 'advanced'
export type LevelName = 'Explorers' | 'Builders' | 'Developers' | 'Engineers'
export type SessionStatus = 'not_started' | 'in_progress' | 'completed' | 'skipped' | 'needs_review'
export type SubscriptionStatus = 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid'
export type PlanName = 'trial' | 'monthly' | 'annual' | 'family' | 'teacher'

// ─── USER MODELS ──────────────────────────────────────────────────────────────

export interface User {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  role: UserRole
  locale: 'en' | 'fr'
  email_verified: boolean
  created_at: string
  updated_at: string
}

export interface StudentProfile {
  id: string
  user_id?: string
  parent_id?: string
  teacher_id?: string
  full_name: string
  avatar_emoji: string
  age?: number
  grade?: string
  level: LevelName
  xp_points: number
  streak_days: number
  last_active_at?: string
  created_at: string
  updated_at: string
}

// ─── ASSESSMENT ───────────────────────────────────────────────────────────────

export interface AssessmentData {
  name: string
  age: number
  grade: string
  experience: 'none' | 'some' | 'good'
  skills: {
    reading: number
    writing: number
    math: number
    logic: number
    focus: number
    coding: number
  }
  interests: string[]
  challenges: string[]
  challenge_notes?: string
  goals: string[]
  learning_style: string
}

export interface LearningProfile {
  id: string
  student_id: string
  assessment_id?: string
  recommended_level: LevelName
  strengths: string[]
  challenges: string[]
  goals: string[]
  recommended_mix: { lessons: number; projects: number; quizzes: number }
  engagement_tips: string[]
  weekly_pace: string
  summary: string
  ai_generated: boolean
  created_at: string
}

// ─── CURRICULUM ───────────────────────────────────────────────────────────────

export interface Lesson {
  id: string
  title: string
  slug: string
  level: LevelName
  category: string
  language?: string
  difficulty: Difficulty
  duration_minutes: number
  status: ContentStatus
  objectives: string[]
  instructions?: string
  starter_code?: string
  solution_code?: string
  tags: string[]
  prerequisites?: string[]
  thumbnail_url?: string
  order_index: number
  created_at: string
}

export interface Project {
  id: string
  title: string
  slug: string
  level: LevelName
  languages: string[]
  difficulty: Difficulty
  duration_minutes: number
  status: ContentStatus
  description: string
  instructions?: string
  expected_output?: string
  starter_code?: string
  tags: string[]
  order_index: number
  created_at: string
}

export interface Quiz {
  id: string
  title: string
  level: LevelName
  topic: string
  difficulty: Difficulty
  duration_minutes: number
  status: ContentStatus
  description: string
  pass_score: number
  tags: string[]
  questions?: QuizQuestion[]
  created_at: string
}

export interface QuizQuestion {
  id: string
  quiz_id: string
  question: string
  question_type: 'multiple_choice' | 'true_false' | 'short_answer' | 'code'
  options?: { id: string; text: string }[]
  correct_answer: string
  explanation?: string
  code_snippet?: string
  order_index: number
  points: number
}

// ─── LEARNING PLANS ───────────────────────────────────────────────────────────

export interface LearningPlan {
  id: string
  student_id: string
  created_by: string
  title: string
  weekly_goal: string
  start_date: string
  sessions_per_week: number
  session_duration: number
  focus_preference: string
  is_active: boolean
  ai_generated: boolean
  ai_tips: string[]
  estimated_xp: number
  sessions?: ScheduledSession[]
  created_at: string
}

export interface ScheduledSession {
  id: string
  plan_id: string
  student_id: string
  content_type: ContentType
  content_id: string
  content_title: string
  scheduled_date: string
  scheduled_time?: string
  duration_minutes: number
  status: SessionStatus
  xp_reward: number
  notes?: string
  completed_at?: string
}

// ─── PROGRESS ─────────────────────────────────────────────────────────────────

export interface ProgressRecord {
  id: string
  student_id: string
  content_type: ContentType
  content_id: string
  content_title?: string
  status: SessionStatus
  score?: number
  time_spent?: number
  attempts: number
  feedback?: string
  xp_earned: number
  started_at?: string
  completed_at?: string
}

export interface QuizAttempt {
  id: string
  student_id: string
  quiz_id: string
  answers: Record<string, string>
  score: number
  passed: boolean
  time_spent: number
  completed_at: string
}

// ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────────

export interface Subscription {
  id: string
  user_id: string
  stripe_subscription_id?: string
  stripe_customer_id?: string
  plan: PlanName
  status: SubscriptionStatus
  current_period_start?: string
  current_period_end?: string
  cancel_at_period_end: boolean
  trial_end?: string
  max_children: number
  max_students: number
  features: {
    ai_planner: boolean
    calendar_sync: boolean
    reports: boolean
  }
}

// ─── AI PLANNER ───────────────────────────────────────────────────────────────

export interface PlannerConfig {
  childId: string
  childName: string
  level: LevelName
  interests: string[]
  challenges: string[]
  sessionsPerWeek: number
  sessionDuration: number
  startDate: string
  focusPreference: 'balanced' | 'projects' | 'concepts'
}

export interface AIGeneratedPlan {
  planTitle: string
  weeklyGoal: string
  sessions: {
    day: string
    date: string
    time: string
    title: string
    type: ContentType
    duration: number
    description: string
    xp: number
    tags: string[]
    contentId?: string
  }[]
  tips: string[]
  estimatedXP: number
}

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

export interface Notification {
  id: string
  user_id: string
  type: string
  title: string
  message?: string
  data?: Record<string, unknown>
  read: boolean
  created_at: string
}

// ─── ACHIEVEMENTS ─────────────────────────────────────────────────────────────

export interface Achievement {
  id: string
  name: string
  description?: string
  emoji?: string
  xp_reward: number
  condition_type: string
  condition_value: number
}

export interface StudentAchievement {
  id: string
  student_id: string
  achievement_id: string
  earned_at: string
  achievement?: Achievement
}
