import Link from 'next/link'
import { Rocket, Shield } from 'lucide-react'

const EFFECTIVE_DATE = 'April 14, 2026'
const COMPANY = 'CODEship Academy Inc.'
const ADDRESS = '21 Simcoe Street South, Oshawa, Ontario, L1H 4G1, Canada'
const EMAIL = 'privacy@codeshipacademy.com'
const SUPPORT_EMAIL = 'admin@codeshipacademy.com'

export const metadata = {
  title: 'Privacy Policy',
  description: 'CODEship Academy Privacy Policy — how we collect, use, and protect your personal information under PIPEDA.',
}

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mb-10 scroll-mt-24">
      <h2 className="text-xl font-black mb-4" style={{ color: '#1E2140' }}>{title}</h2>
      <div className="space-y-4 text-sm leading-relaxed" style={{ color: '#3A3D5C' }}>
        {children}
      </div>
    </section>
  )
}

const TOC = [
  { id: 'overview',       label: '1. Overview & PIPEDA Compliance' },
  { id: 'what-we-collect', label: '2. Information We Collect' },
  { id: 'how-we-use',    label: '3. How We Use Your Information' },
  { id: 'children',      label: '4. Children\'s Privacy' },
  { id: 'sharing',       label: '5. Sharing & Disclosure' },
  { id: 'third-parties', label: '6. Third-Party Services' },
  { id: 'retention',     label: '7. Data Retention' },
  { id: 'security',      label: '8. Security' },
  { id: 'rights',        label: '9. Your Rights' },
  { id: 'cookies',       label: '10. Cookies & Tracking' },
  { id: 'transfers',     label: '11. International Transfers' },
  { id: 'changes',       label: '12. Changes to This Policy' },
  { id: 'contact',       label: '13. Contact & Complaints' },
]

export default function PrivacyPage() {
  return (
    <div className="min-h-screen" style={{ background: '#F8F9FE', fontFamily: 'Nunito, sans-serif' }}>

      {/* Header */}
      <header className="bg-white border-b" style={{ borderColor: '#E8EAF6' }}>
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 no-underline" style={{ textDecoration: 'none' }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#1E2140' }}>
              <Rocket size={18} color="#F5C518" />
            </div>
            <div>
              <div className="font-black text-sm leading-none" style={{ color: '#1E2140' }}>CODEship Academy</div>
              <div className="text-xs font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 8 }}>DREAM. CODE. ACHIEVE.</div>
            </div>
          </Link>
          <div className="flex gap-4 text-sm font-semibold" style={{ color: '#8B90B0' }}>
            <Link href="/terms" style={{ color: '#8B90B0', textDecoration: 'none' }}>Terms of Service</Link>
            <Link href="/auth/login" className="btn-primary text-xs py-2 px-4" style={{ textDecoration: 'none' }}>Sign In</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }} className="py-12 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield size={20} style={{ color: '#F5C518' }} />
            <span className="text-xs font-black uppercase tracking-widest" style={{ color: '#F5C518' }}>Privacy</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Privacy Policy</h1>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
            Effective Date: {EFFECTIVE_DATE} &nbsp;·&nbsp; Governed by PIPEDA (Canada)
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 flex gap-12">

        {/* Sidebar TOC */}
        <aside className="hidden lg:block w-64 flex-shrink-0">
          <div className="sticky top-8 rounded-2xl p-5" style={{ background: 'white', border: '1px solid #E8EAF6' }}>
            <div className="text-xs font-black uppercase tracking-widest mb-3" style={{ color: '#8B90B0' }}>Contents</div>
            <nav className="space-y-1">
              {TOC.map(item => (
                <a key={item.id} href={`#${item.id}`} className="block text-xs py-1 hover:underline" style={{ color: '#8B90B0', textDecoration: 'none' }}>
                  {item.label}
                </a>
              ))}
            </nav>
            <div className="mt-4 p-3 rounded-xl" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
              <div className="text-xs font-black mb-1" style={{ color: '#166534' }}>Our Promise</div>
              <div className="text-xs" style={{ color: '#166534' }}>We never sell your personal information. We never advertise to children.</div>
            </div>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 min-w-0">
          <div className="rounded-2xl p-8" style={{ background: 'white', border: '1px solid #E8EAF6' }}>

            {/* Summary boxes */}
            <div className="grid grid-cols-3 gap-3 mb-8">
              {[
                { icon: '🚫', title: 'No Ads', desc: 'We never show ads to children or use their data for advertising' },
                { icon: '🔒', title: 'No Selling', desc: 'We never sell personal information to third parties' },
                { icon: '🇨🇦', title: 'PIPEDA Compliant', desc: 'Governed by Canadian federal privacy law' },
              ].map(b => (
                <div key={b.title} className="rounded-xl p-3 text-center" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                  <div className="text-2xl mb-1">{b.icon}</div>
                  <div className="text-xs font-black mb-0.5" style={{ color: '#2B2D42' }}>{b.title}</div>
                  <div className="text-xs" style={{ color: '#8B90B0' }}>{b.desc}</div>
                </div>
              ))}
            </div>

            <Section id="overview" title="1. Overview & PIPEDA Compliance">
              <p>
                {COMPANY} ("CODEship Academy," "we," "us," or "our") is committed to protecting the privacy of all users of our platform, with particular care given to the privacy of children. This Privacy Policy explains how we collect, use, disclose, and safeguard personal information in connection with our Services.
              </p>
              <p>
                We are subject to the <strong>Personal Information Protection and Electronic Documents Act (PIPEDA)</strong>, Canada's federal private-sector privacy law, and applicable Ontario legislation including the <strong>Municipal Freedom of Information and Protection of Privacy Act (MFIPPA)</strong> where it applies to personal information held by school boards. We also comply with <strong>Canada's Anti-Spam Legislation (CASL)</strong> for all electronic commercial messages.
              </p>
              <p>
                PIPEDA requires us to: obtain meaningful consent before collecting personal information; limit collection to what is necessary for the stated purpose; keep information accurate and up to date; protect information with appropriate security; allow individuals to access and correct their information; and be accountable for how we handle it. This policy explains how we fulfil each of these obligations.
              </p>
            </Section>

            <Section id="what-we-collect" title="2. Information We Collect">
              <p>We collect only what we need to provide our Services. Here is what we collect and why:</p>

              <h3 className="font-black mt-4 mb-2" style={{ color: '#2B2D42' }}>2.1 Information You Provide Directly</h3>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>Account registration:</strong> Name, email address, password, role (parent/teacher/student), and preferred language (English or French).</li>
                <li><strong>Child profiles:</strong> Child's first name, age, grade, and avatar (emoji). We do not require children's last names, photos, or contact information.</li>
                <li><strong>Assessment data:</strong> Responses to our learning profile assessment, including academic interests, learning style, and self-reported challenges. This is used solely to personalise the learning experience.</li>
                <li><strong>Payment information:</strong> Billing details processed by Stripe. We do not store payment card numbers on our own servers.</li>
                <li><strong>Communications:</strong> Messages you send us for support, feedback, or other enquiries.</li>
                <li><strong>School booking information:</strong> School name, address, contact person, grade range, and session details for in-school workshop bookings.</li>
              </ul>

              <h3 className="font-black mt-4 mb-2" style={{ color: '#2B2D42' }}>2.2 Information Generated Through Use</h3>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>Learning progress:</strong> Lessons completed, time spent per lesson, quiz scores, project submissions, XP points earned, streak data, and achievement badges.</li>
                <li><strong>Code Lab submissions:</strong> Code written in the CODEship Editor or blocks created in CODEship Blocks, when saved or submitted.</li>
                <li><strong>AI interaction data:</strong> Inputs to the AI Lesson Planner and AI Tutor Chat, for the purpose of generating personalised responses. See Section 5 for how this data is handled with Anthropic.</li>
                <li><strong>Usage data:</strong> Pages visited, features used, session duration, and general interaction patterns, collected to improve our Services.</li>
              </ul>

              <h3 className="font-black mt-4 mb-2" style={{ color: '#2B2D42' }}>2.3 Information We Collect Automatically</h3>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>Device information:</strong> Browser type and version, operating system, screen resolution, and device type (desktop/mobile/tablet).</li>
                <li><strong>Log data:</strong> IP address (used for security and fraud prevention), access timestamps, and error logs. IP addresses are not associated with individual users beyond what is necessary for security purposes.</li>
                <li><strong>Cookies:</strong> Session cookies essential to platform operation, and optional preference cookies. See Section 10 for details.</li>
              </ul>
            </Section>

            <Section id="how-we-use" title="3. How We Use Your Information">
              <p>Under PIPEDA, we must identify and document the purposes for which we collect personal information before or at the time of collection. We use your information for the following purposes:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Providing and improving the Services:</strong> Delivering curriculum content, tracking progress, generating AI-powered lesson plans, running assessments, and operating the platform.</li>
                <li><strong>Personalisation:</strong> Adapting content difficulty, recommendations, and the AI tutor's responses to a student's individual profile and learning history.</li>
                <li><strong>Communication:</strong> Sending weekly progress emails to parents (with consent), transactional emails (receipts, password resets, account notifications), and service announcements. We comply with CASL requirements for commercial electronic messages.</li>
                <li><strong>Billing and account management:</strong> Processing subscription payments, managing renewals, and maintaining accurate account records.</li>
                <li><strong>Safety and security:</strong> Detecting fraud, preventing abuse, enforcing our Terms of Service, and protecting users.</li>
                <li><strong>Legal compliance:</strong> Meeting our obligations under applicable Canadian law.</li>
                <li><strong>Service improvement:</strong> Using aggregated, anonymised data to understand how users interact with the platform and to improve our curriculum and features. We do not use children's individual data for this purpose without explicit consent.</li>
              </ul>
              <p>
                We do not use personal information for purposes beyond those listed here without obtaining fresh consent.
              </p>
            </Section>

            <Section id="children" title="4. Children's Privacy">
              <p>
                The privacy of children is our highest priority. This section describes our specific practices for information collected from or about children under 18.
              </p>
              <p>
                <strong>Minimum data collection from children.</strong> For student accounts, we collect only: a first name (or chosen display name), age range, grade, selected avatar emoji, and learning progress data. We do not collect children's email addresses, phone numbers, home addresses, last names, or photographs.
              </p>
              <p>
                <strong>No advertising to children.</strong> We do not display advertisements to children. We do not build advertising profiles on children. We do not share children's personal information with advertising networks.
              </p>
              <p>
                <strong>No sale of children's data.</strong> We do not sell, rent, or trade children's personal information under any circumstances.
              </p>
              <p>
                <strong>AI and children's data.</strong> When a child interacts with our AI Tutor, the content of that interaction is sent to Anthropic's API to generate a response. Anthropic processes this data under their API Data Privacy policy. We do not send Anthropic information that would identify the specific child (such as name or email). Anthropic's API does not use API inputs to train their models by default.
              </p>
              <p>
                <strong>Parental access and control.</strong> Parents and guardians may at any time: (a) review the personal information associated with their child's account; (b) correct inaccurate information; (c) request deletion of the child's account and associated data; (d) opt out of any optional data collection. To exercise these rights, email {EMAIL}.
              </p>
              <p>
                <strong>Children under 13.</strong> We require parental consent before creating accounts for children under 13. Where a child under 13 uses our platform through a school, the school or school board is responsible for parental consent management under MFIPPA.
              </p>
              <p>
                <strong>Public leaderboard.</strong> The leaderboard feature displays student first names and XP scores. Participation is optional and can be set to "private" in account settings. Parents can disable leaderboard visibility for their child at any time.
              </p>
            </Section>

            <Section id="sharing" title="5. Sharing & Disclosure">
              <p>We do not sell your personal information. We share personal information only in the following limited circumstances:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Service providers:</strong> We share information with carefully selected third-party service providers who help us operate the platform (listed in Section 6). These providers are contractually required to protect your information and may only use it to provide services to us.</li>
                <li><strong>Educational authorities:</strong> For school accounts, we may share class-level progress data (not individual student data beyond what the school provided) with the teacher and school administrator who set up the class.</li>
                <li><strong>Parent/guardian access:</strong> Progress data for student accounts is visible to the parent or guardian who created the child's profile.</li>
                <li><strong>Legal requirements:</strong> We may disclose personal information where required by law, court order, or valid government request, or where necessary to prevent fraud or protect safety.</li>
                <li><strong>Business transfers:</strong> In the event of a merger, acquisition, or sale of substantially all assets, personal information may be transferred to the acquiring entity. We will provide notice before such a transfer occurs and before the new entity's privacy policy applies to your information.</li>
                <li><strong>With your consent:</strong> For any sharing not described above, we will seek your explicit consent first.</li>
              </ul>
            </Section>

            <Section id="third-parties" title="6. Third-Party Services">
              <p>We use the following third-party services to operate our platform. Each is linked to their privacy policy:</p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse mt-2">
                  <thead>
                    <tr style={{ background: '#F8F9FE' }}>
                      {['Provider', 'Purpose', 'Data Shared', 'Location'].map(h => (
                        <th key={h} className="text-left p-3 font-black border" style={{ borderColor: '#E8EAF6', color: '#2B2D42' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Supabase', 'Database & authentication', 'User accounts, progress data', 'USA (AWS)'],
                      ['Anthropic', 'AI features (Claude API)', 'AI tutor inputs (anonymised)', 'USA'],
                      ['Stripe', 'Payment processing', 'Billing information only', 'USA'],
                      ['Resend', 'Transactional email', 'Email address, name', 'USA'],
                      ['Vercel', 'Platform hosting', 'Usage logs, IP address', 'USA'],
                    ].map(([provider, purpose, data, location], i) => (
                      <tr key={provider} style={{ background: i % 2 === 0 ? 'white' : '#F8F9FE' }}>
                        <td className="p-3 border font-semibold" style={{ borderColor: '#E8EAF6', color: '#2B2D42' }}>{provider}</td>
                        <td className="p-3 border" style={{ borderColor: '#E8EAF6', color: '#3A3D5C' }}>{purpose}</td>
                        <td className="p-3 border" style={{ borderColor: '#E8EAF6', color: '#3A3D5C' }}>{data}</td>
                        <td className="p-3 border" style={{ borderColor: '#E8EAF6', color: '#3A3D5C' }}>{location}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs italic mt-2" style={{ color: '#B0B4D0' }}>
                All providers who process personal data on our behalf are bound by Data Processing Agreements requiring PIPEDA-consistent protections.
              </p>
            </Section>

            <Section id="retention" title="7. Data Retention">
              <p>We retain personal information only as long as necessary for the purposes for which it was collected:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>Active accounts:</strong> Retained for the duration of the account plus 90 days after account deletion (to allow for account recovery).</li>
                <li><strong>Learning progress data:</strong> Retained while the account is active. Deleted within 90 days of account deletion.</li>
                <li><strong>Payment records:</strong> Retained for 7 years as required by Canadian tax law.</li>
                <li><strong>AI interaction logs:</strong> Not retained by CODEship Academy beyond the session. Anthropic's retention practices for API inputs are governed by their API Data Privacy policy.</li>
                <li><strong>Backup data:</strong> May be retained in encrypted backups for up to 90 days after deletion from live systems.</li>
                <li><strong>Anonymised/aggregated data:</strong> May be retained indefinitely, as it cannot reasonably be used to identify individuals.</li>
              </ul>
            </Section>

            <Section id="security" title="8. Security">
              <p>
                We implement appropriate technical and organisational measures to protect personal information against unauthorised access, loss, destruction, or alteration. These measures include:
              </p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>All data transmitted to and from our platform is encrypted using TLS (HTTPS)</li>
                <li>Database access is controlled by Row Level Security (RLS) policies that enforce role-based access</li>
                <li>Passwords are hashed using industry-standard algorithms; we never store plaintext passwords</li>
                <li>Payment data is handled entirely by Stripe and is never stored on our servers</li>
                <li>API keys and sensitive credentials are stored as environment variables, not in code</li>
                <li>Access to production systems is restricted to authorised personnel</li>
                <li>We conduct regular reviews of our security practices</li>
              </ul>
              <p>
                No system is completely secure. In the event of a data breach affecting your personal information, we will notify you and the appropriate Canadian authorities in accordance with PIPEDA's mandatory breach reporting requirements.
              </p>
            </Section>

            <Section id="rights" title="9. Your Rights">
              <p>Under PIPEDA and applicable Canadian law, you have the following rights regarding your personal information:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Right of access:</strong> You may request a copy of the personal information we hold about you (or your child). We will respond within 30 days.</li>
                <li><strong>Right to correction:</strong> You may request correction of inaccurate or incomplete information. Most information can be updated directly in your account settings.</li>
                <li><strong>Right to withdraw consent:</strong> Where we rely on consent to process personal information, you may withdraw that consent at any time. Withdrawal will not affect prior processing.</li>
                <li><strong>Right to deletion:</strong> You may request deletion of your account and personal information, subject to legal retention requirements. We will complete deletion within 90 days.</li>
                <li><strong>Right to opt out of communications:</strong> You may unsubscribe from marketing and digest emails at any time via the unsubscribe link in each email or through your account settings.</li>
                <li><strong>Right to complain:</strong> You have the right to lodge a complaint with the Office of the Privacy Commissioner of Canada (OPC) if you believe we have not handled your personal information appropriately.</li>
              </ul>
              <p>
                To exercise any of these rights, contact our Privacy Officer at {EMAIL}.
              </p>
            </Section>

            <Section id="cookies" title="10. Cookies & Tracking">
              <p>We use cookies and similar technologies on our platform. Here is what we use and why:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Essential cookies:</strong> Required for the platform to function. These include your authentication session, your language preference, and security tokens. You cannot opt out of essential cookies without losing access to the platform.</li>
                <li><strong>Preference cookies:</strong> Remember your settings, such as your chosen language (English/French) and dashboard layout preferences.</li>
                <li><strong>Analytics:</strong> We use anonymised, aggregated usage data to understand how the platform is used. We do not use third-party advertising trackers or social media pixels.</li>
              </ul>
              <p>
                We do not use cross-site tracking cookies. We do not participate in advertising networks. Our cookie use is limited to what is necessary to operate and improve our Services.
              </p>
            </Section>

            <Section id="transfers" title="11. International Data Transfers">
              <p>
                Some of our service providers (listed in Section 6) are located in the United States. When we transfer personal information outside of Canada, we ensure that it receives a comparable level of protection through contractual safeguards consistent with PIPEDA's cross-border transfer requirements.
              </p>
              <p>
                By using our Services, you acknowledge that your personal information may be transferred to and processed in the United States, subject to U.S. law. We take steps to ensure that such transfers are made with appropriate protections in place.
              </p>
              <p>
                Users in Quebec: We comply with Quebec's Act Respecting the Protection of Personal Information in the Private Sector (Law 25) and conduct Privacy Impact Assessments (PIA) before any new cross-border data transfer involving Quebec residents.
              </p>
            </Section>

            <Section id="changes" title="12. Changes to This Policy">
              <p>
                We may update this Privacy Policy from time to time. When we make material changes that affect how we handle your personal information, we will notify you by email and by posting a prominent notice on our platform at least 14 days before changes take effect.
              </p>
              <p>
                The "Effective Date" at the top of this page shows when this Policy was last updated. Your continued use of our Services after changes take effect constitutes your acceptance of the updated Policy.
              </p>
            </Section>

            <Section id="contact" title="13. Contact & Complaints">
              <p>Our Privacy Officer is responsible for ensuring CODEship Academy's compliance with PIPEDA and this Privacy Policy.</p>
              <div className="rounded-xl p-4 mt-2" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                <div className="font-black mb-1" style={{ color: '#2B2D42' }}>Privacy Officer — {COMPANY}</div>
                <div style={{ color: '#3A3D5C' }}>{ADDRESS}</div>
                <div className="mt-2">
                  <div>Privacy enquiries: <a href={`mailto:${EMAIL}`} style={{ color: '#F5C518', fontWeight: 700 }}>{EMAIL}</a></div>
                  <div>General support: <a href={`mailto:${SUPPORT_EMAIL}`} style={{ color: '#F5C518', fontWeight: 700 }}>{SUPPORT_EMAIL}</a></div>
                </div>
              </div>
              <p className="mt-4">
                If you are not satisfied with our response to a privacy concern, you may contact the <strong>Office of the Privacy Commissioner of Canada</strong>:
              </p>
              <div className="rounded-xl p-4 mt-2" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                <div className="font-black mb-1" style={{ color: '#2B2D42' }}>Office of the Privacy Commissioner of Canada</div>
                <div style={{ color: '#3A3D5C' }}>30 Victoria Street, Gatineau, Quebec, K1A 1H3</div>
                <div className="mt-1"><a href="https://www.priv.gc.ca" style={{ color: '#F5C518', fontWeight: 700 }}>www.priv.gc.ca</a> &nbsp;·&nbsp; 1-800-282-1376</div>
              </div>
              <p className="text-xs italic mt-4" style={{ color: '#B0B4D0' }}>
                This Privacy Policy was prepared by CODEship Academy to reflect our commitment to PIPEDA compliance. It does not constitute legal advice. We recommend consulting a qualified privacy lawyer for advice specific to your situation.
              </p>
            </Section>

          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t py-8 px-6 text-center" style={{ borderColor: '#E8EAF6', background: 'white' }}>
        <div className="text-xs font-semibold mb-2" style={{ color: '#8B90B0' }}>
          <span style={{ color: '#F5C518', fontWeight: 800 }}>CODEship</span> Academy · © {new Date().getFullYear()} {COMPANY}
        </div>
        <div className="flex items-center justify-center gap-4 text-xs" style={{ color: '#B0B4D0' }}>
          <Link href="/terms" style={{ color: '#8B90B0', textDecoration: 'none' }}>Terms of Service</Link>
          <span>·</span>
          <Link href="/privacy" style={{ color: '#8B90B0', textDecoration: 'none' }}>Privacy Policy</Link>
          <span>·</span>
          <a href={`mailto:${SUPPORT_EMAIL}`} style={{ color: '#8B90B0', textDecoration: 'none' }}>Contact</a>
        </div>
      </footer>
    </div>
  )
}
