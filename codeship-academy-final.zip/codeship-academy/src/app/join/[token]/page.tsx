'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Rocket, CheckCircle, RefreshCw, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function JoinPage() {
  const { token } = useParams<{ token: string }>()
  const router = useRouter()
  const supabase = createClient()
  const [status, setStatus] = useState<'loading' | 'joining' | 'success' | 'error' | 'needs-auth'>('loading')
  const [message, setMessage] = useState('')
  const [className, setClassName] = useState('')

  useEffect(() => {
    const attempt = async () => {
      // Check if logged in
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        // Save token to localStorage, redirect to login
        localStorage.setItem('pending_invite_token', token)
        setStatus('needs-auth')
        return
      }

      // Try to join
      setStatus('joining')
      try {
        const res = await fetch('/api/classes/join', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token }),
        })
        const data = await res.json()
        if (data.success) {
          setClassName(data.className)
          setMessage(data.message)
          setStatus('success')
          setTimeout(() => router.push('/dashboard'), 3000)
        } else {
          setMessage(data.error || 'Could not join class.')
          setStatus('error')
        }
      } catch {
        setMessage('Something went wrong. Please try again.')
        setStatus('error')
      }
    }

    attempt()
  }, [token])

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3" style={{ background: '#F5C518' }}>
            <Rocket size={26} color="#1E2140" />
          </div>
          <div className="text-white font-black text-xl">CODEship Academy</div>
          <div className="text-xs font-bold tracking-widest mt-1" style={{ color: '#F5C518' }}>DREAM. CODE. ACHIEVE.</div>
        </div>

        <div className="card p-8 text-center">
          {status === 'loading' || status === 'joining' ? (
            <>
              <RefreshCw size={36} className="animate-spin mx-auto mb-4" style={{ color: '#F5C518' }} />
              <h2 className="text-xl font-black mb-2" style={{ color: '#2B2D42' }}>
                {status === 'loading' ? 'Checking invite...' : 'Joining class...'}
              </h2>
              <p className="text-sm" style={{ color: '#8B90B0' }}>Just a moment!</p>
            </>
          ) : status === 'needs-auth' ? (
            <>
              <div className="text-4xl mb-4">🎉</div>
              <h2 className="text-xl font-black mb-2" style={{ color: '#2B2D42' }}>You've been invited!</h2>
              <p className="text-sm mb-6" style={{ color: '#8B90B0' }}>
                Sign in or create a free account to join the class. The invite will be applied automatically.
              </p>
              <div className="space-y-3">
                <Link href={`/auth/login?redirect=/join/${token}`} className="btn-primary w-full py-3.5 text-sm" style={{ textDecoration: 'none', display: 'flex', justifyContent: 'center' }}>
                  Sign In to Join
                </Link>
                <Link href={`/auth/signup?redirect=/join/${token}`} className="btn-outline w-full py-3.5 text-sm" style={{ textDecoration: 'none', display: 'flex', justifyContent: 'center' }}>
                  Create Free Account
                </Link>
              </div>
            </>
          ) : status === 'success' ? (
            <>
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#22C55E18' }}>
                <CheckCircle size={32} style={{ color: '#22C55E' }} />
              </div>
              <h2 className="text-xl font-black mb-2" style={{ color: '#2B2D42' }}>You're in! 🎉</h2>
              <p className="text-sm mb-1" style={{ color: '#2B2D42' }}>
                Welcome to <strong>{className}</strong>
              </p>
              <p className="text-sm mb-6" style={{ color: '#8B90B0' }}>Redirecting to your dashboard...</p>
              <Link href="/dashboard" className="btn-primary text-sm py-3 px-8" style={{ textDecoration: 'none' }}>
                Go to Dashboard
              </Link>
            </>
          ) : (
            <>
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#FEF2F2' }}>
                <AlertCircle size={28} style={{ color: '#EF4444' }} />
              </div>
              <h2 className="text-xl font-black mb-2" style={{ color: '#2B2D42' }}>Couldn't join</h2>
              <p className="text-sm mb-6" style={{ color: '#8B90B0' }}>{message}</p>
              <div className="space-y-2">
                <Link href="/dashboard" className="btn-navy w-full py-3 text-sm" style={{ textDecoration: 'none', display: 'flex', justifyContent: 'center' }}>
                  Go to Dashboard
                </Link>
                <Link href="/dashboard/classes" className="btn-outline w-full py-3 text-sm" style={{ textDecoration: 'none', display: 'flex', justifyContent: 'center' }}>
                  Enter Class Code Instead
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
