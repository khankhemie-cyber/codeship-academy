import type { Metadata } from 'next'
import { Nunito } from 'next/font/google'
import { NextIntlClientProvider } from 'next-intl'
import { getLocale, getMessages } from 'next-intl/server'
import './globals.css'

const nunito = Nunito({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800', '900'],
  variable: '--font-nunito',
})

export const metadata: Metadata = {
  title: { default: 'CODEship Academy', template: '%s | CODEship Academy' },
  description: 'Personalized coding education for every child from Kindergarten to Grade 8. Dream. Code. Achieve.',
  keywords: ['coding for kids', 'learn to code', 'children programming', 'online coding school', 'Ontario coding', 'apprentissage codage enfants', 'Ontario'],
  authors: [{ name: 'CODEship Academy' }],
  openGraph: {
    type: 'website',
    siteName: 'CODEship Academy',
    title: 'CODEship Academy — Every Child Can Code',
    description: 'AI-powered personalized coding education for Grades K–8',
  },
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getLocale()
  const messages = await getMessages()

  return (
    <html lang={locale} className={nunito.variable}>
      <body className="font-sans antialiased" style={{ background: '#F8F9FE' }}>
        <NextIntlClientProvider locale={locale} messages={messages}>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  )
}
