import Link from 'next/link'
import { Rocket, Shield, FileText, Mail } from 'lucide-react'

const EFFECTIVE_DATE = 'April 14, 2026'
const COMPANY = 'CODEship Academy Inc.'
const ADDRESS = '21 Simcoe Street South, Oshawa, Ontario, L1H 4G1, Canada'
const EMAIL = 'legal@codeshipacademy.com'
const SUPPORT_EMAIL = 'admin@codeshipacademy.com'
const WEBSITE = 'https://app.codeshipacademy.com'

export const metadata = {
  title: 'Terms of Service',
  description: 'CODEship Academy Terms of Service — the agreement that governs your use of our platform.',
}

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mb-10 scroll-mt-24">
      <h2 className="text-xl font-black mb-4" style={{ color: '#1E2140' }}>{title}</h2>
      <div className="space-y-4 text-sm leading-relaxed" style={{ color: '#3A3D5C' }}>
        {children}
      </div>
    </section>
  )
}

const TOC = [
  { id: 'acceptance',        label: '1. Acceptance of Terms' },
  { id: 'eligibility',       label: '2. Eligibility & Account Registration' },
  { id: 'services',          label: '3. Description of Services' },
  { id: 'subscriptions',     label: '4. Subscriptions & Billing' },
  { id: 'children',          label: '5. Children\'s Accounts & Parental Consent' },
  { id: 'conduct',           label: '6. Acceptable Use' },
  { id: 'ip',                label: '7. Intellectual Property' },
  { id: 'ai',                label: '8. AI-Powered Features' },
  { id: 'schools',           label: '9. School & Educator Accounts' },
  { id: 'disclaimers',       label: '10. Disclaimers & Limitation of Liability' },
  { id: 'termination',       label: '11. Termination' },
  { id: 'governing-law',     label: '12. Governing Law & Disputes' },
  { id: 'changes',           label: '13. Changes to These Terms' },
  { id: 'contact',           label: '14. Contact Us' },
]

export default function TermsPage() {
  return (
    <div className="min-h-screen" style={{ background: '#F8F9FE', fontFamily: 'Nunito, sans-serif' }}>

      {/* Header */}
      <header className="bg-white border-b" style={{ borderColor: '#E8EAF6' }}>
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 no-underline" style={{ textDecoration: 'none' }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#1E2140' }}>
              <Rocket size={18} color="#F5C518" />
            </div>
            <div>
              <div className="font-black text-sm leading-none" style={{ color: '#1E2140' }}>CODEship Academy</div>
              <div className="text-xs font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 8 }}>DREAM. CODE. ACHIEVE.</div>
            </div>
          </Link>
          <div className="flex gap-4 text-sm font-semibold" style={{ color: '#8B90B0' }}>
            <Link href="/privacy" style={{ color: '#8B90B0', textDecoration: 'none' }}>Privacy Policy</Link>
            <Link href="/auth/login" className="btn-primary text-xs py-2 px-4" style={{ textDecoration: 'none' }}>Sign In</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }} className="py-12 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <FileText size={20} style={{ color: '#F5C518' }} />
            <span className="text-xs font-black uppercase tracking-widest" style={{ color: '#F5C518' }}>Legal</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Terms of Service</h1>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
            Effective Date: {EFFECTIVE_DATE} &nbsp;·&nbsp; Jurisdiction: Ontario, Canada
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 flex gap-12">

        {/* Sidebar TOC */}
        <aside className="hidden lg:block w-64 flex-shrink-0">
          <div className="sticky top-8 rounded-2xl p-5" style={{ background: 'white', border: '1px solid #E8EAF6' }}>
            <div className="text-xs font-black uppercase tracking-widest mb-3" style={{ color: '#8B90B0' }}>Contents</div>
            <nav className="space-y-1">
              {TOC.map(item => (
                <a key={item.id} href={`#${item.id}`} className="block text-xs py-1 hover:underline" style={{ color: '#8B90B0', textDecoration: 'none' }}>
                  {item.label}
                </a>
              ))}
            </nav>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 min-w-0">
          <div className="rounded-2xl p-8" style={{ background: 'white', border: '1px solid #E8EAF6' }}>

            {/* Preamble */}
            <div className="rounded-xl p-4 mb-8 text-sm" style={{ background: '#FFFBEB', border: '1px solid #F5C51840' }}>
              <strong style={{ color: '#2B2D42' }}>Plain-language summary:</strong>{' '}
              <span style={{ color: '#3A3D5C' }}>These Terms govern your use of CODEship Academy. By creating an account or using our services, you agree to these Terms. If you are creating an account for a child under 18, you are agreeing on their behalf. Please read the children's section carefully.</span>
            </div>

            <Section id="acceptance" title="1. Acceptance of Terms">
              <p>
                These Terms of Service ("Terms") constitute a legally binding agreement between you ("User," "you," or "your") and {COMPANY} ("CODEship Academy," "we," "us," or "our"), a corporation incorporated under the laws of Ontario, Canada, with its principal place of business at {ADDRESS}.
              </p>
              <p>
                By accessing or using the CODEship Academy platform — including our website at {WEBSITE}, our mobile applications, our in-school workshop program, and all related services (collectively, the "Services") — you confirm that you have read, understood, and agree to be bound by these Terms and our Privacy Policy, which is incorporated by reference.
              </p>
              <p>
                If you do not agree to these Terms, you must not access or use our Services. If you are entering into these Terms on behalf of an organisation (such as a school or school board), you represent that you have authority to bind that organisation.
              </p>
            </Section>

            <Section id="eligibility" title="2. Eligibility & Account Registration">
              <p>
                <strong>Age requirements.</strong> Our Services are designed for use by children aged 5–16 (Kindergarten to Grade 8). To create a parent or teacher account, you must be at least 18 years of age. Students under 18 may only use our platform through an account created by a parent, guardian, or authorised educator. We do not knowingly permit children to create their own accounts without adult involvement.
              </p>
              <p>
                <strong>Account accuracy.</strong> You agree to provide accurate, current, and complete information when creating an account and to keep that information updated. You are responsible for maintaining the confidentiality of your account credentials and for all activity that occurs under your account.
              </p>
              <p>
                <strong>One account per user.</strong> You may not create multiple accounts or use another person's account without permission. Accounts are non-transferable.
              </p>
              <p>
                <strong>Student accounts.</strong> Student accounts may be created by a parent/guardian who registers and adds a child profile, by a teacher who creates a class and shares a class code, or by a student who enters a class code during registration (with parental consent acknowledged during signup). By proceeding with student account creation, you represent that you have obtained appropriate parental consent where required.
              </p>
            </Section>

            <Section id="services" title="3. Description of Services">
              <p>CODEship Academy provides the following services, subject to your subscription plan:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Online learning platform:</strong> Curriculum-aligned coding lessons, projects, quizzes, and assessments for Grades K–8, organised across four levels (Explorers, Builders, Developers, Engineers).</li>
                <li><strong>AI-powered features:</strong> An AI lesson planner, a learning profile assessment, an in-lesson AI tutor, and post-quiz feedback, all powered by Anthropic's Claude AI model.</li>
                <li><strong>Code Lab environments:</strong> CODEship Blocks (visual block-based coding) and CODEship Editor (live HTML/CSS/JavaScript/Python coding environment).</li>
                <li><strong>School program:</strong> In-person 90-minute coding workshops delivered at schools in Ontario by CODEship Academy instructors.</li>
                <li><strong>School portal:</strong> A dashboard for educators to book sessions, track attendance, and generate impact reports.</li>
                <li><strong>Class management:</strong> Tools for teachers to create classes, generate class codes, create invite links, and monitor student progress.</li>
                <li><strong>Progress tracking:</strong> XP points, streak tracking, achievement badges, mastery tracking, and shareable progress certificates.</li>
              </ul>
              <p>
                We reserve the right to modify, suspend, or discontinue any feature of our Services at any time with reasonable notice. We will provide at least 30 days' notice before discontinuing a material feature that is core to your subscription.
              </p>
            </Section>

            <Section id="subscriptions" title="4. Subscriptions & Billing">
              <p>
                <strong>Free trial.</strong> New accounts receive a 14-day free trial of our paid features. No payment information is required to start a trial. At the end of the trial period, access to paid features will be restricted unless you subscribe.
              </p>
              <p>
                <strong>Subscription plans.</strong> We offer several subscription tiers for families, educators, and schools, with pricing available at {WEBSITE}/dashboard/subscription. All prices are in Canadian dollars (CAD) unless stated otherwise, and are subject to applicable taxes including HST/GST.
              </p>
              <p>
                <strong>Automatic renewal.</strong> Subscriptions renew automatically at the end of each billing period unless you cancel before the renewal date. You will receive an email reminder at least 7 days before your subscription renews. You may cancel at any time through your account's Billing settings or by contacting us at {SUPPORT_EMAIL}.
              </p>
              <p>
                <strong>Refunds.</strong> We offer a 7-day refund on new subscriptions if you are not satisfied. To request a refund, contact us at {SUPPORT_EMAIL} within 7 days of your initial payment. Renewals are generally non-refundable except where required by applicable law. We reserve the right to grant refunds at our discretion in cases of technical failure or exceptional circumstances.
              </p>
              <p>
                <strong>Session packs.</strong> One-time purchases of in-school workshop session packs are non-refundable once sessions have been booked and confirmed. Unbooked session credits are valid for 12 months from the purchase date.
              </p>
              <p>
                <strong>School licences.</strong> School and school board licences are governed by a separate School Services Agreement. In the event of conflict between these Terms and a School Services Agreement, the School Services Agreement prevails.
              </p>
              <p>
                <strong>Payment processing.</strong> Payment processing is handled by Stripe, Inc. By providing payment information, you authorise us to charge your payment method for the amounts due. Your payment information is stored and processed by Stripe and is not stored on our own servers. Stripe's privacy policy and terms apply to payment data.
              </p>
              <p>
                <strong>Price changes.</strong> We reserve the right to change our subscription prices with at least 30 days' written notice. Price changes will not affect your current billing period; they will take effect at your next renewal.
              </p>
            </Section>

            <Section id="children" title="5. Children's Accounts & Parental Consent">
              <p>
                CODEship Academy takes the privacy and safety of children very seriously. This section should be read carefully by parents and guardians.
              </p>
              <p>
                <strong>Parental responsibility.</strong> Parents and guardians who create accounts for children are responsible for their child's use of the platform and for ensuring that such use is appropriate. By creating a child profile, you consent to the collection and use of your child's information as described in our Privacy Policy.
              </p>
              <p>
                <strong>Children's data.</strong> We collect limited personal information from children only for the purpose of delivering our educational services. We do not sell children's personal information. We do not display advertising to children. We do not use children's data to build advertising profiles. For full details, see our Privacy Policy.
              </p>
              <p>
                <strong>Consent for children under 13.</strong> In compliance with Canada's Personal Information Protection and Electronic Documents Act (PIPEDA) and applicable provincial legislation, we require verifiable parental or guardian consent before collecting, using, or disclosing personal information from children under 13 years of age. By creating a student profile for a child under 13, you represent that you are the parent or legal guardian of that child and consent to these Terms and our Privacy Policy on their behalf.
              </p>
              <p>
                <strong>Teacher-created student accounts.</strong> Where a teacher creates student accounts using a class code system, the school or school board is responsible for ensuring that appropriate parental consent has been obtained in accordance with applicable provincial privacy legislation, including the Municipal Freedom of Information and Protection of Privacy Act (MFIPPA) in Ontario.
              </p>
              <p>
                <strong>Removing a child's account.</strong> Parents may request the deletion of a child's account and associated data at any time by emailing {EMAIL}. We will respond within 30 days.
              </p>
            </Section>

            <Section id="conduct" title="6. Acceptable Use">
              <p>You agree to use our Services only for lawful purposes and in accordance with these Terms. You agree not to:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Use the Services in any way that violates applicable law or regulation, including Canadian federal and Ontario provincial law</li>
                <li>Upload, post, or transmit content that is harmful, abusive, discriminatory, defamatory, or otherwise objectionable</li>
                <li>Attempt to gain unauthorised access to our systems, other user accounts, or our platform infrastructure</li>
                <li>Use automated tools, bots, scrapers, or scripts to access the Services without our written permission</li>
                <li>Reverse engineer, decompile, or attempt to extract source code from our platform</li>
                <li>Reproduce, redistribute, sell, or sublicense our curriculum content or platform features without express written authorisation</li>
                <li>Use the Services to send unsolicited communications (spam)</li>
                <li>Misrepresent your identity or affiliation with any person or organisation</li>
                <li>Use a student account to gain access to features intended for adults</li>
                <li>Share account credentials with unauthorised persons</li>
              </ul>
              <p>
                We reserve the right to investigate violations of these rules and to suspend or terminate accounts where violations are found. We may report illegal activity to appropriate law enforcement authorities.
              </p>
            </Section>

            <Section id="ip" title="7. Intellectual Property">
              <p>
                <strong>Our content.</strong> All curriculum content, lesson materials, project templates, quiz questions, code examples, design elements, trademarks, logos, and the CODEship Academy brand are owned by or licensed to {COMPANY} and are protected by Canadian copyright law and applicable international intellectual property treaties. You may not copy, reproduce, distribute, or create derivative works from our content without express written permission.
              </p>
              <p>
                <strong>Your content.</strong> When you submit projects, code, or other creative work through our platform ("User Content"), you retain ownership of that work. By submitting User Content, you grant CODEship Academy a non-exclusive, royalty-free, worldwide licence to use, display, and reproduce your User Content solely for the purpose of operating and improving our Services, including displaying your work to teachers and parents who have authority over your account.
              </p>
              <p>
                <strong>Feedback.</strong> If you provide us with feedback, suggestions, or ideas, you grant us the right to use that feedback without restriction or compensation to you.
              </p>
              <p>
                <strong>Open source.</strong> Certain components of our platform incorporate open-source software. These components are used in accordance with their respective licences.
              </p>
            </Section>

            <Section id="ai" title="8. AI-Powered Features">
              <p>
                Our platform uses artificial intelligence, including Anthropic's Claude AI model, to power features including the AI Lesson Planner, Learning Profile Assessment, AI Tutor Chat, and Quiz Feedback. By using these features, you acknowledge and agree to the following:
              </p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li><strong>AI outputs are not guarantees.</strong> AI-generated lesson plans, assessments, and feedback are tools to support learning — they are not professional educational assessments or guaranteed to be accurate in all cases. They should be reviewed by a parent or educator.</li>
                <li><strong>AI tutor limitations.</strong> The AI Tutor is designed to guide and hint, not to complete assignments for students. It is not a substitute for qualified human instruction.</li>
                <li><strong>Data use for AI.</strong> Your inputs to AI features (such as assessment responses and questions asked to the tutor) are processed by Anthropic's API. We do not use your data to train AI models without your explicit consent. See our Privacy Policy for details.</li>
                <li><strong>No medical or therapeutic advice.</strong> Our AI features are educational tools only. They are not medical, psychological, or therapeutic advice.</li>
              </ul>
            </Section>

            <Section id="schools" title="9. School & Educator Accounts">
              <p>
                <strong>Educator responsibilities.</strong> Teachers and school administrators who use our platform are responsible for ensuring that their use complies with applicable privacy legislation, including PIPEDA and MFIPPA, and with their school board's policies regarding student data and technology use.
              </p>
              <p>
                <strong>School program workshops.</strong> In-school workshops are subject to our School Program Terms, which are provided separately upon booking. Key provisions include: workshops are conducted by CODEship Academy-trained instructors; schools are responsible for providing a suitable classroom space and supervision; cancellations with less than 48 hours' notice may result in a session credit rather than a refund.
              </p>
              <p>
                <strong>Impact data.</strong> Schools that use our portal consent to our collection and display of aggregate session and attendance data for the purpose of generating impact reports. This data does not include personally identifiable student information beyond what is necessary to track attendance.
              </p>
            </Section>

            <Section id="disclaimers" title="10. Disclaimers & Limitation of Liability">
              <p>
                <strong>Services provided "as is."</strong> To the maximum extent permitted by applicable law, our Services are provided "as is" and "as available" without warranties of any kind, either express or implied, including without limitation implied warranties of merchantability, fitness for a particular purpose, or non-infringement.
              </p>
              <p>
                <strong>No guarantee of outcomes.</strong> We do not guarantee that use of our platform will result in specific educational outcomes, improved grades, or career readiness.
              </p>
              <p>
                <strong>Limitation of liability.</strong> To the maximum extent permitted by applicable Canadian law, CODEship Academy's total liability to you for any claim arising from or related to these Terms or our Services shall not exceed the greater of (a) the total amount you paid to us in the 12 months preceding the claim, or (b) CAD $100.00. We are not liable for indirect, incidental, special, consequential, or punitive damages.
              </p>
              <p>
                <strong>Consumer protection.</strong> Nothing in these Terms limits your rights under applicable Canadian consumer protection legislation, including the Ontario Consumer Protection Act, 2002.
              </p>
            </Section>

            <Section id="termination" title="11. Termination">
              <p>
                <strong>By you.</strong> You may close your account at any time by contacting us at {SUPPORT_EMAIL} or through your account settings. Upon termination, you will lose access to the Services and any content associated with your account. We will retain and delete your data in accordance with our Privacy Policy and applicable law.
              </p>
              <p>
                <strong>By us.</strong> We may suspend or terminate your account immediately if we determine, in our reasonable discretion, that you have violated these Terms, engaged in fraudulent activity, or if required to do so by law. We will provide notice where practicable.
              </p>
              <p>
                <strong>Effect of termination.</strong> Upon termination, your right to use the Services ceases immediately. Provisions of these Terms that by their nature should survive termination shall survive, including but not limited to intellectual property, disclaimers, and limitation of liability.
              </p>
            </Section>

            <Section id="governing-law" title="12. Governing Law & Disputes">
              <p>
                These Terms and any disputes arising from them are governed by the laws of the Province of Ontario and the federal laws of Canada applicable therein, without regard to conflict of law principles.
              </p>
              <p>
                Any dispute that cannot be resolved through good-faith negotiation shall be submitted to the exclusive jurisdiction of the courts of the Province of Ontario, sitting in the City of Oshawa or Toronto.
              </p>
              <p>
                <strong>Informal resolution first.</strong> Before commencing any legal action, you agree to contact us at {EMAIL} and attempt to resolve the dispute informally for at least 30 days.
              </p>
            </Section>

            <Section id="changes" title="13. Changes to These Terms">
              <p>
                We may update these Terms from time to time to reflect changes in our Services, applicable law, or business practices. When we make material changes, we will notify you by email and by posting a prominent notice on our platform at least 14 days before the changes take effect.
              </p>
              <p>
                Your continued use of the Services after the effective date of updated Terms constitutes your acceptance of those Terms. If you do not agree with the updated Terms, you must stop using the Services and may request account deletion.
              </p>
              <p>
                The "Effective Date" at the top of this page indicates when these Terms were last updated.
              </p>
            </Section>

            <Section id="contact" title="14. Contact Us">
              <p>If you have questions about these Terms, please contact us:</p>
              <div className="rounded-xl p-4 mt-2" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                <div className="font-black mb-1" style={{ color: '#2B2D42' }}>{COMPANY}</div>
                <div style={{ color: '#3A3D5C' }}>{ADDRESS}</div>
                <div className="mt-2">
                  <div>Legal enquiries: <a href={`mailto:${EMAIL}`} style={{ color: '#F5C518', fontWeight: 700 }}>{EMAIL}</a></div>
                  <div>General support: <a href={`mailto:${SUPPORT_EMAIL}`} style={{ color: '#F5C518', fontWeight: 700 }}>{SUPPORT_EMAIL}</a></div>
                </div>
              </div>
              <p className="text-xs mt-4 italic" style={{ color: '#B0B4D0' }}>
                Note: These Terms have been prepared by CODEship Academy for general guidance. They do not constitute legal advice. We recommend consulting a qualified Ontario lawyer for advice specific to your situation.
              </p>
            </Section>

          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t py-8 px-6 text-center" style={{ borderColor: '#E8EAF6', background: 'white' }}>
        <div className="text-xs font-semibold mb-2" style={{ color: '#8B90B0' }}>
          <span style={{ color: '#F5C518', fontWeight: 800 }}>CODEship</span> Academy · © {new Date().getFullYear()} {COMPANY}
        </div>
        <div className="flex items-center justify-center gap-4 text-xs" style={{ color: '#B0B4D0' }}>
          <Link href="/terms" style={{ color: '#8B90B0', textDecoration: 'none' }}>Terms of Service</Link>
          <span>·</span>
          <Link href="/privacy" style={{ color: '#8B90B0', textDecoration: 'none' }}>Privacy Policy</Link>
          <span>·</span>
          <a href={`mailto:${SUPPORT_EMAIL}`} style={{ color: '#8B90B0', textDecoration: 'none' }}>Contact</a>
        </div>
      </footer>
    </div>
  )
}
