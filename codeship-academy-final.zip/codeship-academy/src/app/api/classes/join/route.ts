import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'You must be signed in to join a class.' }, { status: 401 })

    const { code, token } = await request.json()

    let result: any

    if (token) {
      // Join via invite link token
      const { data, error } = await supabase.rpc('join_class_by_invite', {
        p_user_id: user.id,
        p_token: token,
      })
      if (error) throw error
      result = data
    } else if (code) {
      // Join via class code
      const { data, error } = await supabase.rpc('join_class_by_code', {
        p_user_id: user.id,
        p_code: code.toUpperCase().trim(),
      })
      if (error) throw error
      result = data
    } else {
      return NextResponse.json({ error: 'Provide a class code or invite token.' }, { status: 400 })
    }

    if (!result?.success) {
      return NextResponse.json({ error: result?.error || 'Could not join class.' }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      classId: result.class_id,
      className: result.class_name,
      message: result.teacher_message,
    })
  } catch (error: any) {
    console.error('Join class error:', error)
    return NextResponse.json({ error: error.message || 'Something went wrong.' }, { status: 500 })
  }
}
