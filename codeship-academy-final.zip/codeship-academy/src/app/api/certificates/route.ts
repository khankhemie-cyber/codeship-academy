import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

// Generates a certificate as a self-contained HTML page that prints to PDF
// The client triggers window.print() on the response
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const studentId = searchParams.get('studentId')
  const level = searchParams.get('level')

  if (!studentId || !level) {
    return NextResponse.json({ error: 'Missing parameters' }, { status: 400 })
  }

  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: student } = await supabase
    .from('student_profiles')
    .select('full_name, level, xp_points')
    .eq('id', studentId)
    .single()

  if (!student) return NextResponse.json({ error: 'Student not found' }, { status: 404 })

  const date = new Date().toLocaleDateString('en-CA', { year: 'numeric', month: 'long', day: 'numeric' })

  const levelDescriptions: Record<string, string> = {
    Explorers: 'demonstrating foundational understanding of computers, patterns, algorithms, and block-based coding',
    Builders: 'demonstrating proficiency in HTML, CSS, and introductory web development',
    Developers: 'demonstrating proficiency in JavaScript, DOM manipulation, APIs, and interactive web applications',
    Engineers: 'demonstrating advanced proficiency in Python, Flask, SQL, Git, data analysis, and full-stack development',
  }

  const levelColors: Record<string, string> = {
    Explorers: '#22C55E', Builders: '#0EA5E9', Developers: '#7C3AED', Engineers: '#F5C518'
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CODEship Certificate — ${student.full_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Nunito', sans-serif; background: #f0f2ff; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 24px; }
  .cert {
    width: 800px; max-width: 100%;
    background: white;
    border-radius: 24px;
    overflow: hidden;
    box-shadow: 0 32px 80px rgba(30,33,64,0.2);
    position: relative;
  }
  /* Top bar */
  .top-bar { height: 16px; background: linear-gradient(90deg, #1E2140, #F5C518, #1E2140); }
  .inner { padding: 48px 64px; text-align: center; position: relative; }
  /* Corner decorations */
  .corner { position: absolute; width: 80px; height: 80px; border: 4px solid ${levelColors[level] || '#F5C518'}; border-radius: 4px; opacity: 0.3; }
  .corner.tl { top: 24px; left: 24px; border-right: none; border-bottom: none; }
  .corner.tr { top: 24px; right: 24px; border-left: none; border-bottom: none; }
  .corner.bl { bottom: 24px; left: 24px; border-right: none; border-top: none; }
  .corner.br { bottom: 24px; right: 24px; border-left: none; border-top: none; }

  .logo-row { display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 8px; }
  .logo-icon { width: 48px; height: 48px; background: #1E2140; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
  .logo-text { text-align: left; }
  .logo-name { font-size: 22px; font-weight: 900; color: #1E2140; line-height: 1; }
  .logo-tag { font-size: 9px; font-weight: 800; letter-spacing: 0.15em; color: #F5C518; text-transform: uppercase; }

  .cert-of { font-size: 11px; font-weight: 800; letter-spacing: 0.2em; color: #8B90B0; text-transform: uppercase; margin: 32px 0 8px; }
  .cert-title { font-size: 42px; font-weight: 900; color: #1E2140; line-height: 1; margin-bottom: 24px; }
  .divider { width: 80px; height: 3px; background: ${levelColors[level] || '#F5C518'}; margin: 0 auto 24px; border-radius: 99px; }
  .presented-to { font-size: 13px; font-weight: 700; color: #8B90B0; margin-bottom: 8px; }
  .student-name { font-size: 40px; font-weight: 900; color: ${levelColors[level] || '#F5C518'}; margin-bottom: 32px; line-height: 1.1; }

  .level-badge { display: inline-flex; align-items: center; gap: 10px; background: ${levelColors[level] || '#F5C518'}18; border: 2px solid ${levelColors[level] || '#F5C518'}44; border-radius: 99px; padding: 8px 24px; margin-bottom: 24px; }
  .level-badge span { font-size: 18px; font-weight: 900; color: ${levelColors[level] || '#F5C518'}; }

  .description { font-size: 15px; color: #5A5F80; line-height: 1.7; max-width: 520px; margin: 0 auto 36px; font-weight: 600; }

  .sig-row { display: flex; justify-content: center; gap: 80px; margin-bottom: 36px; }
  .sig-block { text-align: center; }
  .sig-line { width: 160px; height: 2px; background: #E8EAF6; margin: 0 auto 8px; }
  .sig-name { font-size: 13px; font-weight: 800; color: #2B2D42; }
  .sig-title { font-size: 11px; color: #8B90B0; font-weight: 600; }

  .footer-row { display: flex; justify-content: space-between; align-items: center; padding-top: 20px; border-top: 1px solid #E8EAF6; }
  .footer-date { font-size: 12px; color: #8B90B0; font-weight: 600; }
  .xp-badge { background: #1E2140; color: #F5C518; font-size: 11px; font-weight: 900; padding: 4px 12px; border-radius: 99px; }
  .tagline { font-size: 10px; font-weight: 800; letter-spacing: 0.15em; color: #C4C9E0; text-transform: uppercase; }

  /* Bottom bar */
  .bottom-bar { height: 8px; background: ${levelColors[level] || '#F5C518'}; }

  @media print {
    body { background: white; padding: 0; min-height: auto; }
    .cert { box-shadow: none; border-radius: 0; max-width: none; width: 100%; }
    .print-btn { display: none !important; }
  }
</style>
</head>
<body>
<div class="cert">
  <div class="top-bar"></div>
  <div class="inner">
    <div class="corner tl"></div>
    <div class="corner tr"></div>
    <div class="corner bl"></div>
    <div class="corner br"></div>

    <div class="logo-row">
      <div class="logo-icon">🚀</div>
      <div class="logo-text">
        <div class="logo-name">CODEship Academy</div>
        <div class="logo-tag">Dream. Code. Achieve.</div>
      </div>
    </div>

    <div class="cert-of">Certificate of</div>
    <div class="cert-title">Completion</div>
    <div class="divider"></div>

    <div class="presented-to">This certificate is proudly presented to</div>
    <div class="student-name">${student.full_name}</div>

    <div class="level-badge">
      <span>${level}</span>
      <span style="font-size:14px;color:#5A5F80;font-weight:700">Level Completion</span>
    </div>

    <div class="description">
      For successfully completing the <strong>CODEship Academy ${level} Level</strong>,<br>
      ${levelDescriptions[level] || 'demonstrating coding excellence and dedication to learning'}.
    </div>

    <div class="sig-row">
      <div class="sig-block">
        <div class="sig-line"></div>
        <div class="sig-name">CODEship Academy</div>
        <div class="sig-title">Director of Education</div>
      </div>
      <div class="sig-block">
        <div class="sig-line"></div>
        <div class="sig-name">${student.full_name}</div>
        <div class="sig-title">Student</div>
      </div>
    </div>

    <div class="footer-row">
      <div class="footer-date">${date}</div>
      <div class="tagline">DREAM. CODE. ACHIEVE.</div>
      <div class="xp-badge">⚡ ${student.xp_points} XP Earned</div>
    </div>
  </div>
  <div class="bottom-bar"></div>
</div>

<button class="print-btn" onclick="window.print()" style="position:fixed;bottom:24px;right:24px;background:#1E2140;color:#F5C518;border:none;border-radius:14px;padding:12px 24px;font-family:Nunito,sans-serif;font-size:15px;font-weight:900;cursor:pointer;box-shadow:0 8px 24px rgba(30,33,64,0.3)">
  📄 Print / Save PDF
</button>
</body>
</html>`

  // Log certificate issuance
  await supabase.from('certificates').upsert({
    student_id: studentId,
    level,
  }, { onConflict: 'student_id,level' })

  return new NextResponse(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  })
}
