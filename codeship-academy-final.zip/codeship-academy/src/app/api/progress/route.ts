import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { studentId, contentType, contentId, contentTitle, status, score, timeSpent, xpEarned } = await request.json()

    const { data, error } = await supabase
      .from('progress_records')
      .upsert({
        student_id: studentId,
        content_type: contentType,
        content_id: contentId,
        content_title: contentTitle,
        status,
        score: score ?? null,
        time_spent: timeSpent ?? 0,
        xp_earned: xpEarned ?? 0,
        started_at: status === 'in_progress' ? new Date().toISOString() : undefined,
        completed_at: status === 'completed' ? new Date().toISOString() : undefined,
      }, { onConflict: 'student_id,content_id' })
      .select()
      .single()

    if (error) throw error

    // Award XP if completed
    if (status === 'completed' && xpEarned > 0) {
      await supabase.rpc('award_xp', { p_student_id: studentId, p_xp: xpEarned })
      await supabase.rpc('update_streak', { p_student_id: studentId })
    }

    return NextResponse.json({ record: data })
  } catch (error: any) {
    console.error('Progress update error:', error)
    return NextResponse.json({ error: error.message || 'Failed to update progress' }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const studentId = searchParams.get('studentId')
    const contentType = searchParams.get('contentType')

    if (!studentId) return NextResponse.json({ error: 'studentId required' }, { status: 400 })

    let query = supabase
      .from('progress_records')
      .select('*')
      .eq('student_id', studentId)
      .order('updated_at', { ascending: false })

    if (contentType) query = query.eq('content_type', contentType)

    const { data, error } = await query
    if (error) throw error

    const summary = {
      total: data?.length ?? 0,
      completed: data?.filter(r => r.status === 'completed').length ?? 0,
      inProgress: data?.filter(r => r.status === 'in_progress').length ?? 0,
      totalXP: data?.reduce((s, r) => s + (r.xp_earned || 0), 0) ?? 0,
    }

    return NextResponse.json({ records: data, summary })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
