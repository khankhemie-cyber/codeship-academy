import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateWeeklyPlan } from '@/lib/anthropic'
import type { PlannerConfig } from '@/types'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    // Check subscription has AI planner access
    const { data: sub } = await supabase
      .from('subscriptions')
      .select('features, status')
      .eq('user_id', user.id)
      .single()

    // Allow trial users a limited number of generations
    const hasAccess = sub?.status === 'trialing' || sub?.features?.ai_planner === true
    if (!hasAccess) {
      return NextResponse.json({ error: 'Upgrade your plan to use the AI Planner' }, { status: 403 })
    }

    const body = await request.json() as PlannerConfig

    // Get learning profile if exists
    const { data: profile } = await supabase
      .from('learning_profiles')
      .select('*')
      .eq('student_id', body.childId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    const plan = await generateWeeklyPlan(body, profile || {})

    // Audit log
    await supabase.from('admin_audit_logs').insert({
      actor_id: user.id,
      actor_email: user.email,
      action: 'ai_plan_generated',
      resource_type: 'learning_plan',
      metadata: { child_id: body.childId, child_name: body.childName },
    })

    return NextResponse.json({ plan })
  } catch (error) {
    console.error('Planner error:', error)
    return NextResponse.json({ error: 'Failed to generate plan' }, { status: 500 })
  }
}
