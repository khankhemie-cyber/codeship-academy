import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { messages, lessonTitle, level, language, context, studentName } = await request.json()

    if (!messages?.length) return NextResponse.json({ error: 'No messages' }, { status: 400 })

    const ageGroup = ['Explorers', 'Builders'].includes(level) ? 'ages 6-9' : level === 'Developers' ? 'ages 10-12' : 'ages 13-16'

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 400,
      system: `You are a warm, encouraging coding tutor for CODEship Academy. The student is in the ${level} level working on: "${lessonTitle}".${language && language !== 'None' ? ` The programming language is ${language}.` : ''}${context ? ` Lesson context: ${context.slice(0, 500)}` : ''}

Rules:
- Keep answers SHORT (2-4 sentences for simple questions, up to 8 for complex)
- Use simple language appropriate for ${ageGroup}
- Be encouraging — never say "wrong" or "incorrect". Say "great try! here's another way..."
- Use emojis sparingly but warmly
- For code questions, show SHORT examples in backticks
- If they're frustrated, acknowledge it warmly first
- NEVER do homework for them — guide with hints instead
- End with a small encouraging nudge to try it themselves`,
      messages: messages.map((m: { role: string; content: string }) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
    })

    const reply = (response.content[0] as { text: string }).text
    return NextResponse.json({ reply })
  } catch (error: any) {
    console.error('AI tutor error:', error)
    return NextResponse.json({ reply: "I had a hiccup! Try asking again 🔄" })
  }
}
