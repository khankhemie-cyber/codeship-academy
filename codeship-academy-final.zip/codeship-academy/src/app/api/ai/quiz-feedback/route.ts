import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateQuizFeedback } from '@/lib/anthropic'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { quizTitle, score, wrongQuestions } = await request.json()
    const { data: studentProfile } = await supabase
      .from('student_profiles').select('full_name').eq('user_id', user.id).single()
    const name = studentProfile?.full_name || 'Student'

    const feedback = await generateQuizFeedback(name, quizTitle, score, wrongQuestions)
    return NextResponse.json({ feedback })
  } catch (error) {
    return NextResponse.json({ feedback: 'Great effort! Review the questions you found tricky and try again.' })
  }
}
