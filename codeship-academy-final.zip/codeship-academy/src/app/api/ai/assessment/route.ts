import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateLearningProfile } from '@/lib/anthropic'
import type { AssessmentData } from '@/types'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { studentId, assessment } = await request.json() as { studentId: string; assessment: AssessmentData }

    // Save assessment
    const { data: savedAssessment } = await supabase.from('assessments').insert({
      student_id: studentId,
      completed_by: user.id,
      age: assessment.age,
      grade: assessment.grade,
      experience: assessment.experience,
      skills: assessment.skills,
      interests: assessment.interests,
      challenges: assessment.challenges,
      challenge_notes: assessment.challenge_notes,
      goals: assessment.goals,
      learning_style: assessment.learning_style,
    }).select().single()

    // Generate AI profile
    const profile = await generateLearningProfile(assessment)

    // Save learning profile
    const { data: savedProfile } = await supabase.from('learning_profiles').insert({
      student_id: studentId,
      assessment_id: savedAssessment?.id,
      ...profile,
      ai_generated: true,
    }).select().single()

    // Update student level
    if (profile.recommended_level) {
      await supabase.from('student_profiles')
        .update({ level: profile.recommended_level })
        .eq('id', studentId)
    }

    await supabase.from('admin_audit_logs').insert({
      actor_id: user.id,
      actor_email: user.email,
      action: 'assessment_completed',
      resource_type: 'assessment',
      resource_id: savedAssessment?.id,
      metadata: { student_id: studentId },
    })

    return NextResponse.json({ profile: savedProfile })
  } catch (error) {
    console.error('Assessment error:', error)
    return NextResponse.json({ error: 'Failed to generate profile' }, { status: 500 })
  }
}
