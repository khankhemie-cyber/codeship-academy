import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const unreadOnly = searchParams.get('unread') === 'true'
    const limit = parseInt(searchParams.get('limit') || '20')

    let query = supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (unreadOnly) query = query.eq('read', false)

    const { data, error } = await query
    if (error) throw error

    const unreadCount = data?.filter(n => !n.read).length ?? 0
    return NextResponse.json({ notifications: data, unreadCount })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { data: me } = await supabase.from('users').select('role').eq('id', user.id).single()

    // Mark as read
    const body = await request.json()

    if (body.action === 'markRead') {
      const ids: string[] = body.ids || []
      if (ids.length === 0) {
        // Mark all read
        await supabase.from('notifications').update({ read: true }).eq('user_id', user.id).eq('read', false)
      } else {
        await supabase.from('notifications').update({ read: true }).in('id', ids)
      }
      return NextResponse.json({ success: true })
    }

    // Create notification (admin only)
    if (body.action === 'create') {
      if (me?.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
      const { data, error } = await supabase.from('notifications').insert({
        user_id: body.userId,
        type: body.type || 'info',
        title: body.title,
        message: body.message,
        link: body.link || null,
      }).select().single()
      if (error) throw error
      return NextResponse.json({ notification: data })
    }

    return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (id) {
      await supabase.from('notifications').delete().eq('id', id).eq('user_id', user.id)
    } else {
      // Delete all read notifications
      await supabase.from('notifications').delete().eq('user_id', user.id).eq('read', true)
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
