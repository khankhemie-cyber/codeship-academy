import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { type, contentId, contentTitle, metadata } = await request.json()

    const { data: student } = await supabase
      .from('student_profiles')
      .select('id')
      .or(`user_id.eq.${user.id},parent_id.eq.${user.id}`)
      .limit(1)
      .single()

    if (!student) return NextResponse.json({ error: 'No student profile found' }, { status: 404 })

    // Check if token already exists for this content
    const { data: existing } = await supabase
      .from('share_tokens')
      .select('token')
      .eq('student_id', student.id)
      .eq('type', type)
      .eq('content_id', contentId || '00000000-0000-0000-0000-000000000000')
      .single()

    if (existing) {
      return NextResponse.json({
        token: existing.token,
        url: `${process.env.NEXT_PUBLIC_APP_URL}/share/${existing.token}`,
      })
    }

    const { data: share, error } = await supabase
      .from('share_tokens')
      .insert({
        student_id: student.id,
        type,
        content_id: contentId || null,
        content_title: contentTitle || null,
        metadata: metadata || {},
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      token: share.token,
      url: `${process.env.NEXT_PUBLIC_APP_URL}/share/${share.token}`,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
