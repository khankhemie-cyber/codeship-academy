import { NextResponse } from 'next/server'
import { stripe, PLAN_FEATURES } from '@/lib/stripe'
import { createAdminClient } from '@/lib/supabase/server'
import Stripe from 'stripe'

export async function POST(request: Request) {
  const body = await request.text()
  const sig = request.headers.get('stripe-signature')!
  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    return NextResponse.json({ error: 'Webhook signature failed' }, { status: 400 })
  }

  const supabase = createAdminClient()

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.CheckoutSession
      const userId = session.metadata?.user_id
      const plan = session.metadata?.plan as string
      if (!userId || !plan) break

      const features = PLAN_FEATURES[plan as keyof typeof PLAN_FEATURES] || PLAN_FEATURES.trial
      await supabase.from('subscriptions').update({
        stripe_subscription_id: session.subscription as string,
        stripe_customer_id: session.customer as string,
        plan, status: 'trialing',
        max_children: features.max_children,
        max_students: features.max_students,
        features: {
          ai_planner: features.ai_planner,
          calendar_sync: features.calendar_sync,
          reports: features.reports,
        },
        updated_at: new Date().toISOString(),
      }).eq('user_id', userId)

      await supabase.from('notifications').insert({
        user_id: userId, type: 'subscription_activated',
        title: '🎉 Subscription activated!',
        message: `Your ${plan} plan is now active. All features are unlocked.`,
      })
      break
    }

    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription
      const userId = sub.metadata?.user_id
      if (!userId) break

      await supabase.from('subscriptions').update({
        status: sub.status as any,
        current_period_start: new Date(sub.current_period_start * 1000).toISOString(),
        current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
        cancel_at_period_end: sub.cancel_at_period_end,
        updated_at: new Date().toISOString(),
      }).eq('user_id', userId)
      break
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription
      const userId = sub.metadata?.user_id
      if (!userId) break

      await supabase.from('subscriptions').update({
        status: 'canceled', plan: 'trial',
        features: { ai_planner: false, calendar_sync: false, reports: false },
        updated_at: new Date().toISOString(),
      }).eq('user_id', userId)

      await supabase.from('notifications').insert({
        user_id: userId, type: 'subscription_canceled',
        title: 'Subscription canceled',
        message: 'Your subscription has ended. You still have access to free features.',
      })
      break
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice
      if (!invoice.customer_email) break
      const { data: user } = await supabase.from('users').select('id').eq('email', invoice.customer_email).single()
      if (!user) break
      await supabase.from('payments').insert({
        user_id: user.id,
        stripe_invoice_id: invoice.id,
        amount: invoice.amount_paid,
        currency: invoice.currency,
        status: 'paid',
        description: invoice.description || 'CODEship subscription',
        invoice_url: invoice.hosted_invoice_url,
      })
      break
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice
      if (!invoice.customer_email) break
      const { data: user } = await supabase.from('users').select('id').eq('email', invoice.customer_email).single()
      if (!user) break
      await supabase.from('subscriptions').update({ status: 'past_due' }).eq('user_id', user.id)
      await supabase.from('notifications').insert({
        user_id: user.id, type: 'payment_failed',
        title: 'Payment failed',
        message: 'We could not process your payment. Please update your payment method.',
      })
      break
    }
  }

  await supabase.from('admin_audit_logs').insert({
    action: `stripe_webhook_${event.type}`,
    resource_type: 'stripe',
    metadata: { event_id: event.id },
  })

  return NextResponse.json({ received: true })
}
