import { NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { sendWeeklyDigest } from '@/lib/email'

// Called by Vercel Cron: every Monday at 8am Eastern
// vercel.json: { "crons": [{ "path": "/api/emails/weekly-digest", "schedule": "0 12 * * 1" }] }
export async function GET(request: Request) {
  // Verify cron secret
  const auth = request.headers.get('authorization')
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const supabase = createAdminClient()
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()

  // Get all parent users with active subscriptions
  const { data: parents } = await supabase
    .from('users')
    .select('id, email, full_name')
    .eq('role', 'parent')

  if (!parents?.length) return NextResponse.json({ sent: 0 })

  let sent = 0

  for (const parent of parents) {
    try {
      // Get their children
      const { data: children } = await supabase
        .from('student_profiles')
        .select('*')
        .eq('parent_id', parent.id)

      if (!children?.length) continue

      // Build child stats for the past week
      const childStats = await Promise.all(children.map(async child => {
        const [{ data: progress }, { data: quizAttempts }, { data: achievements }] = await Promise.all([
          supabase.from('progress_records')
            .select('content_type, xp_earned, status')
            .eq('student_id', child.id)
            .gte('completed_at', weekAgo),
          supabase.from('quiz_attempts')
            .select('score')
            .eq('student_id', child.id)
            .gte('completed_at', weekAgo),
          supabase.from('student_achievements')
            .select('achievements(name)')
            .eq('student_id', child.id)
            .gte('earned_at', weekAgo),
        ])

        const xpEarned = progress?.reduce((s, r) => s + (r.xp_earned || 0), 0) ?? 0
        const lessonsCompleted = progress?.filter(r => r.content_type === 'lesson' && r.status === 'completed').length ?? 0
        const quizzesTaken = quizAttempts?.length ?? 0
        const avgQuizScore = quizzesTaken
          ? Math.round(quizAttempts!.reduce((s, a) => s + a.score, 0) / quizzesTaken)
          : 0

        return {
          name: child.full_name,
          level: child.level,
          xpEarned,
          totalXP: child.xp_points,
          lessonsCompleted,
          quizzesTaken,
          avgQuizScore,
          streakDays: child.streak_days || 0,
          achievements: achievements?.map((a: any) => a.achievements?.name).filter(Boolean) ?? [],
        }
      }))

      // Only send if there's activity
      const hasActivity = childStats.some(c => c.xpEarned > 0 || c.lessonsCompleted > 0 || c.quizzesTaken > 0)
      if (!hasActivity) continue

      // Check we haven't sent this week already
      const { data: alreadySent } = await supabase
        .from('email_log')
        .select('id')
        .eq('user_id', parent.id)
        .eq('type', 'weekly_digest')
        .gte('sent_at', weekAgo)
        .single()

      if (alreadySent) continue

      await sendWeeklyDigest(parent.email, {
        parentName: parent.full_name?.split(' ')[0] || 'there',
        children: childStats,
      })

      await supabase.from('email_log').insert({
        user_id: parent.id, type: 'weekly_digest',
        subject: 'Weekly Progress Report',
      })

      sent++
    } catch (err) {
      console.error(`Failed to send digest to ${parent.email}:`, err)
    }
  }

  return NextResponse.json({ sent, total: parents.length })
}
