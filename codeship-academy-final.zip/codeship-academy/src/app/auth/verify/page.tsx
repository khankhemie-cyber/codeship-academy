'use client'
import { Rocket, Mail, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useState } from 'react'

export default function VerifyPage() {
  const supabase = createClient()
  const params = useSearchParams()
  const email = params.get('email') || 'your email'
  const [resent, setResent] = useState(false)
  const [loading, setLoading] = useState(false)

  const resend = async () => {
    setLoading(true)
    await supabase.auth.resend({ type: 'signup', email })
    setResent(true); setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3" style={{ background: '#F5C518' }}>
            <Rocket size={26} color="#1E2140" />
          </div>
          <div className="text-white font-black text-xl">CODEship Academy</div>
        </div>

        <div className="card p-8 text-center">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-5" style={{ background: '#0EA5E918' }}>
            <Mail size={32} style={{ color: '#0EA5E9' }} />
          </div>
          <h1 className="text-2xl font-black mb-2" style={{ color: '#2B2D42' }}>Check your inbox!</h1>
          <p className="text-sm mb-2" style={{ color: '#8B90B0' }}>We sent a verification link to</p>
          <p className="font-bold text-base mb-6" style={{ color: '#2B2D42' }}>{email}</p>

          <div className="rounded-xl p-4 mb-6 text-sm text-left space-y-2" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
            <div className="flex items-start gap-2">
              <span>1️⃣</span>
              <span style={{ color: '#2B2D42' }}>Open the email from CODEship Academy</span>
            </div>
            <div className="flex items-start gap-2">
              <span>2️⃣</span>
              <span style={{ color: '#2B2D42' }}>Click the <strong>Verify Email</strong> button</span>
            </div>
            <div className="flex items-start gap-2">
              <span>3️⃣</span>
              <span style={{ color: '#2B2D42' }}>You'll be taken straight to your dashboard</span>
            </div>
          </div>

          {resent ? (
            <p className="text-sm font-bold mb-4" style={{ color: '#22C55E' }}>✓ Verification email resent!</p>
          ) : (
            <button onClick={resend} disabled={loading} className="text-sm font-bold mb-4 block w-full" style={{ color: '#0EA5E9', background: 'none', border: 'none', cursor: 'pointer' }}>
              {loading ? 'Sending...' : "Didn't get it? Resend the email"}
            </button>
          )}

          <p className="text-xs mb-4" style={{ color: '#8B90B0' }}>Check your spam folder if you don't see it within a minute.</p>

          <Link href="/auth/login" className="flex items-center justify-center gap-2 text-sm font-semibold" style={{ color: '#8B90B0', textDecoration: 'none' }}>
            Back to sign in <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </div>
  )
}
