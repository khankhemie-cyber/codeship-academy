'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Rocket, Eye, EyeOff, Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const router = useRouter()
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false); return }
    router.push('/dashboard')
    router.refresh()
  }

  const handleGoogleLogin = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback?next=/dashboard` }
    })
  }

  return (
    <div className="min-h-screen flex" style={{ fontFamily: 'var(--font-nunito), Nunito, sans-serif' }}>
      {/* Left panel */}
      <div className="hidden lg:flex w-1/2 flex-col justify-between p-12" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}><Rocket size={20} color="#1E2140" /></div>
          <div>
            <div className="text-white font-black text-lg">CODEship</div>
            <div className="text-xs font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 9 }}>ACADEMY</div>
          </div>
        </div>
        <div>
          <div className="text-5xl mb-6">👋</div>
          <h2 className="text-3xl font-black text-white mb-3 leading-tight">Welcome back!<br />Ready to code?</h2>
          <p className="text-white/50 text-base">Your child's learning journey continues today.</p>
        </div>
        <div className="text-white/30 text-sm font-bold tracking-widest uppercase">Dream. Code. Achieve.</div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center px-6 bg-white">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#F5C518' }}><Rocket size={16} color="#1E2140" /></div>
            <span className="font-black text-lg" style={{ color: '#1E2140' }}>CODEship Academy</span>
          </div>

          <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>Sign in</h1>
          <p className="text-sm text-gray-400 mb-7">Access your dashboard and learning plans</p>

          {error && (
            <div className="mb-4 p-3 rounded-xl text-sm font-semibold" style={{ background: '#FEF2F2', color: '#EF4444', border: '1px solid #FECACA' }}>{error}</div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input" placeholder="you@email.com" required />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} className="input pr-10" placeholder="••••••••" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div className="flex justify-end">
              <Link href="/auth/reset-password" className="text-sm font-semibold" style={{ color: '#F5C518' }}>Forgot password?</Link>
            </div>
            <button type="submit" disabled={loading} className="btn-navy w-full py-3.5">
              {loading ? <><Loader2 size={16} className="animate-spin" /> Signing in...</> : 'Sign in'}
            </button>
          </form>

          <div className="relative my-5">
            <div className="border-t border-gray-100" />
            <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xs font-semibold text-gray-300 bg-white px-3">OR</span>
          </div>

          <button onClick={handleGoogleLogin} className="btn-outline w-full py-3.5 flex items-center justify-center gap-2">
            <svg className="w-4 h-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
            Continue with Google
          </button>

          <p className="text-center text-sm text-gray-400 mt-6">
            Don't have an account? <Link href="/auth/signup" className="font-bold" style={{ color: '#F5C518' }}>Sign up free</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
