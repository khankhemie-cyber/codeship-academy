'use client'
import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Rocket, Check, Eye, EyeOff } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import type { UserRole } from '@/types'

const ROLE_OPTIONS = [
  { value: 'parent',  label: 'Parent',  icon: '👨‍👩‍👧', desc: 'Manage my children and track their progress' },
  { value: 'teacher', label: 'Teacher', icon: '👩‍🏫', desc: 'Manage a classroom of students' },
  { value: 'student', label: 'Student', icon: '🧑‍💻', desc: "Start learning to code!" },
]

export default function SignupPage() {
  const router = useRouter()
  const params = useSearchParams()
  const supabase = createClient()
  const [step, setStep] = useState<'role' | 'details'>('role')
  const [role, setRole] = useState<UserRole>('parent')
  const [showPass, setShowPass] = useState(false)
  const [classCode, setClassCode] = useState('')
  const [form, setForm] = useState({ fullName: '', email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    const pendingToken = localStorage.getItem('pending_invite_token')
    if (pendingToken) setClassCode('(invite link — will join automatically)')
  }, [])

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password.length < 8) { setError('Password must be at least 8 characters'); return }
    setLoading(true); setError('')
    const { error: signupErr } = await supabase.auth.signUp({
      email: form.email.trim(),
      password: form.password,
      options: {
        data: { full_name: form.fullName.trim(), role },
        emailRedirectTo: `${window.location.origin}/auth/callback?next=/dashboard`,
      }
    })
    if (signupErr) { setError(signupErr.message); setLoading(false); return }
    if (role === 'student' && classCode.trim() && !classCode.includes('invite')) {
      localStorage.setItem('pending_class_code', classCode.trim().toUpperCase())
    }
    router.push('/auth/verify?email=' + encodeURIComponent(form.email.trim()))
  }

  const handleGoogle = async () => {
    const redirect = params.get('redirect') || '/dashboard'
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback?next=${redirect}`, queryParams: { role } }
    })
  }

  return (
    <div className="min-h-screen flex" style={{ fontFamily: 'var(--font-nunito), Nunito, sans-serif' }}>
      <div className="hidden lg:flex w-5/12 flex-col justify-between p-12" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}><Rocket size={20} color="#1E2140" /></div>
          <div>
            <div className="text-white font-black text-lg leading-none">CODEship</div>
            <div className="font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 9 }}>ACADEMY</div>
          </div>
        </div>
        <div>
          <div className="text-5xl mb-6">🚀</div>
          <h2 className="text-3xl font-black text-white mb-4 leading-tight">Every child can<br />learn to code.</h2>
          {['AI-personalized for every learner','100+ lessons, projects & quizzes','Grades K–8, all experience levels','English & French / Anglais & Français','14-day free trial — no card needed'].map(f => (
            <div key={f} className="flex items-center gap-2 mb-2.5">
              <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#22C55E22' }}><Check size={10} style={{ color: '#22C55E' }} /></div>
              <span className="text-sm" style={{ color: 'rgba(255,255,255,0.7)' }}>{f}</span>
            </div>
          ))}
        </div>
        <div className="text-xs font-bold tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.25)' }}>Dream. Code. Achieve.</div>
      </div>

      <div className="flex-1 flex items-center justify-center px-6 py-10 bg-white overflow-y-auto">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>Create your account</h1>
          <p className="text-sm text-gray-400 mb-7">Already have one? <Link href="/auth/login" style={{ color: '#F5C518', fontWeight: 700 }}>Sign in</Link></p>

          {step === 'role' && (
            <div>
              <p className="label mb-3">I am a...</p>
              <div className="space-y-2.5 mb-6">
                {ROLE_OPTIONS.map(opt => (
                  <button key={opt.value} onClick={() => setRole(opt.value as UserRole)} className="w-full flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all" style={{ borderColor: role === opt.value ? '#F5C518' : '#E8EAF6', background: role === opt.value ? '#FFFBEB' : 'white' }}>
                    <span className="text-2xl">{opt.icon}</span>
                    <div>
                      <div className="font-black text-sm" style={{ color: '#2B2D42' }}>{opt.label}</div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>{opt.desc}</div>
                    </div>
                    {role === opt.value && <div className="ml-auto w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#F5C518' }}><Check size={12} color="#1E2140" /></div>}
                  </button>
                ))}
              </div>
              <button onClick={() => setStep('details')} className="btn-primary w-full py-3.5 text-base">
                Continue as {ROLE_OPTIONS.find(r => r.value === role)?.label} →
              </button>
              <div className="flex items-center gap-3 my-5">
                <div className="flex-1 h-px" style={{ background: '#E8EAF6' }} />
                <span className="text-xs font-semibold" style={{ color: '#8B90B0' }}>or</span>
                <div className="flex-1 h-px" style={{ background: '#E8EAF6' }} />
              </div>
              <button onClick={handleGoogle} className="w-full flex items-center justify-center gap-3 border py-3.5 rounded-xl font-bold text-sm transition-all hover:bg-gray-50" style={{ borderColor: '#E8EAF6', color: '#2B2D42' }}>
                <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Continue with Google
              </button>
            </div>
          )}

          {step === 'details' && (
            <div>
              <button onClick={() => setStep('role')} className="text-sm font-semibold mb-6 flex items-center gap-1" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>← Back</button>
              {error && <div className="rounded-xl p-3 mb-4 text-sm" style={{ background: '#FEF2F2', border: '1px solid #FECACA', color: '#991B1B' }}>{error}</div>}
              <form onSubmit={handleSignup} className="space-y-4">
                <div>
                  <label className="label">Full name</label>
                  <input value={form.fullName} onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))} required placeholder="Your full name" className="input" />
                </div>
                <div>
                  <label className="label">Email</label>
                  <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required placeholder="you@email.com" className="input" />
                </div>
                <div>
                  <label className="label">Password</label>
                  <div className="relative">
                    <input type={showPass ? 'text' : 'password'} value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required minLength={8} placeholder="Min. 8 characters" className="input pr-10" />
                    <button type="button" onClick={() => setShowPass(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 p-1">
                      {showPass ? <EyeOff size={16} style={{ color: '#8B90B0' }} /> : <Eye size={16} style={{ color: '#8B90B0' }} />}
                    </button>
                  </div>
                </div>
                {role === 'student' && (
                  <div>
                    <label className="label">Class Code <span style={{ color: '#8B90B0', fontWeight: 400 }}>(optional)</span></label>
                    <input value={classCode} onChange={e => setClassCode(e.target.value.toUpperCase())} placeholder="e.g. ABC123 — from your teacher" className="input font-mono tracking-widest" maxLength={8} />
                    <p className="text-xs mt-1" style={{ color: '#8B90B0' }}>Enter the code your teacher gave you to join their class automatically.</p>
                  </div>
                )}
                <button type="submit" disabled={loading || !form.fullName || !form.email || !form.password} className="btn-primary w-full py-3.5 text-base">
                  {loading ? 'Creating account...' : 'Create Account →'}
                </button>
              </form>
              <p className="text-xs text-center mt-4" style={{ color: '#B0B4D0' }}>By signing up you agree to our <Link href="/terms" style={{ color: '#8B90B0' }}>Terms</Link> and <Link href="/privacy" style={{ color: '#8B90B0' }}>Privacy Policy</Link>.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
