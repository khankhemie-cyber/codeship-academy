'use client'
import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { ArrowLeft, Send } from 'lucide-react'

export default function ResetPasswordPage() {
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const submit = async () => {
    if (!email) return
    setLoading(true); setError('')
    const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/update-password`,
    })
    if (err) setError(err.message)
    else setSent(true)
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #1E2140 0%, #3A3D5C 100%)' }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}>
              <span className="text-lg">🚀</span>
            </div>
            <div className="text-left">
              <div className="font-black text-white text-lg leading-none">CODEship</div>
              <div className="text-xs font-bold tracking-widest" style={{ color: '#F5C518' }}>ACADEMY</div>
            </div>
          </div>
          <h1 className="text-2xl font-black text-white mb-2">Reset Password</h1>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)' }}>Enter your email and we'll send a reset link</p>
        </div>

        <div className="rounded-2xl p-6" style={{ background: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.1)' }}>
          {sent ? (
            <div className="text-center py-4">
              <div className="text-4xl mb-3">📬</div>
              <h2 className="font-black text-white mb-2">Check your email!</h2>
              <p className="text-sm mb-4" style={{ color: 'rgba(255,255,255,0.6)' }}>We sent a reset link to <strong className="text-white">{email}</strong></p>
              <Link href="/auth/login" className="text-sm font-bold" style={{ color: '#F5C518' }}>Back to Login</Link>
            </div>
          ) : (
            <div className="space-y-4">
              {error && <div className="text-sm px-3 py-2 rounded-xl" style={{ background: 'rgba(239,68,68,0.2)', color: '#FCA5A5' }}>{error}</div>}
              <div>
                <label className="block text-xs font-bold mb-1.5" style={{ color: 'rgba(255,255,255,0.7)' }}>Email Address</label>
                <input className="w-full px-4 py-3 rounded-xl text-sm outline-none" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)', color: 'white', fontFamily: 'inherit' }} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.com" />
              </div>
              <button onClick={submit} disabled={loading || !email} className="btn-primary w-full py-3.5">
                {loading ? 'Sending...' : <><Send size={15} /> Send Reset Link</>}
              </button>
              <Link href="/auth/login" className="flex items-center justify-center gap-1 text-sm font-semibold" style={{ color: 'rgba(255,255,255,0.5)' }}>
                <ArrowLeft size={13} /> Back to Login
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
