import { createAdminClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { Rocket, Award, Target, Code2, TrendingUp } from 'lucide-react'
import Link from 'next/link'

export default async function SharePage({ params }: { params: { token: string } }) {
  const supabase = createAdminClient()

  const { data: share } = await supabase
    .from('share_tokens')
    .select('*, student_profiles(full_name, level, xp_points, streak_days, avatar_emoji)')
    .eq('token', params.token)
    .single()

  if (!share) notFound()

  // Increment view count
  await supabase.from('share_tokens').update({ views: (share.views || 0) + 1 }).eq('token', params.token)

  const student = share.student_profiles as any
  const meta = share.metadata as any

  const LEVEL_COLORS: Record<string, string> = {
    Explorers: '#22C55E', Builders: '#0EA5E9',
    Developers: '#7C3AED', Engineers: '#F5C518'
  }
  const levelColor = LEVEL_COLORS[student?.level] ?? '#F5C518'

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)', fontFamily: 'Nunito, sans-serif' }}>

      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}>
            <Rocket size={18} color="#1E2140" />
          </div>
          <div>
            <div className="text-white font-black text-sm leading-none">CODEship</div>
            <div className="font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 8 }}>ACADEMY</div>
          </div>
        </div>
        <Link href="/auth/signup" className="text-sm font-bold px-4 py-2 rounded-xl" style={{ background: '#F5C518', color: '#1E2140', textDecoration: 'none' }}>
          Join Free →
        </Link>
      </nav>

      <div className="max-w-lg mx-auto px-4 py-8">

        {/* Student card */}
        <div className="rounded-2xl overflow-hidden mb-4" style={{ background: 'white' }}>
          <div className="p-6 text-center" style={{ background: levelColor + '18', borderBottom: '1px solid ' + levelColor + '33' }}>
            <div className="text-5xl mb-3">{student?.avatar_emoji || '🧑‍💻'}</div>
            <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>{student?.full_name}</h1>
            <span className="badge text-sm px-3 py-1" style={{ background: levelColor + '20', color: levelColor }}>{student?.level}</span>
          </div>

          <div className="grid grid-cols-3 divide-x" style={{ borderBottom: '1px solid #E8EAF6' }}>
            {[
              { label: 'XP Earned', value: `⚡${(student?.xp_points || 0).toLocaleString()}`, color: '#F5C518' },
              { label: 'Day Streak', value: `🔥${student?.streak_days || 0}`, color: '#EF4444' },
              { label: 'Level', value: student?.level?.slice(0, 3) ?? '—', color: levelColor },
            ].map(s => (
              <div key={s.label} className="text-center py-4">
                <div className="text-xl font-black" style={{ color: s.color }}>{s.value}</div>
                <div className="text-xs font-semibold mt-0.5" style={{ color: '#8B90B0' }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Content depending on share type */}
          <div className="p-6">
            {share.type === 'quiz_score' && meta && (
              <div className="text-center">
                <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#F59E0B18' }}>
                  <Target size={26} style={{ color: '#F59E0B' }} />
                </div>
                <h2 className="text-lg font-black mb-1" style={{ color: '#2B2D42' }}>{meta.quizTitle}</h2>
                <div className="text-5xl font-black mb-2" style={{ color: meta.score >= 80 ? '#22C55E' : '#F59E0B' }}>{meta.score}%</div>
                <div className="text-sm font-semibold mb-1" style={{ color: meta.passed ? '#22C55E' : '#F59E0B' }}>{meta.passed ? '✅ Passed!' : 'Good effort!'}</div>
                <div className="text-xs" style={{ color: '#8B90B0' }}>{meta.correct} of {meta.total} correct · {meta.timeSpent} min</div>
              </div>
            )}

            {share.type === 'project' && meta && (
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#7C3AED18' }}>
                    <Code2 size={20} style={{ color: '#7C3AED' }} />
                  </div>
                  <div>
                    <h2 className="font-black" style={{ color: '#2B2D42' }}>{share.content_title}</h2>
                    <p className="text-xs" style={{ color: '#8B90B0' }}>{meta.level} · {meta.languages?.join(', ')}</p>
                  </div>
                </div>
                {meta.submissionUrl && (
                  <a href={meta.submissionUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 text-sm font-bold py-3 rounded-xl"
                    style={{ background: '#7C3AED18', color: '#7C3AED', textDecoration: 'none' }}>
                    🔗 View Project →
                  </a>
                )}
                {meta.notes && <p className="text-sm mt-3" style={{ color: '#8B90B0' }}>{meta.notes}</p>}
              </div>
            )}

            {share.type === 'certificate' && meta && (
              <div className="text-center">
                <div className="text-5xl mb-3">🏆</div>
                <h2 className="text-xl font-black mb-1" style={{ color: '#2B2D42' }}>Level Complete!</h2>
                <p className="text-sm mb-3" style={{ color: '#8B90B0' }}>
                  {student?.full_name} completed the <strong>{meta.level}</strong> level curriculum on CODEship Academy.
                </p>
                <div className="text-xs font-semibold" style={{ color: '#B0B4D0' }}>
                  Issued {new Date(meta.issuedAt).toLocaleDateString('en-CA', { month: 'long', day: 'numeric', year: 'numeric' })}
                </div>
              </div>
            )}

            {share.type === 'progress' && meta && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp size={18} style={{ color: '#0EA5E9' }} />
                  <h2 className="font-black" style={{ color: '#2B2D42' }}>Progress Snapshot</h2>
                </div>
                <div className="space-y-2 text-sm">
                  {meta.highlights?.map((h: string, i: number) => (
                    <div key={i} className="flex items-center gap-2" style={{ color: '#2B2D42' }}>
                      <span style={{ color: '#22C55E' }}>✓</span> {h}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="card p-6 text-center">
          <div className="text-2xl mb-2">🚀</div>
          <h3 className="font-black text-lg mb-1" style={{ color: '#2B2D42' }}>Start your coding journey!</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Join CODEship Academy free for 14 days. AI-powered. K–Grade 8.</p>
          <Link href="/auth/signup" className="btn-primary text-sm py-3 px-8 inline-flex" style={{ textDecoration: 'none' }}>
            Get Started Free →
          </Link>
          <p className="text-xs mt-3" style={{ color: '#B0B4D0' }}>No credit card required · codeshipacademy.com</p>
        </div>
      </div>
    </div>
  )
}
