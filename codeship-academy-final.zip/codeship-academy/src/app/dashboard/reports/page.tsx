import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { FileText, Download, TrendingUp, Target, Users, BarChart2 } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function ReportsPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  // ── Correct join: teacher → classes → class_memberships → student_profiles ──
  const { data: classes } = await supabase
    .from('classes')
    .select('id, name')
    .eq('teacher_id', user.id)
    .eq('status', 'active')

  const classIds = classes?.map(c => c.id) ?? []

  const { data: memberships } = classIds.length
    ? await supabase
        .from('class_memberships')
        .select('student_id, user_id, class_id')
        .in('class_id', classIds)
        .eq('status', 'active')
    : { data: [] }

  // Get student_profiles for all members who have one
  const studentUserIds = [...new Set(memberships?.map(m => m.user_id).filter(Boolean) ?? [])]
  const { data: students } = studentUserIds.length
    ? await supabase
        .from('student_profiles')
        .select('*')
        .in('user_id', studentUserIds)
    : { data: [] }

  const studentIds = students?.map(s => s.id) ?? []

  // Fetch progress and quiz attempts in parallel
  const [{ data: attempts }, { data: progress }] = await Promise.all([
    studentIds.length
      ? supabase.from('quiz_attempts').select('student_id, score, passed, completed_at').in('student_id', studentIds)
      : Promise.resolve({ data: [] }),
    studentIds.length
      ? supabase.from('progress_records').select('student_id, status, content_type, xp_earned').in('student_id', studentIds)
      : Promise.resolve({ data: [] }),
  ])

  // Summary stats
  const totalCompleted = progress?.filter(p => p.status === 'completed').length ?? 0
  const avgScore = attempts?.length
    ? Math.round(attempts.reduce((s, a) => s + a.score, 0) / attempts.length)
    : 0
  const passRate = attempts?.length
    ? Math.round((attempts.filter(a => a.passed).length / attempts.length) * 100)
    : 0
  const totalXP = students?.reduce((s, st) => s + (st.xp_points ?? 0), 0) ?? 0

  // CSV export helper — called client-side via download link
  const csvRows = [
    ['Student', 'Level', 'Grade', 'XP', 'Streak', 'Lessons Done', 'Quiz Attempts', 'Quiz Avg', 'Pass Rate'],
    ...(students ?? []).map(s => {
      const sAttempts = attempts?.filter(a => a.student_id === s.id) ?? []
      const sCompleted = progress?.filter(p => p.student_id === s.id && p.status === 'completed' && p.content_type === 'lesson') ?? []
      const sAvg = sAttempts.length ? Math.round(sAttempts.reduce((acc, a) => acc + a.score, 0) / sAttempts.length) : 0
      const sPassed = sAttempts.length ? Math.round((sAttempts.filter(a => a.passed).length / sAttempts.length) * 100) : 0
      return [s.full_name, s.level, s.grade ?? '', s.xp_points, s.streak_days, sCompleted.length, sAttempts.length, sAvg ? `${sAvg}%` : '—', sPassed ? `${sPassed}%` : '—']
    })
  ]
  const csvContent = encodeURIComponent(csvRows.map(r => r.map(c => `"${c}"`).join(',')).join('\n'))

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Classroom Reports</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>
            {students?.length ?? 0} students across {classes?.length ?? 0} {(classes?.length ?? 0) === 1 ? 'class' : 'classes'}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/reports/quiz" className="btn-outline text-sm py-2.5 px-4" style={{ textDecoration: 'none' }}>
            <BarChart2 size={14} /> Quiz Matrix
          </Link>
          <a
            href={`data:text/csv;charset=utf-8,${csvContent}`}
            download={`codeship-report-${new Date().toISOString().slice(0, 10)}.csv`}
            className="btn-primary text-sm py-2.5 px-4"
            style={{ textDecoration: 'none' }}
          >
            <Download size={14} /> Export CSV
          </a>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Students', value: students?.length ?? 0, icon: Users, color: '#0EA5E9' },
          { label: 'Items Completed', value: totalCompleted, icon: TrendingUp, color: '#22C55E' },
          { label: 'Avg Quiz Score', value: avgScore ? `${avgScore}%` : '—', icon: Target, color: '#F59E0B' },
          { label: 'Total XP Earned', value: totalXP.toLocaleString(), icon: FileText, color: '#7C3AED' },
        ].map(s => (
          <div key={s.label} className="card-flat flex items-center gap-3 p-4">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: s.color + '18' }}>
              <s.icon size={18} style={{ color: s.color }} />
            </div>
            <div>
              <div className="text-xl font-black" style={{ color: '#2B2D42' }}>{s.value}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* No classes yet */}
      {!classes?.length && (
        <div className="card-flat text-center py-16">
          <div className="text-4xl mb-3">🏫</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No classes yet</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>
            Create a class and share your class code or invite link to enrol students.
          </p>
          <Link href="/dashboard/classes" className="btn-primary text-sm" style={{ textDecoration: 'none' }}>
            Create a Class
          </Link>
        </div>
      )}

      {/* Per-student table */}
      {!!students?.length && (
        <div className="card-flat overflow-hidden p-0">
          <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid #E8EAF6' }}>
            <h2 className="font-black text-base" style={{ color: '#2B2D42' }}>Student Progress Summary</h2>
            <span className="text-xs font-semibold" style={{ color: '#8B90B0' }}>{students.length} students</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                  {['Student', 'Level', 'XP', 'Lessons', 'Projects', 'Quiz Avg', 'Pass Rate', 'Streak'].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {students.map((s, i) => {
                  const lvl = getLevelConfig(s.level as LevelName)
                  const sAttempts = attempts?.filter(a => a.student_id === s.id) ?? []
                  const sLessons = progress?.filter(p => p.student_id === s.id && p.status === 'completed' && p.content_type === 'lesson') ?? []
                  const sProjects = progress?.filter(p => p.student_id === s.id && p.status === 'completed' && p.content_type === 'project') ?? []
                  const sAvg = sAttempts.length ? Math.round(sAttempts.reduce((acc, a) => acc + a.score, 0) / sAttempts.length) : 0
                  const sPassed = sAttempts.length ? Math.round((sAttempts.filter(a => a.passed).length / sAttempts.length) * 100) : 0
                  return (
                    <tr key={s.id} style={{ borderBottom: i < students.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{s.avatar_emoji || '🧑‍💻'}</span>
                          <span className="font-bold" style={{ color: '#2B2D42' }}>{s.full_name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{s.level}</span>
                      </td>
                      <td className="px-4 py-3 font-bold" style={{ color: '#F5C518' }}>⚡{s.xp_points}</td>
                      <td className="px-4 py-3 font-bold" style={{ color: '#2B2D42' }}>{sLessons.length}</td>
                      <td className="px-4 py-3 font-bold" style={{ color: '#2B2D42' }}>{sProjects.length}</td>
                      <td className="px-4 py-3">
                        <span className="font-bold" style={{ color: sAvg >= 80 ? '#22C55E' : sAvg >= 60 ? '#F59E0B' : sAvg > 0 ? '#EF4444' : '#C4C9E0' }}>
                          {sAttempts.length ? `${sAvg}%` : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-bold" style={{ color: sPassed >= 70 ? '#22C55E' : sPassed > 0 ? '#F59E0B' : '#C4C9E0' }}>
                          {sAttempts.length ? `${sPassed}%` : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3" style={{ color: s.streak_days >= 7 ? '#EF4444' : '#2B2D42' }}>
                        🔥 {s.streak_days}d
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
