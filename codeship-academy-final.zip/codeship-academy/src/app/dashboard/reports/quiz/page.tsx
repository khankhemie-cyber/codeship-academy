import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Target, TrendingUp, Award, Download, Users } from 'lucide-react'

export default async function QuizReportPage({ searchParams }: { searchParams: { quiz?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  // Get teacher's students
  const { data: classes } = await supabase.from('classes').select('id').eq('teacher_id', user!.id)
  const classIds = classes?.map(c => c.id) ?? []

  const { data: memberships } = classIds.length
    ? await supabase.from('class_memberships').select('user_id, student_profiles(id, full_name, level, avatar_emoji)').in('class_id', classIds).eq('status', 'active')
    : { data: [] }

  const students = memberships?.map(m => (m as any).student_profiles).filter(Boolean) ?? []
  const studentIds = students.map((s: any) => s.id)

  // Get all quizzes
  const { data: quizzes } = await supabase.from('quizzes').select('id, title, level, pass_score').eq('status', 'published').order('level').order('title')

  // Get all quiz attempts for these students
  const { data: attempts } = studentIds.length
    ? await supabase.from('quiz_attempts').select('student_id, quiz_id, score, passed, completed_at').in('student_id', studentIds)
    : { data: [] }

  // Build score matrix: studentId → quizId → best attempt
  const scoreMatrix: Record<string, Record<string, { score: number; passed: boolean }>> = {}
  attempts?.forEach(a => {
    if (!scoreMatrix[a.student_id]) scoreMatrix[a.student_id] = {}
    const existing = scoreMatrix[a.student_id][a.quiz_id]
    if (!existing || a.score > existing.score) {
      scoreMatrix[a.student_id][a.quiz_id] = { score: a.score, passed: a.passed }
    }
  })

  // Per-quiz stats
  const quizStats = quizzes?.map(quiz => {
    const quizAttempts = attempts?.filter(a => a.quiz_id === quiz.id) ?? []
    const scores = quizAttempts.map(a => a.score)
    return {
      ...quiz,
      attemptCount: quizAttempts.length,
      avgScore: scores.length ? Math.round(scores.reduce((s, v) => s + v, 0) / scores.length) : null,
      passRate: quizAttempts.length ? Math.round((quizAttempts.filter(a => a.passed).length / quizAttempts.length) * 100) : null,
    }
  }) ?? []

  // Selected quiz for drill-down
  const selectedQuizId = searchParams.quiz
  const selectedQuiz = quizzes?.find(q => q.id === selectedQuizId)
  const selectedQuizStats = selectedQuizId ? quizStats.find(q => q.id === selectedQuizId) : null

  const scoreColor = (score: number | null, passScore: number) => {
    if (score === null) return { bg: '#F8F9FE', text: '#C4C9E0', label: '—' }
    if (score >= passScore) return { bg: '#F0FDF4', text: '#22C55E', label: `${score}%` }
    if (score >= passScore - 15) return { bg: '#FFFBEB', text: '#F59E0B', label: `${score}%` }
    return { bg: '#FEF2F2', text: '#EF4444', label: `${score}%` }
  }

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Quiz Performance Report</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{students.length} students · {quizzes?.length ?? 0} quizzes</p>
        </div>
        <div className="flex gap-2">
          <a href={`/api/reports/quiz-export?teacher=${user!.id}`} className="btn-outline text-sm py-2.5 px-4" style={{ textDecoration: 'none' }}>
            <Download size={14} /> Export CSV
          </a>
        </div>
      </div>

      {/* Class-level summary */}
      {quizStats.filter(q => q.avgScore !== null).length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Class Avg Score', value: `${Math.round(quizStats.filter(q => q.avgScore !== null).reduce((s, q) => s + (q.avgScore ?? 0), 0) / quizStats.filter(q => q.avgScore !== null).length)}%`, icon: Target, color: '#F59E0B' },
            { label: 'Overall Pass Rate', value: `${quizStats.filter(q => q.passRate !== null).length ? Math.round(quizStats.filter(q => q.passRate !== null).reduce((s, q) => s + (q.passRate ?? 0), 0) / quizStats.filter(q => q.passRate !== null).length) : 0}%`, icon: Award, color: '#22C55E' },
            { label: 'Total Attempts', value: attempts?.length ?? 0, icon: TrendingUp, color: '#0EA5E9' },
          ].map(s => (
            <div key={s.label} className="card-flat flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: s.color + '18' }}>
                <s.icon size={20} style={{ color: s.color }} />
              </div>
              <div>
                <div className="text-2xl font-black" style={{ color: '#2B2D42' }}>{s.value}</div>
                <div className="text-xs font-semibold" style={{ color: '#8B90B0' }}>{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {!students.length ? (
        <div className="card-flat text-center py-16">
          <div className="text-4xl mb-3">📊</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No students yet</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Share your class code or invite link to get students enrolled.</p>
          <Link href="/dashboard/classes" className="btn-primary text-sm">Manage Classes</Link>
        </div>
      ) : (
        <>
          {/* Class × Quiz matrix */}
          <div className="card-flat overflow-hidden p-0">
            <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid #E8EAF6' }}>
              <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Class Performance Matrix</h3>
              <div className="flex items-center gap-3 text-xs" style={{ color: '#8B90B0' }}>
                <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ background: '#22C55E' }} /> Passed</span>
                <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ background: '#F59E0B' }} /> Close</span>
                <span className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded" style={{ background: '#EF4444' }} /> Review</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="text-xs" style={{ minWidth: '100%' }}>
                <thead>
                  <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                    <th className="text-left px-4 py-3 font-bold uppercase tracking-wide sticky left-0 bg-gray-50 z-10" style={{ color: '#8B90B0', minWidth: 140 }}>
                      Student
                    </th>
                    {quizzes?.slice(0, 12).map(q => (
                      <th key={q.id} className="px-2 py-3 font-bold text-center" style={{ color: '#8B90B0', minWidth: 72 }}>
                        <Link href={`?quiz=${q.id}`} className="hover:underline" style={{ color: '#8B90B0', textDecoration: 'none' }}>
                          <div className="truncate max-w-16 text-center mx-auto leading-tight">{q.title.replace(' Quiz', '').replace(' Level', '')}</div>
                          <div className="mt-0.5 font-normal opacity-60">{q.level.slice(0, 3)}</div>
                        </Link>
                      </th>
                    ))}
                    <th className="px-4 py-3 font-bold uppercase tracking-wide text-right" style={{ color: '#8B90B0' }}>Avg</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student: any, i: number) => {
                    const studentScores = scoreMatrix[student.id] ?? {}
                    const allScores = Object.values(studentScores).map(s => s.score)
                    const avg = allScores.length ? Math.round(allScores.reduce((s, v) => s + v, 0) / allScores.length) : null
                    return (
                      <tr key={student.id} style={{ borderBottom: i < students.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                        <td className="px-4 py-2.5 sticky left-0 bg-white z-10" style={{ borderRight: '1px solid #F0F2FA' }}>
                          <div className="flex items-center gap-2">
                            <span className="text-base">{student.avatar_emoji || '🧑‍💻'}</span>
                            <div>
                              <div className="font-bold" style={{ color: '#2B2D42' }}>{student.full_name}</div>
                              <div style={{ color: '#8B90B0' }}>{student.level}</div>
                            </div>
                          </div>
                        </td>
                        {quizzes?.slice(0, 12).map(quiz => {
                          const attempt = studentScores[quiz.id]
                          const { bg, text, label } = scoreColor(attempt?.score ?? null, quiz.pass_score)
                          return (
                            <td key={quiz.id} className="px-2 py-2 text-center">
                              <div className="w-14 h-7 rounded-lg flex items-center justify-center mx-auto font-black text-xs" style={{ background: bg, color: text }}>
                                {label}
                              </div>
                            </td>
                          )
                        })}
                        <td className="px-4 py-2 text-right">
                          <span className="font-black text-sm" style={{ color: avg !== null ? (avg >= 70 ? '#22C55E' : '#EF4444') : '#C4C9E0' }}>
                            {avg !== null ? `${avg}%` : '—'}
                          </span>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
                {/* Quiz averages row */}
                <tfoot>
                  <tr style={{ borderTop: '2px solid #E8EAF6', background: '#F8F9FE' }}>
                    <td className="px-4 py-3 font-black text-xs sticky left-0 bg-gray-50" style={{ color: '#8B90B0' }}>Class Avg</td>
                    {quizzes?.slice(0, 12).map(quiz => {
                      const stat = quizStats.find(q => q.id === quiz.id)
                      return (
                        <td key={quiz.id} className="px-2 py-3 text-center">
                          <span className="font-black text-xs" style={{ color: stat?.avgScore !== null && stat?.avgScore !== undefined ? (stat.avgScore >= quiz.pass_score ? '#22C55E' : '#EF4444') : '#C4C9E0' }}>
                            {stat?.avgScore !== null && stat?.avgScore !== undefined ? `${stat.avgScore}%` : '—'}
                          </span>
                        </td>
                      )
                    })}
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Per-quiz drill-down */}
          {selectedQuiz && (
            <div className="card-flat">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>{selectedQuiz.title} — Drill-Down</h3>
                  <p className="text-xs mt-0.5" style={{ color: '#8B90B0' }}>Pass mark: {selectedQuiz.pass_score}% · {selectedQuizStats?.attemptCount ?? 0} attempts · {selectedQuizStats?.passRate ?? 0}% pass rate</p>
                </div>
                <Link href="?" className="text-xs font-bold px-3 py-1.5 rounded-lg" style={{ background: '#EEF0FA', color: '#8B90B0', textDecoration: 'none' }}>
                  ✕ Close
                </Link>
              </div>
              <div className="space-y-2">
                {students.map((student: any) => {
                  const attempt = scoreMatrix[student.id]?.[selectedQuiz.id]
                  const { bg, text } = scoreColor(attempt?.score ?? null, selectedQuiz.pass_score)
                  return (
                    <div key={student.id} className="flex items-center gap-4 p-3 rounded-xl" style={{ background: '#F8F9FE' }}>
                      <span className="text-lg">{student.avatar_emoji || '🧑‍💻'}</span>
                      <div className="flex-1">
                        <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{student.full_name}</div>
                        <div className="text-xs" style={{ color: '#8B90B0' }}>{student.level}</div>
                      </div>
                      {attempt ? (
                        <>
                          <div className="w-36">
                            <div className="h-2 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
                              <div className="h-full rounded-full" style={{ width: `${attempt.score}%`, background: text }} />
                            </div>
                          </div>
                          <div className="text-sm font-black w-12 text-right" style={{ color: text }}>{attempt.score}%</div>
                          <span className="badge text-xs w-16 text-center" style={{ background: bg, color: text }}>
                            {attempt.passed ? 'Passed' : 'Review'}
                          </span>
                        </>
                      ) : (
                        <span className="text-xs font-semibold" style={{ color: '#C4C9E0' }}>Not attempted</span>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
