import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Calendar, ChevronLeft, ChevronRight, Plus, Clock, Sparkles } from 'lucide-react'

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate()
}
function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay()
}

export default async function SchedulePage({ searchParams }: { searchParams: { month?: string; year?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const today = new Date()
  const year = parseInt(searchParams.year || today.getFullYear().toString())
  const month = parseInt(searchParams.month || today.getMonth().toString())

  const monthStart = new Date(year, month, 1).toISOString().split('T')[0]
  const monthEnd = new Date(year, month + 1, 0).toISOString().split('T')[0]

  // Get all students for this user
  const { data: students } = await supabase.from('student_profiles').select('id,full_name,avatar_emoji').eq('parent_id', user!.id)
  const studentIds = students?.map(s => s.id) || []

  const { data: sessions } = studentIds.length ? await supabase
    .from('scheduled_sessions')
    .select('*')
    .in('student_id', studentIds)
    .gte('scheduled_date', monthStart)
    .lte('scheduled_date', monthEnd)
    .order('scheduled_date') : { data: [] }

  // Group by date
  const sessionsByDate: Record<string, any[]> = {}
  sessions?.forEach(s => {
    if (!sessionsByDate[s.scheduled_date]) sessionsByDate[s.scheduled_date] = []
    sessionsByDate[s.scheduled_date].push(s)
  })

  const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December']
  const DAY_NAMES = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
  const daysInMonth = getDaysInMonth(year, month)
  const firstDay = getFirstDayOfMonth(year, month)

  const prevMonth = month === 0 ? `?year=${year - 1}&month=11` : `?year=${year}&month=${month - 1}`
  const nextMonth = month === 11 ? `?year=${year + 1}&month=0` : `?year=${year}&month=${month + 1}`

  const typeColor: Record<string, string> = { lesson: '#0EA5E9', project: '#7C3AED', quiz: '#F59E0B', game: '#22C55E' }

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Schedule</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{sessions?.length || 0} sessions this month</p>
        </div>
        <Link href="/dashboard/planner" className="btn-primary text-sm">
          <Sparkles size={15} /> Generate Plan
        </Link>
      </div>

      {/* Calendar */}
      <div className="card-flat">
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <Link href={prevMonth} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
            <ChevronLeft size={18} style={{ color: '#8B90B0' }} />
          </Link>
          <h2 className="text-lg font-black" style={{ color: '#2B2D42' }}>{MONTH_NAMES[month]} {year}</h2>
          <Link href={nextMonth} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
            <ChevronRight size={18} style={{ color: '#8B90B0' }} />
          </Link>
        </div>

        {/* Day names */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {DAY_NAMES.map(d => (
            <div key={d} className="text-center text-xs font-bold py-1" style={{ color: '#8B90B0' }}>{d}</div>
          ))}
        </div>

        {/* Days grid */}
        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells before first day */}
          {Array.from({ length: firstDay }).map((_, i) => <div key={`empty-${i}`} />)}

          {/* Days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
            const daySessions = sessionsByDate[dateStr] || []
            const isToday = dateStr === today.toISOString().split('T')[0]

            return (
              <div key={day} className="min-h-[72px] p-1.5 rounded-xl border transition-all" style={{
                borderColor: isToday ? '#F5C518' : '#F0F2FA',
                background: isToday ? '#FFFBEB' : 'white',
              }}>
                <div className="text-xs font-black mb-1 text-right" style={{ color: isToday ? '#F5C518' : '#2B2D42' }}>{day}</div>
                {daySessions.slice(0, 2).map((s, si) => (
                  <div key={si} className="text-xs font-semibold px-1.5 py-0.5 rounded mb-0.5 truncate" style={{ background: (typeColor[s.content_type] || '#0EA5E9') + '20', color: typeColor[s.content_type] || '#0EA5E9' }}>
                    {s.content_title?.split(' ').slice(0, 2).join(' ')}
                  </div>
                ))}
                {daySessions.length > 2 && <div className="text-xs" style={{ color: '#8B90B0' }}>+{daySessions.length - 2} more</div>}
              </div>
            )
          })}
        </div>
      </div>

      {/* Upcoming sessions list */}
      <div>
        <h2 className="section-title">Upcoming Sessions</h2>
        {!sessions?.length ? (
          <div className="card-flat text-center py-10">
            <Calendar size={32} className="mx-auto mb-3" style={{ color: '#E8EAF6' }} />
            <p className="text-sm font-semibold mb-3" style={{ color: '#8B90B0' }}>No sessions scheduled this month.</p>
            <Link href="/dashboard/planner" className="btn-primary text-sm">Generate a Plan</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {sessions?.filter(s => s.scheduled_date >= today.toISOString().split('T')[0]).slice(0, 10).map(s => {
              const student = students?.find(st => st.id === s.student_id)
              return (
                <div key={s.id} className="card p-4 flex items-center gap-4">
                  <div className="w-12 text-center flex-shrink-0">
                    <div className="text-xs font-bold" style={{ color: '#8B90B0' }}>{new Date(s.scheduled_date + 'T00:00:00').toLocaleDateString('en-CA', { month: 'short' })}</div>
                    <div className="text-xl font-black" style={{ color: '#2B2D42' }}>{new Date(s.scheduled_date + 'T00:00:00').getDate()}</div>
                  </div>
                  <div className="w-px self-stretch" style={{ background: '#E8EAF6' }} />
                  <div className="flex-1 min-w-0">
                    <div className="font-black text-sm mb-0.5" style={{ color: '#2B2D42' }}>{s.content_title}</div>
                    <div className="flex items-center gap-2 text-xs" style={{ color: '#8B90B0' }}>
                      {student && <span>{student.avatar_emoji} {student.full_name}</span>}
                      <span>·</span>
                      <Clock size={10} />
                      <span>{s.duration_minutes} min</span>
                      {s.scheduled_time && <><span>·</span><span>{s.scheduled_time}</span></>}
                    </div>
                  </div>
                  <span className="badge text-xs capitalize" style={{ background: (typeColor[s.content_type] || '#0EA5E9') + '18', color: typeColor[s.content_type] || '#0EA5E9' }}>
                    {s.content_type}
                  </span>
                  <span className={`badge text-xs ${s.status === 'completed' ? 'badge-success' : ''}`} style={{
                    background: s.status === 'completed' ? '#22C55E18' : '#EEF0FA',
                    color: s.status === 'completed' ? '#22C55E' : '#8B90B0',
                  }}>{s.status}</span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
