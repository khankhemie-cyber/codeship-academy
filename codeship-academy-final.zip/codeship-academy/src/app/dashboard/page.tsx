import { redirect } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Sparkles, TrendingUp, UserCheck, Calendar, ArrowRight, CheckCircle, Zap, Star, Users } from 'lucide-react'
import { formatRelative, getLevelConfig } from '@/lib/utils'

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: profile } = await supabase.from('users').select('*, subscriptions(*)').eq('id', user.id).single()
  const { data: students } = await supabase.from('student_profiles').select('*').eq('parent_id', user.id)
  const role = profile?.role ?? 'parent'

  if (role === 'student') redirect('/dashboard/today')
  if (role === 'teacher') redirect('/dashboard/students')
  if (role === 'admin') redirect('/dashboard/analytics')

  const subscription = profile?.subscriptions?.[0]
  const isTrialing = subscription?.status === 'trialing'

  return (
    <div className="p-6 space-y-6 animate-in">

      {/* Trial banner */}
      {isTrialing && (
        <div className="rounded-2xl p-4 flex items-center justify-between" style={{ background: 'linear-gradient(90deg, #F5C51818, #F5C51808)', border: '1px solid #F5C51840' }}>
          <div className="flex items-center gap-3">
            <Zap size={18} style={{ color: '#F5C518' }} />
            <span className="text-sm font-bold" style={{ color: '#2B2D42' }}>
              You're on a free trial — {Math.max(0, Math.ceil((new Date(subscription?.trial_end).getTime() - Date.now()) / 86400000))} days remaining
            </span>
          </div>
          <Link href="/dashboard/subscription" className="btn-primary text-xs py-2 px-4">Upgrade Now</Link>
        </div>
      )}

      {/* Welcome */}
      <div className="rounded-2xl p-7 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
        <div className="absolute right-0 top-0 w-48 h-48 rounded-full opacity-10" style={{ background: '#F5C518', transform: 'translate(30%, -30%)' }} />
        <div className="flex items-center justify-between relative">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#F5C518' }}>Welcome back 👋</div>
            <h1 className="text-2xl font-black text-white mb-1">{profile?.full_name?.split(' ')[0] || 'Parent'}!</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)' }}>
              {students?.length ? `${students.length} ${students.length === 1 ? 'child' : 'children'} in your account` : "Let's add your first child"}
            </p>
          </div>
          <div className="flex gap-3">
            <Link href="/dashboard/planner" className="btn-primary text-sm">
              <Sparkles size={15} /> AI Planner
            </Link>
            {!students?.length && (
              <Link href="/dashboard/children/new" className="btn-outline text-sm" style={{ color: 'white', borderColor: 'rgba(255,255,255,0.3)', background: 'transparent' }}>
                Add Child
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { href: '/dashboard/assessment', icon: UserCheck, label: 'Run Assessment', desc: 'Profile a child', color: '#0EA5E9' },
          { href: '/dashboard/planner', icon: Sparkles, label: 'Generate Plan', desc: 'AI lesson plan', color: '#F5C518' },
          { href: '/dashboard/progress', icon: TrendingUp, label: 'View Progress', desc: 'See reports', color: '#22C55E' },
          { href: '/dashboard/schedule', icon: Calendar, label: 'Schedule', desc: 'Set up sessions', color: '#7C3AED' },
        ].map(a => (
          <Link key={a.href} href={a.href} className="card flex items-center gap-3 p-4 no-underline" style={{ textDecoration: 'none' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: a.color + '18' }}>
              <a.icon size={18} style={{ color: a.color }} />
            </div>
            <div>
              <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{a.label}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>{a.desc}</div>
            </div>
          </Link>
        ))}
      </div>

      {/* Children */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title mb-0">Children</h2>
          <Link href="/dashboard/children" className="text-xs font-bold flex items-center gap-1" style={{ color: '#0EA5E9' }}>
            Manage <ArrowRight size={12} />
          </Link>
        </div>

        {!students?.length ? (
          <div className="card-flat text-center py-12">
            <div className="text-4xl mb-3">👶</div>
            <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No children added yet</h3>
            <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Add your first child to get started with a personalized plan.</p>
            <Link href="/dashboard/children/new" className="btn-primary text-sm">Add First Child</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {students.map(child => {
              const lvl = getLevelConfig(child.level)
              return (
                <div key={child.id} className="card p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl" style={{ background: lvl.color + '20' }}>
                      {child.avatar_emoji}
                    </div>
                    <div className="flex-1">
                      <div className="font-black text-base" style={{ color: '#2B2D42' }}>{child.full_name}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{child.level}</span>
                        <span className="text-xs" style={{ color: '#8B90B0' }}>Grade {child.grade}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold" style={{ color: '#F5C518' }}>🔥 {child.streak_days} days</div>
                      <div className="text-xs mt-0.5" style={{ color: '#8B90B0' }}>{formatRelative(child.last_active_at || child.created_at)}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-xl p-2.5 text-center" style={{ background: '#F8F9FE' }}>
                      <div className="font-black text-lg" style={{ color: '#2B2D42' }}>⚡ {child.xp_points}</div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>XP</div>
                    </div>
                    <Link href={`/dashboard/progress?child=${child.id}`} className="rounded-xl p-2.5 text-center no-underline hover:bg-gray-100 transition-colors" style={{ background: '#F8F9FE', textDecoration: 'none' }}>
                      <div className="font-black text-lg" style={{ color: '#2B2D42' }}>
                        <TrendingUp size={16} className="mx-auto" style={{ color: '#0EA5E9' }} />
                      </div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>Progress</div>
                    </Link>
                    <Link href={`/dashboard/planner?child=${child.id}`} className="rounded-xl p-2.5 text-center no-underline hover:bg-gray-100 transition-colors" style={{ background: '#F8F9FE', textDecoration: 'none' }}>
                      <div className="font-black text-lg" style={{ color: '#2B2D42' }}>
                        <Sparkles size={16} className="mx-auto" style={{ color: '#F5C518' }} />
                      </div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>Plan</div>
                    </Link>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
