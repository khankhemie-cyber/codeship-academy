'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Code2, CheckCircle, Upload, Clock, ChevronRight, RefreshCw, ExternalLink } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import type { Project } from '@/types'

export default function ProjectViewerPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const supabase = createClient()

  const [project, setProject] = useState<Project | null>(null)
  const [submission, setSubmission] = useState<any>(null)
  const [studentId, setStudentId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [submissionUrl, setSubmissionUrl] = useState('')
  const [submissionNotes, setSubmissionNotes] = useState('')
  const [submissionType, setSubmissionType] = useState<'draft' | 'final'>('draft')

  useEffect(() => {
    const load = async () => {
      const { data: p } = await supabase.from('projects').select('*').eq('id', id).single()
      setProject(p)
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: s } = await supabase.from('student_profiles').select('id').eq('user_id', user.id).single()
        if (s) {
          setStudentId(s.id)
          const { data: sub } = await supabase.from('project_submissions')
            .select('*').eq('student_id', s.id).eq('project_id', id).order('created_at', { ascending: false }).limit(1).single()
          if (sub) {
            setSubmission(sub)
            setSubmissionUrl(sub.submission_url || '')
            setSubmissionNotes(sub.notes || '')
          }
        }
      }
      setLoading(false)
    }
    load()
  }, [id])

  const handleSubmit = async () => {
    if (!studentId) return
    setSubmitting(true)
    const { data: { user } } = await supabase.auth.getUser()

    const payload = {
      student_id: studentId,
      project_id: id,
      submission_type: submissionType,
      submission_url: submissionUrl.trim() || null,
      notes: submissionNotes.trim() || null,
      submitted_at: new Date().toISOString(),
    }

    if (submission) {
      await supabase.from('project_submissions').update(payload).eq('id', submission.id)
    } else {
      await supabase.from('project_submissions').insert(payload)
      // Award XP for first submission
      if (submissionType === 'final') {
        await supabase.rpc('award_xp', { p_student_id: studentId, p_xp: 100 })
        await supabase.from('progress_records').upsert({
          student_id: studentId, content_type: 'project', content_id: id,
          content_title: project?.title, status: 'completed',
          xp_earned: 100, completed_at: new Date().toISOString(),
        }, { onConflict: 'student_id,content_id' })
      }
    }
    setSubmitted(true)
    setSubmitting(false)
    setTimeout(() => setSubmitted(false), 3000)
  }

  if (loading) return (
    <div className="flex items-center justify-center h-full py-20">
      <RefreshCw size={28} className="animate-spin" style={{ color: '#F5C518' }} />
    </div>
  )

  if (!project) return <div className="p-6">Project not found.</div>

  return (
    <div className="p-6 max-w-3xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back to Projects
      </button>

      {/* Header */}
      <div className="card-flat mb-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: '#7C3AED18' }}>
            <Code2 size={22} style={{ color: '#7C3AED' }} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="badge text-xs" style={{ background: '#7C3AED18', color: '#7C3AED' }}>Project</span>
              <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{project.level}</span>
              <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{project.difficulty}</span>
            </div>
            <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>{project.title}</h1>
            <p className="text-sm mb-3" style={{ color: '#8B90B0', lineHeight: 1.6 }}>{project.description}</p>
            <div className="flex items-center gap-4 text-xs" style={{ color: '#8B90B0' }}>
              <span className="flex items-center gap-1"><Clock size={11} />{project.duration_minutes} min</span>
              {project.languages?.map((lang: string) => (
                <span key={lang} className="px-2 py-0.5 rounded-full font-semibold" style={{ background: '#EEF0FA' }}>{lang}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Status badge if submitted */}
        {submission && (
          <div className="mt-4 flex items-center gap-2 p-3 rounded-xl" style={{ background: submission.submission_type === 'final' ? '#22C55E10' : '#F5C51810', border: `1px solid ${submission.submission_type === 'final' ? '#22C55E30' : '#F5C51830'}` }}>
            <CheckCircle size={16} style={{ color: submission.submission_type === 'final' ? '#22C55E' : '#F5C518' }} />
            <span className="text-sm font-bold" style={{ color: '#2B2D42' }}>
              {submission.submission_type === 'final' ? 'Project submitted — +100 XP earned! 🎉' : 'Draft saved'}
            </span>
            <span className="text-xs ml-auto" style={{ color: '#8B90B0' }}>{new Date(submission.submitted_at).toLocaleDateString()}</span>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="card-flat mb-5">
        <h2 className="section-title">Project Instructions</h2>
        <div className="text-sm leading-relaxed prose prose-sm max-w-none" style={{ color: '#2B2D42' }}>
          <pre className="whitespace-pre-wrap font-sans">{project.instructions || 'Instructions coming soon.'}</pre>
        </div>
      </div>

      {/* Submission */}
      <div className="card-flat space-y-4">
        <h2 className="section-title">Submit Your Project</h2>

        <div>
          <label className="label">Project URL (optional)</label>
          <input type="url" value={submissionUrl} onChange={e => setSubmissionUrl(e.target.value)}
            placeholder="https://your-project.netlify.app or https://github.com/you/project"
            className="input" />
          <p className="text-xs mt-1" style={{ color: '#8B90B0' }}>Share a live link, GitHub repo, or Replit project</p>
        </div>

        <div>
          <label className="label">Notes / What you built (optional)</label>
          <textarea value={submissionNotes} onChange={e => setSubmissionNotes(e.target.value)}
            rows={3} placeholder="Tell us what you built, what challenges you faced, and what you're proud of!"
            className="input resize-none" style={{ height: 80 }} />
        </div>

        <div>
          <label className="label">Submission Type</label>
          <div className="flex gap-3">
            {(['draft', 'final'] as const).map(type => (
              <button key={type} onClick={() => setSubmissionType(type)} className="flex-1 py-3 rounded-xl border-2 font-bold text-sm capitalize transition-all" style={{ borderColor: submissionType === type ? '#F5C518' : '#E8EAF6', background: submissionType === type ? '#FFFBEB' : 'white', color: submissionType === type ? '#2B2D42' : '#8B90B0' }}>
                {type === 'draft' ? '💾 Save Draft' : '🚀 Final Submission'}
              </button>
            ))}
          </div>
          {submissionType === 'final' && !submission && (
            <p className="text-xs mt-2 font-semibold" style={{ color: '#22C55E' }}>✓ Final submission earns +100 XP!</p>
          )}
        </div>

        <button onClick={handleSubmit} disabled={submitting || submitted} className="btn-primary w-full py-4 text-base">
          {submitted ? '✓ Saved!' : submitting ? <><RefreshCw size={15} className="animate-spin" /> Saving...</> : <><Upload size={15} /> {submissionType === 'final' ? 'Submit Project' : 'Save Draft'}</>}
        </button>

        {submissionUrl && (
          <a href={submissionUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm font-semibold justify-center" style={{ color: '#0EA5E9' }}>
            <ExternalLink size={14} /> Preview your project
          </a>
        )}
      </div>
    </div>
  )
}
