import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Play, Edit3, Eye, BookOpen, Code2, Target, Globe, Plus, Search } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName, ContentType } from '@/types'

export default async function CurriculumPage({
  searchParams
}: {
  searchParams: { type?: string; level?: string; q?: string }
}) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: profile } = await supabase.from('users').select('role').eq('id', user!.id).single()
  const role = profile?.role ?? 'parent'

  const typeFilter = searchParams.type || 'all'
  const levelFilter = searchParams.level || 'all'
  const query = searchParams.q || ''

  // Fetch curriculum
  const levels = ['Explorers', 'Builders', 'Developers', 'Engineers'] as LevelName[]
  const [{ data: lessons }, { data: projects }, { data: quizzes }] = await Promise.all([
    supabase.from('lessons').select('*').eq('status', 'published').order('level').order('order_index'),
    supabase.from('projects').select('*').eq('status', 'published').order('level').order('order_index'),
    supabase.from('quizzes').select('*').eq('status', 'published').order('level'),
  ])

  const allContent = [
    ...(lessons || []).map(l => ({ ...l, type: 'lesson' as ContentType })),
    ...(projects || []).map(p => ({ ...p, type: 'project' as ContentType })),
    ...(quizzes || []).map(q => ({ ...q, type: 'quiz' as ContentType })),
  ].filter(item => {
    if (typeFilter !== 'all' && item.type !== typeFilter) return false
    if (levelFilter !== 'all' && item.level !== levelFilter) return false
    if (query && !item.title.toLowerCase().includes(query.toLowerCase())) return false
    return true
  })

  const typeColor = { lesson: '#0EA5E9', project: '#7C3AED', quiz: '#F59E0B' }
  const diffColor = { beginner: '#22C55E', intermediate: '#F59E0B', advanced: '#EF4444' }

  return (
    <div className="p-6 space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Lessons', value: lessons?.length ?? 0, icon: BookOpen, color: '#0EA5E9' },
          { label: 'Projects', value: projects?.length ?? 0, icon: Code2, color: '#7C3AED' },
          { label: 'Quizzes', value: quizzes?.length ?? 0, icon: Target, color: '#F59E0B' },
          { label: 'Languages', value: 5, icon: Globe, color: '#22C55E' },
        ].map(s => (
          <div key={s.label} className="card-flat flex items-center gap-3 p-4">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: s.color + '18' }}>
              <s.icon size={18} style={{ color: s.color }} />
            </div>
            <div>
              <div className="text-xl font-black" style={{ color: '#2B2D42' }}>{s.value}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap items-center">
        <form className="flex gap-3 flex-wrap flex-1" method="GET">
          <div className="flex gap-1 p-1 rounded-xl" style={{ background: '#EEF0FA' }}>
            {['all', 'lesson', 'project', 'quiz'].map(t => (
              <button key={t} name="type" value={t} type="submit" className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all capitalize" style={{ background: typeFilter === t ? '#1E2140' : 'transparent', color: typeFilter === t ? 'white' : '#8B90B0' }}>
                {t === 'all' ? 'All' : t + 's'}
              </button>
            ))}
          </div>
          <div className="flex gap-1 p-1 rounded-xl" style={{ background: '#EEF0FA' }}>
            {['all', ...levels].map(l => (
              <button key={l} name="level" value={l} type="submit" className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all" style={{ background: levelFilter === l ? '#1E2140' : 'transparent', color: levelFilter === l ? 'white' : '#8B90B0' }}>
                {l === 'all' ? 'All Levels' : l}
              </button>
            ))}
          </div>
          {/* hidden fields to preserve other params */}
          {typeFilter !== 'all' && <input type="hidden" name="type" value={typeFilter} />}
          {levelFilter !== 'all' && <input type="hidden" name="level" value={levelFilter} />}
        </form>
        {role === 'admin' && (
          <Link href="/dashboard/curriculum/new" className="btn-primary text-xs py-2 px-4">
            <Plus size={14} /> Add Content
          </Link>
        )}
      </div>

      {/* Content grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {allContent.map(item => {
          const lvl = getLevelConfig(item.level as LevelName)
          const tc = typeColor[item.type]
          const dc = (diffColor as any)[item.difficulty] ?? '#8B90B0'
          return (
            <div key={`${item.type}-${item.id}`} className="card p-4 flex flex-col">
              <div className="flex items-start justify-between mb-3">
                <div className="flex gap-2">
                  <span className="badge text-xs" style={{ background: tc + '18', color: tc }}>{item.type}</span>
                  <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{item.level}</span>
                </div>
                {role === 'admin' && (
                  <div className="flex gap-1">
                    <Link href={`/dashboard/curriculum/${item.type}/${item.id}/edit`} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                      <Edit3 size={13} style={{ color: '#8B90B0' }} />
                    </Link>
                    <Link href={`/dashboard/curriculum/${item.type}/${item.id}`} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                      <Eye size={13} style={{ color: '#8B90B0' }} />
                    </Link>
                  </div>
                )}
              </div>
              <h3 className="font-bold text-sm mb-2 flex-1" style={{ color: '#2B2D42' }}>{item.title}</h3>
              <div className="flex items-center gap-2.5 text-xs mb-3" style={{ color: '#8B90B0' }}>
                <span>{item.category}</span>
                <span>·</span>
                <span>⏱ {item.duration_minutes}m</span>
                {(item as any).language && (item as any).language !== 'None' && <><span>·</span><span>💻 {(item as any).language}</span></>}
              </div>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-xs font-semibold" style={{ color: dc }}>{item.difficulty}</span>
                {role === 'student' ? (
                  <Link href={`/dashboard/curriculum/${item.type}/${item.id}`} className="btn-navy text-xs py-1.5 px-3">
                    <Play size={11} /> Start
                  </Link>
                ) : (
                  <Link href={`/dashboard/curriculum/${item.type}/${item.id}`} className="text-xs font-semibold flex items-center gap-1 hover:underline" style={{ color: tc }}>
                    Preview <Eye size={11} />
                  </Link>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {allContent.length === 0 && (
        <div className="text-center py-16">
          <div className="text-4xl mb-3">📚</div>
          <h3 className="font-bold mb-1" style={{ color: '#2B2D42' }}>No content found</h3>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Try adjusting your filters.</p>
        </div>
      )}
    </div>
  )
}
