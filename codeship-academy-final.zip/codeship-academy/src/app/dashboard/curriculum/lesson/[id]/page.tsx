'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { CheckCircle, ArrowLeft, Clock, ChevronRight, BookOpen } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import AITutorChat from '@/components/learning/AITutorChat'

function Markdown({ content }: { content: string }) {
  const html = content
    .replace(/^### (.+)$/gm, '<h3 style="font-size:1rem;font-weight:900;margin:1.25rem 0 0.5rem;color:#1E2140">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="font-size:1.2rem;font-weight:900;margin:1.5rem 0 0.5rem;color:#1E2140">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="font-size:1.5rem;font-weight:900;margin:0 0 0.75rem;color:#1E2140">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre style="background:#1E2140;color:#F5C518;padding:1rem;border-radius:12px;overflow-x:auto;font-family:monospace;font-size:0.8rem;margin:1rem 0;line-height:1.6"><code>$2</code></pre>')
    .replace(/`([^`]+)`/g, '<code style="background:#EEF0FA;color:#7C3AED;padding:1px 6px;border-radius:4px;font-family:monospace;font-size:0.85em">$1</code>')
    .replace(/^- (.+)$/gm, '<li style="margin-bottom:4px;color:#3A3D5C">$1</li>')
    .replace(/\n/g, '<br>')
  return <div className="text-sm leading-relaxed" style={{ color: '#2B2D42' }} dangerouslySetInnerHTML={{ __html: html }} />
}

export default function LessonPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const supabase = createClient()
  const [lesson, setLesson] = useState<any>(null)
  const [completed, setCompleted] = useState(false)
  const [completing, setCompleting] = useState(false)
  const [studentId, setStudentId] = useState<string | null>(null)
  const [studentName, setStudentName] = useState('')
  const [startTime] = useState(Date.now())

  useEffect(() => {
    const load = async () => {
      const { data: l } = await supabase.from('lessons').select('*').eq('id', id).single()
      setLesson(l)
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: s } = await supabase.from('student_profiles').select('id, full_name').eq('user_id', user.id).single()
        if (s) {
          setStudentId(s.id)
          setStudentName(s.full_name || '')
          const { data: p } = await supabase.from('progress_records').select('status').eq('student_id', s.id).eq('content_id', id).single()
          if (p?.status === 'completed') setCompleted(true)
          if (!p || p.status === 'not_started') {
            await supabase.from('progress_records').upsert({
              student_id: s.id, content_type: 'lesson', content_id: id,
              content_title: l?.title, status: 'in_progress', started_at: new Date().toISOString(),
            }, { onConflict: 'student_id,content_id' })
          }
        }
      }
    }
    load()
  }, [id])

  const markComplete = async () => {
    if (!studentId || completing) return
    setCompleting(true)
    const timeSpent = Math.round((Date.now() - startTime) / 1000)
    await supabase.from('progress_records').upsert({
      student_id: studentId, content_type: 'lesson', content_id: id,
      content_title: lesson?.title, status: 'completed',
      time_spent: timeSpent, xp_earned: 50, completed_at: new Date().toISOString(),
    }, { onConflict: 'student_id,content_id' })
    await supabase.rpc('award_xp', { p_student_id: studentId, p_xp: 50 })
    await supabase.rpc('update_streak', { p_student_id: studentId })
    setCompleted(true); setCompleting(false)
  }

  if (!lesson) return (
    <div className="flex items-center justify-center h-full py-20">
      <div className="w-8 h-8 border-2 rounded-full animate-spin" style={{ borderColor: '#F5C518', borderTopColor: 'transparent' }} />
    </div>
  )

  return (
    <div className="p-6 max-w-3xl mx-auto animate-in pb-28">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back
      </button>

      <div className="card-flat mb-5">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: '#0EA5E918' }}>
            <BookOpen size={22} style={{ color: '#0EA5E9' }} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="badge text-xs" style={{ background: '#0EA5E918', color: '#0EA5E9' }}>Lesson</span>
              <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{lesson.level}</span>
              <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{lesson.difficulty}</span>
            </div>
            <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>{lesson.title}</h1>
            <div className="flex items-center gap-3 text-xs" style={{ color: '#8B90B0' }}>
              <span className="flex items-center gap-1"><Clock size={11} />{lesson.duration_minutes} min</span>
              <span>{lesson.category}</span>
              {lesson.language && lesson.language !== 'None' && <span>💻 {lesson.language}</span>}
            </div>
          </div>
          {completed && <div className="flex items-center gap-1.5 text-sm font-bold" style={{ color: '#22C55E' }}><CheckCircle size={18} /> Done</div>}
        </div>
        {lesson.objectives?.length > 0 && (
          <div className="mt-4 p-3 rounded-xl" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
            <div className="text-xs font-black uppercase tracking-wide mb-2" style={{ color: '#8B90B0' }}>Learning Objectives</div>
            {lesson.objectives.map((obj: string, i: number) => (
              <div key={i} className="flex items-start gap-2 text-xs mb-1" style={{ color: '#2B2D42' }}>
                <ChevronRight size={12} style={{ color: '#F5C518', flexShrink: 0, marginTop: 1 }} />{obj}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card-flat mb-5">
        {lesson.instructions ? <Markdown content={lesson.instructions} /> : <p style={{ color: '#8B90B0' }}>Content coming soon.</p>}
      </div>

      {!completed ? (
        <button onClick={markComplete} disabled={completing} className="btn-primary w-full py-4 text-base">
          {completing ? 'Saving...' : <><CheckCircle size={18} /> Mark Complete — +50 XP</>}
        </button>
      ) : (
        <div className="card-flat text-center py-6">
          <div className="text-3xl mb-2">🎉</div>
          <h3 className="font-black text-lg mb-1" style={{ color: '#2B2D42' }}>Lesson Complete!</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>You earned 50 XP. Keep going!</p>
          <button onClick={() => router.push('/dashboard/curriculum')} className="btn-navy text-sm py-2.5 px-6">
            Next Lesson <ChevronRight size={14} />
          </button>
        </div>
      )}

      <AITutorChat lessonTitle={lesson.title} level={lesson.level} language={lesson.language} context={lesson.instructions?.slice(0, 600)} studentName={studentName} />
    </div>
  )
}
