'use client'
import { useState, useEffect } from 'react'
import { Plus, Copy, Link, Users, RefreshCw, Trash2, CheckCircle, QrCode, Send, Eye } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import Link2 from 'next/link'

interface Class {
  id: string; name: string; description: string; level: string
  grade_range: string; class_code: string; max_students: number
  status: string; created_at: string; _member_count?: number
}

interface Invite {
  id: string; token: string; label: string; uses: number; max_uses: number | null; expires_at: string | null; created_at: string
}

export default function ClassesPage() {
  const supabase = createClient()
  const [classes, setClasses] = useState<Class[]>([])
  const [selectedClass, setSelectedClass] = useState<Class | null>(null)
  const [invites, setInvites] = useState<Invite[]>([])
  const [members, setMembers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)
  const [form, setForm] = useState({ name: '', description: '', level: 'Builders', grade_range: '', max_students: 30 })
  const [showNewForm, setShowNewForm] = useState(false)
  const [inviteLabel, setInviteLabel] = useState('')

  const load = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data: cls } = await supabase.from('classes').select('*').eq('teacher_id', user.id).eq('status', 'active').order('created_at', { ascending: false })
    // Count members
    const withCounts = await Promise.all((cls || []).map(async c => {
      const { count } = await supabase.from('class_memberships').select('id', { count: 'exact', head: true }).eq('class_id', c.id).eq('status', 'active')
      return { ...c, _member_count: count ?? 0 }
    }))
    setClasses(withCounts)
    setLoading(false)
  }

  const loadClassDetails = async (cls: Class) => {
    setSelectedClass(cls)
    const [{ data: inv }, { data: mem }] = await Promise.all([
      supabase.from('class_invites').select('*').eq('class_id', cls.id).order('created_at', { ascending: false }),
      supabase.from('class_memberships').select('*, users(full_name, email), student_profiles(full_name, level, xp_points)').eq('class_id', cls.id).eq('status', 'active'),
    ])
    setInvites(inv || [])
    setMembers(mem || [])
  }

  useEffect(() => { load() }, [])

  const createClass = async () => {
    if (!form.name.trim()) return
    setCreating(true)
    const { data: { user } } = await supabase.auth.getUser()
    const { data, error } = await supabase.from('classes').insert({ ...form, teacher_id: user!.id }).select().single()
    if (!error && data) { await load(); setShowNewForm(false); setForm({ name: '', description: '', level: 'Builders', grade_range: '', max_students: 30 }) }
    setCreating(false)
  }

  const createInvite = async () => {
    if (!selectedClass) return
    const { data: { user } } = await supabase.auth.getUser()
    await supabase.from('class_invites').insert({
      class_id: selectedClass.id, created_by: user!.id,
      label: inviteLabel || `Invite ${new Date().toLocaleDateString()}`,
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    })
    setInviteLabel('')
    await loadClassDetails(selectedClass)
  }

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text)
    setCopied(key); setTimeout(() => setCopied(null), 2000)
  }

  const removeStudent = async (membershipId: string) => {
    await supabase.from('class_memberships').update({ status: 'removed' }).eq('id', membershipId)
    if (selectedClass) loadClassDetails(selectedClass)
  }

  const deleteInvite = async (inviteId: string) => {
    await supabase.from('class_invites').delete().eq('id', inviteId)
    if (selectedClass) loadClassDetails(selectedClass)
  }

  const appUrl = typeof window !== 'undefined' ? window.location.origin : ''

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">My Classes</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Manage classes, share codes, and track students</p>
        </div>
        <button onClick={() => setShowNewForm(true)} className="btn-primary text-sm">
          <Plus size={15} /> New Class
        </button>
      </div>

      {/* New class form */}
      {showNewForm && (
        <div className="card-flat space-y-4">
          <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Create New Class</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Class Name *</label>
              <input className="input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Grade 4 Coding Club" />
            </div>
            <div>
              <label className="label">Grade Range</label>
              <input className="input" value={form.grade_range} onChange={e => setForm(f => ({ ...f, grade_range: e.target.value }))} placeholder="e.g. Grades 3–4" />
            </div>
            <div>
              <label className="label">CODEship Level</label>
              <select className="input" value={form.level} onChange={e => setForm(f => ({ ...f, level: e.target.value }))}>
                {['Explorers', 'Builders', 'Developers', 'Engineers'].map(l => <option key={l}>{l}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Max Students</label>
              <input type="number" className="input" value={form.max_students} onChange={e => setForm(f => ({ ...f, max_students: +e.target.value }))} min={1} max={200} />
            </div>
            <div className="col-span-2">
              <label className="label">Description (optional)</label>
              <input className="input" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Brief description of this class" />
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={createClass} disabled={creating || !form.name.trim()} className="btn-primary text-sm py-2.5 px-5">
              {creating ? <><RefreshCw size={14} className="animate-spin" /> Creating...</> : 'Create Class'}
            </button>
            <button onClick={() => setShowNewForm(false)} className="btn-outline text-sm py-2.5 px-5">Cancel</button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20"><RefreshCw size={24} className="animate-spin" style={{ color: '#F5C518' }} /></div>
      ) : classes.length === 0 ? (
        <div className="card-flat text-center py-16">
          <div className="text-4xl mb-3">🏫</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No classes yet</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Create your first class and share the code with your students.</p>
          <button onClick={() => setShowNewForm(true)} className="btn-primary text-sm"><Plus size={14} /> Create First Class</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Class list */}
          <div className="space-y-3">
            {classes.map(cls => (
              <div key={cls.id} onClick={() => loadClassDetails(cls)}
                className="card p-4 cursor-pointer transition-all"
                style={{ borderColor: selectedClass?.id === cls.id ? '#F5C518' : '#E8EAF6', background: selectedClass?.id === cls.id ? '#FFFBEB' : 'white' }}>
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-black text-sm" style={{ color: '#2B2D42' }}>{cls.name}</h3>
                  <span className="text-lg">🏫</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  <span className="badge text-xs" style={{ background: '#F5C51818', color: '#D4A800' }}>{cls.level}</span>
                  {cls.grade_range && <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{cls.grade_range}</span>}
                </div>
                {/* Class code big display */}
                <div className="rounded-xl p-2.5 flex items-center justify-between" style={{ background: '#1E2140' }}>
                  <div>
                    <div className="text-xs font-bold mb-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>Class Code</div>
                    <div className="text-xl font-black tracking-widest" style={{ color: '#F5C518' }}>{cls.class_code}</div>
                  </div>
                  <button onClick={e => { e.stopPropagation(); copyToClipboard(cls.class_code, cls.id) }}
                    className="p-2 rounded-lg transition-colors" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    {copied === cls.id ? <CheckCircle size={15} style={{ color: '#22C55E' }} /> : <Copy size={15} style={{ color: 'rgba(255,255,255,0.6)' }} />}
                  </button>
                </div>
                <div className="flex items-center justify-between mt-2.5 text-xs" style={{ color: '#8B90B0' }}>
                  <span><Users size={11} className="inline mr-1" />{cls._member_count} / {cls.max_students} students</span>
                  <span>{new Date(cls.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Class detail panel */}
          {selectedClass ? (
            <div className="md:col-span-2 space-y-4">
              <div className="card-flat">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-black text-lg" style={{ color: '#2B2D42' }}>{selectedClass.name}</h2>
                  <Link2 href={`/dashboard/students?class=${selectedClass.id}`} className="btn-outline text-xs py-2 px-3" style={{ textDecoration: 'none' }}>
                    <Eye size={13} /> Full Roster
                  </Link2>
                </div>

                {/* Sharing options */}
                <div className="grid grid-cols-2 gap-3 mb-5">
                  <div className="rounded-xl p-4" style={{ background: '#1E2140' }}>
                    <div className="text-xs font-bold mb-1" style={{ color: 'rgba(255,255,255,0.5)' }}>Class Code — students type this at signup</div>
                    <div className="text-3xl font-black tracking-widest mb-2" style={{ color: '#F5C518' }}>{selectedClass.class_code}</div>
                    <button onClick={() => copyToClipboard(selectedClass.class_code, 'code-detail')}
                      className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg"
                      style={{ background: 'rgba(245,197,24,0.15)', color: '#F5C518' }}>
                      {copied === 'code-detail' ? <><CheckCircle size={12} /> Copied!</> : <><Copy size={12} /> Copy Code</>}
                    </button>
                  </div>

                  <div className="rounded-xl p-4" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                    <div className="text-xs font-bold mb-2" style={{ color: '#8B90B0' }}>Create Invite Link</div>
                    <input value={inviteLabel} onChange={e => setInviteLabel(e.target.value)} placeholder='Label (e.g. "Term 2")' className="input text-xs py-1.5 mb-2" style={{ fontSize: 12 }} />
                    <button onClick={createInvite} className="btn-navy text-xs py-1.5 px-3 w-full">
                      <Link size={12} /> Generate Link
                    </button>
                  </div>
                </div>

                {/* Active invite links */}
                {invites.length > 0 && (
                  <div>
                    <div className="text-xs font-black uppercase tracking-wide mb-2" style={{ color: '#8B90B0' }}>Active Invite Links</div>
                    <div className="space-y-2">
                      {invites.map(inv => {
                        const link = `${appUrl}/join/${inv.token}`
                        const isExpired = inv.expires_at && new Date(inv.expires_at) < new Date()
                        return (
                          <div key={inv.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6', opacity: isExpired ? 0.5 : 1 }}>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs font-bold mb-0.5" style={{ color: '#2B2D42' }}>{inv.label || 'Invite Link'}</div>
                              <div className="text-xs truncate font-mono" style={{ color: '#8B90B0' }}>{link}</div>
                              <div className="text-xs mt-0.5" style={{ color: '#8B90B0' }}>
                                {inv.uses} use{inv.uses !== 1 ? 's' : ''}
                                {inv.max_uses ? ` / ${inv.max_uses} max` : ''}
                                {inv.expires_at ? ` · ${isExpired ? 'Expired' : 'Expires'} ${new Date(inv.expires_at).toLocaleDateString()}` : ''}
                              </div>
                            </div>
                            <div className="flex gap-1.5 flex-shrink-0">
                              <button onClick={() => copyToClipboard(link, inv.id)}
                                className="p-1.5 rounded-lg" style={{ background: '#EEF0FA' }}>
                                {copied === inv.id ? <CheckCircle size={13} style={{ color: '#22C55E' }} /> : <Copy size={13} style={{ color: '#8B90B0' }} />}
                              </button>
                              <button onClick={() => deleteInvite(inv.id)}
                                className="p-1.5 rounded-lg" style={{ background: '#FEF2F2' }}>
                                <Trash2 size={13} style={{ color: '#EF4444' }} />
                              </button>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Members list */}
              <div className="card-flat">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="section-title mb-0">Students ({members.length})</h3>
                </div>
                {members.length === 0 ? (
                  <p className="text-sm text-center py-6" style={{ color: '#8B90B0' }}>No students yet — share the class code or invite link!</p>
                ) : (
                  <div className="space-y-0">
                    {members.map((m, i) => {
                      const name = m.student_profiles?.full_name || m.users?.full_name || m.users?.email || 'Student'
                      const xp = m.student_profiles?.xp_points ?? 0
                      const level = m.student_profiles?.level ?? '—'
                      return (
                        <div key={m.id} className="flex items-center gap-3 py-3" style={{ borderBottom: i < members.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0" style={{ background: '#F5C51820', color: '#F5C518' }}>
                            {name[0]?.toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-bold truncate" style={{ color: '#2B2D42' }}>{name}</div>
                            <div className="text-xs" style={{ color: '#8B90B0' }}>{level} · ⚡{xp} XP · via {m.joined_via}</div>
                          </div>
                          <button onClick={() => removeStudent(m.id)} className="p-1.5 rounded-lg opacity-0 hover:opacity-100 transition-opacity" style={{ background: '#FEF2F2' }}>
                            <Trash2 size={12} style={{ color: '#EF4444' }} />
                          </button>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="md:col-span-2 flex items-center justify-center rounded-2xl" style={{ background: '#F8F9FE', border: '1px dashed #E8EAF6', minHeight: 300 }}>
              <div className="text-center">
                <div className="text-3xl mb-2">👈</div>
                <p className="text-sm font-semibold" style={{ color: '#8B90B0' }}>Select a class to manage it</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
