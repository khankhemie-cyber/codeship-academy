import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { UserPlus, TrendingUp, Search } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function StudentsPage({ searchParams }: { searchParams: { q?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const q = searchParams.q || ''

  let query = supabase.from('student_profiles').select('*, users!student_profiles_parent_id_fkey(email)').eq('teacher_id', user!.id).order('full_name')
  if (q) query = query.ilike('full_name', `%${q}%`)
  const { data: students } = await query

  const levelCounts: Record<string, number> = {}
  students?.forEach(s => { levelCounts[s.level] = (levelCounts[s.level] || 0) + 1 })

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">My Students</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{students?.length || 0} students</p>
        </div>
        <Link href="/dashboard/students/invite" className="btn-primary text-sm">
          <UserPlus size={15} /> Invite Student
        </Link>
      </div>

      {/* Level summary */}
      <div className="grid grid-cols-4 gap-3">
        {['Explorers', 'Builders', 'Developers', 'Engineers'].map(level => {
          const lvl = getLevelConfig(level as LevelName)
          return (
            <div key={level} className="card-flat flex items-center gap-3 p-3">
              <span className="text-xl">{lvl.icon}</span>
              <div>
                <div className="text-lg font-black" style={{ color: '#2B2D42' }}>{levelCounts[level] || 0}</div>
                <div className="text-xs" style={{ color: '#8B90B0' }}>{level}</div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Search */}
      <form method="GET">
        <div className="flex items-center gap-2 rounded-xl border px-3 py-2" style={{ borderColor: '#E8EAF6', background: '#F8F9FE' }}>
          <Search size={15} style={{ color: '#8B90B0' }} />
          <input name="q" defaultValue={q} placeholder="Search students..." className="flex-1 bg-transparent outline-none text-sm" style={{ fontFamily: 'inherit', color: '#2B2D42' }} />
        </div>
      </form>

      {/* Student list */}
      {!students?.length ? (
        <div className="card-flat text-center py-12">
          <div className="text-4xl mb-3">👥</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>{q ? 'No students found' : 'No students yet'}</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Invite students to your classroom to get started.</p>
        </div>
      ) : (
        <div className="card-flat overflow-hidden p-0">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                {['Student', 'Level', 'XP', 'Streak', 'Last Active', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {students.map(s => {
                const lvl = getLevelConfig(s.level as LevelName)
                return (
                  <tr key={s.id} style={{ borderBottom: '1px solid #F0F2FA' }}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm" style={{ background: lvl.color + '20' }}>{s.avatar_emoji}</div>
                        <div>
                          <div className="font-bold text-sm" style={{ color: '#2B2D42' }}>{s.full_name}</div>
                          <div className="text-xs" style={{ color: '#8B90B0' }}>Grade {s.grade}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{s.level}</span>
                    </td>
                    <td className="px-4 py-3 text-sm font-bold" style={{ color: '#F5C518' }}>⚡ {s.xp_points}</td>
                    <td className="px-4 py-3 text-sm" style={{ color: '#2B2D42' }}>🔥 {s.streak_days}d</td>
                    <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0' }}>{s.last_active_at ? new Date(s.last_active_at).toLocaleDateString() : 'Never'}</td>
                    <td className="px-4 py-3">
                      <Link href={`/dashboard/progress?child=${s.id}`} className="flex items-center gap-1 text-xs font-bold hover:underline" style={{ color: '#0EA5E9' }}>
                        <TrendingUp size={12} /> Progress
                      </Link>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
