import { createClient } from '@/lib/supabase/server'
import { Award } from 'lucide-react'

export default async function AchievementsPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: studentProfile } = await supabase.from('student_profiles').select('id,xp_points,streak_days').eq('user_id', user!.id).single()
  const { data: allAchievements } = await supabase.from('achievements').select('*')
  const { data: earned } = studentProfile
    ? await supabase.from('student_achievements').select('achievement_id,earned_at').eq('student_id', studentProfile.id)
    : { data: [] }
  const earnedIds = new Set(earned?.map(e => e.achievement_id))
  const earnedMap: Record<string, string> = {}
  earned?.forEach(e => { earnedMap[e.achievement_id] = e.earned_at })

  return (
    <div className="p-6 space-y-5 animate-in">
      <div>
        <h1 className="page-header">Achievements</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>{earnedIds.size} of {allAchievements?.length} earned</p>
      </div>

      {/* Progress */}
      <div className="card-flat">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold" style={{ color: '#2B2D42' }}>Achievement Progress</span>
          <span className="text-sm font-black" style={{ color: '#F5C518' }}>{earnedIds.size}/{allAchievements?.length}</span>
        </div>
        <div className="progress-bar h-3">
          <div className="progress-fill" style={{ width: `${allAchievements?.length ? (earnedIds.size / allAchievements.length) * 100 : 0}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
        {allAchievements?.map(achievement => {
          const isEarned = earnedIds.has(achievement.id)
          const earnedDate = earnedMap[achievement.id]
          return (
            <div key={achievement.id} className="card p-5 flex flex-col items-center text-center" style={{ opacity: isEarned ? 1 : 0.4, borderColor: isEarned ? '#F5C51844' : undefined }}>
              <div className="text-4xl mb-3">{achievement.emoji}</div>
              <div className="font-black text-sm mb-1" style={{ color: '#2B2D42' }}>{achievement.name}</div>
              <p className="text-xs mb-3" style={{ color: '#8B90B0', lineHeight: 1.4 }}>{achievement.description}</p>
              <div className="text-xs font-bold" style={{ color: '#F5C518' }}>+{achievement.xp_reward} XP</div>
              {isEarned && earnedDate && (
                <div className="mt-2 text-xs" style={{ color: '#22C55E' }}>
                  ✓ Earned {new Date(earnedDate).toLocaleDateString()}
                </div>
              )}
              {!isEarned && (
                <div className="mt-2 flex items-center gap-1 text-xs" style={{ color: '#8B90B0' }}>
                  <Award size={10} /> Locked
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
