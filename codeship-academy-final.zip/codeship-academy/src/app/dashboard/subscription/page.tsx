'use client'
import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { CheckCircle, CreditCard, Download, ExternalLink, AlertCircle, Zap, Building2, Package } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { PLAN_DISPLAY, SESSION_PACKS, SCHOOL_PLANS } from '@/lib/stripe'

type BillingCycle = 'monthly' | 'annual'
type Tab = 'personal' | 'sessions' | 'school'

export default function SubscriptionPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createClient()
  const [sub, setSub] = useState<any>(null)
  const [payments, setPayments] = useState<any[]>([])
  const [loading, setLoading] = useState<string | null>(null)
  const [cycle, setCycle] = useState<BillingCycle>('monthly')
  const [tab, setTab] = useState<Tab>('personal')

  const success = searchParams.get('success')
  const canceled = searchParams.get('canceled')

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const [{ data: s }, { data: p }] = await Promise.all([
        supabase.from('subscriptions').select('*').eq('user_id', user.id).single(),
        supabase.from('payments').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10),
      ])
      setSub(s); setPayments(p || [])
    }
    load()
  }, [])

  const checkout = async (planId: string) => {
    setLoading(planId)
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan: planId }),
    })
    const { url } = await res.json()
    if (url) window.location.href = url
    setLoading(null)
  }

  const openPortal = async () => {
    setLoading('portal')
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const { url } = await res.json()
    if (url) window.location.href = url
    setLoading(null)
  }

  const isActive = sub?.status === 'active' || sub?.status === 'trialing'
  const trialDays = sub?.trial_end ? Math.max(0, Math.ceil((new Date(sub.trial_end).getTime() - Date.now()) / 86400000)) : 0

  const annualPlan = PLAN_DISPLAY.find(p => p.id === 'annual')
  const monthlyPlan = PLAN_DISPLAY.find(p => p.id === 'monthly')
  const annualSavings = monthlyPlan && annualPlan
    ? Math.round((1 - (annualPlan.price / (monthlyPlan.price * 12))) * 100)
    : 35

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 animate-in">

      {success && (
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
          <CheckCircle size={18} style={{ color: '#22C55E' }} />
          <span className="text-sm font-bold" style={{ color: '#166534' }}>🎉 Subscription activated! All features are now unlocked.</span>
        </div>
      )}
      {canceled && (
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: '#FEF2F2', border: '1px solid #FECACA' }}>
          <AlertCircle size={18} style={{ color: '#EF4444' }} />
          <span className="text-sm font-semibold" style={{ color: '#991B1B' }}>Checkout was canceled. No charge was made.</span>
        </div>
      )}

      {/* Current plan banner */}
      <div className="rounded-2xl p-6 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#F5C518' }}>Your Plan</div>
            <h2 className="text-2xl font-black text-white capitalize mb-1">{sub?.plan || 'trial'}</h2>
            <div className="text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
              Status: <span className="font-bold" style={{ color: isActive ? '#22C55E' : '#EF4444' }}>{sub?.status || 'trialing'}</span>
              {sub?.status === 'trialing' && <span className="ml-2">· {trialDays} days left</span>}
              {sub?.current_period_end && sub?.status === 'active' && (
                <span className="ml-2">· Renews {new Date(sub.current_period_end).toLocaleDateString()}</span>
              )}
              {sub?.cancel_at_period_end && <span className="ml-2 text-yellow-400">· Cancels at period end</span>}
            </div>
          </div>
          <div className="flex gap-2 flex-wrap justify-end">
            {sub?.stripe_customer_id && (
              <button onClick={openPortal} disabled={loading === 'portal'} className="btn-outline text-sm py-2 px-4" style={{ background: 'rgba(255,255,255,0.1)', color: 'white', borderColor: 'rgba(255,255,255,0.2)' }}>
                <ExternalLink size={13} /> Manage Billing
              </button>
            )}
          </div>
        </div>
        <div className="flex gap-6 mt-4">
          {[
            { label: 'Children', value: sub?.max_children ?? 1 },
            { label: 'AI Planner', value: sub?.features?.ai_planner ? '✓' : '—' },
            { label: 'Reports', value: sub?.features?.reports ? '✓' : '—' },
            { label: 'Session Packs', value: sub?.session_packs_remaining ?? 0 },
          ].map(f => (
            <div key={f.label}>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>{f.label}</div>
              <div className="font-bold text-white">{f.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tab nav */}
      <div className="flex gap-1 p-1 rounded-xl self-start" style={{ background: '#EEF0FA', width: 'fit-content' }}>
        {([
          { id: 'personal', icon: Zap, label: 'Personal Plans' },
          { id: 'sessions', icon: Package, label: 'Session Packs' },
          { id: 'school', icon: Building2, label: 'School Plans' },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold transition-all"
            style={{ background: tab === t.id ? '#1E2140' : 'transparent', color: tab === t.id ? 'white' : '#8B90B0' }}>
            <t.icon size={14} />{t.label}
          </button>
        ))}
      </div>

      {/* Personal plans */}
      {tab === 'personal' && (
        <>
          <div className="flex justify-center">
            <div className="flex p-1 rounded-xl" style={{ background: '#EEF0FA' }}>
              {(['monthly', 'annual'] as const).map(c => (
                <button key={c} onClick={() => setCycle(c)}
                  className="px-5 py-2 rounded-lg text-sm font-bold transition-all"
                  style={{ background: cycle === c ? '#1E2140' : 'transparent', color: cycle === c ? 'white' : '#8B90B0' }}>
                  {c === 'annual' ? `Annual — Save ${annualSavings}%` : 'Monthly'}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {PLAN_DISPLAY.map(plan => {
              const isCurrent = sub?.plan === plan.id
              const displayPrice = cycle === 'annual' && plan.id === 'annual' ? plan.price : plan.price
              return (
                <div key={plan.id} className="rounded-2xl p-5 border-2 relative" style={{ borderColor: isCurrent ? plan.color : '#E8EAF6', background: isCurrent ? plan.color + '08' : 'white' }}>
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-black px-3 py-1 rounded-full whitespace-nowrap" style={{ background: '#F5C518', color: '#1E2140' }}>
                      BEST VALUE
                    </div>
                  )}
                  <div className="font-black text-base mb-1" style={{ color: '#1E2140' }}>{plan.name}</div>
                  <div className="flex items-baseline gap-1 mb-3">
                    <span className="text-2xl font-black" style={{ color: plan.color }}>${displayPrice}</span>
                    <span className="text-xs" style={{ color: '#8B90B0' }}>{plan.period}</span>
                  </div>
                  <div className="space-y-1.5 mb-4">
                    {plan.features.map(f => (
                      <div key={f} className="flex items-center gap-1.5 text-xs">
                        <CheckCircle size={10} style={{ color: plan.color, flexShrink: 0 }} />
                        <span style={{ color: '#2B2D42' }}>{f}</span>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => isCurrent ? openPortal() : checkout(plan.id)}
                    disabled={!!loading}
                    className="w-full py-2.5 rounded-xl text-xs font-bold transition-all"
                    style={{ background: isCurrent ? plan.color : plan.color + '18', color: isCurrent ? (plan.id === 'annual' ? '#1E2140' : 'white') : plan.color }}>
                    {loading === plan.id ? 'Loading...' : isCurrent ? '✓ Current Plan' : 'Choose Plan'}
                  </button>
                </div>
              )
            })}
          </div>
        </>
      )}

      {/* Session packs */}
      {tab === 'sessions' && (
        <div className="space-y-4">
          <div className="rounded-xl p-4 text-sm" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6', color: '#8B90B0' }}>
            💡 Session packs are one-time purchases for CODEship's in-school 90-minute workshop program. Each session is delivered at your school by a CODEship instructor.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {SESSION_PACKS.map(pack => (
              <div key={pack.id} className="rounded-2xl p-6 border-2" style={{ borderColor: pack.color + '44', background: pack.color + '06' }}>
                <div className="text-3xl mb-3 font-black" style={{ color: pack.color }}>{pack.name}</div>
                <div className="flex items-baseline gap-1 mb-1">
                  <span className="text-3xl font-black" style={{ color: '#2B2D42' }}>${(pack.price / 100).toFixed(0)}</span>
                </div>
                <div className="text-sm mb-4" style={{ color: '#8B90B0' }}>
                  ${pack.perSession}/session · Save {Math.round((1 - pack.perSession / 99) * 100)}% vs single session
                </div>
                <div className="space-y-1.5 mb-5">
                  {[
                    `${pack.name.split(' ')[0]} × 90-minute workshops`,
                    'Any CODEship level (K–8)',
                    'Up to 30 students per session',
                    'All materials included',
                    'Valid for 12 months',
                  ].map(f => (
                    <div key={f} className="flex items-center gap-1.5 text-xs">
                      <CheckCircle size={10} style={{ color: pack.color, flexShrink: 0 }} />
                      <span style={{ color: '#2B2D42' }}>{f}</span>
                    </div>
                  ))}
                </div>
                <button onClick={() => checkout(pack.id)} disabled={!!loading}
                  className="w-full py-3 rounded-xl text-sm font-black transition-all"
                  style={{ background: pack.color, color: pack.id === 'sessions_10' ? '#1E2140' : 'white' }}>
                  {loading === pack.id ? 'Loading...' : `Buy ${pack.name}`}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* School plans */}
      {tab === 'school' && (
        <div className="space-y-4">
          <div className="rounded-xl p-4 text-sm" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6', color: '#8B90B0' }}>
            🏫 School plans include a full digital platform license for your school plus a set number of in-person workshops per year.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {SCHOOL_PLANS.map(plan => (
              <div key={plan.id} className="rounded-2xl p-6 border-2 relative" style={{ borderColor: plan.color + '44', background: plan.id === 'school_annual' ? plan.color + '06' : 'white' }}>
                {plan.id === 'school_annual' && (
                  <div className="absolute -top-3 left-6 text-xs font-black px-3 py-1 rounded-full" style={{ background: '#F5C518', color: '#1E2140' }}>
                    BEST VALUE
                  </div>
                )}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="font-black text-lg mb-1" style={{ color: '#1E2140' }}>{plan.name}</div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-black" style={{ color: plan.color }}>${plan.price}</span>
                      <span className="text-sm" style={{ color: '#8B90B0' }}>{plan.period}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-black" style={{ color: '#2B2D42' }}>{plan.students}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>student accounts</div>
                    <div className="text-lg font-black mt-1" style={{ color: '#2B2D42' }}>{plan.sessions}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>workshops/year</div>
                  </div>
                </div>
                <div className="space-y-2 mb-5">
                  {plan.features.map(f => (
                    <div key={f} className="flex items-center gap-2 text-sm">
                      <CheckCircle size={14} style={{ color: plan.color, flexShrink: 0 }} />
                      <span style={{ color: '#2B2D42' }}>{f}</span>
                    </div>
                  ))}
                </div>
                <button onClick={() => checkout(plan.id)} disabled={!!loading}
                  className="w-full py-3.5 rounded-xl font-black transition-all"
                  style={{ background: plan.color, color: plan.id === 'school_annual' ? '#1E2140' : 'white' }}>
                  {loading === plan.id ? 'Loading...' : 'Get School Plan'}
                </button>
              </div>
            ))}
          </div>
          <div className="text-center text-sm" style={{ color: '#8B90B0' }}>
            Need a custom quote for your school board? <a href="mailto:admin@codeshipacademy.com" style={{ color: '#F5C518', fontWeight: 700 }}>Contact us</a>
          </div>
        </div>
      )}

      {/* Billing history */}
      {payments.length > 0 && (
        <div className="card-flat">
          <h3 className="section-title">Billing History</h3>
          <div className="space-y-0">
            {payments.map((p, i) => (
              <div key={i} className="flex items-center gap-4 py-3 border-b last:border-b-0" style={{ borderColor: '#F0F2FA' }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#22C55E18' }}>
                  <CreditCard size={15} style={{ color: '#22C55E' }} />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold" style={{ color: '#2B2D42' }}>{p.description || 'CODEship subscription'}</div>
                  <div className="text-xs" style={{ color: '#8B90B0' }}>{new Date(p.created_at).toLocaleDateString()}</div>
                </div>
                <div className="font-bold text-sm" style={{ color: '#2B2D42' }}>${(p.amount / 100).toFixed(2)} {p.currency?.toUpperCase()}</div>
                <span className="badge text-xs" style={{ background: '#22C55E18', color: '#22C55E' }}>Paid</span>
                {p.invoice_url && (
                  <a href={p.invoice_url} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-lg hover:bg-gray-100">
                    <Download size={13} style={{ color: '#8B90B0' }} />
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
