'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Save, LogOut, Eye, EyeOff } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function SettingsPage() {
  const supabase = createClient()
  const router = useRouter()
  const [profile, setProfile] = useState<any>(null)
  const [form, setForm] = useState({ full_name: '', email: '' })
  const [password, setPassword] = useState({ current: '', new: '', confirm: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return
      supabase.from('users').select('*').eq('id', user.id).single().then(({ data }) => {
        setProfile(data)
        setForm({ full_name: data?.full_name || '', email: user.email || '' })
      })
    })
  }, [])

  const saveProfile = async () => {
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    await supabase.from('users').update({ full_name: form.full_name }).eq('id', user!.id)
    setMsg('Profile updated!')
    setSaving(false)
    setTimeout(() => setMsg(''), 3000)
  }

  const changePassword = async () => {
    if (password.new !== password.confirm) { setMsg('Passwords do not match'); return }
    if (password.new.length < 8) { setMsg('Password must be at least 8 characters'); return }
    setSaving(true)
    const { error } = await supabase.auth.updateUser({ password: password.new })
    setMsg(error ? `Error: ${error.message}` : 'Password changed successfully!')
    setPassword({ current: '', new: '', confirm: '' })
    setSaving(false)
    setTimeout(() => setMsg(''), 4000)
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  return (
    <div className="p-6 max-w-xl mx-auto space-y-5 animate-in">
      <h1 className="page-header">Account Settings</h1>

      {msg && <div className="text-sm px-4 py-3 rounded-xl font-semibold" style={{ background: msg.startsWith('Error') ? '#FEF2F2' : '#F0FDF4', color: msg.startsWith('Error') ? '#991B1B' : '#166534' }}>{msg}</div>}

      {/* Profile */}
      <div className="card-flat space-y-4">
        <h2 className="font-black text-base" style={{ color: '#2B2D42' }}>Profile</h2>
        <div>
          <label className="label">Full Name</label>
          <input className="input" value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} />
        </div>
        <div>
          <label className="label">Email Address</label>
          <input className="input" value={form.email} disabled style={{ opacity: 0.6 }} />
          <p className="text-xs mt-1" style={{ color: '#8B90B0' }}>Email cannot be changed. Contact support to update.</p>
        </div>
        <div>
          <label className="label">Role</label>
          <div className="input capitalize" style={{ opacity: 0.6, cursor: 'default' }}>{profile?.role || 'parent'}</div>
        </div>
        <button onClick={saveProfile} disabled={saving} className="btn-primary w-full">
          <Save size={15} /> {saving ? 'Saving...' : 'Save Profile'}
        </button>
      </div>

      {/* Password */}
      <div className="card-flat space-y-4">
        <h2 className="font-black text-base" style={{ color: '#2B2D42' }}>Change Password</h2>
        <div>
          <label className="label">New Password</label>
          <div className="relative">
            <input className="input pr-10" type={showPwd ? 'text' : 'password'} value={password.new} onChange={e => setPassword(p => ({ ...p, new: e.target.value }))} placeholder="8+ characters" />
            <button onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-1/2 -translate-y-1/2">
              {showPwd ? <EyeOff size={16} style={{ color: '#8B90B0' }} /> : <Eye size={16} style={{ color: '#8B90B0' }} />}
            </button>
          </div>
        </div>
        <div>
          <label className="label">Confirm New Password</label>
          <input className="input" type={showPwd ? 'text' : 'password'} value={password.confirm} onChange={e => setPassword(p => ({ ...p, confirm: e.target.value }))} />
        </div>
        <button onClick={changePassword} disabled={!password.new || !password.confirm || saving} className="btn-navy w-full">
          Update Password
        </button>
      </div>

      {/* Danger zone */}
      <div className="card-flat space-y-4" style={{ borderColor: '#FECACA' }}>
        <h2 className="font-black text-base" style={{ color: '#EF4444' }}>Sign Out</h2>
        <button onClick={signOut} className="w-full py-3 rounded-xl border-2 font-bold text-sm flex items-center justify-center gap-2 transition-all hover:bg-red-50" style={{ borderColor: '#FECACA', color: '#EF4444' }}>
          <LogOut size={15} /> Sign Out of All Devices
        </button>
      </div>
    </div>
  )
}
