'use client'
import { useEffect } from 'react'
import { AlertTriangle, RefreshCw, Home } from 'lucide-react'
import Link from 'next/link'

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error('[CODEship Error]', error)
  }, [error])

  return (
    <div className="flex items-center justify-center min-h-full p-8">
      <div className="card-flat text-center max-w-md w-full py-12 px-8">
        <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-5" style={{ background: '#FEF2F2' }}>
          <AlertTriangle size={28} style={{ color: '#EF4444' }} />
        </div>
        <h2 className="text-xl font-black mb-2" style={{ color: '#2B2D42' }}>Something went wrong</h2>
        <p className="text-sm mb-6" style={{ color: '#8B90B0', lineHeight: 1.6 }}>
          We hit an unexpected error loading this page. This has been logged and our team will look into it.
        </p>
        {error.message && (
          <div className="text-xs font-mono px-3 py-2 rounded-lg mb-6 text-left overflow-auto" style={{ background: '#FEF2F2', color: '#991B1B', maxHeight: 80 }}>
            {error.message}
          </div>
        )}
        <div className="flex gap-3 justify-center">
          <button onClick={reset} className="btn-primary text-sm py-2.5 px-5">
            <RefreshCw size={14} /> Try Again
          </button>
          <Link href="/dashboard" className="btn-outline text-sm py-2.5 px-5" style={{ textDecoration: 'none' }}>
            <Home size={14} /> Dashboard
          </Link>
        </div>
      </div>
    </div>
  )
}
