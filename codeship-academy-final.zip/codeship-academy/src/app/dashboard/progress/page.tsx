import { createClient } from '@/lib/supabase/server'
import MasteryPanel from '@/components/learning/MasteryPanel'
import { TrendingUp, CheckCircle, Target, Star, Zap, BookOpen, Code2 } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function ProgressPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: profile } = await supabase.from('users').select('role').eq('id', user!.id).single()
  const role = profile?.role

  // For parents, get all children; for students, get own record
  let students: any[] = []
  if (role === 'student') {
    const { data } = await supabase.from('student_profiles').select('*').eq('user_id', user!.id).single()
    if (data) students = [data]
  } else {
    const { data } = await supabase.from('student_profiles').select('*').eq('parent_id', user!.id)
    students = data || []
  }

  const selectedStudent = students[0]
  const progressRecords = selectedStudent ? (await supabase
    .from('progress_records').select('*')
    .eq('student_id', selectedStudent.id)
    .order('completed_at', { ascending: false })
    .limit(50)).data || [] : []

  const quizAttempts = selectedStudent ? (await supabase
    .from('quiz_attempts').select('*, quizzes(title, topic)')
    .eq('student_id', selectedStudent.id)
    .order('completed_at', { ascending: false })
    .limit(20)).data || [] : []

  const completed = progressRecords.filter(r => r.status === 'completed').length
  const avgScore = quizAttempts.length ? Math.round(quizAttempts.reduce((s: number, a: any) => s + a.score, 0) / quizAttempts.length) : 0
  const totalXP = progressRecords.reduce((s, r) => s + (r.xp_earned || 0), 0)

  const lvl = selectedStudent ? getLevelConfig(selectedStudent.level as LevelName) : null

  return (
    <div className="p-6 space-y-5 animate-in">

      {/* Student selector (parent view) */}
      {role === 'parent' && students.length > 1 && (
        <div className="flex gap-3">
          {students.map(s => {
            const slvl = getLevelConfig(s.level as LevelName)
            return (
              <div key={s.id} className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl border-2" style={{ borderColor: slvl.color, background: slvl.color + '08' }}>
                <span className="text-lg">{s.avatar_emoji}</span>
                <div>
                  <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{s.full_name}</div>
                  <div className="text-xs" style={{ color: slvl.color }}>{s.level}</div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {!selectedStudent ? (
        <div className="card-flat text-center py-16">
          <div className="text-4xl mb-3">📊</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No students yet</h3>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Add a child to start tracking progress.</p>
        </div>
      ) : (
        <>
          {/* Summary stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Completed', value: completed, icon: CheckCircle, color: '#22C55E' },
              { label: 'Quiz Avg', value: `${avgScore}%`, icon: Target, color: '#F59E0B' },
              { label: 'Total XP', value: totalXP, icon: Star, color: '#F5C518' },
              { label: 'Streak', value: `🔥 ${selectedStudent.streak_days}`, icon: Zap, color: '#EF4444' },
              { label: 'Level', value: selectedStudent.level, icon: TrendingUp, color: lvl?.color || '#0EA5E9' },
            ].map(s => (
              <div key={s.label} className="card-flat flex items-center gap-3 p-4">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: s.color + '18' }}>
                  <s.icon size={18} style={{ color: s.color }} />
                </div>
                <div>
                  <div className="text-lg font-black" style={{ color: '#2B2D42' }}>{s.value}</div>
                  <div className="text-xs" style={{ color: '#8B90B0' }}>{s.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* XP progress bar */}
          <div className="card-flat">
            <div className="flex items-center justify-between mb-3">
              <h3 className="section-title mb-0">XP Progress — {selectedStudent.level}</h3>
              <span className="text-sm font-black" style={{ color: '#F5C518' }}>⚡ {selectedStudent.xp_points} XP</span>
            </div>
            <div className="progress-bar h-4">
              <div className="progress-fill" style={{ width: `${Math.min((selectedStudent.xp_points % 500) / 5, 100)}%` }} />
            </div>
            <div className="flex justify-between text-xs mt-1" style={{ color: '#8B90B0' }}>
              <span>Level {Math.floor(selectedStudent.xp_points / 500) + 1}</span>
              <span>{500 - (selectedStudent.xp_points % 500)} XP to next level</span>
            </div>
          </div>

          {/* Quiz scores */}
          {selectedStudent && (
            <MasteryPanel studentId={selectedStudent.id} level={selectedStudent.level as any} />
          )}

          {quizAttempts.length > 0 && (
            <div className="card-flat">
              <h3 className="section-title">Quiz Performance</h3>
              <div className="space-y-3">
                {quizAttempts.slice(0, 8).map((attempt: any, i: number) => (
                  <div key={i} className="flex items-center gap-4">
                    <div className="flex-1 text-sm font-semibold truncate" style={{ color: '#2B2D42' }}>
                      {attempt.quizzes?.title || 'Quiz'}
                    </div>
                    <div className="w-36">
                      <div className="progress-bar h-2">
                        <div className="h-full rounded-full" style={{ width: `${attempt.score}%`, background: attempt.score >= 80 ? '#22C55E' : attempt.score >= 60 ? '#F59E0B' : '#EF4444' }} />
                      </div>
                    </div>
                    <div className="text-sm font-black w-12 text-right" style={{ color: attempt.score >= 80 ? '#22C55E' : attempt.score >= 60 ? '#F59E0B' : '#EF4444' }}>
                      {attempt.score}%
                    </div>
                    <span className="badge text-xs w-16 justify-center" style={{ background: attempt.passed ? '#22C55E18' : '#EF4444', color: attempt.passed ? '#22C55E' : 'white' }}>
                      {attempt.passed ? 'Passed' : 'Review'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent activity */}
          <div className="card-flat">
            <h3 className="section-title">Recent Activity</h3>
            {progressRecords.length === 0 ? (
              <p className="text-sm text-center py-6" style={{ color: '#8B90B0' }}>No activity yet. Start a lesson!</p>
            ) : (
              <div className="space-y-0">
                {progressRecords.slice(0, 12).map((record, i) => {
                  const typeIcon = record.content_type === 'lesson' ? BookOpen : record.content_type === 'project' ? Code2 : Target
                  const typeColor = record.content_type === 'lesson' ? '#0EA5E9' : record.content_type === 'project' ? '#7C3AED' : '#F59E0B'
                  return (
                    <div key={i} className="flex items-center gap-3 py-3 border-b last:border-b-0" style={{ borderColor: '#F0F2FA' }}>
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: typeColor + '18' }}>
                        {typeIcon && <typeIcon size={14} style={{ color: typeColor }} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold truncate" style={{ color: '#2B2D42' }}>{record.content_title}</div>
                        <div className="text-xs" style={{ color: '#8B90B0' }}>
                          {record.completed_at ? new Date(record.completed_at).toLocaleDateString() : 'In progress'}
                          {record.score != null && <> · {record.score}%</>}
                        </div>
                      </div>
                      {record.xp_earned > 0 && (
                        <span className="text-xs font-bold" style={{ color: '#F5C518' }}>+{record.xp_earned} XP</span>
                      )}
                      <span className="badge text-xs" style={{
                        background: record.status === 'completed' ? '#22C55E18' : record.status === 'in_progress' ? '#F59E0B18' : '#EEF0FA',
                        color: record.status === 'completed' ? '#22C55E' : record.status === 'in_progress' ? '#F59E0B' : '#8B90B0'
                      }}>
                        {record.status === 'in_progress' ? 'In Progress' : record.status === 'completed' ? 'Done' : record.status}
                      </span>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
