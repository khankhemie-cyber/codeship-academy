'use client'
import dynamic from 'next/dynamic'

const CodeEditor = dynamic(() => import('@/components/code-lab/CodeEditor'), { ssr: false })

export default function EditorPage() {
  return <CodeEditor />
}
