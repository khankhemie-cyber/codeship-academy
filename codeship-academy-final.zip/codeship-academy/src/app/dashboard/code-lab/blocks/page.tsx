'use client'
import dynamic from 'next/dynamic'

const BlocksEnvironment = dynamic(() => import('@/components/code-lab/BlocksEnvironment'), { ssr: false })

export default function BlocksPage() {
  return <BlocksEnvironment />
}
