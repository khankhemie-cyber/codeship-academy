import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Code2, Blocks, ArrowRight } from 'lucide-react'

export default async function CodeLabPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: profile } = await supabase.from('users').select('role').eq('id', user!.id).single()
  const { data: student } = await supabase.from('student_profiles').select('level').eq('user_id', user!.id).single()

  const level = student?.level ?? 'Explorers'
  const isYoungLevel = level === 'Explorers' || level === 'Builders'

  return (
    <div className="p-6 max-w-3xl mx-auto animate-in">
      <h1 className="page-header">CODEship Code Lab</h1>
      <p className="text-sm mb-8" style={{ color: '#8B90B0' }}>Choose your coding environment — you can use both!</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Blocks */}
        <Link href="/dashboard/code-lab/blocks" className="card p-6 no-underline group" style={{ textDecoration: 'none', borderColor: isYoungLevel ? '#F5C51866' : '#E8EAF6' }}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: '#F5C51820' }}>
            <span className="text-3xl">🧩</span>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-lg font-black" style={{ color: '#2B2D42' }}>CODEship Blocks</h2>
            {isYoungLevel && <span className="badge text-xs" style={{ background: '#F5C51818', color: '#D4A800' }}>Recommended</span>}
          </div>
          <p className="text-sm mb-4" style={{ color: '#8B90B0', lineHeight: 1.6 }}>
            Drag-and-drop block coding. Move your rocket around the stage using visual code blocks — perfect for Explorers and Builders!
          </p>
          <div className="flex flex-wrap gap-2 mb-5">
            {['Explorers', 'Builders', 'K–3', 'Ages 6–9', 'Visual Coding'].map(tag => (
              <span key={tag} className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{tag}</span>
            ))}
          </div>
          <div className="flex items-center gap-2 text-sm font-bold group-hover:gap-3 transition-all" style={{ color: '#F5C518' }}>
            Open Blocks Editor <ArrowRight size={15} />
          </div>
        </Link>

        {/* Code Editor */}
        <Link href="/dashboard/code-lab/editor" className="card p-6 no-underline group" style={{ textDecoration: 'none', borderColor: !isYoungLevel ? '#0EA5E966' : '#E8EAF6' }}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: '#0EA5E918' }}>
            <Code2 size={26} style={{ color: '#0EA5E9' }} />
          </div>
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-lg font-black" style={{ color: '#2B2D42' }}>CODEship Editor</h2>
            {!isYoungLevel && <span className="badge text-xs" style={{ background: '#0EA5E918', color: '#0EA5E9' }}>Recommended</span>}
          </div>
          <p className="text-sm mb-4" style={{ color: '#8B90B0', lineHeight: 1.6 }}>
            Live coding environment with real-time preview. Write HTML, CSS, JavaScript, or Python and see results instantly.
          </p>
          <div className="flex flex-wrap gap-2 mb-5">
            {['Developers', 'Engineers', 'Gr 4–8', 'HTML/CSS/JS', 'Python'].map(tag => (
              <span key={tag} className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{tag}</span>
            ))}
          </div>
          <div className="flex items-center gap-2 text-sm font-bold group-hover:gap-3 transition-all" style={{ color: '#0EA5E9' }}>
            Open Code Editor <ArrowRight size={15} />
          </div>
        </Link>
      </div>

      {/* Info */}
      <div className="mt-6 rounded-2xl p-5" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
        <h3 className="font-black text-sm mb-2" style={{ color: '#2B2D42' }}>💡 How Code Lab works</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm" style={{ color: '#8B90B0' }}>
          <div>
            <strong style={{ color: '#2B2D42' }}>CODEship Blocks</strong> — drag blocks from the palette onto the script area. Click Run to see your rocket execute the program on stage. Try the example to get started instantly!
          </div>
          <div>
            <strong style={{ color: '#2B2D42' }}>CODEship Editor</strong> — write real code with syntax highlighting and live preview. Python runs in the browser using Skulpt. HTML/CSS/JS renders instantly. Download your work when done.
          </div>
        </div>
      </div>
    </div>
  )
}
