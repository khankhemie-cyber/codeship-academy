import Link from 'next/link'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { Play, CheckCircle, Clock, Zap, BookOpen, Code2, Target, ArrowRight } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'

export default async function TodayPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: studentProfile } = await supabase
    .from('student_profiles').select('*').eq('user_id', user.id).single()

  if (!studentProfile) {
    return (
      <div className="p-6 text-center py-20">
        <div className="text-4xl mb-3">👋</div>
        <h2 className="font-black text-xl mb-2" style={{ color: '#2B2D42' }}>Welcome to CODEship!</h2>
        <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Ask your parent to set up your account and create your first lesson plan.</p>
      </div>
    )
  }

  const today = new Date().toISOString().split('T')[0]
  const { data: sessions } = await supabase
    .from('scheduled_sessions')
    .select('*')
    .eq('student_id', studentProfile.id)
    .eq('scheduled_date', today)
    .order('scheduled_time')

  const lvl = getLevelConfig(studentProfile.level)

  const typeIcon = { lesson: BookOpen, project: Code2, quiz: Target }
  const typeColor = { lesson: '#0EA5E9', project: '#7C3AED', quiz: '#F59E0B' }
  const typeHref = { lesson: '/dashboard/curriculum/lesson', project: '/dashboard/projects', quiz: '/dashboard/quizzes' }

  const completed = sessions?.filter(s => s.status === 'completed').length ?? 0
  const total = sessions?.length ?? 0

  return (
    <div className="p-6 space-y-5 animate-in">
      {/* Hero greeting */}
      <div className="rounded-2xl p-6 relative overflow-hidden" style={{ background: lvl.color + '18', border: `1.5px solid ${lvl.color}33` }}>
        <div className="absolute right-4 top-4 text-5xl opacity-20">{lvl.icon}</div>
        <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: lvl.color }}>
          {new Date().toLocaleDateString('en-CA', { weekday: 'long', month: 'long', day: 'numeric' })}
        </div>
        <h1 className="text-2xl font-black mb-1" style={{ color: '#1E2140' }}>
          Hey {studentProfile.full_name?.split(' ')[0]}! 👋
        </h1>
        <p className="text-sm" style={{ color: '#3A3D5C' }}>
          {total === 0 ? "No sessions scheduled today — great day to explore!" : completed === total ? "You finished all your sessions today! Amazing! 🎉" : `${total - completed} session${total - completed > 1 ? 's' : ''} left today`}
        </p>
        <div className="flex items-center gap-4 mt-4">
          <div className="flex items-center gap-1.5 text-sm font-bold" style={{ color: '#1E2140' }}>
            <Zap size={15} style={{ color: '#F5C518' }} /> {studentProfile.xp_points} XP
          </div>
          <div className="flex items-center gap-1.5 text-sm font-bold" style={{ color: '#1E2140' }}>
            🔥 {studentProfile.streak_days} day streak
          </div>
          <div className="flex items-center gap-1.5 text-sm font-bold" style={{ color: lvl.color }}>
            {lvl.icon} {studentProfile.level}
          </div>
        </div>
      </div>

      {/* Progress bar */}
      {total > 0 && (
        <div>
          <div className="flex justify-between text-xs font-semibold mb-2" style={{ color: '#8B90B0' }}>
            <span>Today's progress</span>
            <span style={{ color: '#2B2D42' }}>{completed}/{total} done</span>
          </div>
          <div className="progress-bar h-3">
            <div className="progress-fill" style={{ width: `${total ? (completed / total) * 100 : 0}%` }} />
          </div>
        </div>
      )}

      {/* Sessions */}
      {sessions && sessions.length > 0 ? (
        <div className="space-y-3">
          <h2 className="section-title">Today's Sessions</h2>
          {sessions.map(session => {
            const Icon = typeIcon[session.content_type as keyof typeof typeIcon] ?? BookOpen
            const color = typeColor[session.content_type as keyof typeof typeColor] ?? '#8B90B0'
            const href = `${typeHref[session.content_type as keyof typeof typeHref]}/${session.content_id}`
            const done = session.status === 'completed'
            const active = session.status === 'in_progress'
            return (
              <div key={session.id} className="card p-4 flex items-center gap-4" style={{ opacity: done ? 0.7 : 1, borderColor: active ? '#F5C51888' : undefined }}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: done ? '#22C55E18' : color + '18' }}>
                  {done ? <CheckCircle size={22} style={{ color: '#22C55E' }} /> : <Icon size={20} style={{ color }} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-black text-sm mb-0.5" style={{ color: done ? '#8B90B0' : '#2B2D42', textDecoration: done ? 'line-through' : 'none' }}>{session.content_title}</div>
                  <div className="flex items-center gap-2 text-xs" style={{ color: '#8B90B0' }}>
                    <span>{session.scheduled_time}</span>
                    <span>·</span>
                    <Clock size={10} />
                    <span>{session.duration_minutes} min</span>
                    <span>·</span>
                    <span style={{ color: '#F5C518', fontWeight: 700 }}>+{session.xp_reward} XP</span>
                  </div>
                  {active && (
                    <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ background: '#EEF0FA', width: '60%' }}>
                      <div className="h-full rounded-full" style={{ width: '42%', background: '#F5C518' }} />
                    </div>
                  )}
                </div>
                {!done && (
                  <Link href={href} className="btn-navy text-xs py-2 px-4 flex-shrink-0" style={{ textDecoration: 'none' }}>
                    {active ? <><Play size={12} /> Continue</> : <><Play size={12} /> Start</>}
                  </Link>
                )}
              </div>
            )
          })}
        </div>
      ) : (
        <div className="card-flat text-center py-10">
          <div className="text-3xl mb-3">📅</div>
          <h3 className="font-bold mb-1" style={{ color: '#2B2D42' }}>No sessions today</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Why not explore a lesson or take a quiz?</p>
          <div className="flex gap-3 justify-center">
            <Link href="/dashboard/curriculum" className="btn-outline text-sm py-2 px-4" style={{ textDecoration: 'none' }}>Browse Lessons</Link>
            <Link href="/dashboard/quizzes" className="btn-navy text-sm py-2 px-4" style={{ textDecoration: 'none' }}>Take a Quiz</Link>
          </div>
        </div>
      )}

      {/* Explore more */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Browse Lessons', href: '/dashboard/curriculum', icon: BookOpen, color: '#0EA5E9' },
          { label: 'My Projects', href: '/dashboard/projects', icon: Code2, color: '#7C3AED' },
          { label: 'Take a Quiz', href: '/dashboard/quizzes', icon: Target, color: '#F59E0B' },
        ].map(a => (
          <Link key={a.label} href={a.href} className="card p-4 flex flex-col items-center gap-2 text-center no-underline" style={{ textDecoration: 'none' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: a.color + '18' }}>
              <a.icon size={18} style={{ color: a.color }} />
            </div>
            <div className="text-xs font-bold" style={{ color: '#2B2D42' }}>{a.label}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
