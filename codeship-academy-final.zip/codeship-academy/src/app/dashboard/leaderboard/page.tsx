import { createClient } from '@/lib/supabase/server'
import { Trophy, Flame, Star, Zap, TrendingUp } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function LeaderboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: me } = await supabase.from('users').select('role').eq('id', user!.id).single()

  // Get all students ordered by XP
  const { data: allStudents } = await supabase
    .from('student_profiles')
    .select('id, full_name, avatar_emoji, level, xp_points, streak_days, user_id')
    .eq('visibility', 'public')
    .order('xp_points', { ascending: false })
    .limit(50)

  // Get current user's student profile for highlighting
  const { data: myProfile } = await supabase
    .from('student_profiles')
    .select('id, full_name, avatar_emoji, level, xp_points, streak_days')
    .eq('user_id', user!.id)
    .single()

  // Top streaks
  const topStreaks = [...(allStudents ?? [])].sort((a, b) => b.streak_days - a.streak_days).slice(0, 10)

  const medal = (rank: number) => {
    if (rank === 1) return '🥇'
    if (rank === 2) return '🥈'
    if (rank === 3) return '🥉'
    return `#${rank}`
  }

  const myRank = allStudents?.findIndex(s => s.id === myProfile?.id)

  return (
    <div className="p-6 space-y-5 animate-in">
      <div>
        <h1 className="page-header">Leaderboard 🏆</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>Top coders ranked by XP earned — keep learning to climb the ranks!</p>
      </div>

      {/* My rank banner */}
      {myProfile && myRank !== undefined && myRank >= 0 && (
        <div className="rounded-2xl p-4 flex items-center gap-4" style={{ background: 'linear-gradient(135deg, #F5C51818, #F5C51808)', border: '2px solid #F5C51844' }}>
          <div className="text-3xl font-black" style={{ color: '#F5C518' }}>{medal(myRank + 1)}</div>
          <div className="text-3xl">{myProfile.avatar_emoji || '🧑‍💻'}</div>
          <div className="flex-1">
            <div className="font-black text-base" style={{ color: '#2B2D42' }}>Your Rank: #{myRank + 1}</div>
            <div className="text-sm" style={{ color: '#8B90B0' }}>{myProfile.full_name} · ⚡{myProfile.xp_points} XP · 🔥{myProfile.streak_days} day streak</div>
          </div>
          {myRank > 0 && (
            <div className="text-xs font-semibold text-right" style={{ color: '#8B90B0' }}>
              <div>{(allStudents?.[myRank - 1]?.xp_points ?? 0) - myProfile.xp_points} XP to</div>
              <div>rank #{myRank}</div>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* XP Leaderboard */}
        <div className="md:col-span-2 card-flat">
          <div className="flex items-center gap-2 mb-4">
            <Trophy size={18} style={{ color: '#F5C518' }} />
            <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Top Coders by XP</h3>
          </div>

          {/* Podium top 3 */}
          {allStudents && allStudents.length >= 3 && (
            <div className="flex items-end justify-center gap-4 mb-6 px-4">
              {[allStudents[1], allStudents[0], allStudents[2]].map((s, podiumIdx) => {
                const rank = podiumIdx === 0 ? 2 : podiumIdx === 1 ? 1 : 3
                const heights = [80, 100, 64]
                const lvl = getLevelConfig(s.level as LevelName)
                return (
                  <div key={s.id} className="flex flex-col items-center gap-2">
                    <div className={`text-${rank === 1 ? '3xl' : '2xl'}`}>{s.avatar_emoji || '🧑‍💻'}</div>
                    <div className="text-xs font-bold text-center truncate max-w-20" style={{ color: '#2B2D42' }}>{s.full_name?.split(' ')[0]}</div>
                    <div className="text-xs font-black" style={{ color: '#F5C518' }}>⚡{s.xp_points}</div>
                    <div className="w-16 rounded-t-xl flex items-end justify-center pb-2 text-2xl"
                      style={{ height: heights[podiumIdx], background: rank === 1 ? '#F5C518' : rank === 2 ? '#C0C0C0' : '#CD7F32' }}>
                      {medal(rank)}
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          {/* Full list */}
          <div className="space-y-0">
            {allStudents?.map((s, i) => {
              const isMe = s.id === myProfile?.id
              const lvl = getLevelConfig(s.level as LevelName)
              return (
                <div key={s.id} className="flex items-center gap-3 py-3 transition-all"
                  style={{ borderBottom: i < allStudents.length - 1 ? '1px solid #F0F2FA' : 'none', background: isMe ? '#FFFBEB' : 'transparent', borderRadius: isMe ? 12 : 0, padding: isMe ? '8px 12px' : '12px 0' }}>
                  <div className="text-sm font-black w-8 text-center flex-shrink-0" style={{ color: i < 3 ? '#F5C518' : '#8B90B0' }}>
                    {medal(i + 1)}
                  </div>
                  <div className="text-xl flex-shrink-0">{s.avatar_emoji || '🧑‍💻'}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold truncate" style={{ color: '#2B2D42' }}>{s.full_name}</span>
                      {isMe && <span className="badge text-xs" style={{ background: '#F5C51818', color: '#D4A800' }}>You</span>}
                    </div>
                    <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{s.level}</span>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="font-black text-sm" style={{ color: '#2B2D42' }}>⚡{s.xp_points.toLocaleString()}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>XP</div>
                  </div>
                </div>
              )
            })}
            {!allStudents?.length && (
              <div className="text-center py-10">
                <div className="text-3xl mb-2">🚀</div>
                <p className="text-sm" style={{ color: '#8B90B0' }}>Be the first on the leaderboard! Complete lessons to earn XP.</p>
              </div>
            )}
          </div>
        </div>

        {/* Streak leaderboard */}
        <div className="space-y-4">
          <div className="card-flat">
            <div className="flex items-center gap-2 mb-4">
              <Flame size={18} style={{ color: '#EF4444' }} />
              <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Top Streaks 🔥</h3>
            </div>
            <div className="space-y-0">
              {topStreaks.slice(0, 8).map((s, i) => {
                const isMe = s.id === myProfile?.id
                return (
                  <div key={s.id} className="flex items-center gap-3 py-2.5" style={{ borderBottom: i < 7 ? '1px solid #F0F2FA' : 'none' }}>
                    <div className="text-xs font-black w-5 text-center" style={{ color: '#EF4444' }}>{i + 1}</div>
                    <span className="text-base">{s.avatar_emoji || '🧑‍💻'}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold truncate" style={{ color: '#2B2D42' }}>
                        {s.full_name?.split(' ')[0]} {isMe && '(you)'}
                      </div>
                    </div>
                    <div className="text-sm font-black" style={{ color: '#EF4444' }}>🔥{s.streak_days}d</div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Tips */}
          <div className="rounded-2xl p-4" style={{ background: '#F5C51810', border: '1px solid #F5C51830' }}>
            <div className="text-sm font-black mb-3" style={{ color: '#2B2D42' }}>💡 Climb the ranks</div>
            <div className="space-y-2 text-xs" style={{ color: '#3A3D5C' }}>
              <div>• Complete lessons → earn 50 XP each</div>
              <div>• Pass quizzes → earn 5–50 XP</div>
              <div>• Submit projects → earn 100 XP</div>
              <div>• Maintain streaks → bonus multiplier</div>
              <div>• Unlock achievements → bonus XP</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
