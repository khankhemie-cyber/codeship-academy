'use client'
import { useState, useEffect } from 'react'
import { Sparkles, RefreshCw, Calendar, Download, BookOpen, Code2, Target, Brain, ChevronRight } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { getLevelConfig, generateICSContent } from '@/lib/utils'
import type { StudentProfile, AIGeneratedPlan, PlannerConfig } from '@/types'

const TYPE_COLORS = { lesson: '#0EA5E9', project: '#7C3AED', quiz: '#F59E0B' }
const TYPE_ICONS = { lesson: BookOpen, project: Code2, quiz: Target }

export default function PlannerPage() {
  const supabase = createClient()
  const [students, setStudents] = useState<StudentProfile[]>([])
  const [selectedStudent, setSelectedStudent] = useState<StudentProfile | null>(null)
  const [config, setConfig] = useState<Partial<PlannerConfig>>({
    sessionsPerWeek: 3, sessionDuration: 30,
    startDate: new Date().toISOString().split('T')[0],
    focusPreference: 'balanced',
  })
  const [plan, setPlan] = useState<AIGeneratedPlan | null>(null)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    supabase.from('student_profiles').select('*').then(({ data }) => {
      if (data) { setStudents(data); if (data[0]) setSelectedStudent(data[0]) }
    })
  }, [])

  const generate = async () => {
    if (!selectedStudent) return
    setLoading(true); setPlan(null)
    try {
      const res = await fetch('/api/ai/planner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          childName: selectedStudent.full_name,
          level: selectedStudent.level,
          interests: [], challenges: [],
          ...config,
          childId: selectedStudent.id,
        }),
      })
      const data = await res.json()
      if (data.plan) setPlan(data.plan)
    } catch (e) { console.error(e) }
    setLoading(false)
  }

  const savePlan = async () => {
    if (!plan || !selectedStudent) return
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    await supabase.from('learning_plans').insert({
      student_id: selectedStudent.id,
      created_by: user!.id,
      title: plan.planTitle,
      weekly_goal: plan.weeklyGoal,
      start_date: config.startDate,
      sessions_per_week: config.sessionsPerWeek,
      session_duration: config.sessionDuration,
      focus_preference: config.focusPreference,
      ai_generated: true,
      ai_tips: plan.tips,
      estimated_xp: plan.estimatedXP,
    })
    setSaving(false); setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const downloadICS = () => {
    if (!plan) return
    const ics = generateICSContent(plan.sessions.map(s => ({
      title: s.title, date: `${config.startDate?.slice(0, 4)}-04-07`,
      time: s.time, duration: s.duration, description: s.description,
    })))
    const blob = new Blob([ics], { type: 'text/calendar' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url
    a.download = `${selectedStudent?.full_name?.replace(/\s/g, '-')}-codeship-plan.ics`
    a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="p-6 flex gap-6 animate-in">

      {/* Config sidebar */}
      <div className="w-72 flex-shrink-0 space-y-4">
        <div className="card-flat space-y-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#F5C51820' }}>
              <Brain size={18} style={{ color: '#F5C518' }} />
            </div>
            <div>
              <div className="font-black text-sm" style={{ color: '#2B2D42' }}>AI Lesson Planner</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>Personalized for each child</div>
            </div>
          </div>

          {/* Child selector */}
          <div>
            <label className="label">Child</label>
            <div className="space-y-2">
              {students.map(s => {
                const lvl = getLevelConfig(s.level)
                return (
                  <button key={s.id} onClick={() => setSelectedStudent(s)} className="w-full flex items-center gap-2.5 p-2.5 rounded-xl border-2 text-left transition-all" style={{ borderColor: selectedStudent?.id === s.id ? '#F5C518' : '#E8EAF6', background: selectedStudent?.id === s.id ? '#FFFBEB' : 'white' }}>
                    <span className="text-lg">{s.avatar_emoji}</span>
                    <div>
                      <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{s.full_name}</div>
                      <div className="text-xs" style={{ color: lvl.color }}>{s.level}</div>
                    </div>
                  </button>
                )
              })}
              {!students.length && <p className="text-xs text-gray-400 p-2">Add a child first in My Children.</p>}
            </div>
          </div>

          {/* Sessions per week */}
          <div>
            <label className="label">Sessions per week <span style={{ color: '#F5C518', fontWeight: 800 }}>{config.sessionsPerWeek}</span></label>
            <input type="range" min={1} max={7} value={config.sessionsPerWeek} onChange={e => setConfig(c => ({ ...c, sessionsPerWeek: +e.target.value }))} className="w-full" style={{ accentColor: '#F5C518' }} />
            <div className="flex justify-between text-xs" style={{ color: '#8B90B0' }}><span>1</span><span>7</span></div>
          </div>

          {/* Duration */}
          <div>
            <label className="label">Duration <span style={{ color: '#F5C518', fontWeight: 800 }}>{config.sessionDuration} min</span></label>
            <input type="range" min={15} max={90} step={5} value={config.sessionDuration} onChange={e => setConfig(c => ({ ...c, sessionDuration: +e.target.value }))} className="w-full" style={{ accentColor: '#F5C518' }} />
          </div>

          {/* Start date */}
          <div>
            <label className="label">Start Date</label>
            <input type="date" value={config.startDate} onChange={e => setConfig(c => ({ ...c, startDate: e.target.value }))} className="input" />
          </div>

          {/* Focus */}
          <div>
            <label className="label">Focus Preference</label>
            <div className="space-y-1.5">
              {[['balanced', 'Balanced Mix'], ['projects', 'Project-Heavy'], ['concepts', 'Concept-First']].map(([val, label]) => (
                <button key={val} onClick={() => setConfig(c => ({ ...c, focusPreference: val as any }))} className="w-full text-left px-3 py-2 rounded-xl border text-sm font-semibold transition-all" style={{ borderColor: config.focusPreference === val ? '#F5C518' : '#E8EAF6', background: config.focusPreference === val ? '#FFFBEB' : 'white', color: config.focusPreference === val ? '#2B2D42' : '#8B90B0' }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <button onClick={generate} disabled={loading || !selectedStudent} className="btn-primary w-full py-3.5 text-sm">
            {loading ? <><RefreshCw size={15} className="animate-spin" /> Generating...</> : <><Sparkles size={15} /> Generate Plan</>}
          </button>
        </div>
      </div>

      {/* Plan display */}
      <div className="flex-1 min-w-0">
        {!plan && !loading && (
          <div className="flex flex-col items-center justify-center h-full min-h-96 gap-4">
            <div className="w-20 h-20 rounded-full flex items-center justify-center" style={{ background: '#F5C51818' }}>
              <Sparkles size={36} style={{ color: '#F5C518' }} />
            </div>
            <h3 className="text-xl font-black" style={{ color: '#2B2D42' }}>Ready to plan?</h3>
            <p className="text-sm text-center max-w-xs" style={{ color: '#8B90B0' }}>Configure preferences and click Generate Plan. Our AI creates a personalized schedule tailored to your child's profile.</p>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center h-full min-h-96 gap-4">
            <RefreshCw size={36} style={{ color: '#F5C518' }} className="animate-spin" />
            <h3 className="text-lg font-bold" style={{ color: '#2B2D42' }}>Building {selectedStudent?.full_name}'s plan...</h3>
            <p className="text-sm" style={{ color: '#8B90B0' }}>Our AI is personalizing each session</p>
          </div>
        )}

        {plan && (
          <div className="space-y-4 animate-in">
            {/* Header card */}
            <div className="rounded-2xl p-6 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#F5C518' }}>AI-Generated Weekly Plan</div>
                  <h2 className="text-xl font-black text-white mb-1">{plan.planTitle}</h2>
                  <p className="text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>{plan.weeklyGoal}</p>
                </div>
                <div className="text-center px-4 py-3 rounded-xl" style={{ background: 'rgba(245,197,24,0.15)' }}>
                  <div className="text-2xl font-black" style={{ color: '#F5C518' }}>⚡{plan.estimatedXP}</div>
                  <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>Est. XP</div>
                </div>
              </div>
            </div>

            {/* Sessions */}
            <div className="space-y-3">
              {plan.sessions?.map((session, i) => {
                const color = TYPE_COLORS[session.type] ?? '#0EA5E9'
                const Icon = TYPE_ICONS[session.type] ?? BookOpen
                return (
                  <div key={i} className="card p-4">
                    <div className="flex gap-4 items-start">
                      <div className="text-center min-w-[48px]">
                        <div className="text-xs font-bold" style={{ color: '#8B90B0' }}>{session.day?.slice(0, 3)}</div>
                        <div className="text-xl font-black" style={{ color: '#2B2D42' }}>{session.date?.split(' ')[1] || session.date}</div>
                        <div className="text-xs" style={{ color: '#8B90B0' }}>{session.time}</div>
                      </div>
                      <div className="w-px self-stretch" style={{ background: '#E8EAF6' }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: color + '18' }}>
                            <Icon size={14} style={{ color }} />
                          </div>
                          <span className="font-black text-sm" style={{ color: '#2B2D42' }}>{session.title}</span>
                          {(session as any).isQuickWin && <span className="badge text-xs" style={{ background: '#22C55E18', color: '#22C55E' }}>Quick Win</span>}
                          {(session as any).isChallenge && <span className="badge text-xs" style={{ background: '#7C3AED18', color: '#7C3AED' }}>Challenge</span>}
                        </div>
                        <p className="text-xs mb-2" style={{ color: '#8B90B0', lineHeight: 1.5 }}>{session.description}</p>
                        <div className="flex items-center gap-3 flex-wrap">
                          <span className="badge text-xs" style={{ background: color + '18', color }}>
                            {session.type}
                          </span>
                          <span className="text-xs" style={{ color: '#8B90B0' }}>⏱ {session.duration} min</span>
                          <span className="text-xs font-bold" style={{ color: '#F5C518' }}>+{session.xp} XP</span>
                          {session.tags?.map(tag => (
                            <span key={tag} className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{tag}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Tips */}
            {plan.tips?.length > 0 && (
              <div className="rounded-2xl p-4" style={{ background: '#F5C51810', border: '1px solid #F5C51830' }}>
                <div className="text-sm font-black mb-3" style={{ color: '#2B2D42' }}>💡 Personalized Tips</div>
                {plan.tips.map((tip, i) => (
                  <div key={i} className="flex gap-2 mb-2 text-sm" style={{ color: '#2B2D42' }}>
                    <ChevronRight size={14} style={{ color: '#F5C518', flexShrink: 0, marginTop: 2 }} />
                    {tip}
                  </div>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3">
              <button onClick={savePlan} disabled={saving || saved} className="btn-navy flex-1 py-3">
                {saved ? '✓ Saved to Schedule' : saving ? <><RefreshCw size={15} className="animate-spin" /> Saving...</> : <><Calendar size={15} /> Save to Schedule</>}
              </button>
              <button onClick={downloadICS} className="btn-outline px-4 py-3">
                <Download size={15} /> .ics
              </button>
              <button onClick={generate} className="btn-outline px-4 py-3">
                <RefreshCw size={15} /> Regenerate
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
