import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { Users, Shield, CreditCard, CheckCircle } from 'lucide-react'

export default async function AdminUsersPage({ searchParams }: { searchParams: { q?: string; role?: string } }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: me } = await supabase.from('users').select('role').eq('id', user!.id).single()
  if (me?.role !== 'admin') redirect('/dashboard')

  const { data: users } = await supabase
    .from('users')
    .select('*, subscriptions(plan, status)')
    .order('created_at', { ascending: false })

  const filtered = users?.filter(u => {
    if (searchParams.role && searchParams.role !== 'all' && u.role !== searchParams.role) return false
    if (searchParams.q && !u.full_name?.toLowerCase().includes(searchParams.q.toLowerCase()) && !u.email?.toLowerCase().includes(searchParams.q.toLowerCase())) return false
    return true
  }) ?? []

  const byRole = ['parent','teacher','student','admin'].map(r => ({ role: r, count: users?.filter(u => u.role === r).length ?? 0 }))

  return (
    <div className="p-6 space-y-5 animate-in">
      <div>
        <h1 className="page-header">User Management</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>{users?.length ?? 0} total accounts</p>
      </div>

      {/* Role breakdown */}
      <div className="grid grid-cols-4 gap-4">
        {byRole.map(r => (
          <div key={r.role} className="card-flat text-center py-4">
            <div className="text-2xl font-black" style={{ color: '#2B2D42' }}>{r.count}</div>
            <div className="text-xs font-semibold capitalize mt-1" style={{ color: '#8B90B0' }}>{r.role}s</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <form method="GET" className="flex gap-3 flex-wrap">
        <input name="q" defaultValue={searchParams.q} placeholder="Search name or email..." className="input flex-1 min-w-48 py-2" />
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: '#EEF0FA' }}>
          {['all','parent','teacher','student','admin'].map(r => (
            <button key={r} name="role" value={r} type="submit"
              className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all capitalize"
              style={{ background: (searchParams.role || 'all') === r ? '#1E2140' : 'transparent', color: (searchParams.role || 'all') === r ? 'white' : '#8B90B0' }}>
              {r === 'all' ? 'All' : r}
            </button>
          ))}
        </div>
      </form>

      {/* User table */}
      <div className="card-flat overflow-hidden p-0">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
              {['User', 'Role', 'Plan', 'Status', 'Joined'].map(h => (
                <th key={h} className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((u, i) => {
              const sub = u.subscriptions?.[0]
              const roleColor = { admin: '#EF4444', teacher: '#7C3AED', parent: '#0EA5E9', student: '#22C55E' }[u.role] ?? '#8B90B0'
              return (
                <tr key={u.id} style={{ borderBottom: i < filtered.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                  <td className="px-5 py-3">
                    <div>
                      <div className="font-bold" style={{ color: '#2B2D42' }}>{u.full_name || '—'}</div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>{u.email}</div>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <span className="badge text-xs capitalize" style={{ background: roleColor + '18', color: roleColor }}>{u.role}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className="text-sm capitalize" style={{ color: '#2B2D42' }}>{sub?.plan ?? 'trial'}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className="badge text-xs" style={{ background: sub?.status === 'active' ? '#22C55E18' : '#F5C51818', color: sub?.status === 'active' ? '#22C55E' : '#F59E0B' }}>
                      {sub?.status ?? 'trialing'}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-xs" style={{ color: '#8B90B0' }}>
                    {new Date(u.created_at).toLocaleDateString()}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {!filtered.length && <div className="text-center py-10 text-sm" style={{ color: '#8B90B0' }}>No users found</div>}
      </div>
    </div>
  )
}
