import { createClient } from '@/lib/supabase/server'
import { Shield } from 'lucide-react'

export default async function AuditPage({ searchParams }: { searchParams: { page?: string } }) {
  const supabase = createClient()
  const page = parseInt(searchParams.page || '1')
  const pageSize = 50
  const offset = (page - 1) * pageSize

  const { data: logs, count } = await supabase
    .from('admin_audit_logs')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(offset, offset + pageSize - 1)

  const actionColor: Record<string, string> = {
    ai_plan_generated: '#F5C518',
    assessment_completed: '#22C55E',
    stripe_webhook: '#0EA5E9',
    subscription_activated: '#22C55E',
    payment_failed: '#EF4444',
  }

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center gap-3">
        <Shield size={22} style={{ color: '#7C3AED' }} />
        <div>
          <h1 className="page-header">Audit Logs</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{count?.toLocaleString()} total events</p>
        </div>
      </div>

      <div className="card-flat overflow-hidden p-0">
        <table className="w-full">
          <thead>
            <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
              {['Time', 'Action', 'Actor', 'Resource', 'Details'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {logs?.map(log => {
              const color = Object.entries(actionColor).find(([k]) => log.action.startsWith(k))?.[1] || '#8B90B0'
              return (
                <tr key={log.id} style={{ borderBottom: '1px solid #F0F2FA' }}>
                  <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0', whiteSpace: 'nowrap' }}>
                    {new Date(log.created_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-3">
                    <span className="badge text-xs" style={{ background: color + '18', color }}>{log.action}</span>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: '#2B2D42' }}>{log.actor_email || '—'}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0' }}>{log.resource_type || '—'}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0', maxWidth: 200 }}>
                    {log.metadata ? JSON.stringify(log.metadata).slice(0, 60) : '—'}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {!logs?.length && (
          <div className="text-center py-12 text-sm" style={{ color: '#8B90B0' }}>No audit events yet.</div>
        )}
      </div>

      {/* Pagination */}
      {(count || 0) > pageSize && (
        <div className="flex items-center gap-3 justify-center">
          {page > 1 && <a href={`?page=${page - 1}`} className="btn-outline text-sm px-4 py-2">← Prev</a>}
          <span className="text-sm" style={{ color: '#8B90B0' }}>Page {page} of {Math.ceil((count || 0) / pageSize)}</span>
          {page < Math.ceil((count || 0) / pageSize) && <a href={`?page=${page + 1}`} className="btn-outline text-sm px-4 py-2">Next →</a>}
        </div>
      )}
    </div>
  )
}
