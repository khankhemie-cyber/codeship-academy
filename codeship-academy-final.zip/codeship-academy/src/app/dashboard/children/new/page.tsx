'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Save } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const AVATARS = ['🚀', '⭐', '🦄', '🐉', '🦊', '🐼', '🦁', '🐬', '🦋', '🌟', '🎯', '🔥']
const LEVELS = [
  { id: 'Explorers', label: 'Explorers', ages: 'Ages 6–7, K–1', desc: 'Block coding, patterns, digital basics' },
  { id: 'Builders', label: 'Builders', ages: 'Ages 8–9, Gr 2–3', desc: 'HTML, CSS, web design' },
  { id: 'Developers', label: 'Developers', ages: 'Ages 10–12, Gr 4–6', desc: 'JavaScript, DOM, APIs' },
  { id: 'Engineers', label: 'Engineers', ages: 'Ages 13–16, Gr 7–8', desc: 'Python, Flask, SQL, Git' },
]

export default function NewChildPage() {
  const router = useRouter()
  const supabase = createClient()
  const [form, setForm] = useState({ full_name: '', age: '', grade: '', level: 'Explorers', avatar_emoji: '🚀' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const save = async () => {
    if (!form.full_name.trim()) { setError('Please enter a name'); return }
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    const { error: err } = await supabase.from('student_profiles').insert({
      parent_id: user!.id,
      full_name: form.full_name.trim(),
      age: parseInt(form.age) || null,
      grade: parseInt(form.grade) || null,
      level: form.level,
      avatar_emoji: form.avatar_emoji,
    })
    setSaving(false)
    if (err) { setError(err.message); return }
    router.push('/dashboard/children')
  }

  return (
    <div className="p-6 max-w-xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back
      </button>

      <div className="card-flat space-y-5">
        <h1 className="text-xl font-black" style={{ color: '#2B2D42' }}>Add a Child</h1>
        {error && <div className="text-sm px-3 py-2 rounded-xl" style={{ background: '#FEF2F2', color: '#991B1B' }}>{error}</div>}

        {/* Avatar */}
        <div>
          <label className="label">Choose an Avatar</label>
          <div className="flex flex-wrap gap-2">
            {AVATARS.map(a => (
              <button key={a} onClick={() => setForm(f => ({ ...f, avatar_emoji: a }))} className="w-10 h-10 text-2xl rounded-xl border-2 transition-all" style={{ borderColor: form.avatar_emoji === a ? '#F5C518' : '#E8EAF6', background: form.avatar_emoji === a ? '#FFFBEB' : 'white' }}>
                {a}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label">Child's First Name *</label>
          <input className="input" placeholder="e.g. Zara" value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Age</label>
            <input className="input" type="number" min="5" max="16" placeholder="e.g. 10" value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
          </div>
          <div>
            <label className="label">Grade</label>
            <select className="input" value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))}>
              <option value="">Select</option>
              {['K', '1', '2', '3', '4', '5', '6', '7', '8'].map(g => <option key={g} value={g === 'K' ? '0' : g}>{g === 'K' ? 'Kindergarten' : `Grade ${g}`}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="label">Starting Level</label>
          <div className="space-y-2">
            {LEVELS.map(l => (
              <button key={l.id} onClick={() => setForm(f => ({ ...f, level: l.id }))} className="w-full text-left p-3.5 rounded-xl border-2 transition-all" style={{ borderColor: form.level === l.id ? '#F5C518' : '#E8EAF6', background: form.level === l.id ? '#FFFBEB' : 'white' }}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-bold text-sm" style={{ color: '#2B2D42' }}>{l.label}</div>
                    <div className="text-xs mt-0.5" style={{ color: '#8B90B0' }}>{l.desc}</div>
                  </div>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{l.ages}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2 flex gap-3">
          <button onClick={() => router.back()} className="btn-outline px-5">Cancel</button>
          <button onClick={save} disabled={saving} className="btn-primary flex-1">
            {saving ? 'Saving...' : <><Save size={15} /> Add Child</>}
          </button>
        </div>
      </div>
    </div>
  )
}
