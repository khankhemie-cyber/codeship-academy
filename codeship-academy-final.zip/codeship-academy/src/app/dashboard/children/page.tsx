import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Plus, TrendingUp, Sparkles, Edit2, UserCheck } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function ChildrenPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: students } = await supabase
    .from('student_profiles')
    .select('*')
    .eq('parent_id', user!.id)
    .order('created_at')

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">My Children</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{students?.length || 0} children in your account</p>
        </div>
        <Link href="/dashboard/children/new" className="btn-primary text-sm">
          <Plus size={15} /> Add Child
        </Link>
      </div>

      {!students?.length ? (
        <div className="card-flat text-center py-16">
          <div className="text-5xl mb-4">👶</div>
          <h3 className="text-lg font-black mb-2" style={{ color: '#2B2D42' }}>No children added yet</h3>
          <p className="text-sm mb-6" style={{ color: '#8B90B0' }}>Add your child to start their personalised coding journey.</p>
          <Link href="/dashboard/children/new" className="btn-primary">Add First Child</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {students.map(child => {
            const lvl = getLevelConfig(child.level as LevelName)
            return (
              <div key={child.id} className="card p-6">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl" style={{ background: lvl.color + '20' }}>
                    {child.avatar_emoji || '🚀'}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-black" style={{ color: '#2B2D42' }}>{child.full_name}</h3>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{child.level}</span>
                      <span className="text-xs" style={{ color: '#8B90B0' }}>Grade {child.grade}</span>
                      <span className="text-xs" style={{ color: '#8B90B0' }}>Age {child.age}</span>
                    </div>
                  </div>
                  <Link href={`/dashboard/children/${child.id}/edit`} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
                    <Edit2 size={16} style={{ color: '#8B90B0' }} />
                  </Link>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[
                    { label: 'XP', value: `⚡ ${child.xp_points}` },
                    { label: 'Streak', value: `🔥 ${child.streak_days}d` },
                    { label: 'Level', value: lvl.icon + ' ' + child.level.slice(0, 3) },
                  ].map(s => (
                    <div key={s.label} className="rounded-xl p-3 text-center" style={{ background: '#F8F9FE' }}>
                      <div className="text-sm font-black" style={{ color: '#2B2D42' }}>{s.value}</div>
                      <div className="text-xs" style={{ color: '#8B90B0' }}>{s.label}</div>
                    </div>
                  ))}
                </div>

                {/* XP progress */}
                <div className="mb-5">
                  <div className="flex justify-between text-xs mb-1.5" style={{ color: '#8B90B0' }}>
                    <span>Level {Math.floor(child.xp_points / 500) + 1}</span>
                    <span>{500 - (child.xp_points % 500)} XP to next level</span>
                  </div>
                  <div className="progress-bar h-2">
                    <div className="progress-fill" style={{ width: `${Math.min((child.xp_points % 500) / 5, 100)}%` }} />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Link href={`/dashboard/assessment?child=${child.id}`} className="flex-1 text-center text-xs font-bold py-2.5 rounded-xl border-2 transition-all hover:border-yellow-400" style={{ borderColor: '#E8EAF6', color: '#8B90B0', textDecoration: 'none' }}>
                    <UserCheck size={13} className="inline mr-1" />Assess
                  </Link>
                  <Link href={`/dashboard/planner?child=${child.id}`} className="flex-1 text-center text-xs font-bold py-2.5 rounded-xl border-2 transition-all hover:border-yellow-400" style={{ borderColor: '#E8EAF6', color: '#8B90B0', textDecoration: 'none' }}>
                    <Sparkles size={13} className="inline mr-1" />Plan
                  </Link>
                  <Link href={`/dashboard/progress?child=${child.id}`} className="flex-1 text-center text-xs font-bold py-2.5 rounded-xl border-2 transition-all hover:border-yellow-400" style={{ borderColor: '#E8EAF6', color: '#8B90B0', textDecoration: 'none' }}>
                    <TrendingUp size={13} className="inline mr-1" />Progress
                  </Link>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
