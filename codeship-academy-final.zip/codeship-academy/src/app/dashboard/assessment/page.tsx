'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ChevronRight, ChevronLeft, CheckCircle, Sparkles, RefreshCw } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const STEPS = ['Child Info', 'Experience', 'Interests', 'Learning Style']

const SKILLS = ['No experience', 'I have played with coding toys', 'I know some Scratch', 'I know some HTML', 'I know JavaScript basics', 'I know Python', 'I have built projects']
const INTERESTS = ['Games 🎮', 'Art & Design 🎨', 'Science 🔬', 'Music 🎵', 'Sports ⚽', 'Animals 🐶', 'Space 🚀', 'Math 🔢', 'Movies 🎬', 'Building things 🔧', 'Storytelling 📖', 'Robots 🤖']
const CHALLENGES = ['Reading for long periods', 'Sitting still', 'Working independently', 'Group work', 'Following written instructions', 'Math concepts', 'None of the above']
const LEARNING_STYLES = [
  { id: 'visual', label: 'Visual Learner 👁️', desc: 'I learn best from pictures, diagrams, and videos' },
  { id: 'hands-on', label: 'Hands-On Learner 🖐️', desc: 'I learn best by doing and building things' },
  { id: 'reading', label: 'Reading Learner 📖', desc: 'I learn best from reading and taking notes' },
  { id: 'listening', label: 'Listening Learner 👂', desc: 'I learn best from explanations and discussion' },
]

type FormData = {
  childName: string; age: string; grade: string; experience: string
  skills: string[]; interests: string[]; challenges: string[]; challengeNotes: string
  goals: string; learningStyle: string
}

export default function AssessmentPage() {
  const router = useRouter()
  const supabase = createClient()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState<FormData>({
    childName: '', age: '', grade: '', experience: '',
    skills: [], interests: [], challenges: [], challengeNotes: '',
    goals: '', learningStyle: '',
  })
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [studentId, setStudentId] = useState<string | null>(null)

  const toggle = (field: 'skills' | 'interests' | 'challenges', val: string) => {
    setForm(f => ({
      ...f,
      [field]: f[field].includes(val) ? f[field].filter(x => x !== val) : [...f[field], val],
    }))
  }

  const canNext = () => {
    if (step === 0) return form.childName && form.age && form.grade
    if (step === 1) return form.experience && form.skills.length > 0
    if (step === 2) return form.interests.length > 0
    if (step === 3) return form.learningStyle
    return false
  }

  const submit = async () => {
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      // Create student profile if not exists
      let sid = studentId
      if (!sid) {
        const { data: existing } = await supabase
          .from('student_profiles')
          .select('id')
          .eq('parent_id', user!.id)
          .eq('full_name', form.childName)
          .single()

        if (existing) {
          sid = existing.id
        } else {
          const { data: newStudent } = await supabase
            .from('student_profiles')
            .insert({
              parent_id: user!.id,
              full_name: form.childName,
              grade: parseInt(form.grade),
              level: 'Explorers',
              avatar_emoji: '🚀',
            })
            .select()
            .single()
          sid = newStudent?.id
        }
        setStudentId(sid)
      }

      const res = await fetch('/api/ai/assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: sid,
          assessment: {
            age: parseInt(form.age),
            grade: parseInt(form.grade),
            experience: form.experience,
            skills: form.skills,
            interests: form.interests,
            challenges: form.challenges,
            challenge_notes: form.challengeNotes,
            goals: form.goals,
            learning_style: form.learningStyle,
          },
        }),
      })
      const data = await res.json()
      setResult(data.profile)
    } catch (e) { console.error(e) }
    setLoading(false)
  }

  const Chip = ({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) => (
    <button onClick={onClick} className="px-3 py-2 rounded-xl text-sm font-semibold border-2 transition-all text-left" style={{
      borderColor: active ? '#F5C518' : '#E8EAF6',
      background: active ? '#FFFBEB' : 'white',
      color: active ? '#2B2D42' : '#8B90B0',
    }}>{label}</button>
  )

  if (result) return (
    <div className="p-6 max-w-2xl mx-auto animate-in">
      <div className="card-flat text-center py-10 space-y-5">
        <div className="text-5xl">🎉</div>
        <div>
          <h2 className="text-2xl font-black mb-2" style={{ color: '#2B2D42' }}>Profile Complete!</h2>
          <p className="text-sm" style={{ color: '#8B90B0' }}>AI has analysed {form.childName}'s learning profile</p>
        </div>
        <div className="rounded-2xl p-6 text-left space-y-4" style={{ background: 'linear-gradient(135deg,#1E2140,#3A3D5C)' }}>
          <div>
            <div className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: '#F5C518' }}>Recommended Level</div>
            <div className="text-xl font-black text-white">{result.recommended_level || 'Explorers'}</div>
          </div>
          {result.strengths?.length > 0 && (
            <div>
              <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#F5C518' }}>Strengths</div>
              {result.strengths.map((s: string, i: number) => (
                <div key={i} className="flex gap-2 text-sm mb-1" style={{ color: 'rgba(255,255,255,0.8)' }}>
                  <CheckCircle size={14} style={{ color: '#22C55E', flexShrink: 0, marginTop: 2 }} />{s}
                </div>
              ))}
            </div>
          )}
          {result.focus_areas?.length > 0 && (
            <div>
              <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#F5C518' }}>Focus Areas</div>
              {result.focus_areas.map((a: string, i: number) => (
                <div key={i} className="text-sm mb-1" style={{ color: 'rgba(255,255,255,0.7)' }}>• {a}</div>
              ))}
            </div>
          )}
          {result.summary && (
            <div>
              <div className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: '#F5C518' }}>Summary</div>
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.7)', lineHeight: 1.6 }}>{result.summary}</p>
            </div>
          )}
        </div>
        <div className="flex gap-3 justify-center">
          <button onClick={() => router.push('/dashboard/planner')} className="btn-primary">
            <Sparkles size={15} /> Generate Learning Plan
          </button>
          <button onClick={() => router.push('/dashboard')} className="btn-outline">Back to Dashboard</button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="p-6 max-w-2xl mx-auto animate-in">
      {/* Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black transition-all" style={{
                background: i < step ? '#22C55E' : i === step ? '#F5C518' : '#EEF0FA',
                color: i <= step ? '#1E2140' : '#8B90B0',
              }}>
                {i < step ? '✓' : i + 1}
              </div>
              <span className="text-xs font-semibold hidden sm:block" style={{ color: i === step ? '#2B2D42' : '#8B90B0' }}>{s}</span>
              {i < STEPS.length - 1 && <div className="w-8 h-px mx-1" style={{ background: i < step ? '#22C55E' : '#E8EAF6' }} />}
            </div>
          ))}
        </div>
      </div>

      <div className="card-flat space-y-5">
        {/* Step 0 */}
        {step === 0 && (
          <>
            <h2 className="text-xl font-black" style={{ color: '#2B2D42' }}>👋 Tell us about your child</h2>
            <div>
              <label className="label">Child's First Name</label>
              <input className="input" placeholder="e.g. Zara" value={form.childName} onChange={e => setForm(f => ({ ...f, childName: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Age</label>
                <input className="input" type="number" min="5" max="16" placeholder="e.g. 10" value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
              </div>
              <div>
                <label className="label">Grade</label>
                <select className="input" value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))}>
                  <option value="">Select grade</option>
                  {['K', '1', '2', '3', '4', '5', '6', '7', '8'].map(g => <option key={g} value={g}>{g === 'K' ? 'Kindergarten' : `Grade ${g}`}</option>)}
                </select>
              </div>
            </div>
          </>
        )}

        {/* Step 1 */}
        {step === 1 && (
          <>
            <h2 className="text-xl font-black" style={{ color: '#2B2D42' }}>💻 Coding Experience</h2>
            <div>
              <label className="label">How would you describe {form.childName}'s coding experience?</label>
              <div className="space-y-2">
                {['Complete beginner — never tried coding', 'A little experience — explored some coding tools', 'Some experience — completed a course or two', 'Experienced — has built several projects'].map(opt => (
                  <button key={opt} onClick={() => setForm(f => ({ ...f, experience: opt }))} className="w-full text-left px-4 py-3 rounded-xl border-2 text-sm font-semibold transition-all" style={{
                    borderColor: form.experience === opt ? '#F5C518' : '#E8EAF6',
                    background: form.experience === opt ? '#FFFBEB' : 'white',
                    color: form.experience === opt ? '#2B2D42' : '#8B90B0',
                  }}>{opt}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="label">What has {form.childName} tried? (select all that apply)</label>
              <div className="flex flex-wrap gap-2">
                {SKILLS.map(s => <Chip key={s} label={s} active={form.skills.includes(s)} onClick={() => toggle('skills', s)} />)}
              </div>
            </div>
          </>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <>
            <h2 className="text-xl font-black" style={{ color: '#2B2D42' }}>🌟 Interests & Goals</h2>
            <div>
              <label className="label">What is {form.childName} interested in? (pick as many as apply)</label>
              <div className="flex flex-wrap gap-2">
                {INTERESTS.map(i => <Chip key={i} label={i} active={form.interests.includes(i)} onClick={() => toggle('interests', i)} />)}
              </div>
            </div>
            <div>
              <label className="label">Any learning challenges? (optional)</label>
              <div className="flex flex-wrap gap-2">
                {CHALLENGES.map(c => <Chip key={c} label={c} active={form.challenges.includes(c)} onClick={() => toggle('challenges', c)} />)}
              </div>
            </div>
            <div>
              <label className="label">What do you hope {form.childName} achieves? (optional)</label>
              <textarea className="input" rows={3} placeholder="e.g. Build a simple game, understand how websites work..." value={form.goals} onChange={e => setForm(f => ({ ...f, goals: e.target.value }))} />
            </div>
          </>
        )}

        {/* Step 3 */}
        {step === 3 && (
          <>
            <h2 className="text-xl font-black" style={{ color: '#2B2D42' }}>🧠 Learning Style</h2>
            <div className="space-y-3">
              {LEARNING_STYLES.map(ls => (
                <button key={ls.id} onClick={() => setForm(f => ({ ...f, learningStyle: ls.id }))} className="w-full text-left p-4 rounded-xl border-2 transition-all" style={{
                  borderColor: form.learningStyle === ls.id ? '#F5C518' : '#E8EAF6',
                  background: form.learningStyle === ls.id ? '#FFFBEB' : 'white',
                }}>
                  <div className="font-bold text-sm mb-1" style={{ color: '#2B2D42' }}>{ls.label}</div>
                  <div className="text-xs" style={{ color: '#8B90B0' }}>{ls.desc}</div>
                </button>
              ))}
            </div>
          </>
        )}

        {/* Navigation */}
        <div className="flex gap-3 pt-2">
          {step > 0 && (
            <button onClick={() => setStep(s => s - 1)} className="btn-outline px-5">
              <ChevronLeft size={16} /> Back
            </button>
          )}
          {step < STEPS.length - 1 ? (
            <button onClick={() => setStep(s => s + 1)} disabled={!canNext()} className="btn-primary flex-1">
              Next <ChevronRight size={16} />
            </button>
          ) : (
            <button onClick={submit} disabled={!canNext() || loading} className="btn-primary flex-1 py-3.5">
              {loading ? <><RefreshCw size={15} className="animate-spin" /> Generating Profile...</> : <><Sparkles size={15} /> Generate AI Profile</>}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
