import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { Plus, MapPin, Phone, Mail, Building2, ArrowRight } from 'lucide-react'

export default async function SchoolsPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: me } = await supabase.from('users').select('role').eq('id', user.id).single()
  if (!['admin', 'teacher'].includes(me?.role ?? '')) redirect('/dashboard')

  const { data: schools } = await supabase
    .from('schools')
    .select('*')
    .order('name')

  // Get session counts per school
  const { data: sessionCounts } = await supabase
    .from('workshop_sessions')
    .select('school_id, status')

  const countMap: Record<string, { total: number; completed: number }> = {}
  sessionCounts?.forEach(s => {
    if (!countMap[s.school_id]) countMap[s.school_id] = { total: 0, completed: 0 }
    countMap[s.school_id].total++
    if (s.status === 'completed') countMap[s.school_id].completed++
  })

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Partner Schools</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{schools?.length ?? 0} schools in your network</p>
        </div>
        <Link href="/dashboard/school/schools/new" className="btn-primary text-sm">
          <Plus size={15} /> Add School
        </Link>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Active Schools', value: schools?.filter(s => s.status === 'active').length ?? 0, color: '#22C55E' },
          { label: 'Total Sessions', value: Object.values(countMap).reduce((s, c) => s + c.total, 0), color: '#0EA5E9' },
          { label: 'Completed Sessions', value: Object.values(countMap).reduce((s, c) => s + c.completed, 0), color: '#F5C518' },
        ].map(stat => (
          <div key={stat.label} className="card-flat text-center py-4">
            <div className="text-3xl font-black mb-1" style={{ color: stat.color }}>{stat.value}</div>
            <div className="text-xs font-semibold" style={{ color: '#8B90B0' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Schools grid */}
      {!schools?.length ? (
        <div className="card-flat text-center py-16">
          <div className="text-4xl mb-3">🏫</div>
          <h3 className="font-bold mb-2" style={{ color: '#2B2D42' }}>No schools yet</h3>
          <p className="text-sm mb-4" style={{ color: '#8B90B0' }}>Add your first partner school to start booking sessions.</p>
          <Link href="/dashboard/school/schools/new" className="btn-primary text-sm" style={{ textDecoration: 'none' }}>Add First School</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {schools.map(school => {
            const counts = countMap[school.id] || { total: 0, completed: 0 }
            return (
              <div key={school.id} className="card p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-black text-base mb-0.5" style={{ color: '#2B2D42' }}>{school.name}</div>
                    {school.board && <div className="text-xs" style={{ color: '#8B90B0' }}>{school.board}</div>}
                  </div>
                  <span className="badge text-xs capitalize" style={{ background: school.status === 'active' ? '#22C55E18' : '#EEF0FA', color: school.status === 'active' ? '#22C55E' : '#8B90B0' }}>
                    {school.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs mb-4" style={{ color: '#8B90B0' }}>
                  {(school.city || school.province) && (
                    <div className="flex items-center gap-1.5"><MapPin size={11} />{[school.city, school.province].filter(Boolean).join(', ')}</div>
                  )}
                  {school.contact_name && (
                    <div className="flex items-center gap-1.5"><Building2 size={11} />{school.contact_name}</div>
                  )}
                  {school.contact_email && (
                    <div className="flex items-center gap-1.5"><Mail size={11} />{school.contact_email}</div>
                  )}
                  {school.contact_phone && (
                    <div className="flex items-center gap-1.5"><Phone size={11} />{school.contact_phone}</div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="rounded-xl p-2.5 text-center" style={{ background: '#F8F9FE' }}>
                    <div className="font-black text-lg" style={{ color: '#2B2D42' }}>{counts.total}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>Total Sessions</div>
                  </div>
                  <div className="rounded-xl p-2.5 text-center" style={{ background: '#22C55E08' }}>
                    <div className="font-black text-lg" style={{ color: '#22C55E' }}>{counts.completed}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>Completed</div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Link href={`/dashboard/school/sessions/new?school=${school.id}`} className="btn-navy text-xs py-2 px-3 flex-1 text-center" style={{ textDecoration: 'none' }}>
                    + Book Session
                  </Link>
                  <Link href={`/dashboard/school/reports?school=${school.id}`} className="btn-outline text-xs py-2 px-3" style={{ textDecoration: 'none' }}>
                    Report <ArrowRight size={11} />
                  </Link>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
