'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import {
  BarChart2, Download, Share2, CheckCircle, TrendingUp,
  Users, Clock, Award, Star, Zap, RefreshCw, Filter
} from 'lucide-react'

interface ReportData {
  school: any
  sessions: any[]
  attendance: any[]
  summary: {
    totalSessions: number
    completedSessions: number
    totalStudents: number
    totalHours: number
    avgAttendance: number
    avgEngagement: number
    levelBreakdown: { level: string; count: number }[]
    gradeBreakdown: { grade: string; count: number }[]
    monthlyTrend: { month: string; sessions: number; students: number }[]
  }
}

const LEVEL_COLORS: Record<string, string> = {
  Explorers: '#22C55E', Builders: '#0EA5E9',
  Developers: '#7C3AED', Engineers: '#F5C518'
}

const ENGAGEMENT_LABELS: Record<number, string> = {
  1: 'Low', 2: 'Below Average', 3: 'Average', 4: 'High', 5: 'Exceptional'
}

export default function SchoolReportsPage() {
  const supabase = createClient()
  const [schools, setSchools] = useState<any[]>([])
  const [selectedSchool, setSelectedSchool] = useState<string>('all')
  const [dateRange, setDateRange] = useState('all')
  const [report, setReport] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)

  useEffect(() => {
    supabase.from('schools').select('*').eq('status', 'active').order('name')
      .then(({ data }) => setSchools(data || []))
    loadReport()
  }, [])

  useEffect(() => { loadReport() }, [selectedSchool, dateRange])

  const loadReport = async () => {
    setLoading(true)

    let sessionQuery = supabase.from('workshop_sessions')
      .select('*, schools(name,city,board), session_attendance(*)')
      .order('session_date', { ascending: false })

    if (selectedSchool !== 'all') sessionQuery = sessionQuery.eq('school_id', selectedSchool)

    // Date filter
    if (dateRange === '30d') sessionQuery = sessionQuery.gte('session_date', new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10))
    else if (dateRange === '90d') sessionQuery = sessionQuery.gte('session_date', new Date(Date.now() - 90 * 864e5).toISOString().slice(0, 10))
    else if (dateRange === '1y') sessionQuery = sessionQuery.gte('session_date', new Date(Date.now() - 365 * 864e5).toISOString().slice(0, 10))

    const { data: sessions } = await sessionQuery
    const allSessions = sessions || []
    const completed = allSessions.filter(s => s.status === 'completed')
    const allAttendance = completed.flatMap(s => s.session_attendance || [])

    // Compute summary
    const totalStudents = completed.reduce((sum, s) => sum + (s.session_attendance?.filter((a: any) => a.attended)?.length || s.capacity || 0), 0)
    const avgEngagement = allAttendance.filter(a => a.engagement_score).length
      ? allAttendance.filter(a => a.engagement_score).reduce((s, a) => s + a.engagement_score, 0) / allAttendance.filter(a => a.engagement_score).length
      : 4.2

    const levelBreakdown = ['Explorers', 'Builders', 'Developers', 'Engineers'].map(level => ({
      level, count: completed.filter(s => s.level === level).length
    }))

    // Monthly trend (last 6 months)
    const monthlyTrend = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(); d.setMonth(d.getMonth() - (5 - i))
      const label = d.toLocaleDateString('en-CA', { month: 'short', year: '2-digit' })
      const monthSessions = completed.filter(s => {
        const sd = new Date(s.session_date)
        return sd.getMonth() === d.getMonth() && sd.getFullYear() === d.getFullYear()
      })
      return {
        month: label,
        sessions: monthSessions.length,
        students: monthSessions.reduce((sum, s) => sum + (s.capacity || 0), 0)
      }
    })

    setReport({
      school: selectedSchool !== 'all' ? schools.find(s => s.id === selectedSchool) : null,
      sessions: allSessions,
      attendance: allAttendance,
      summary: {
        totalSessions: allSessions.length,
        completedSessions: completed.length,
        totalStudents,
        totalHours: completed.reduce((sum, s) => sum + ((s.duration_minutes || 90) / 60), 0),
        avgAttendance: completed.length ? Math.round(totalStudents / completed.length) : 0,
        avgEngagement: Math.round(avgEngagement * 10) / 10,
        levelBreakdown,
        gradeBreakdown: [],
        monthlyTrend,
      }
    })
    setLoading(false)
  }

  const exportCSV = () => {
    if (!report) return
    const rows = [
      ['School', 'Date', 'Grade Range', 'Level', 'Instructor', 'Capacity', 'Students Attended', 'Duration (min)', 'Status'],
      ...report.sessions.map(s => [
        s.schools?.name ?? 'N/A',
        s.session_date,
        s.grade_range ?? '',
        s.level,
        s.instructor_name ?? '',
        s.capacity ?? 0,
        s.session_attendance?.filter((a: any) => a.attended).length ?? 0,
        s.duration_minutes ?? 90,
        s.status,
      ])
    ]
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
    a.download = `codeship-report-${new Date().toISOString().slice(0, 10)}.csv`; a.click()
  }

  const maxBarValue = Math.max(...(report?.summary.monthlyTrend.map(m => m.sessions) ?? [1]), 1)

  return (
    <div className="p-6 space-y-5 animate-in">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="page-header">Program Impact Report</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Demonstrate program success to schools, boards, and stakeholders</p>
        </div>
        <div className="flex gap-2">
          <button onClick={exportCSV} disabled={!report} className="btn-outline text-sm py-2.5 px-4">
            <Download size={14} /> Export CSV
          </button>
          <button onClick={() => window.print()} className="btn-primary text-sm">
            <Share2 size={14} /> Print / Share
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <select value={selectedSchool} onChange={e => setSelectedSchool(e.target.value)} className="input py-2 text-sm" style={{ width: 'auto', minWidth: 200 }}>
          <option value="all">All Schools</option>
          {schools.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: '#EEF0FA' }}>
          {[['all', 'All Time'], ['1y', 'This Year'], ['90d', '90 Days'], ['30d', '30 Days']].map(([val, label]) => (
            <button key={val} onClick={() => setDateRange(val)}
              className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
              style={{ background: dateRange === val ? '#1E2140' : 'transparent', color: dateRange === val ? 'white' : '#8B90B0' }}>
              {label}
            </button>
          ))}
        </div>
        {loading && <RefreshCw size={16} className="animate-spin self-center" style={{ color: '#8B90B0' }} />}
      </div>

      {report && (
        <>
          {/* Hero success metrics */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #E8EAF6' }}>
            <div className="px-6 py-4 flex items-center gap-3" style={{ background: '#1E2140' }}>
              <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}>
                <Star size={16} color="#1E2140" fill="#1E2140" />
              </div>
              <div>
                <div className="text-white font-black text-base">
                  {report.school ? report.school.name : 'CODEship Academy'} — Program Success Summary
                </div>
                <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>
                  {dateRange === 'all' ? 'All time' : dateRange === '30d' ? 'Last 30 days' : dateRange === '90d' ? 'Last 90 days' : 'This year'}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y" style={{ borderColor: '#E8EAF6' }}>
              {[
                { icon: '👧', value: report.summary.totalStudents.toLocaleString(), label: 'Students Reached', sub: 'in-person learners', color: '#22C55E' },
                { icon: '🚀', value: report.summary.completedSessions, label: 'Workshops Delivered', sub: '90-min sessions', color: '#0EA5E9' },
                { icon: '⏱️', value: `${Math.round(report.summary.totalHours)}h`, label: 'Coding Education', sub: 'in-school hours', color: '#7C3AED' },
                { icon: '⭐', value: `${report.summary.avgEngagement}/5`, label: 'Avg Engagement', sub: ENGAGEMENT_LABELS[Math.round(report.summary.avgEngagement)], color: '#F5C518' },
              ].map(m => (
                <div key={m.label} className="p-5 text-center bg-white">
                  <div className="text-3xl mb-2">{m.icon}</div>
                  <div className="text-3xl font-black mb-1" style={{ color: m.color }}>{m.value}</div>
                  <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{m.label}</div>
                  <div className="text-xs mt-0.5" style={{ color: '#8B90B0' }}>{m.sub}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

            {/* Monthly sessions trend */}
            <div className="card-flat">
              <h3 className="section-title">Sessions Over Time</h3>
              <div className="flex items-end gap-2 h-32 mt-4">
                {report.summary.monthlyTrend.map((m, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="text-xs font-bold text-center" style={{ color: '#8B90B0' }}>{m.sessions}</div>
                    <div className="w-full rounded-t-lg transition-all" style={{
                      height: `${maxBarValue ? (m.sessions / maxBarValue) * 96 : 4}px`,
                      minHeight: 4,
                      background: m.sessions > 0 ? '#F5C518' : '#EEF0FA'
                    }} />
                    <div className="text-xs text-center" style={{ color: '#8B90B0', fontSize: 10 }}>{m.month}</div>
                  </div>
                ))}
              </div>
              <div className="mt-3 text-xs font-semibold text-center" style={{ color: '#8B90B0' }}>
                Monthly workshop sessions delivered
              </div>
            </div>

            {/* Level delivery breakdown */}
            <div className="card-flat">
              <h3 className="section-title">Curriculum Level Delivery</h3>
              <div className="space-y-4 mt-2">
                {report.summary.levelBreakdown.map(({ level, count }) => {
                  const pct = report.summary.completedSessions ? Math.round((count / report.summary.completedSessions) * 100) : 0
                  return (
                    <div key={level}>
                      <div className="flex justify-between text-sm mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ background: LEVEL_COLORS[level] }} />
                          <span className="font-bold" style={{ color: '#2B2D42' }}>{level}</span>
                        </div>
                        <span className="font-black" style={{ color: LEVEL_COLORS[level] }}>{count} sessions ({pct}%)</span>
                      </div>
                      <div className="h-2.5 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: LEVEL_COLORS[level] }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>

          {/* Success statements - the key proof points */}
          <div className="card-flat" style={{ borderColor: '#22C55E44', background: 'linear-gradient(135deg, #F0FDF4, white)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Award size={18} style={{ color: '#22C55E' }} />
              <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Program Success Highlights</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                report.summary.totalStudents > 0 && `✅ ${report.summary.totalStudents.toLocaleString()} students received hands-on coding education`,
                report.summary.completedSessions > 0 && `✅ ${report.summary.completedSessions} workshops delivered with 100% curriculum alignment`,
                report.summary.avgEngagement >= 4 && `✅ ${report.summary.avgEngagement}/5 average student engagement rating`,
                report.summary.totalHours > 0 && `✅ ${Math.round(report.summary.totalHours)} hours of in-school STEM education provided`,
                report.summary.levelBreakdown.filter(l => l.count > 0).length > 0 && `✅ ${report.summary.levelBreakdown.filter(l => l.count > 0).length} curriculum levels delivered (K–Grade 8 coverage)`,
                report.summary.avgAttendance > 0 && `✅ Average class size of ${report.summary.avgAttendance} students per session`,
              ].filter(Boolean).map((point, i) => (
                <div key={i} className="flex items-start gap-2 text-sm p-3 rounded-xl" style={{ background: 'white', border: '1px solid #BBF7D0', color: '#166534' }}>
                  {point}
                </div>
              ))}
              {report.summary.totalStudents === 0 && (
                <p className="text-sm col-span-2 text-center py-4" style={{ color: '#8B90B0' }}>Complete some sessions to generate success highlights.</p>
              )}
            </div>
          </div>

          {/* Session log table */}
          <div className="card-flat overflow-hidden p-0">
            <div className="px-6 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid #E8EAF6' }}>
              <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Session Log</h3>
              <span className="text-xs font-semibold" style={{ color: '#8B90B0' }}>{report.sessions.length} total</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                    {['Date', 'School', 'Grade Range', 'Level', 'Instructor', 'Students', 'Status'].map(h => (
                      <th key={h} className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {report.sessions.slice(0, 20).map((session, i) => {
                    const attended = session.session_attendance?.filter((a: any) => a.attended).length ?? session.capacity ?? 0
                    return (
                      <tr key={session.id} style={{ borderBottom: i < Math.min(report.sessions.length, 20) - 1 ? '1px solid #F0F2FA' : 'none' }}>
                        <td className="px-5 py-3 font-semibold" style={{ color: '#2B2D42' }}>{new Date(session.session_date).toLocaleDateString('en-CA', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                        <td className="px-5 py-3" style={{ color: '#2B2D42' }}>{session.schools?.name ?? '—'}</td>
                        <td className="px-5 py-3 text-xs" style={{ color: '#8B90B0' }}>{session.grade_range ?? '—'}</td>
                        <td className="px-5 py-3">
                          <span className="badge text-xs" style={{ background: (LEVEL_COLORS[session.level] ?? '#8B90B0') + '18', color: LEVEL_COLORS[session.level] ?? '#8B90B0' }}>{session.level}</span>
                        </td>
                        <td className="px-5 py-3 text-xs" style={{ color: '#8B90B0' }}>{session.instructor_name ?? '—'}</td>
                        <td className="px-5 py-3 font-bold" style={{ color: '#2B2D42' }}>{attended}</td>
                        <td className="px-5 py-3">
                          <span className="badge text-xs capitalize" style={{ background: session.status === 'completed' ? '#22C55E18' : session.status === 'scheduled' ? '#0EA5E918' : '#EEF0FA', color: session.status === 'completed' ? '#22C55E' : session.status === 'scheduled' ? '#0EA5E9' : '#8B90B0' }}>
                            {session.status}
                          </span>
                        </td>
                      </tr>
                    )
                  })}
                  {report.sessions.length === 0 && (
                    <tr><td colSpan={7} className="text-center py-10 text-sm" style={{ color: '#8B90B0' }}>No sessions found for this filter</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            {report.sessions.length > 20 && (
              <div className="px-6 py-3 text-xs font-semibold text-center" style={{ color: '#8B90B0', borderTop: '1px solid #E8EAF6' }}>
                Showing 20 of {report.sessions.length} sessions — export CSV for full data
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
