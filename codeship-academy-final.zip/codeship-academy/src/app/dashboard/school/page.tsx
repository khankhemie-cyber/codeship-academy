import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import {
  Users, BookOpen, Target, TrendingUp, Award, Zap,
  ArrowRight, CheckCircle, BarChart2, School, Star
} from 'lucide-react'

export default async function SchoolDashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: me } = await supabase.from('users').select('role').eq('id', user.id).single()
  if (!['admin', 'teacher'].includes(me?.role ?? '')) redirect('/dashboard')

  // Load all school data
  const [
    { data: schools },
    { data: sessions },
    { data: teachers },
  ] = await Promise.all([
    supabase.from('schools').select('*').eq('status', 'active').order('name'),
    supabase.from('workshop_sessions').select('*, schools(name)').order('session_date', { ascending: false }),
    supabase.from('users').select('id, full_name, email').eq('role', 'teacher'),
  ])

  // Aggregate success metrics
  const completedSessions = sessions?.filter(s => s.status === 'completed') ?? []
  const totalStudentsReached = completedSessions.reduce((sum, s) => sum + (s.capacity || 0), 0)
  const totalSessionHours = completedSessions.reduce((sum, s) => sum + ((s.duration_minutes || 90) / 60), 0)
  const upcomingSessions = sessions?.filter(s => s.status === 'scheduled' && new Date(s.session_date) >= new Date()) ?? []

  // Level breakdown across all sessions
  const levelBreakdown = ['Explorers', 'Builders', 'Developers', 'Engineers'].map(level => ({
    level,
    count: completedSessions.filter(s => s.level === level).length,
  }))

  const levelColors: Record<string, string> = {
    Explorers: '#22C55E', Builders: '#0EA5E9',
    Developers: '#7C3AED', Engineers: '#F5C518'
  }
  const maxLevelCount = Math.max(...levelBreakdown.map(l => l.count), 1)

  // Schools with session counts
  const schoolsWithData = schools?.map(school => ({
    ...school,
    sessionCount: sessions?.filter(s => s.school_id === school.id).length ?? 0,
    completedCount: sessions?.filter(s => s.school_id === school.id && s.status === 'completed').length ?? 0,
    upcomingCount: sessions?.filter(s => s.school_id === school.id && s.status === 'scheduled').length ?? 0,
  })) ?? []

  return (
    <div className="p-6 space-y-6 animate-in">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="page-header">School Program Portal</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Track sessions, students, and program impact across all schools</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/school/reports" className="btn-primary text-sm">
            <BarChart2 size={15} /> Impact Report
          </Link>
          <Link href="/dashboard/school/sessions/new" className="btn-navy text-sm">
            + Book Session
          </Link>
        </div>
      </div>

      {/* Hero success metrics */}
      <div className="rounded-2xl p-6 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
        <div className="absolute right-0 top-0 w-64 h-64 rounded-full opacity-5" style={{ background: '#F5C518', transform: 'translate(30%, -30%)' }} />
        <div className="text-xs font-bold uppercase tracking-widest mb-4" style={{ color: '#F5C518' }}>Program Impact — All Time</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Students Reached', value: totalStudentsReached.toLocaleString(), icon: '👧', desc: 'across all workshops' },
            { label: 'Sessions Delivered', value: completedSessions.length, icon: '🚀', desc: '90-min workshops' },
            { label: 'Hours of Coding', value: Math.round(totalSessionHours), icon: '⏱️', desc: 'in-school learning time' },
            { label: 'Schools Served', value: schools?.length ?? 0, icon: '🏫', desc: 'active partner schools' },
          ].map(m => (
            <div key={m.label}>
              <div className="text-3xl mb-1">{m.icon}</div>
              <div className="text-3xl font-black text-white">{m.value}</div>
              <div className="text-sm font-bold" style={{ color: '#F5C518' }}>{m.label}</div>
              <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{m.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Active Schools', value: schools?.length ?? 0, icon: School, color: '#0EA5E9', href: '/dashboard/school/schools' },
          { label: 'Teachers', value: teachers?.length ?? 0, icon: Users, color: '#7C3AED', href: '/dashboard/school/teachers' },
          { label: 'Upcoming Sessions', value: upcomingSessions.length, icon: Target, color: '#22C55E', href: '/dashboard/school/sessions' },
          { label: 'Avg Class Size', value: completedSessions.length ? Math.round(completedSessions.reduce((s, sess) => s + (sess.capacity || 0), 0) / completedSessions.length) : 0, icon: BarChart2, color: '#F5C518', href: '/dashboard/school/sessions' },
        ].map(k => (
          <Link key={k.label} href={k.href} className="card p-4 flex items-center gap-3 no-underline" style={{ textDecoration: 'none' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: k.color + '18' }}>
              <k.icon size={20} style={{ color: k.color }} />
            </div>
            <div>
              <div className="text-2xl font-black" style={{ color: '#2B2D42' }}>{k.value}</div>
              <div className="text-xs font-semibold" style={{ color: '#8B90B0' }}>{k.label}</div>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

        {/* Level delivery breakdown */}
        <div className="card-flat">
          <h3 className="section-title">Sessions by Curriculum Level</h3>
          <div className="space-y-4">
            {levelBreakdown.map(({ level, count }) => (
              <div key={level}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-bold" style={{ color: '#2B2D42' }}>{level}</span>
                  <span className="font-black" style={{ color: levelColors[level] }}>{count} sessions</span>
                </div>
                <div className="h-3 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${maxLevelCount ? (count / maxLevelCount) * 100 : 0}%`, background: levelColors[level] }} />
                </div>
              </div>
            ))}
            {completedSessions.length === 0 && (
              <p className="text-sm text-center py-4" style={{ color: '#8B90B0' }}>No completed sessions yet</p>
            )}
          </div>
        </div>

        {/* Upcoming sessions */}
        <div className="card-flat">
          <div className="flex items-center justify-between mb-4">
            <h3 className="section-title mb-0">Upcoming Sessions</h3>
            <Link href="/dashboard/school/sessions" className="text-xs font-bold flex items-center gap-1" style={{ color: '#0EA5E9', textDecoration: 'none' }}>
              All <ArrowRight size={12} />
            </Link>
          </div>
          {upcomingSessions.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-3xl mb-2">📅</div>
              <p className="text-sm font-semibold mb-3" style={{ color: '#8B90B0' }}>No upcoming sessions booked</p>
              <Link href="/dashboard/school/sessions/new" className="btn-primary text-xs py-2 px-4" style={{ textDecoration: 'none' }}>Book a Session</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingSessions.slice(0, 5).map(session => (
                <div key={session.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6' }}>
                  <div className="text-center w-12 flex-shrink-0">
                    <div className="text-xs font-bold uppercase" style={{ color: '#8B90B0' }}>{new Date(session.session_date).toLocaleDateString('en-CA', { month: 'short' })}</div>
                    <div className="text-2xl font-black" style={{ color: '#2B2D42' }}>{new Date(session.session_date).getDate()}</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm truncate" style={{ color: '#2B2D42' }}>{(session as any).schools?.name ?? 'School'}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>{session.grade_range} · {session.level} · {session.session_time?.slice(0, 5)}</div>
                  </div>
                  <span className="badge text-xs" style={{ background: '#22C55E18', color: '#22C55E' }}>Scheduled</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Schools table */}
      <div className="card-flat overflow-hidden p-0">
        <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: '1px solid #E8EAF6' }}>
          <h3 className="font-black text-base" style={{ color: '#2B2D42' }}>Partner Schools</h3>
          <Link href="/dashboard/school/schools" className="text-xs font-bold flex items-center gap-1" style={{ color: '#0EA5E9', textDecoration: 'none' }}>
            Manage <ArrowRight size={12} />
          </Link>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
              {['School', 'City', 'Total Sessions', 'Completed', 'Upcoming', 'Status'].map(h => (
                <th key={h} className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schoolsWithData.map((school, i) => (
              <tr key={school.id} style={{ borderBottom: i < schoolsWithData.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                <td className="px-5 py-3">
                  <div>
                    <div className="font-bold" style={{ color: '#2B2D42' }}>{school.name}</div>
                    {school.board && <div className="text-xs" style={{ color: '#8B90B0' }}>{school.board}</div>}
                  </div>
                </td>
                <td className="px-5 py-3 text-sm" style={{ color: '#8B90B0' }}>{school.city}</td>
                <td className="px-5 py-3 font-bold" style={{ color: '#2B2D42' }}>{school.sessionCount}</td>
                <td className="px-5 py-3">
                  <span className="font-bold" style={{ color: '#22C55E' }}>{school.completedCount}</span>
                </td>
                <td className="px-5 py-3">
                  <span className="font-bold" style={{ color: '#0EA5E9' }}>{school.upcomingCount}</span>
                </td>
                <td className="px-5 py-3">
                  <span className="badge text-xs capitalize" style={{ background: school.status === 'active' ? '#22C55E18' : '#EEF0FA', color: school.status === 'active' ? '#22C55E' : '#8B90B0' }}>
                    {school.status}
                  </span>
                </td>
              </tr>
            ))}
            {!schoolsWithData.length && (
              <tr><td colSpan={6} className="text-center py-10 text-sm" style={{ color: '#8B90B0' }}>No schools added yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
