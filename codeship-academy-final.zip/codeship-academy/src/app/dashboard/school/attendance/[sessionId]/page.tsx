'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Plus, Trash2, RefreshCw, CheckCircle, Star } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface AttendeeRow {
  id?: string; name: string; grade: string; attended: boolean; engagement: number; notes: string
}

export default function AttendancePage() {
  const { sessionId } = useParams<{ sessionId: string }>()
  const router = useRouter()
  const supabase = createClient()
  const [session, setSession] = useState<any>(null)
  const [rows, setRows] = useState<AttendeeRow[]>([])
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data: s } = await supabase.from('workshop_sessions')
        .select('*, schools(name, city)').eq('id', sessionId).single()
      setSession(s)

      const { data: att } = await supabase.from('session_attendance')
        .select('*').eq('session_id', sessionId).order('student_name')

      if (att && att.length > 0) {
        setRows(att.map(a => ({ id: a.id, name: a.student_name, grade: a.grade ?? '', attended: a.attended, engagement: a.engagement_score ?? 4, notes: a.notes ?? '' })))
      } else if (s?.capacity) {
        // Pre-populate with blank rows
        setRows(Array.from({ length: s.capacity }, () => ({ name: '', grade: '', attended: true, engagement: 4, notes: '' })))
      }
    }
    load()
  }, [sessionId])

  const addRow = () => setRows(r => [...r, { name: '', grade: '', attended: true, engagement: 4, notes: '' }])
  const removeRow = (i: number) => setRows(r => r.filter((_, idx) => idx !== i))
  const update = (i: number, field: keyof AttendeeRow, val: any) => setRows(r => r.map((row, idx) => idx === i ? { ...row, [field]: val } : row))

  const handleSave = async () => {
    setSaving(true)
    const validRows = rows.filter(r => r.name.trim())

    // Delete existing and re-insert
    await supabase.from('session_attendance').delete().eq('session_id', sessionId)
    if (validRows.length > 0) {
      await supabase.from('session_attendance').insert(
        validRows.map(r => ({
          session_id: sessionId,
          student_name: r.name.trim(),
          grade: r.grade || null,
          attended: r.attended,
          engagement_score: r.engagement,
          notes: r.notes || null,
        }))
      )
    }

    // Mark session as completed if not already
    if (session?.status === 'scheduled') {
      await supabase.from('workshop_sessions').update({ status: 'completed' }).eq('id', sessionId)
    }

    setSaved(true); setSaving(false)
    setTimeout(() => setSaved(false), 3000)
  }

  const attended = rows.filter(r => r.attended && r.name.trim()).length
  const avgEngagement = rows.filter(r => r.attended && r.name.trim()).length
    ? rows.filter(r => r.attended && r.name.trim()).reduce((s, r) => s + r.engagement, 0) / rows.filter(r => r.attended && r.name.trim()).length
    : 0

  return (
    <div className="p-6 max-w-3xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back
      </button>

      {session && (
        <>
          <div className="card-flat mb-5">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-black mb-1" style={{ color: '#2B2D42' }}>{session.schools?.name}</h1>
                <div className="flex gap-3 text-sm" style={{ color: '#8B90B0' }}>
                  <span>📅 {new Date(session.session_date).toLocaleDateString('en-CA', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
                  <span>⏰ {session.session_time?.slice(0, 5)}</span>
                  <span>📍 {session.location || 'TBD'}</span>
                </div>
                <div className="flex gap-2 mt-2">
                  <span className="badge text-xs" style={{ background: '#F5C51818', color: '#D4A800' }}>{session.grade_range}</span>
                  <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{session.level}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-black" style={{ color: '#22C55E' }}>{attended}</div>
                <div className="text-xs" style={{ color: '#8B90B0' }}>attended</div>
                {avgEngagement > 0 && (
                  <div className="flex items-center gap-1 mt-1 justify-end">
                    <Star size={12} style={{ color: '#F5C518' }} />
                    <span className="text-sm font-bold" style={{ color: '#2B2D42' }}>{avgEngagement.toFixed(1)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Attendance table */}
          <div className="card-flat overflow-hidden p-0 mb-4">
            <div className="flex items-center justify-between px-5 py-3.5" style={{ borderBottom: '1px solid #E8EAF6' }}>
              <h3 className="font-black text-sm" style={{ color: '#2B2D42' }}>Student Attendance ({rows.length} students)</h3>
              <button onClick={addRow} className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg" style={{ background: '#F5C51818', color: '#D4A800' }}>
                <Plus size={12} /> Add Student
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                    <th className="text-left px-4 py-2.5 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>Student Name</th>
                    <th className="text-left px-4 py-2.5 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>Grade</th>
                    <th className="text-center px-4 py-2.5 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>Attended</th>
                    <th className="text-left px-4 py-2.5 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>Engagement (1–5)</th>
                    <th className="text-left px-4 py-2.5 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>Notes</th>
                    <th className="w-8" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid #F0F2FA', opacity: row.attended ? 1 : 0.5 }}>
                      <td className="px-4 py-2">
                        <input value={row.name} onChange={e => update(i, 'name', e.target.value)} placeholder={`Student ${i + 1}`} className="input py-1.5 text-sm" style={{ minWidth: 140 }} />
                      </td>
                      <td className="px-4 py-2">
                        <input value={row.grade} onChange={e => update(i, 'grade', e.target.value)} placeholder="e.g. 4" className="input py-1.5 text-sm" style={{ width: 60 }} />
                      </td>
                      <td className="px-4 py-2 text-center">
                        <input type="checkbox" checked={row.attended} onChange={e => update(i, 'attended', e.target.checked)}
                          className="w-4 h-4 rounded cursor-pointer" style={{ accentColor: '#22C55E' }} />
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map(n => (
                            <button key={n} onClick={() => update(i, 'engagement', n)}
                              className="w-6 h-6 rounded text-xs font-bold transition-all"
                              style={{ background: row.engagement >= n ? '#F5C518' : '#EEF0FA', color: row.engagement >= n ? '#1E2140' : '#8B90B0' }}>
                              {n}
                            </button>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-2">
                        <input value={row.notes} onChange={e => update(i, 'notes', e.target.value)} placeholder="Optional note" className="input py-1.5 text-sm" style={{ minWidth: 120 }} />
                      </td>
                      <td className="px-2">
                        <button onClick={() => removeRow(i)} className="p-1 rounded hover:bg-red-50 transition-colors">
                          <Trash2 size={13} style={{ color: '#EF4444' }} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={handleSave} disabled={saving} className="btn-primary py-3.5 px-6 text-sm">
              {saved ? <><CheckCircle size={15} /> Saved!</> : saving ? <><RefreshCw size={14} className="animate-spin" /> Saving...</> : '💾 Save Attendance'}
            </button>
            <button onClick={addRow} className="btn-outline py-3.5 px-4 text-sm">
              <Plus size={14} /> Add Row
            </button>
          </div>
        </>
      )}
    </div>
  )
}
