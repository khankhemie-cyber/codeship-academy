'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, RefreshCw, CheckCircle } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function NewSessionPage() {
  const supabase = createClient()
  const router = useRouter()
  const [schools, setSchools] = useState<any[]>([])
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    school_id: '', title: '90-Minute Coding Workshop', grade_range: '',
    level: 'Builders', session_date: '', session_time: '10:00',
    duration_minutes: 90, capacity: 25, location: '',
    instructor_name: '', notes: '',
  })

  useEffect(() => {
    supabase.from('schools').select('id, name, city').eq('status', 'active').order('name')
      .then(({ data }) => setSchools(data || []))
  }, [])

  const f = (k: string, v: any) => setForm(prev => ({ ...prev, [k]: v }))

  const handleSave = async () => {
    if (!form.school_id || !form.session_date) return
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    const { error } = await supabase.from('workshop_sessions').insert({ ...form, teacher_id: user!.id })
    if (!error) { setSaved(true); setTimeout(() => router.push('/dashboard/school/sessions'), 1500) }
    setSaving(false)
  }

  return (
    <div className="p-6 max-w-2xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back to Sessions
      </button>

      <h1 className="page-header">Book Workshop Session</h1>

      <div className="card-flat space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="label">School *</label>
            <select className="input" value={form.school_id} onChange={e => f('school_id', e.target.value)}>
              <option value="">Select a school...</option>
              {schools.map(s => <option key={s.id} value={s.id}>{s.name} — {s.city}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Session Date *</label>
            <input type="date" className="input" value={form.session_date} onChange={e => f('session_date', e.target.value)} min={new Date().toISOString().slice(0, 10)} />
          </div>
          <div>
            <label className="label">Start Time</label>
            <input type="time" className="input" value={form.session_time} onChange={e => f('session_time', e.target.value)} />
          </div>
          <div>
            <label className="label">Grade Range</label>
            <input className="input" value={form.grade_range} onChange={e => f('grade_range', e.target.value)} placeholder="e.g. Grades 3–4" />
          </div>
          <div>
            <label className="label">Curriculum Level</label>
            <select className="input" value={form.level} onChange={e => f('level', e.target.value)}>
              {['Explorers', 'Builders', 'Developers', 'Engineers'].map(l => <option key={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Expected Students</label>
            <input type="number" className="input" value={form.capacity} onChange={e => f('capacity', +e.target.value)} min={1} max={200} />
          </div>
          <div>
            <label className="label">Duration (minutes)</label>
            <select className="input" value={form.duration_minutes} onChange={e => f('duration_minutes', +e.target.value)}>
              <option value={60}>60 min</option>
              <option value={90}>90 min (standard)</option>
              <option value={120}>120 min</option>
            </select>
          </div>
          <div>
            <label className="label">Location in School</label>
            <input className="input" value={form.location} onChange={e => f('location', e.target.value)} placeholder="e.g. Library, Room 204" />
          </div>
          <div>
            <label className="label">Instructor Name</label>
            <input className="input" value={form.instructor_name} onChange={e => f('instructor_name', e.target.value)} placeholder="e.g. Khemie A." />
          </div>
          <div className="col-span-2">
            <label className="label">Notes</label>
            <textarea className="input resize-none" rows={3} value={form.notes} onChange={e => f('notes', e.target.value)} placeholder="Any special requirements, equipment needed, etc." style={{ height: 72 }} />
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={handleSave} disabled={saving || saved || !form.school_id || !form.session_date} className="btn-primary py-3 px-6 text-sm">
            {saved ? <><CheckCircle size={15} /> Booked!</> : saving ? <><RefreshCw size={14} className="animate-spin" /> Saving...</> : '📅 Book Session'}
          </button>
          <button onClick={() => router.back()} className="btn-outline py-3 px-5 text-sm">Cancel</button>
        </div>
      </div>
    </div>
  )
}
