import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Plus, Clock, Users, MapPin, CheckCircle, Calendar } from 'lucide-react'

const LEVEL_COLORS: Record<string, string> = {
  Explorers: '#22C55E', Builders: '#0EA5E9',
  Developers: '#7C3AED', Engineers: '#F5C518'
}

export default async function SessionsPage() {
  const supabase = createClient()
  const { data: sessions } = await supabase
    .from('workshop_sessions')
    .select('*, schools(name, city)')
    .order('session_date', { ascending: false })
    .limit(50)

  const upcoming = sessions?.filter(s => s.status === 'scheduled' && new Date(s.session_date) >= new Date()) ?? []
  const past = sessions?.filter(s => s.status === 'completed' || new Date(s.session_date) < new Date()) ?? []

  return (
    <div className="p-6 space-y-5 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Workshop Sessions</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>{upcoming.length} upcoming · {past.length} completed</p>
        </div>
        <Link href="/dashboard/school/sessions/new" className="btn-primary text-sm">
          <Plus size={15} /> Book Session
        </Link>
      </div>

      {/* Upcoming */}
      {upcoming.length > 0 && (
        <div>
          <h2 className="section-title">Upcoming</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcoming.map(session => (
              <div key={session.id} className="card p-5" style={{ borderColor: '#22C55E33' }}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-black text-base" style={{ color: '#2B2D42' }}>{(session as any).schools?.name}</div>
                    <div className="flex items-center gap-1.5 text-xs mt-1" style={{ color: '#8B90B0' }}>
                      <MapPin size={11} />{(session as any).schools?.city}
                      {session.location && <span>· {session.location}</span>}
                    </div>
                  </div>
                  <div className="text-center px-3 py-2 rounded-xl" style={{ background: '#22C55E18' }}>
                    <div className="text-xs font-bold uppercase" style={{ color: '#22C55E' }}>{new Date(session.session_date).toLocaleDateString('en-CA', { month: 'short' })}</div>
                    <div className="text-2xl font-black" style={{ color: '#22C55E' }}>{new Date(session.session_date).getDate()}</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="flex items-center gap-1" style={{ color: '#8B90B0' }}>
                    <Clock size={11} />{session.session_time?.slice(0, 5)} · {session.duration_minutes}m
                  </div>
                  <div className="flex items-center gap-1" style={{ color: '#8B90B0' }}>
                    <Users size={11} />Up to {session.capacity} students
                  </div>
                  <div>
                    <span className="badge text-xs" style={{ background: (LEVEL_COLORS[session.level] ?? '#8B90B0') + '18', color: LEVEL_COLORS[session.level] ?? '#8B90B0' }}>
                      {session.level}
                    </span>
                  </div>
                </div>
                {session.instructor_name && (
                  <div className="mt-2 text-xs" style={{ color: '#8B90B0' }}>👤 {session.instructor_name}</div>
                )}
                <div className="flex gap-2 mt-4">
                  <Link href={`/dashboard/school/attendance/${session.id}`} className="btn-navy text-xs py-2 px-3 flex-1 text-center" style={{ textDecoration: 'none' }}>
                    <CheckCircle size={12} /> Mark Attendance
                  </Link>
                  <Link href={`/dashboard/school/sessions/${session.id}/edit`} className="btn-outline text-xs py-2 px-3" style={{ textDecoration: 'none' }}>
                    Edit
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Past sessions */}
      <div>
        <h2 className="section-title">Completed Sessions</h2>
        {past.length === 0 ? (
          <div className="card-flat text-center py-10">
            <div className="text-3xl mb-2">📅</div>
            <p className="text-sm" style={{ color: '#8B90B0' }}>No completed sessions yet. Book your first workshop!</p>
          </div>
        ) : (
          <div className="card-flat overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
                  {['Date', 'School', 'Grade Range', 'Level', 'Instructor', 'Students', 'Actions'].map(h => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {past.map((session, i) => (
                  <tr key={session.id} style={{ borderBottom: i < past.length - 1 ? '1px solid #F0F2FA' : 'none' }}>
                    <td className="px-5 py-3 font-semibold" style={{ color: '#2B2D42' }}>
                      {new Date(session.session_date).toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })}
                    </td>
                    <td className="px-5 py-3" style={{ color: '#2B2D42' }}>{(session as any).schools?.name ?? '—'}</td>
                    <td className="px-5 py-3 text-xs" style={{ color: '#8B90B0' }}>{session.grade_range ?? '—'}</td>
                    <td className="px-5 py-3">
                      <span className="badge text-xs" style={{ background: (LEVEL_COLORS[session.level] ?? '#8B90B0') + '18', color: LEVEL_COLORS[session.level] ?? '#8B90B0' }}>{session.level}</span>
                    </td>
                    <td className="px-5 py-3 text-xs" style={{ color: '#8B90B0' }}>{session.instructor_name ?? '—'}</td>
                    <td className="px-5 py-3 font-bold" style={{ color: '#2B2D42' }}>{session.capacity ?? '—'}</td>
                    <td className="px-5 py-3">
                      <Link href={`/dashboard/school/attendance/${session.id}`} className="text-xs font-bold" style={{ color: '#0EA5E9', textDecoration: 'none' }}>
                        View Report
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
