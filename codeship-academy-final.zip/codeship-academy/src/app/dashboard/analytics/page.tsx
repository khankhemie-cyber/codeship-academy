import { createClient } from '@/lib/supabase/server'
import { Users, BookOpen, CreditCard, TrendingUp, Target, Award } from 'lucide-react'

export default async function AnalyticsPage() {
  const supabase = createClient()

  const [
    { count: totalUsers },
    { count: totalStudents },
    { count: totalLessons },
    { count: totalQuizzes },
    { count: activeSubscriptions },
    { count: totalAttempts },
  ] = await Promise.all([
    supabase.from('users').select('*', { count: 'exact', head: true }),
    supabase.from('student_profiles').select('*', { count: 'exact', head: true }),
    supabase.from('lessons').select('*', { count: 'exact', head: true }).eq('status', 'published'),
    supabase.from('quizzes').select('*', { count: 'exact', head: true }).eq('status', 'published'),
    supabase.from('subscriptions').select('*', { count: 'exact', head: true }).in('status', ['active', 'trialing']),
    supabase.from('quiz_attempts').select('*', { count: 'exact', head: true }),
  ])

  // Recent registrations
  const { data: recentUsers } = await supabase.from('users').select('id, full_name, email, role, created_at').order('created_at', { ascending: false }).limit(10)

  // Level breakdown
  const { data: levelBreakdown } = await supabase.from('student_profiles').select('level')
  const levels: Record<string, number> = {}
  levelBreakdown?.forEach(s => { levels[s.level] = (levels[s.level] || 0) + 1 })

  // Subscription breakdown
  const { data: subBreakdown } = await supabase.from('subscriptions').select('plan, status')
  const plans: Record<string, number> = {}
  subBreakdown?.forEach(s => { plans[s.plan] = (plans[s.plan] || 0) + 1 })

  const metrics = [
    { label: 'Total Users', value: totalUsers || 0, icon: Users, color: '#0EA5E9' },
    { label: 'Students', value: totalStudents || 0, icon: Target, color: '#7C3AED' },
    { label: 'Active Subscriptions', value: activeSubscriptions || 0, icon: CreditCard, color: '#22C55E' },
    { label: 'Published Lessons', value: totalLessons || 0, icon: BookOpen, color: '#F59E0B' },
    { label: 'Quiz Attempts', value: totalAttempts || 0, icon: TrendingUp, color: '#EF4444' },
    { label: 'Total Quizzes', value: totalQuizzes || 0, icon: Award, color: '#F5C518' },
  ]

  return (
    <div className="p-6 space-y-6 animate-in">
      <div>
        <h1 className="page-header">Platform Analytics</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>Live overview — admin only</p>
      </div>

      {/* Key metrics */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {metrics.map(m => (
          <div key={m.label} className="card-flat flex items-center gap-3 p-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: m.color + '18' }}>
              <m.icon size={20} style={{ color: m.color }} />
            </div>
            <div>
              <div className="text-2xl font-black" style={{ color: '#2B2D42' }}>{m.value.toLocaleString()}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>{m.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Level breakdown */}
        <div className="card-flat">
          <h2 className="section-title">Students by Level</h2>
          {Object.entries(levels).map(([level, count]) => (
            <div key={level} className="mb-3">
              <div className="flex justify-between text-sm mb-1">
                <span className="font-semibold" style={{ color: '#2B2D42' }}>{level}</span>
                <span className="font-black" style={{ color: '#2B2D42' }}>{count}</span>
              </div>
              <div className="progress-bar h-2">
                <div className="progress-fill" style={{ width: `${totalStudents ? (count / totalStudents!) * 100 : 0}%` }} />
              </div>
            </div>
          ))}
          {!Object.keys(levels).length && <p className="text-sm" style={{ color: '#8B90B0' }}>No data yet.</p>}
        </div>

        {/* Plans breakdown */}
        <div className="card-flat">
          <h2 className="section-title">Subscriptions by Plan</h2>
          {Object.entries(plans).map(([plan, count]) => (
            <div key={plan} className="flex items-center justify-between py-2 border-b last:border-0" style={{ borderColor: '#F0F2FA' }}>
              <span className="text-sm font-semibold capitalize" style={{ color: '#2B2D42' }}>{plan}</span>
              <span className="badge text-xs" style={{ background: '#F5C51820', color: '#F5C518' }}>{count}</span>
            </div>
          ))}
          {!Object.keys(plans).length && <p className="text-sm" style={{ color: '#8B90B0' }}>No data yet.</p>}
        </div>
      </div>

      {/* Recent users */}
      <div className="card-flat overflow-hidden p-0">
        <div className="px-5 py-4 border-b" style={{ borderColor: '#E8EAF6' }}>
          <h2 className="font-black text-base" style={{ color: '#2B2D42' }}>Recent Registrations</h2>
        </div>
        <table className="w-full">
          <thead><tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
            {['User', 'Role', 'Joined'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>)}
          </tr></thead>
          <tbody>
            {recentUsers?.map(u => (
              <tr key={u.id} style={{ borderBottom: '1px solid #F0F2FA' }}>
                <td className="px-4 py-3">
                  <div className="font-semibold text-sm" style={{ color: '#2B2D42' }}>{u.full_name || '—'}</div>
                  <div className="text-xs" style={{ color: '#8B90B0' }}>{u.email}</div>
                </td>
                <td className="px-4 py-3"><span className="badge text-xs capitalize">{u.role}</span></td>
                <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0' }}>{new Date(u.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
