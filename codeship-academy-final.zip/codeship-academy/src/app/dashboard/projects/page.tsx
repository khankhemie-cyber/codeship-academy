import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Code2, Clock, ChevronRight, Plus, CheckCircle, FolderOpen } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function ProjectsPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: profile } = await supabase.from('users').select('role').eq('id', user!.id).single()
  const { data: projects } = await supabase.from('projects').select('*').eq('status', 'published').order('level').order('order_index')

  // Get submissions for student
  const { data: studentProfile } = await supabase.from('student_profiles').select('id').eq('user_id', user!.id).single()
  const { data: submissions } = studentProfile
    ? await supabase.from('project_submissions').select('project_id,submission_type,submitted_at').eq('student_id', studentProfile.id)
    : { data: [] }
  const submissionMap: Record<string, { type: string; date: string }> = {}
  submissions?.forEach(s => { submissionMap[s.project_id] = { type: s.submission_type, date: s.submitted_at } })

  const levels: LevelName[] = ['Explorers', 'Builders', 'Developers', 'Engineers']

  return (
    <div className="p-6 space-y-8 animate-in">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="page-header">Projects</h1>
          <p className="text-sm" style={{ color: '#8B90B0' }}>Build real things and show what you know</p>
        </div>
        {profile?.role === 'admin' && (
          <Link href="/dashboard/projects/new" className="btn-primary text-sm"><Plus size={15} /> New Project</Link>
        )}
      </div>

      {levels.map(level => {
        const levelProjects = projects?.filter(p => p.level === level) ?? []
        if (!levelProjects.length) return null
        const lvl = getLevelConfig(level)
        return (
          <div key={level}>
            <div className="flex items-center gap-2.5 mb-4">
              <span className="text-lg">{lvl.icon}</span>
              <h2 className="text-base font-black" style={{ color: '#2B2D42' }}>{level}</h2>
              <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{lvl.grades}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {levelProjects.map(project => {
                const submission = submissionMap[project.id]
                const isFinal = submission?.type === 'final'
                return (
                  <div key={project.id} className="card p-5">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#7C3AED18' }}>
                        {isFinal ? <CheckCircle size={20} style={{ color: '#22C55E' }} /> : <Code2 size={20} style={{ color: '#7C3AED' }} />}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-black text-sm mb-1" style={{ color: '#2B2D42' }}>{project.title}</h3>
                        <p className="text-xs" style={{ color: '#8B90B0', lineHeight: 1.5 }}>{project.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-xs mb-4" style={{ color: '#8B90B0' }}>
                      <span className="flex items-center gap-1"><Clock size={11} />{project.duration_minutes}m</span>
                      <span>{project.difficulty}</span>
                      {project.languages?.map((lang: string) => (
                        <span key={lang} className="px-2 py-0.5 rounded-full text-xs font-semibold" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{lang}</span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      {submission && (
                        <span className="badge text-xs" style={{ background: isFinal ? '#22C55E18' : '#F59E0B18', color: isFinal ? '#22C55E' : '#F59E0B' }}>
                          {isFinal ? '✓ Submitted' : 'Draft saved'}
                        </span>
                      )}
                      <Link href={`/dashboard/projects/${project.id}`} className="btn-navy text-xs py-2 px-4 ml-auto" style={{ textDecoration: 'none' }}>
                        {submission ? 'View Project' : 'Start Project'} <ChevronRight size={12} />
                      </Link>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}

      {/* My submissions */}
      {submissions && submissions.length > 0 && (
        <div>
          <h2 className="section-title">My Submitted Work</h2>
          <div className="card-flat space-y-3">
            {submissions.map((sub, i) => {
              const project = projects?.find(p => p.id === sub.project_id)
              return (
                <div key={i} className="flex items-center gap-4 py-3 border-b last:border-b-0" style={{ borderColor: '#F0F2FA' }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#7C3AED18' }}>
                    <FolderOpen size={15} style={{ color: '#7C3AED' }} />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-bold" style={{ color: '#2B2D42' }}>{project?.title || 'Project'}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>{new Date(sub.submitted_at).toLocaleDateString()}</div>
                  </div>
                  <span className="badge text-xs" style={{ background: sub.submission_type === 'final' ? '#22C55E18' : '#F59E0B18', color: sub.submission_type === 'final' ? '#22C55E' : '#F59E0B' }}>
                    {sub.submission_type}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
