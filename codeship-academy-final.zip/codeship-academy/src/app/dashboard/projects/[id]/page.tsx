'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Code2, Send, RefreshCw, CheckCircle, ExternalLink } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

function Markdown({ content }: { content: string }) {
  const html = content
    .replace(/^### (.+)$/gm, '<h3 style="font-weight:900;font-size:1rem;color:#1E2140;margin:16px 0 8px">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="font-weight:900;font-size:1.2rem;color:#1E2140;margin:20px 0 8px">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="font-weight:900;font-size:1.5rem;color:#1E2140;margin:0 0 12px">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre style="background:#1E2140;color:#F5C518;padding:16px;border-radius:12px;overflow-x:auto;font-family:monospace;font-size:13px;margin:12px 0"><code>$2</code></pre>')
    .replace(/`([^`]+)`/g, '<code style="background:#EEF0FA;color:#7C3AED;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:0.85em">$1</code>')
    .replace(/^- (.+)$/gm, '<li style="margin-left:20px;margin-bottom:4px;color:#3A3D5C">$1</li>')
    .replace(/^(\d+)\. (.+)$/gm, '<li style="margin-left:20px;margin-bottom:4px;color:#3A3D5C">$2</li>')
    .replace(/\n/g, '<br>')
  return <div style={{ fontSize: 14, lineHeight: 1.7, color: '#2B2D42' }} dangerouslySetInnerHTML={{ __html: html }} />
}

export default function ProjectPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const supabase = createClient()
  const [project, setProject] = useState<any>(null)
  const [submission, setSubmission] = useState<any>(null)
  const [code, setCode] = useState('')
  const [repoUrl, setRepoUrl] = useState('')
  const [liveUrl, setLiveUrl] = useState('')
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [studentId, setStudentId] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const { data: p } = await supabase.from('projects').select('*').eq('id', id).single()
      setProject(p)
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: s } = await supabase.from('student_profiles').select('id').eq('user_id', user.id).single()
        if (s) {
          setStudentId(s.id)
          const { data: sub } = await supabase.from('project_submissions').select('*').eq('student_id', s.id).eq('project_id', id).single()
          if (sub) { setSubmission(sub); setCode(sub.code_content || ''); setRepoUrl(sub.repo_url || ''); setLiveUrl(sub.live_url || ''); setNotes(sub.notes || ''); setSubmitted(sub.submission_type === 'final') }
        }
      }
    }
    load()
  }, [id])

  const save = async (type: 'draft' | 'final') => {
    if (!studentId) return
    setSubmitting(true)
    await supabase.from('project_submissions').upsert({
      student_id: studentId, project_id: id,
      code_content: code, repo_url: repoUrl, live_url: liveUrl,
      notes, submission_type: type,
      submitted_at: type === 'final' ? new Date().toISOString() : null,
    }, { onConflict: 'student_id,project_id' })
    if (type === 'final') {
      await supabase.from('progress_records').upsert({
        student_id: studentId, content_type: 'project', content_id: id,
        content_title: project?.title, status: 'completed',
        xp_earned: 100, completed_at: new Date().toISOString(),
      }, { onConflict: 'student_id,content_id' })
      setSubmitted(true)
    }
    setSubmitting(false)
  }

  if (!project) return <div className="p-6 flex justify-center"><RefreshCw className="animate-spin" style={{ color: '#F5C518' }} /></div>

  return (
    <div className="p-6 max-w-4xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-5" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back to Projects
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Instructions */}
        <div className="lg:col-span-3 space-y-4">
          <div className="card-flat">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#7C3AED18' }}>
                <Code2 size={20} style={{ color: '#7C3AED' }} />
              </div>
              <div>
                <h1 className="text-xl font-black" style={{ color: '#1E2140' }}>{project.title}</h1>
                <div className="flex gap-2 mt-1 flex-wrap">
                  <span className="badge text-xs" style={{ background: '#7C3AED18', color: '#7C3AED' }}>Project</span>
                  <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>{project.level}</span>
                  <span className="badge text-xs" style={{ background: '#EEF0FA', color: '#8B90B0' }}>⏱ {project.duration_minutes}m</span>
                  <span className="badge text-xs" style={{ background: '#F5C51820', color: '#F5C518' }}>+100 XP on submit</span>
                </div>
              </div>
            </div>
            <p className="text-sm mb-4" style={{ color: '#8B90B0', lineHeight: 1.6 }}>{project.description}</p>
            {project.languages?.length > 0 && (
              <div className="flex gap-2 flex-wrap mb-4">
                {project.languages.map((lang: string) => (
                  <span key={lang} className="badge text-xs px-2.5 py-1" style={{ background: '#1E214010', color: '#1E2140', fontWeight: 700 }}>💻 {lang}</span>
                ))}
              </div>
            )}
          </div>

          <div className="card-flat">
            <h2 className="font-black text-base mb-4" style={{ color: '#1E2140' }}>Project Instructions</h2>
            {project.instructions ? <Markdown content={project.instructions} /> : <p style={{ color: '#8B90B0' }}>Instructions coming soon.</p>}
          </div>
        </div>

        {/* Submission */}
        <div className="lg:col-span-2 space-y-4">
          {submitted && (
            <div className="rounded-xl p-4 flex items-center gap-2" style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
              <CheckCircle size={18} style={{ color: '#22C55E' }} />
              <div>
                <div className="text-sm font-bold" style={{ color: '#166534' }}>Project Submitted!</div>
                <div className="text-xs" style={{ color: '#166534' }}>+100 XP earned</div>
              </div>
            </div>
          )}

          <div className="card-flat space-y-4">
            <h2 className="font-black text-base" style={{ color: '#1E2140' }}>Your Work</h2>

            <div>
              <label className="label">Code (paste your solution)</label>
              <textarea
                className="input font-mono text-xs"
                rows={12}
                value={code}
                onChange={e => setCode(e.target.value)}
                placeholder="Paste your code here..."
                style={{ fontFamily: 'monospace', resize: 'vertical' }}
              />
            </div>

            <div>
              <label className="label">GitHub / Repo URL (optional)</label>
              <input className="input" type="url" value={repoUrl} onChange={e => setRepoUrl(e.target.value)} placeholder="https://github.com/..." />
            </div>

            <div>
              <label className="label">Live URL (optional)</label>
              <input className="input" type="url" value={liveUrl} onChange={e => setLiveUrl(e.target.value)} placeholder="https://myproject.netlify.app" />
            </div>

            {liveUrl && (
              <a href={liveUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs font-semibold" style={{ color: '#0EA5E9' }}>
                <ExternalLink size={12} /> Preview Live Project
              </a>
            )}

            <div>
              <label className="label">Notes or reflection (optional)</label>
              <textarea className="input" rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="What did you learn? What was challenging?" />
            </div>

            <div className="flex gap-3">
              <button onClick={() => save('draft')} disabled={submitting} className="btn-outline flex-1 text-sm">
                Save Draft
              </button>
              <button onClick={() => save('final')} disabled={submitting || submitted} className="btn-primary flex-1 text-sm">
                {submitting ? <RefreshCw size={14} className="animate-spin" /> : <><Send size={14} /> Submit</>}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
