'use client'
import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { CheckCircle, XCircle, ChevronRight, Clock, Target, RefreshCw, Award, ArrowLeft } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import HeartsDisplay, { useHearts } from '@/components/learning/Hearts'
import type { Quiz, QuizQuestion } from '@/types'

type Phase = 'intro' | 'playing' | 'result'

export default function QuizPlayerPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const supabase = createClient()
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const { lives, maxLives, loseLife, reset: resetHearts, showLostHeart } = useHearts(3)
  const [phase, setPhase] = useState<Phase>('intro')
  const [currentQ, setCurrentQ] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [selected, setSelected] = useState<string | null>(null)
  const [revealed, setRevealed] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const [timeSpent, setTimeSpent] = useState(0)
  const [feedback, setFeedback] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [studentId, setStudentId] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const [{ data: q }, { data: qq }] = await Promise.all([
        supabase.from('quizzes').select('*').eq('id', id).single(),
        supabase.from('quiz_questions').select('*').eq('quiz_id', id).order('order_index'),
      ])
      setQuiz(q); setQuestions(qq || [])
      setTimeLeft((q?.duration_minutes || 15) * 60)
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: s } = await supabase.from('student_profiles').select('id').eq('user_id', user.id).single()
        if (s) setStudentId(s.id)
      }
      setLoading(false)
    }
    load()
  }, [id])

  useEffect(() => {
    if (phase !== 'playing') return
    timerRef.current = setInterval(() => {
      setTimeLeft(t => { if (t <= 1) { clearInterval(timerRef.current!); finishQuiz(); return 0 } return t - 1 })
      setTimeSpent(t => t + 1)
    }, 1000)
    return () => clearInterval(timerRef.current!)
  }, [phase])

  const select = (optId: string) => {
    if (revealed) return
    setSelected(optId)
    setRevealed(true)
    setAnswers(a => ({ ...a, [questions[currentQ].id]: optId }))
    if (optId !== questions[currentQ].correct_answer) loseLife()
  }

  const next = () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ(q => q + 1); setSelected(null); setRevealed(false)
    } else {
      finishQuiz()
    }
  }

  const finishQuiz = async () => {
    clearInterval(timerRef.current!)
    setPhase('result')

    // Calculate score
    const correct = questions.filter(q => answers[q.id] === q.correct_answer).length
    const score = Math.round((correct / questions.length) * 100)

    // Get AI feedback
    try {
      const wrong = questions.filter(q => answers[q.id] !== q.correct_answer).map(q => ({
        question: q.question,
        studentAnswer: q.options?.find(o => o.id === answers[q.id])?.text || answers[q.id] || '(skipped)',
        correct: q.options?.find(o => o.id === q.correct_answer)?.text || q.correct_answer,
        explanation: q.explanation || '',
      }))
      const res = await fetch('/api/ai/quiz-feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quizTitle: quiz?.title, score, wrongQuestions: wrong }),
      })
      const d = await res.json()
      setFeedback(d.feedback || '')
    } catch {}

    // Save attempt
    if (studentId) {
      const correct = questions.filter(q => answers[q.id] === q.correct_answer).length
      const score = Math.round((correct / questions.length) * 100)
      await supabase.from('quiz_attempts').insert({
        student_id: studentId, quiz_id: id,
        answers, score, passed: score >= (quiz?.pass_score ?? 70),
        time_spent: timeSpent,
      })
      await supabase.from('progress_records').upsert({
        student_id: studentId, content_type: 'quiz', content_id: id,
        content_title: quiz?.title, status: 'completed',
        score, time_spent: timeSpent,
        xp_earned: Math.round(score / 10) * 5,
        completed_at: new Date().toISOString(),
      }, { onConflict: 'student_id,content_id' })
    }
  }

  const q = questions[currentQ]
  const correct = questions.filter(q => answers[q.id] === q.correct_answer).length
  const score = questions.length ? Math.round((correct / questions.length) * 100) : 0
  const passed = score >= (quiz?.pass_score ?? 70)
  const mins = Math.floor(timeLeft / 60)
  const secs = timeLeft % 60

  if (loading) return (
    <div className="flex items-center justify-center h-full py-20">
      <RefreshCw size={28} className="animate-spin" style={{ color: '#F5C518' }} />
    </div>
  )

  if (!quiz) return <div className="p-6">Quiz not found.</div>

  return (
    <div className="p-6 max-w-2xl mx-auto animate-in">
      <button onClick={() => router.back()} className="flex items-center gap-2 text-sm font-semibold mb-4" style={{ color: '#8B90B0', background: 'none', border: 'none', cursor: 'pointer' }}>
        <ArrowLeft size={15} /> Back
      </button>

      {/* Intro */}
      {phase === 'intro' && (
        <div className="card-flat space-y-5 text-center py-10">
          <div className="text-5xl">🎯</div>
          <div>
            <h1 className="text-2xl font-black mb-2" style={{ color: '#2B2D42' }}>{quiz.title}</h1>
            <p className="text-sm" style={{ color: '#8B90B0' }}>{quiz.description}</p>
          </div>
          <div className="flex justify-center gap-6 text-sm">
            <div className="flex items-center gap-1.5" style={{ color: '#8B90B0' }}><Target size={15} style={{ color: '#F59E0B' }} />{questions.length} questions</div>
            <div className="flex items-center gap-1.5" style={{ color: '#8B90B0' }}><Clock size={15} style={{ color: '#0EA5E9' }} />{quiz.duration_minutes} minutes</div>
            <div className="flex items-center gap-1.5" style={{ color: '#8B90B0' }}><CheckCircle size={15} style={{ color: '#22C55E' }} />Pass: {quiz.pass_score}%</div>
          </div>
          <button onClick={() => setPhase('playing')} className="btn-primary text-base px-8 py-4">
            Start Quiz <ChevronRight size={16} />
          </button>
        </div>
      )}

      {/* Playing */}
      {phase === 'playing' && q && (
        <div className="space-y-4">
          {/* Lives + Progress + timer */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="text-sm font-bold" style={{ color: '#8B90B0' }}>Question {currentQ + 1} of {questions.length}</div>
              <HeartsDisplay lives={lives} maxLives={maxLives} showLostHeart={showLostHeart} />
            </div>
            <div className="flex items-center gap-1.5 text-sm font-bold" style={{ color: timeLeft < 60 ? '#EF4444' : '#8B90B0' }}>
              <Clock size={14} /> {mins}:{secs.toString().padStart(2, '0')}
            </div>
          </div>
          {lives === 0 && (
            <div className="rounded-2xl p-5 text-center mb-4" style={{ background: '#FEF2F2', border: '1px solid #FECACA' }}>
              <div className="text-3xl mb-2">💔</div>
              <h3 className="font-black text-base mb-1" style={{ color: '#2B2D42' }}>No lives left!</h3>
              <p className="text-sm mb-3" style={{ color: '#8B90B0' }}>Take a short break and come back stronger. You're doing great! 💪</p>
              <button onClick={() => { resetHearts(); setPhase('intro'); setCurrentQ(0); setAnswers({}); }} className="btn-primary text-sm py-2 px-5">Try Again</button>
            </div>
          )}
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
            <div className="h-full rounded-full transition-all" style={{ width: `${((currentQ + 1) / questions.length) * 100}%`, background: '#F5C518' }} />
          </div>

          <div className="card-flat">
            {q.code_snippet && (
              <pre className="text-xs p-3 rounded-xl mb-4 overflow-x-auto" style={{ background: '#1E2140', color: '#F5C518', fontFamily: 'monospace' }}>
                {q.code_snippet}
              </pre>
            )}
            <h2 className="text-lg font-black mb-5" style={{ color: '#2B2D42' }}>{q.question}</h2>
            <div className="space-y-3">
              {q.options?.map(opt => {
                const isSelected = selected === opt.id
                const isCorrect = opt.id === q.correct_answer
                let style = { background: 'white', borderColor: '#E8EAF6', color: '#2B2D42' }
                if (revealed) {
                  if (isCorrect) style = { background: '#F0FDF4', borderColor: '#22C55E', color: '#166534' }
                  else if (isSelected && !isCorrect) style = { background: '#FEF2F2', borderColor: '#EF4444', color: '#991B1B' }
                } else if (isSelected) {
                  style = { background: '#FFFBEB', borderColor: '#F5C518', color: '#2B2D42' }
                }
                return (
                  <button key={opt.id} onClick={() => select(opt.id)} disabled={revealed || lives === 0} className="w-full text-left p-4 rounded-xl border-2 font-semibold text-sm transition-all flex items-center justify-between" style={style}>
                    <span>{opt.text}</span>
                    {revealed && isCorrect && <CheckCircle size={18} style={{ color: '#22C55E' }} />}
                    {revealed && isSelected && !isCorrect && <XCircle size={18} style={{ color: '#EF4444' }} />}
                  </button>
                )
              })}
            </div>

            {revealed && q.explanation && (
              <div className="mt-4 p-3 rounded-xl text-sm" style={{ background: '#FFFBEB', border: '1px solid #F5C51840' }}>
                <span className="font-bold" style={{ color: '#F5C518' }}>💡 Explanation: </span>
                <span style={{ color: '#2B2D42' }}>{q.explanation}</span>
              </div>
            )}

            {revealed && (
              <button onClick={next} className="btn-primary w-full mt-4 py-3.5">
                {currentQ < questions.length - 1 ? 'Next Question' : 'See Results'} <ChevronRight size={16} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Result */}
      {phase === 'result' && (
        <div className="card-flat text-center space-y-5 py-8">
          <div className="text-5xl">{passed ? '🎉' : '💪'}</div>
          <div>
            <h2 className="text-2xl font-black mb-1" style={{ color: '#2B2D42' }}>{passed ? 'Great job!' : 'Keep going!'}</h2>
            <div className="text-5xl font-black mb-1" style={{ color: passed ? '#22C55E' : '#F59E0B' }}>{score}%</div>
            <p className="text-sm" style={{ color: '#8B90B0' }}>{correct} of {questions.length} correct · {Math.round(timeSpent / 60)} min</p>
          </div>

          {/* Score breakdown */}
          <div className="flex justify-center gap-6">
            <div className="text-center">
              <div className="text-xl font-black" style={{ color: '#22C55E' }}>{correct}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>Correct</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-black" style={{ color: '#EF4444' }}>{questions.length - correct}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>To review</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-black" style={{ color: '#F5C518' }}>+{Math.round(score / 10) * 5}</div>
              <div className="text-xs" style={{ color: '#8B90B0' }}>XP Earned</div>
            </div>
          </div>

          {feedback && (
            <div className="text-left p-4 rounded-xl text-sm leading-relaxed" style={{ background: '#F8F9FE', border: '1px solid #E8EAF6', color: '#2B2D42' }}>
              {feedback}
            </div>
          )}

          <div className="flex gap-3 justify-center">
            <button onClick={() => { setPhase('intro'); setCurrentQ(0); setAnswers({}); setSelected(null); setRevealed(false) }} className="btn-outline py-3 px-5">
              <RefreshCw size={14} /> Try Again
            </button>
            <button onClick={() => router.push('/dashboard/quizzes')} className="btn-navy py-3 px-5">
              <Award size={14} /> All Quizzes
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
