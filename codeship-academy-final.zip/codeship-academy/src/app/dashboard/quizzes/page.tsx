import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Target, Clock, CheckCircle, Lock } from 'lucide-react'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

export default async function QuizzesPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: quizzes } = await supabase.from('quizzes').select('*, quiz_questions(count)').eq('status', 'published').order('level')

  // Get student's quiz attempts
  const { data: studentProfile } = await supabase.from('student_profiles').select('id,level').eq('user_id', user!.id).single()
  const { data: attempts } = studentProfile ? await supabase.from('quiz_attempts').select('quiz_id,score,passed').eq('student_id', studentProfile.id) : { data: [] }
  const attemptMap: Record<string, { score: number; passed: boolean }> = {}
  attempts?.forEach(a => { attemptMap[a.quiz_id] = a })

  const levels: LevelName[] = ['Explorers', 'Builders', 'Developers', 'Engineers']

  return (
    <div className="p-6 space-y-8 animate-in">
      <div>
        <h1 className="page-header">Quizzes</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>Test your knowledge and earn XP</p>
      </div>

      {levels.map(level => {
        const levelQuizzes = quizzes?.filter(q => q.level === level) ?? []
        if (!levelQuizzes.length) return null
        const lvl = getLevelConfig(level)
        return (
          <div key={level}>
            <div className="flex items-center gap-2.5 mb-4">
              <span className="text-lg">{lvl.icon}</span>
              <h2 className="text-base font-black" style={{ color: '#2B2D42' }}>{level}</h2>
              <span className="badge text-xs" style={{ background: lvl.color + '18', color: lvl.color }}>{lvl.ages}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {levelQuizzes.map(quiz => {
                const attempt = attemptMap[quiz.id]
                const isLocked = studentProfile && lvl.order > (getLevelConfig(studentProfile.level as LevelName)?.order ?? 0) + 1
                const qCount = quiz.quiz_questions?.[0]?.count ?? 0
                return (
                  <div key={quiz.id} className="card p-5 flex flex-col" style={{ opacity: isLocked ? 0.55 : 1 }}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#F59E0B18' }}>
                        {attempt?.passed ? <CheckCircle size={20} style={{ color: '#22C55E' }} /> : <Target size={20} style={{ color: '#F59E0B' }} />}
                      </div>
                      {attempt && (
                        <span className="badge text-xs" style={{ background: attempt.passed ? '#22C55E18' : '#F59E0B18', color: attempt.passed ? '#22C55E' : '#F59E0B' }}>
                          {attempt.score}%
                        </span>
                      )}
                    </div>
                    <h3 className="font-black text-sm mb-1 flex-1" style={{ color: '#2B2D42' }}>{quiz.title}</h3>
                    <p className="text-xs mb-3 flex-1" style={{ color: '#8B90B0', lineHeight: 1.5 }}>{quiz.description}</p>
                    <div className="flex items-center gap-3 text-xs mb-4" style={{ color: '#8B90B0' }}>
                      <span className="flex items-center gap-1"><Target size={11} />{qCount} Qs</span>
                      <span className="flex items-center gap-1"><Clock size={11} />{quiz.duration_minutes}m</span>
                      <span>Pass: {quiz.pass_score}%</span>
                    </div>
                    {isLocked ? (
                      <div className="flex items-center gap-2 text-xs font-semibold py-2.5 px-4 rounded-xl" style={{ background: '#F0F2FA', color: '#8B90B0' }}>
                        <Lock size={12} /> Unlock {level} first
                      </div>
                    ) : (
                      <Link href={`/dashboard/quizzes/${quiz.id}`} className="btn-navy text-xs py-2.5 text-center no-underline" style={{ textDecoration: 'none' }}>
                        {attempt ? 'Retake Quiz' : 'Start Quiz'} →
                      </Link>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}
