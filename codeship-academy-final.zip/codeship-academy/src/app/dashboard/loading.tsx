export default function DashboardLoading() {
  return (
    <div className="p-6 space-y-5 animate-pulse">
      {/* Page header skeleton */}
      <div className="flex items-center justify-between">
        <div>
          <div className="h-7 w-48 rounded-xl mb-2" style={{ background: '#EEF0FA' }} />
          <div className="h-4 w-72 rounded-lg" style={{ background: '#EEF0FA' }} />
        </div>
        <div className="h-10 w-32 rounded-xl" style={{ background: '#EEF0FA' }} />
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="rounded-2xl p-5" style={{ background: 'white', border: '1px solid #E8EAF6' }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl" style={{ background: '#EEF0FA' }} />
              <div>
                <div className="h-6 w-16 rounded-lg mb-1" style={{ background: '#EEF0FA' }} />
                <div className="h-3 w-20 rounded-md" style={{ background: '#EEF0FA' }} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Content area */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {[...Array(2)].map((_, i) => (
          <div key={i} className="rounded-2xl p-6" style={{ background: 'white', border: '1px solid #E8EAF6' }}>
            <div className="h-5 w-32 rounded-lg mb-4" style={{ background: '#EEF0FA' }} />
            <div className="space-y-3">
              {[...Array(4)].map((_, j) => (
                <div key={j} className="flex items-center gap-3 py-2">
                  <div className="w-9 h-9 rounded-xl flex-shrink-0" style={{ background: '#EEF0FA' }} />
                  <div className="flex-1">
                    <div className="h-4 w-3/4 rounded-md mb-1.5" style={{ background: '#EEF0FA' }} />
                    <div className="h-3 w-1/2 rounded-md" style={{ background: '#EEF0FA' }} />
                  </div>
                  <div className="h-7 w-20 rounded-lg" style={{ background: '#EEF0FA' }} />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
