import { createClient } from '@/lib/supabase/server'
import { CreditCard } from 'lucide-react'

export default async function AdminSubscriptionsPage() {
  const supabase = createClient()
  const { data: subscriptions } = await supabase
    .from('subscriptions')
    .select('*, users(full_name, email)')
    .order('created_at', { ascending: false })
    .limit(100)

  const statusColor: Record<string, string> = {
    active: '#22C55E', trialing: '#F5C518', canceled: '#EF4444', past_due: '#F59E0B', inactive: '#8B90B0',
  }

  const totals = { active: 0, trialing: 0, canceled: 0, past_due: 0 }
  subscriptions?.forEach(s => { if (s.status in totals) (totals as any)[s.status]++ })

  return (
    <div className="p-6 space-y-5 animate-in">
      <div>
        <h1 className="page-header">Subscriptions</h1>
        <p className="text-sm" style={{ color: '#8B90B0' }}>{subscriptions?.length} total accounts</p>
      </div>

      {/* Status summary */}
      <div className="grid grid-cols-4 gap-4">
        {Object.entries(totals).map(([status, count]) => (
          <div key={status} className="card-flat p-4">
            <div className="text-2xl font-black mb-1" style={{ color: '#2B2D42' }}>{count}</div>
            <div className="text-xs capitalize font-semibold" style={{ color: statusColor[status] || '#8B90B0' }}>{status}</div>
          </div>
        ))}
      </div>

      <div className="card-flat overflow-hidden p-0">
        <table className="w-full">
          <thead>
            <tr style={{ background: '#F8F9FE', borderBottom: '1px solid #E8EAF6' }}>
              {['User', 'Plan', 'Status', 'Period End', 'Children', 'Features'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wide" style={{ color: '#8B90B0' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {subscriptions?.map(sub => {
              const user = (sub as any).users
              return (
                <tr key={sub.id} style={{ borderBottom: '1px solid #F0F2FA' }}>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-sm" style={{ color: '#2B2D42' }}>{user?.full_name || '—'}</div>
                    <div className="text-xs" style={{ color: '#8B90B0' }}>{user?.email}</div>
                  </td>
                  <td className="px-4 py-3 text-sm capitalize font-semibold" style={{ color: '#2B2D42' }}>{sub.plan}</td>
                  <td className="px-4 py-3">
                    <span className="badge text-xs" style={{ background: (statusColor[sub.status] || '#8B90B0') + '18', color: statusColor[sub.status] || '#8B90B0' }}>{sub.status}</span>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0' }}>
                    {sub.current_period_end ? new Date(sub.current_period_end).toLocaleDateString() : '—'}
                  </td>
                  <td className="px-4 py-3 text-sm" style={{ color: '#2B2D42' }}>{sub.max_children || 1}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: '#8B90B0' }}>
                    {[sub.features?.ai_planner && 'AI', sub.features?.reports && 'Reports', sub.features?.calendar_sync && 'Cal'].filter(Boolean).join(' · ') || '—'}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
