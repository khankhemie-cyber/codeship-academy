import Link from 'next/link'
import { Rocket, Home, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)', fontFamily: 'Nunito, sans-serif' }}>
      <div className="text-center max-w-md w-full">

        {/* Logo */}
        <div className="flex items-center justify-center gap-2.5 mb-12">
          <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}>
            <Rocket size={22} color="#1E2140" />
          </div>
          <div className="text-left">
            <div className="text-white font-black text-lg leading-none">CODEship</div>
            <div className="font-black tracking-widest" style={{ color: '#F5C518', fontSize: 9 }}>ACADEMY</div>
          </div>
        </div>

        {/* 404 */}
        <div className="text-8xl font-black mb-2 leading-none" style={{ color: '#F5C518' }}>404</div>
        <div className="text-6xl mb-6">🚀</div>

        <h1 className="text-2xl font-black text-white mb-3">Houston, we have a problem!</h1>
        <p className="text-sm mb-8" style={{ color: 'rgba(255,255,255,0.55)', lineHeight: 1.7 }}>
          This page drifted off into deep space. Let's navigate you back to a safe orbit.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/dashboard"
            className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl font-black text-sm transition-all hover:scale-105"
            style={{ background: '#F5C518', color: '#1E2140' }}
          >
            <Home size={16} /> Go to Dashboard
          </Link>
          <Link
            href="/"
            className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl font-black text-sm transition-all"
            style={{ background: 'rgba(255,255,255,0.1)', color: 'white', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            <ArrowLeft size={16} /> Back to Home
          </Link>
        </div>

        <div className="mt-12 text-xs font-bold tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.2)' }}>
          DREAM. CODE. ACHIEVE.
        </div>
      </div>
    </div>
  )
}
