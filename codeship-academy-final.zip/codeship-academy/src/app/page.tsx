import Link from 'next/link'
import { Rocket, Sparkles, Star, CheckCircle, ArrowRight, Code2, BookOpen, Target, Users } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen" style={{ fontFamily: 'var(--font-nunito), Nunito, sans-serif' }}>

      {/* ── NAV ─────────────────────────────────────────────── */}
      <nav style={{ background: '#1E2140' }} className="sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#F5C518' }}>
              <Rocket size={18} color="#1E2140" />
            </div>
            <div>
              <div className="text-white font-black text-base leading-none">CODEship</div>
              <div className="text-xs font-bold tracking-widest leading-none" style={{ color: '#F5C518', fontSize: 9 }}>ACADEMY</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6">
            {['Curriculum', 'Pricing', 'About'].map(item => (
              <Link key={item} href={`#${item.toLowerCase()}`} className="text-sm font-semibold text-white/60 hover:text-white transition-colors">{item}</Link>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login" className="text-sm font-bold text-white/70 hover:text-white transition-colors">Sign in</Link>
            <Link href="/auth/signup" className="btn-primary text-sm px-4 py-2">Start Free Trial</Link>
          </div>
        </div>
      </nav>

      {/* ── HERO ────────────────────────────────────────────── */}
      <section style={{ background: 'linear-gradient(135deg, #1E2140 0%, #2B2D42 60%, #3A3D5C 100%)' }} className="pt-24 pb-20 text-center px-6">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full text-xs font-bold px-4 py-2 mb-6" style={{ background: '#F5C51822', color: '#F5C518', border: '1px solid #F5C51844' }}>
            <Sparkles size={13} /> AI-Powered Personalized Learning
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-white mb-6 leading-tight" style={{ letterSpacing: '-1px' }}>
            Every Child<br />
            <span style={{ color: '#F5C518' }}>Can Code.</span>
          </h1>
          <p className="text-lg text-white/70 mb-10 max-w-2xl mx-auto leading-relaxed">
            CODEship Academy delivers AI-personalized coding education for children from Kindergarten to Grade 8 — with real curriculum, progress tracking, and a plan built just for your child.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/auth/signup" className="btn-primary text-base px-7 py-4 rounded-2xl">
              Start Free Trial — 14 Days <ArrowRight size={18} />
            </Link>
            <Link href="#curriculum" className="btn-outline text-base px-7 py-4 rounded-2xl" style={{ background: 'transparent', color: 'white', borderColor: 'rgba(255,255,255,0.2)' }}>
              Explore Curriculum
            </Link>
          </div>
          <div className="flex justify-center gap-8 text-sm text-white/50">
            {['No credit card required', 'Grades K–8', 'Ontario Curriculum-Aligned'].map(t => (
              <div key={t} className="flex items-center gap-1.5"><CheckCircle size={13} style={{ color: '#22C55E' }} />{t}</div>
            ))}
          </div>
        </div>
      </section>

      {/* ── LEVELS ──────────────────────────────────────────── */}
      <section id="curriculum" className="py-20 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-black mb-3" style={{ color: '#1E2140', letterSpacing: '-0.5px' }}>Four Levels. One Journey.</h2>
            <p className="text-gray-500 max-w-xl mx-auto">Each child starts at the right level and grows at their own pace with personalized support.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
            {[
              { name: 'Explorers', ages: 'Ages 6–7', grades: 'K–1', icon: '🚀', color: '#22C55E', skills: ['Patterns & sequences', 'Block coding', 'Digital citizenship'] },
              { name: 'Builders', ages: 'Ages 8–9', grades: '2–3', icon: '🔧', color: '#0EA5E9', skills: ['HTML & CSS', 'Web basics', 'Simple projects'] },
              { name: 'Developers', ages: 'Ages 10–12', grades: '4–6', icon: '💻', color: '#7C3AED', skills: ['JavaScript', 'Flexbox', 'Interactive apps'] },
              { name: 'Engineers', ages: 'Ages 13–16', grades: '7–8', icon: '⚙️', color: '#F5C518', skills: ['Python', 'JSON & APIs', 'Full projects'] },
            ].map(level => (
              <div key={level.name} className="rounded-2xl p-5 border" style={{ borderColor: level.color + '44', background: level.color + '08' }}>
                <div className="text-3xl mb-3">{level.icon}</div>
                <div className="font-black text-lg mb-0.5" style={{ color: '#1E2140' }}>{level.name}</div>
                <div className="text-xs font-semibold mb-1" style={{ color: level.color }}>{level.ages} · Grade {level.grades}</div>
                <ul className="mt-3 space-y-1.5">
                  {level.skills.map(s => <li key={s} className="text-xs text-gray-500 flex items-center gap-1.5"><CheckCircle size={10} style={{ color: level.color }} />{s}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ────────────────────────────────────────── */}
      <section className="py-20 px-6" style={{ background: '#F8F9FE' }}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-black mb-3" style={{ color: '#1E2140', letterSpacing: '-0.5px' }}>Everything Your Child Needs to Succeed</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Sparkles, title: 'AI Lesson Planner', desc: 'Our AI builds a personalized weekly plan based on your child\'s age, learning style, goals, and pace.', color: '#F5C518' },
              { icon: Target, title: 'Smart Assessments', desc: 'A 4-step assessment profiles every child\'s strengths and challenges before they start.', color: '#7C3AED' },
              { icon: Code2, title: 'Real Coding Projects', desc: '100+ lessons, 100+ projects, and 50+ quizzes in HTML, CSS, JavaScript, Python, and JSON.', color: '#0EA5E9' },
              { icon: BookOpen, title: 'Structured Curriculum', desc: 'Four levels aligned to the Ontario curriculum, from block coding to full Python applications.', color: '#22C55E' },
              { icon: Star, title: 'XP & Achievements', desc: 'Kids earn XP, build streaks, and unlock badges that make learning feel like a game.', color: '#F59E0B' },
              { icon: Users, title: 'Parent & Teacher Tools', desc: 'Full dashboards for parents and teachers to track progress, assign plans, and export reports.', color: '#EF4444' },
            ].map(feat => (
              <div key={feat.title} className="card-flat rounded-2xl p-6">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style={{ background: feat.color + '18' }}>
                  <feat.icon size={20} style={{ color: feat.color }} />
                </div>
                <h3 className="font-black text-base mb-2" style={{ color: '#1E2140' }}>{feat.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ─────────────────────────────────────────── */}
      <section id="pricing" className="py-20 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-black mb-3" style={{ color: '#1E2140' }}>Simple, Transparent Pricing</h2>
            <p className="text-gray-500">Start free. Upgrade when you're ready.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: 'Monthly', price: '$19', period: '/month', features: ['2 children', 'Full curriculum', 'AI lesson planner', 'Calendar sync'], color: '#0EA5E9' },
              { name: 'Annual', price: '$149', period: '/year', features: ['2 children', 'Full curriculum', 'AI lesson planner', 'Progress reports', 'Save 35%'], color: '#F5C518', popular: true },
              { name: 'Family', price: '$29', period: '/month', features: ['Up to 5 children', 'Full curriculum', 'AI lesson planner', 'Family insights'], color: '#7C3AED' },
            ].map(plan => (
              <div key={plan.name} className={`rounded-2xl p-6 border-2 relative ${plan.popular ? 'border-[#F5C518]' : 'border-[#E8EAF6]'}`} style={{ background: plan.popular ? '#FFFBEB' : 'white' }}>
                {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-black px-4 py-1 rounded-full" style={{ background: '#F5C518', color: '#1E2140' }}>BEST VALUE</div>}
                <div className="font-black text-lg mb-1" style={{ color: '#1E2140' }}>{plan.name}</div>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-3xl font-black" style={{ color: plan.color }}>{plan.price}</span>
                  <span className="text-sm text-gray-400">{plan.period}</span>
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map(f => <li key={f} className="text-sm text-gray-600 flex items-center gap-2"><CheckCircle size={13} style={{ color: plan.color }} />{f}</li>)}
                </ul>
                <Link href="/auth/signup" className="block text-center py-3 rounded-xl font-bold text-sm transition-all" style={{ background: plan.popular ? plan.color : plan.color + '15', color: plan.popular ? '#1E2140' : plan.color }}>
                  Get Started
                </Link>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-gray-400 mt-8">All plans include a 14-day free trial. Cancel anytime. CAD pricing shown.</p>
        </div>
      </section>

      {/* ── CTA ─────────────────────────────────────────────── */}
      <section style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }} className="py-20 px-6 text-center">
        <h2 className="text-3xl font-black text-white mb-4">Ready to launch your child's coding journey?</h2>
        <p className="text-white/60 mb-8 text-lg">Join hundreds of Canadian families on CODEship Academy.</p>
        <Link href="/auth/signup" className="btn-primary text-base px-8 py-4 rounded-2xl inline-flex">
          Start Free — No Credit Card Needed <ArrowRight size={18} />
        </Link>
        <div className="mt-6 text-white/40 text-sm font-bold tracking-widest uppercase">Dream. Code. Achieve.</div>
      </section>

      {/* ── FOOTER ──────────────────────────────────────────── */}
      <footer style={{ background: '#1E2140' }} className="py-10 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: '#F5C518' }}><Rocket size={14} color="#1E2140" /></div>
            <span className="font-black text-white">CODEship Academy</span>
          </div>
          <div className="text-sm text-white/40">© 2026 CODEship Academy · 21 Simcoe St S, Oshawa ON · admin@codeshipacademy.com</div>
          <div className="flex gap-5">
            {['Privacy', 'Terms', 'Contact'].map(t => <Link key={t} href="#" className="text-sm text-white/40 hover:text-white/70">{t}</Link>)}
          </div>
        </div>
      </footer>
    </div>
  )
}
