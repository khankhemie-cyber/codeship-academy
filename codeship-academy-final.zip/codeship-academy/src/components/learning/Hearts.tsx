'use client'
import { useState, useEffect } from 'react'

interface Props {
  maxLives?: number
  onGameOver?: () => void
}

export function useHearts(maxLives = 3) {
  const [lives, setLives] = useState(maxLives)
  const [rechargeTime, setRechargeTime] = useState<number | null>(null)
  const [showLostHeart, setShowLostHeart] = useState(false)

  const loseLife = () => {
    setLives(l => {
      const newLives = Math.max(0, l - 1)
      if (newLives === 0) {
        // Set recharge timer (30 minutes)
        setRechargeTime(Date.now() + 30 * 60 * 1000)
      }
      return newLives
    })
    setShowLostHeart(true)
    setTimeout(() => setShowLostHeart(false), 1000)
  }

  const gainLife = () => setLives(l => Math.min(maxLives, l + 1))
  const reset = () => { setLives(maxLives); setRechargeTime(null) }

  return { lives, maxLives, loseLife, gainLife, reset, rechargeTime, showLostHeart }
}

export default function HeartsDisplay({ lives, maxLives = 3, showLostHeart = false }: { lives: number; maxLives?: number; showLostHeart?: boolean }) {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: maxLives }, (_, i) => (
        <span key={i} className={`text-xl transition-all duration-300 ${i === lives && showLostHeart ? 'scale-125 opacity-0' : ''}`}
          style={{ filter: i < lives ? 'none' : 'grayscale(1) opacity(0.25)' }}>
          ❤️
        </span>
      ))}
    </div>
  )
}
