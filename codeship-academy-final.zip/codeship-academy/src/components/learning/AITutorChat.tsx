'use client'
import { useState, useRef, useEffect } from 'react'
import { Sparkles, Send, X, ChevronDown, Lightbulb, Code2, RefreshCw } from 'lucide-react'

interface Message {
  role: 'user' | 'assistant'
  content: string
}

interface Props {
  lessonTitle: string
  level: string
  language?: string
  context?: string       // lesson content snippet for context
  studentName?: string
}

const QUICK_PROMPTS = [
  "I don't understand this part",
  "Give me a hint",
  "Show me an example",
  "Why does this work?",
  "I'm stuck — help!",
]

export default function AITutorChat({ lessonTitle, level, language, context, studentName }: Props) {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open && messages.length === 0) {
      // Greeting
      setMessages([{
        role: 'assistant',
        content: `Hi ${studentName || 'there'}! 👋 I'm your CODEship AI tutor. I'm here to help you with **${lessonTitle}**. Ask me anything — no question is too small! 🚀`
      }])
    }
    if (open) setTimeout(() => inputRef.current?.focus(), 100)
  }, [open])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async (text?: string) => {
    const msg = (text || input).trim()
    if (!msg || loading) return
    setInput('')

    const newMessages: Message[] = [...messages, { role: 'user', content: msg }]
    setMessages(newMessages)
    setLoading(true)

    try {
      const res = await fetch('/api/ai/tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          lessonTitle,
          level,
          language,
          context,
          studentName,
        }),
      })
      const data = await res.json()
      const reply = data.reply || "I'm thinking... try rephrasing your question! 🤔"
      setMessages(prev => [...prev, { role: 'assistant', content: reply }])
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: "Oops! I had a hiccup. Try asking again! 🔄" }])
    }
    setLoading(false)
  }

  // Simple markdown renderer
  const renderContent = (text: string) => {
    return text
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`]+)`/g, '<code style="background:#1E214020;padding:1px 5px;border-radius:4px;font-family:monospace;font-size:0.85em">$1</code>')
      .replace(/\n/g, '<br>')
  }

  return (
    <>
      {/* Floating button */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 flex items-center gap-2 px-4 py-3 rounded-2xl shadow-xl font-bold text-sm transition-all hover:scale-105 z-50"
          style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)', color: 'white', boxShadow: '0 8px 32px rgba(30,33,64,0.35)' }}>
          <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: '#F5C518' }}>
            <Sparkles size={14} color="#1E2140" />
          </div>
          AI Tutor
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#22C55E' }} />
        </button>
      )}

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-6 right-6 w-80 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
          style={{ height: 480, background: 'white', border: '1px solid #E8EAF6', boxShadow: '0 24px 64px rgba(30,33,64,0.25)' }}>

          {/* Header */}
          <div className="flex items-center gap-2.5 px-4 py-3 flex-shrink-0" style={{ background: 'linear-gradient(135deg, #1E2140, #3A3D5C)' }}>
            <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#F5C518' }}>
              <Sparkles size={16} color="#1E2140" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-white font-black text-sm">AI Tutor</div>
              <div className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.5)' }}>{lessonTitle}</div>
            </div>
            <div className="flex gap-1">
              <button onClick={() => setMessages([])} className="p-1.5 rounded-lg hover:bg-white/10 transition-colors" title="Clear chat">
                <RefreshCw size={13} color="rgba(255,255,255,0.6)" />
              </button>
              <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg hover:bg-white/10 transition-colors">
                <ChevronDown size={15} color="rgba(255,255,255,0.6)" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {m.role === 'assistant' && (
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mr-1.5 mt-0.5" style={{ background: '#F5C518', minWidth: 24 }}>
                    <Sparkles size={12} color="#1E2140" />
                  </div>
                )}
                <div
                  className="rounded-2xl px-3 py-2.5 max-w-[85%] text-xs leading-relaxed"
                  style={{
                    background: m.role === 'user' ? '#1E2140' : '#F8F9FE',
                    color: m.role === 'user' ? 'white' : '#2B2D42',
                    borderBottomRightRadius: m.role === 'user' ? 4 : undefined,
                    borderBottomLeftRadius: m.role === 'assistant' ? 4 : undefined,
                  }}
                  dangerouslySetInnerHTML={{ __html: renderContent(m.content) }}
                />
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#F5C518' }}>
                  <Sparkles size={12} color="#1E2140" />
                </div>
                <div className="rounded-2xl px-3 py-2.5 flex items-center gap-1.5" style={{ background: '#F8F9FE' }}>
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: '#8B90B0', animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick prompts */}
          {messages.length <= 1 && (
            <div className="px-3 pb-2 flex flex-wrap gap-1.5 flex-shrink-0">
              {QUICK_PROMPTS.map(p => (
                <button key={p} onClick={() => send(p)}
                  className="text-xs px-2.5 py-1 rounded-full font-semibold transition-all hover:scale-105"
                  style={{ background: '#F5C51818', color: '#D4A800', border: '1px solid #F5C51830' }}>
                  {p}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="flex items-center gap-2 px-3 py-2.5 flex-shrink-0" style={{ borderTop: '1px solid #E8EAF6' }}>
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
              placeholder="Ask anything..."
              className="flex-1 text-xs outline-none bg-transparent"
              style={{ color: '#2B2D42', fontFamily: 'Nunito, sans-serif' }}
              disabled={loading}
            />
            <button onClick={() => send()} disabled={!input.trim() || loading}
              className="w-7 h-7 rounded-xl flex items-center justify-center transition-all disabled:opacity-40 flex-shrink-0"
              style={{ background: input.trim() ? '#F5C518' : '#EEF0FA' }}>
              <Send size={13} color={input.trim() ? '#1E2140' : '#8B90B0'} />
            </button>
          </div>
        </div>
      )}
    </>
  )
}
