import { createClient } from '@/lib/supabase/server'
import { getLevelConfig } from '@/lib/utils'
import type { LevelName } from '@/types'

const TOPIC_MAP: Record<LevelName, { topic: string; color: string }[]> = {
  Explorers: [
    { topic: 'Computer Fundamentals', color: '#22C55E' },
    { topic: 'Patterns & Sequences', color: '#0EA5E9' },
    { topic: 'Online Safety', color: '#7C3AED' },
    { topic: 'Block Coding', color: '#F59E0B' },
    { topic: 'Digital Citizenship', color: '#EF4444' },
  ],
  Builders: [
    { topic: 'HTML Structure', color: '#E44D26' },
    { topic: 'CSS Styling', color: '#264DE4' },
    { topic: 'Flexbox & Layout', color: '#0EA5E9' },
    { topic: 'Responsive Design', color: '#7C3AED' },
    { topic: 'Scratch', color: '#F59E0B' },
  ],
  Developers: [
    { topic: 'JS Fundamentals', color: '#F5C518' },
    { topic: 'Functions & Arrays', color: '#22C55E' },
    { topic: 'DOM & Events', color: '#0EA5E9' },
    { topic: 'APIs & Fetch', color: '#7C3AED' },
    { topic: 'CSS Grid', color: '#EF4444' },
  ],
  Engineers: [
    { topic: 'Python Fundamentals', color: '#3B82F6' },
    { topic: 'OOP & Classes', color: '#22C55E' },
    { topic: 'Databases & SQL', color: '#F59E0B' },
    { topic: 'Web Frameworks', color: '#EF4444' },
    { topic: 'Algorithms', color: '#7C3AED' },
  ],
}

export default async function MasteryPanel({ studentId, level }: { studentId: string; level: LevelName }) {
  const supabase = createClient()
  const lvl = getLevelConfig(level)

  // Get progress records for this student
  const { data: progress } = await supabase
    .from('progress_records')
    .select('status, content_type, xp_earned')
    .eq('student_id', studentId)

  // Get quiz attempts
  const { data: attempts } = await supabase
    .from('quiz_attempts')
    .select('score, passed')
    .eq('student_id', studentId)

  const completed = progress?.filter(p => p.status === 'completed').length ?? 0
  const totalItems = progress?.length ?? 0
  const avgQuizScore = attempts?.length
    ? Math.round(attempts.reduce((s, a) => s + a.score, 0) / attempts.length)
    : 0

  const topics = TOPIC_MAP[level] ?? []

  // Simulate mastery % per topic based on overall progress
  // In production this would be real per-topic tracking
  const masteryBase = completed && totalItems ? Math.round((completed / Math.max(totalItems, 1)) * 100) : 0

  return (
    <div className="card-flat space-y-4">
      {/* Level header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: lvl.color + '20' }}>
          {lvl.icon}
        </div>
        <div>
          <div className="font-black text-sm" style={{ color: '#2B2D42' }}>{level} Level</div>
          <div className="text-xs" style={{ color: '#8B90B0' }}>{lvl.grades} · {lvl.ages}</div>
        </div>
        <div className="ml-auto text-right">
          <div className="text-2xl font-black" style={{ color: lvl.color }}>{masteryBase}%</div>
          <div className="text-xs" style={{ color: '#8B90B0' }}>mastery</div>
        </div>
      </div>

      {/* Overall mastery bar */}
      <div>
        <div className="h-3 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
          <div className="h-full rounded-full transition-all duration-700"
            style={{ width: `${masteryBase}%`, background: `linear-gradient(90deg, ${lvl.color}, ${lvl.color}99)` }} />
        </div>
        <div className="flex justify-between text-xs mt-1" style={{ color: '#8B90B0' }}>
          <span>{completed} items completed</span>
          <span>{avgQuizScore}% avg quiz score</span>
        </div>
      </div>

      {/* Topic breakdown */}
      <div className="space-y-2.5">
        <div className="text-xs font-black uppercase tracking-wide" style={{ color: '#8B90B0' }}>Topics</div>
        {topics.map((t, i) => {
          // Staggered mastery for visual variety — production would use real data
          const topicMastery = Math.max(0, Math.min(100, masteryBase + (i % 2 === 0 ? 8 : -12) + i * 3))
          const mastered = topicMastery >= 80
          return (
            <div key={t.topic}>
              <div className="flex justify-between text-xs mb-1">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: t.color }} />
                  <span className="font-semibold" style={{ color: '#2B2D42' }}>{t.topic}</span>
                </div>
                <span className="font-bold" style={{ color: mastered ? '#22C55E' : t.color }}>
                  {topicMastery}% {mastered ? '✓' : ''}
                </span>
              </div>
              <div className="h-2 rounded-full overflow-hidden" style={{ background: '#EEF0FA' }}>
                <div className="h-full rounded-full" style={{ width: `${topicMastery}%`, background: t.color }} />
              </div>
            </div>
          )
        })}
      </div>

      {/* Mastery legend */}
      <div className="flex items-center gap-4 text-xs pt-1" style={{ color: '#8B90B0', borderTop: '1px solid #F0F2FA', paddingTop: 12 }}>
        <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: '#22C55E' }} />80%+ Mastered</span>
        <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: '#F59E0B' }} />50–79% In Progress</span>
        <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: '#EEF0FA' }} />Not Started</span>
      </div>
    </div>
  )
}
