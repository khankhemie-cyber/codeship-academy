'use client'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LanguageSwitcher({ currentLocale }: { currentLocale: string }) {
  const router = useRouter()
  const supabase = createClient()

  const toggle = async () => {
    const next = currentLocale === 'en' ? 'fr' : 'en'
    // Persist to user profile
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      await supabase.from('users').update({ locale: next }).eq('id', user.id)
    }
    // Store in cookie for middleware
    document.cookie = `NEXT_LOCALE=${next}; path=/; max-age=31536000`
    router.refresh()
  }

  return (
    <button
      onClick={toggle}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all hover:scale-105"
      style={{ background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.12)' }}
      title={currentLocale === 'en' ? 'Passer au français' : 'Switch to English'}
    >
      <span className="text-sm">{currentLocale === 'en' ? '🇫🇷' : '🇨🇦'}</span>
      <span>{currentLocale === 'en' ? 'FR' : 'EN'}</span>
    </button>
  )
}
