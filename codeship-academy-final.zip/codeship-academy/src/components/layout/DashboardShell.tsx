'use client'
import { useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  Rocket, Home, Users, Sparkles, Calendar, TrendingUp, BookOpen, CreditCard,
  Zap, FolderOpen, Target, Award, FileText, LayoutDashboard, BarChart2,
  Shield, Settings, Bell, Search, ChevronLeft, ChevronRight, LogOut,
  GraduationCap, UserCheck, Code2
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import LanguageSwitcher from '@/components/layout/LanguageSwitcher'

const NAV: Record<string, { id: string; icon: any; label: string; href: string }[]> = {
  parent: [
    { id: 'dashboard', icon: Home, label: 'Dashboard', href: '/dashboard' },
    { id: 'children', icon: Users, label: 'My Children', href: '/dashboard/children' },
    { id: 'assessment', icon: UserCheck, label: 'Assessment', href: '/dashboard/assessment' },
    { id: 'planner', icon: Sparkles, label: 'AI Planner', href: '/dashboard/planner' },
    { id: 'schedule', icon: Calendar, label: 'Schedule', href: '/dashboard/schedule' },
    { id: 'progress', icon: TrendingUp, label: 'Progress', href: '/dashboard/progress' },
    { id: 'curriculum', icon: BookOpen, label: 'Curriculum', href: '/dashboard/curriculum' },
    { id: 'subscription', icon: CreditCard, label: 'Subscription', href: '/dashboard/subscription' },
  ],
  student: [
    { id: 'dashboard', icon: Home, label: 'Home', href: '/dashboard' },
    { id: 'today', icon: Zap, label: "Today's Tasks", href: '/dashboard/today' },
    { id: 'curriculum', icon: BookOpen, label: 'Lessons', href: '/dashboard/curriculum' },
    { id: 'projects', icon: FolderOpen, label: 'My Projects', href: '/dashboard/projects' },
    { id: 'quizzes', icon: Target, label: 'Quizzes', href: '/dashboard/quizzes' },
    { id: 'progress', icon: TrendingUp, label: 'My Progress', href: '/dashboard/progress' },
    { id: 'achievements', icon: Award, label: 'Achievements', href: '/dashboard/achievements' },
    { id: 'code-lab', icon: Code2, label: 'Code Lab 🚀', href: '/dashboard/code-lab' },
    { id: 'leaderboard', icon: Award, label: 'Leaderboard', href: '/dashboard/leaderboard' },
  ],
  teacher: [
    { id: 'dashboard', icon: Home, label: 'Dashboard', href: '/dashboard' },
    { id: 'classes', icon: Users, label: 'My Classes', href: '/dashboard/classes' },
    { id: 'students', icon: Users, label: 'Students', href: '/dashboard/students' },
    { id: 'planner', icon: Sparkles, label: 'AI Planner', href: '/dashboard/planner' },
    { id: 'curriculum', icon: BookOpen, label: 'Curriculum', href: '/dashboard/curriculum' },
    { id: 'progress', icon: TrendingUp, label: 'Progress', href: '/dashboard/progress' },
    { id: 'reports', icon: FileText, label: 'Reports', href: '/dashboard/reports' },
    { id: 'school', icon: GraduationCap, label: 'School Portal', href: '/dashboard/school' },
    { id: 'schedule', icon: Calendar, label: 'Schedule', href: '/dashboard/schedule' },
  ],
  admin: [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Overview', href: '/dashboard' },
    { id: 'users', icon: Users, label: 'Users', href: '/dashboard/users' },
    { id: 'curriculum', icon: BookOpen, label: 'Content CMS', href: '/dashboard/curriculum' },
    { id: 'subscriptions', icon: CreditCard, label: 'Subscriptions', href: '/dashboard/subscriptions' },
    { id: 'analytics', icon: BarChart2, label: 'Analytics', href: '/dashboard/analytics' },
    { id: 'audit', icon: Shield, label: 'Audit Logs', href: '/dashboard/audit' },
    { id: 'settings', icon: Settings, label: 'Settings', href: '/dashboard/settings' },
  ],
}

export default function DashboardShell({
  children, user, unreadCount
}: {
  children: React.ReactNode
  user: any
  unreadCount: number
}) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const [collapsed, setCollapsed] = useState(false)
  const [search, setSearch] = useState('')

  const role = user?.role ?? 'parent'
  const navItems = NAV[role] ?? NAV.parent

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
    router.refresh()
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#F8F9FE', fontFamily: 'var(--font-nunito), Nunito, sans-serif' }}>

      {/* ── SIDEBAR ─────────────────────────────────────────── */}
      <aside
        className="flex flex-col h-full flex-shrink-0 transition-all duration-300 relative"
        style={{ width: collapsed ? 64 : 240, background: '#1E2140', zIndex: 20 }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2.5 p-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.07)', minHeight: 64 }}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#F5C518' }}>
            <Rocket size={18} color="#1E2140" />
          </div>
          {!collapsed && (
            <div>
              <div className="text-white font-black text-sm leading-none">CODEship</div>
              <div className="font-bold tracking-widest" style={{ color: '#F5C518', fontSize: 8 }}>ACADEMY</div>
            </div>
          )}
        </div>

        {/* Role badge */}
        {!collapsed && (
          <div className="px-4 py-3">
            <div className="text-xs font-bold uppercase tracking-widest px-2 py-1 rounded-lg inline-block" style={{ background: '#F5C51818', color: '#F5C518' }}>
              {role}
            </div>
          </div>
        )}

        {/* Nav */}
        <nav className="flex-1 px-2 py-2 overflow-y-auto space-y-0.5">
          {navItems.map(item => {
            const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))
            return (
              <Link
                key={item.id}
                href={item.href}
                className="sidebar-item"
                style={{
                  color: active ? '#F5C518' : 'rgba(255,255,255,0.55)',
                  background: active ? 'rgba(245,197,24,0.15)' : 'transparent',
                  justifyContent: collapsed ? 'center' : 'flex-start',
                  position: 'relative',
                }}
                title={collapsed ? item.label : undefined}
              >
                {active && !collapsed && (
                  <div className="absolute left-0 top-1/4 bottom-1/4 w-0.5 rounded-r-full" style={{ background: '#F5C518' }} />
                )}
                <item.icon size={18} />
                {!collapsed && <span className={active ? 'font-bold' : ''}>{item.label}</span>}
              </Link>
            )
          })}
        </nav>

        {/* User + Logout */}
        <div className="p-2 border-t space-y-1" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
          {!collapsed && (
            <div className="flex items-center gap-2.5 px-2 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)' }}>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0" style={{ background: '#F5C518', color: '#1E2140' }}>
                {(user?.full_name || user?.email || '?')[0].toUpperCase()}
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="text-xs font-bold text-white truncate">{user?.full_name || 'User'}</div>
                <div className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.35)' }}>{user?.email}</div>
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="sidebar-item w-full"
            style={{ justifyContent: collapsed ? 'center' : 'flex-start' }}
          >
            <LogOut size={16} />
            {!collapsed && <span className="text-sm">Sign out</span>}
          </button>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="sidebar-item w-full"
            style={{ justifyContent: collapsed ? 'center' : 'flex-end' }}
          >
            {collapsed ? <ChevronRight size={15} /> : <><span className="text-xs mr-auto">Collapse</span><ChevronLeft size={15} /></>}
          </button>
        </div>
      </aside>

      {/* ── MAIN ────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Header */}
        <header className="flex items-center justify-between px-6 bg-white border-b flex-shrink-0" style={{ height: 64, borderColor: '#E8EAF6' }}>
          <div className="flex items-center gap-3">
            <LanguageSwitcher currentLocale={user?.locale ?? "en"} />
            <div className="flex items-center gap-2 rounded-xl px-3 py-2 border text-sm" style={{ background: '#F8F9FE', borderColor: '#E8EAF6' }}>
              <Search size={14} style={{ color: '#8B90B0' }} />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search..."
                className="bg-transparent outline-none text-sm w-32"
                style={{ color: '#2B2D42', fontFamily: 'inherit' }}
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/dashboard/notifications" className="relative p-2 rounded-xl hover:bg-gray-50 transition-colors">
              <Bell size={19} style={{ color: '#8B90B0' }} />
              {unreadCount > 0 && (
                <div className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ background: '#EF4444' }} />
              )}
            </Link>
            <Link href="/dashboard/settings" className="flex items-center gap-2 rounded-xl px-3 py-1.5 hover:bg-gray-50 transition-colors">
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0" style={{ background: '#F5C518', color: '#1E2140' }}>
                {(user?.full_name || user?.email || '?')[0].toUpperCase()}
              </div>
              <span className="text-sm font-semibold hidden md:block" style={{ color: '#2B2D42' }}>{user?.full_name?.split(' ')[0] || 'User'}</span>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-white border-t flex-shrink-0" style={{ borderColor: '#E8EAF6' }}>
          <span className="text-xs font-semibold" style={{ color: '#8B90B0' }}>
            <span style={{ color: '#F5C518', fontWeight: 800 }}>CODEship</span> · DREAM. CODE. ACHIEVE.
          </span>
          <span className="text-xs" style={{ color: '#8B90B0' }}>Every Child Can Code™</span>
        </div>
      </div>
    </div>
  )
}
