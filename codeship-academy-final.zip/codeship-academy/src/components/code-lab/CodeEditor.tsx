'use client'
import { useState, useRef, useEffect } from 'react'
import { Play, RotateCcw, Copy, Download, ChevronDown, Rocket, Code2, Eye, Terminal } from 'lucide-react'

type Lang = 'html' | 'css' | 'js' | 'python'

const STARTERS: Record<Lang, string> = {
  html: `<!DOCTYPE html>
<html>
<head>
  <title>My CODEship Page</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #1E2140;
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      gap: 16px;
    }
    h1 { color: #F5C518; font-size: 2rem; margin: 0; }
    button {
      background: #F5C518;
      color: #1E2140;
      border: none;
      padding: 12px 28px;
      border-radius: 12px;
      font-size: 1rem;
      font-weight: 800;
      cursor: pointer;
      transition: transform 0.15s;
    }
    button:hover { transform: scale(1.05); }
    #count {
      font-size: 4rem;
      font-weight: 900;
      color: #F5C518;
    }
  </style>
</head>
<body>
  <h1>🚀 CODEship Counter</h1>
  <div id="count">0</div>
  <button onclick="increment()">Click me!</button>
  <script>
    let count = 0;
    function increment() {
      count++;
      document.getElementById('count').textContent = count;
    }
  </script>
</body>
</html>`,

  css: `/* CODEship CSS Playground */
body {
  font-family: 'Segoe UI', sans-serif;
  background: linear-gradient(135deg, #1E2140, #3A3D5C);
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0;
}

.card {
  background: white;
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  max-width: 360px;
}

.card h1 {
  color: #1E2140;
  font-size: 2rem;
  margin-bottom: 8px;
}

.badge {
  display: inline-block;
  background: #F5C518;
  color: #1E2140;
  font-weight: 800;
  font-size: 0.75rem;
  padding: 4px 12px;
  border-radius: 99px;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}`,

  js: `// CODEship JavaScript Playground
// Try editing and see it run!

// Create a quiz
const questions = [
  { q: "What does HTML stand for?", a: "HyperText Markup Language" },
  { q: "What does CSS stand for?", a: "Cascading Style Sheets" },
  { q: "What does JS stand for?", a: "JavaScript" }
];

let score = 0;
let current = 0;

function showQuestion() {
  if (current >= questions.length) {
    document.getElementById('app').innerHTML = \`
      <h2 style="color:#F5C518">Quiz Complete! 🎉</h2>
      <p style="font-size:3rem;font-weight:900">\${score}/\${questions.length}</p>
      <button onclick="restartQuiz()" style="margin-top:12px">Try Again</button>
    \`;
    return;
  }
  document.getElementById('question').textContent = questions[current].q;
  document.getElementById('answer').value = '';
  document.getElementById('feedback').textContent = '';
}

function checkAnswer() {
  const ans = document.getElementById('answer').value.trim();
  const correct = questions[current].a;
  const fb = document.getElementById('feedback');
  if (ans.toLowerCase() === correct.toLowerCase()) {
    fb.textContent = '✅ Correct! +1 point';
    fb.style.color = '#22C55E';
    score++;
  } else {
    fb.textContent = \`❌ Answer: \${correct}\`;
    fb.style.color = '#EF4444';
  }
  current++;
  setTimeout(showQuestion, 1500);
}

function restartQuiz() { score = 0; current = 0; showQuestion(); }

showQuestion();`,

  python: `# CODEship Python Playground
# Code runs right in the browser using Skulpt!

import random

def greet(name):
    return f"Hello, {name}! Welcome to CODEship 🚀"

def calculate_grade(score):
    if score >= 90:
        return "A - Outstanding!"
    elif score >= 80:
        return "B - Great work!"
    elif score >= 70:
        return "C - Good effort!"
    else:
        return "Keep practising!"

# Test your functions
print(greet("Zara"))
print(greet("Leo"))
print()

scores = [85, 92, 78, 95, 63, 88]
print("Grade Report:")
print("-" * 30)
for i, score in enumerate(scores, 1):
    grade = calculate_grade(score)
    print(f"Student {i}: {score}% → {grade}")

print()
print(f"Class average: {sum(scores)/len(scores):.1f}%")
print(f"Highest score: {max(scores)}%")
print(f"Lowest score:  {min(scores)}%")
`
}

const HTML_STARTERS: Record<string, string> = {
  css: `<!DOCTYPE html><html><head><style>CSSHERE</style></head><body><div class="card"><h1>🚀 CODEship</h1><p class="badge">Builder Level</p></div></body></html>`,
  js: `<!DOCTYPE html><html><head><style>body{font-family:Segoe UI,sans-serif;background:#1E2140;color:white;padding:32px;min-height:100vh;margin:0;box-sizing:border-box;}h2{color:#F5C518;margin-bottom:20px;}input{width:100%;padding:10px 14px;border-radius:10px;border:2px solid #3A3D5C;background:#2B2D42;color:white;font-size:1rem;margin-bottom:12px;box-sizing:border-box;}button{background:#F5C518;color:#1E2140;border:none;padding:10px 24px;border-radius:10px;font-weight:800;cursor:pointer;font-size:1rem;}#app h2{margin-top:0;}#question{font-size:1.2rem;font-weight:700;margin-bottom:16px;}#feedback{font-size:0.95rem;font-weight:600;margin-top:10px;min-height:24px;}</style></head><body><div id="app"><h2>🎯 CODEship Quiz</h2><p id="question"></p><input id="answer" placeholder="Your answer..." onkeydown="if(event.key==='Enter')checkAnswer()"><button onclick="checkAnswer()">Submit</button><p id="feedback"></p></div><script>JSHERE</script></body></html>`,
}

// Simple Python runner using Skulpt
const SKULPT_RUNNER = `
<!DOCTYPE html><html><head>
<script src="https://cdn.jsdelivr.net/npm/skulpt@1.2.0/dist/skulpt.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/skulpt@1.2.0/dist/skulpt-stdlib.js"></script>
<style>
  body { margin: 0; background: #1E2140; color: #F5C518; font-family: 'Courier New', monospace; font-size: 13px; padding: 16px; }
  pre { margin: 0; white-space: pre-wrap; word-break: break-all; line-height: 1.6; }
  .error { color: #EF4444; }
  .prompt { color: rgba(245,197,24,0.4); font-size: 11px; margin-bottom: 8px; }
</style>
</head><body>
<div class="prompt">▶ Running Python...</div>
<pre id="output"></pre>
<script>
function outf(text) { document.getElementById('output').textContent += text; }
function builtinRead(x) {
  if (Sk.builtinFiles?.files[x] != null) return Sk.builtinFiles.files[x];
  throw "File not found: '" + x + "'";
}
Sk.configure({ output: outf, read: builtinRead, execLimit: 10000 });
const code = \`PYTHONCODE\`;
Sk.misceval.asyncToPromise(() => Sk.importMainWithBody("<stdin>", false, code, true))
  .catch(e => {
    const out = document.getElementById('output');
    out.innerHTML += '<span class="error">\\n❌ ' + e.toString() + '</span>';
  });
</script></body></html>
`

export default function CodeEditor() {
  const [lang, setLang] = useState<Lang>('html')
  const [code, setCode] = useState<Record<Lang, string>>({ html: STARTERS.html, css: STARTERS.css, js: STARTERS.js, python: STARTERS.python })
  const [output, setOutput] = useState('')
  const [showPreview, setShowPreview] = useState(true)
  const [running, setRunning] = useState(false)
  const [copied, setCopied] = useState(false)
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Tab key support
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const ta = textareaRef.current!
      const start = ta.selectionStart, end = ta.selectionEnd
      const newCode = code[lang].substring(0, start) + '  ' + code[lang].substring(end)
      setCode(c => ({ ...c, [lang]: newCode }))
      setTimeout(() => { ta.selectionStart = ta.selectionEnd = start + 2 }, 0)
    }
  }

  const runCode = () => {
    setRunning(true)
    const iframe = iframeRef.current
    if (!iframe) { setRunning(false); return }

    let html = ''
    if (lang === 'html') {
      html = code.html
    } else if (lang === 'css') {
      html = HTML_STARTERS.css.replace('CSSHERE', code.css)
    } else if (lang === 'js') {
      html = HTML_STARTERS.js.replace('JSHERE', code.js)
    } else if (lang === 'python') {
      const escaped = code.python.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\${/g, '\\${')
      html = SKULPT_RUNNER.replace('PYTHONCODE', escaped)
    }

    iframe.srcdoc = html
    setTimeout(() => setRunning(false), 800)
  }

  // Auto-run on mount
  useEffect(() => { setTimeout(runCode, 300) }, [])

  const handleCopy = () => {
    navigator.clipboard.writeText(code[lang])
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const ext = lang === 'python' ? 'py' : lang === 'html' ? 'html' : lang === 'css' ? 'css' : 'js'
    const blob = new Blob([code[lang]], { type: 'text/plain' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `codeship-project.${ext}`
    a.click()
  }

  const langMeta: Record<Lang, { label: string; color: string; emoji: string }> = {
    html: { label: 'HTML', color: '#E44D26', emoji: '🌐' },
    css:  { label: 'CSS',  color: '#264DE4', emoji: '🎨' },
    js:   { label: 'JS',   color: '#F5C518', emoji: '⚡' },
    python: { label: 'Python', color: '#3B82F6', emoji: '🐍' },
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden" style={{ fontFamily: 'Nunito, sans-serif', background: '#0D0F1E' }}>

      {/* ── TOOLBAR ───────────────────────────────────────── */}
      <header className="flex items-center gap-3 px-4 py-2.5 flex-shrink-0" style={{ background: '#1E2140', borderBottom: '1px solid #2B2D42' }}>
        {/* Logo */}
        <div className="flex items-center gap-2 mr-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: '#F5C518' }}>
            <Rocket size={14} color="#1E2140" />
          </div>
          <div>
            <span className="text-white font-black text-xs">CODEship</span>
            <span className="text-xs font-black ml-1" style={{ color: '#F5C518' }}>EDITOR</span>
          </div>
        </div>

        {/* Language tabs */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: '#2B2D42' }}>
          {(Object.keys(langMeta) as Lang[]).map(l => (
            <button key={l} onClick={() => { setLang(l); setTimeout(runCode, 100) }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all"
              style={{ background: lang === l ? langMeta[l].color : 'transparent', color: lang === l ? (l === 'js' ? '#1E2140' : 'white') : 'rgba(255,255,255,0.45)' }}>
              {langMeta[l].emoji} {langMeta[l].label}
            </button>
          ))}
        </div>

        {/* Actions */}
        <button onClick={runCode} disabled={running}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-black transition-all disabled:opacity-60 ml-1"
          style={{ background: '#F5C518', color: '#1E2140' }}>
          <Play size={13} fill="#1E2140" /> {running ? 'Running...' : 'Run'}
        </button>

        <div className="flex gap-1 ml-auto">
          <button onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all"
            style={{ background: 'rgba(255,255,255,0.07)', color: copied ? '#22C55E' : 'rgba(255,255,255,0.6)' }}>
            <Copy size={12} /> {copied ? 'Copied!' : 'Copy'}
          </button>
          <button onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold"
            style={{ background: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.6)' }}>
            <Download size={12} /> Save
          </button>
          <button onClick={() => setCode(c => ({ ...c, [lang]: STARTERS[lang] }))}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold"
            style={{ background: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.6)' }}>
            <RotateCcw size={12} /> Reset
          </button>
          <button onClick={() => setShowPreview(p => !p)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold"
            style={{ background: showPreview ? '#7C3AED22' : 'rgba(255,255,255,0.07)', color: showPreview ? '#A78BFA' : 'rgba(255,255,255,0.6)' }}>
            <Eye size={12} /> Preview
          </button>
        </div>
      </header>

      {/* ── MAIN SPLIT ────────────────────────────────────── */}
      <div className="flex flex-1 min-h-0">

        {/* Editor */}
        <div className="flex flex-col min-w-0" style={{ flex: showPreview ? '0 0 50%' : '1', borderRight: showPreview ? '1px solid #2B2D42' : 'none' }}>
          {/* Editor header */}
          <div className="flex items-center gap-2 px-4 py-2 flex-shrink-0" style={{ background: '#161828', borderBottom: '1px solid #2B2D42' }}>
            <Code2 size={13} style={{ color: langMeta[lang].color }} />
            <span className="text-xs font-bold" style={{ color: 'rgba(255,255,255,0.5)' }}>
              codeship-project.{lang === 'python' ? 'py' : lang}
            </span>
            <div className="flex gap-1 ml-auto">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#EF4444' }} />
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#F59E0B' }} />
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#22C55E' }} />
            </div>
          </div>

          {/* Line numbers + textarea */}
          <div className="flex flex-1 min-h-0 overflow-hidden">
            {/* Line numbers */}
            <div className="flex-shrink-0 py-3 pr-2 pl-3 text-right select-none overflow-hidden" style={{ background: '#0D0F1E', minWidth: 44 }}>
              {code[lang].split('\n').map((_, i) => (
                <div key={i} style={{ fontFamily: "'Fira Code', 'Courier New', monospace", fontSize: 12, lineHeight: '22px', color: '#3A3D5C' }}>{i + 1}</div>
              ))}
            </div>

            {/* Code textarea */}
            <textarea
              ref={textareaRef}
              value={code[lang]}
              onChange={e => setCode(c => ({ ...c, [lang]: e.target.value }))}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              className="flex-1 min-w-0 resize-none outline-none border-0 py-3 px-4"
              style={{
                background: '#0D0F1E',
                color: '#E8EAF6',
                fontFamily: "'Fira Code', 'Courier New', monospace",
                fontSize: 12,
                lineHeight: '22px',
                overflowY: 'auto',
                caretColor: '#F5C518',
              }} />
          </div>
        </div>

        {/* Preview */}
        {showPreview && (
          <div className="flex flex-col min-h-0" style={{ flex: '0 0 50%' }}>
            <div className="flex items-center gap-2 px-4 py-2 flex-shrink-0" style={{ background: '#161828', borderBottom: '1px solid #2B2D42' }}>
              <Eye size={13} style={{ color: '#22C55E' }} />
              <span className="text-xs font-bold" style={{ color: 'rgba(255,255,255,0.5)' }}>
                {lang === 'python' ? 'Python Output' : 'Live Preview'}
              </span>
              {running && <div className="w-2 h-2 rounded-full ml-1 animate-pulse" style={{ background: '#22C55E' }} />}
            </div>
            <iframe
              ref={iframeRef}
              className="flex-1 min-h-0 border-0"
              sandbox="allow-scripts allow-same-origin"
              title="preview"
              style={{ background: 'white' }} />
          </div>
        )}
      </div>

      {/* ── BOTTOM STATUS ─────────────────────────────────── */}
      <div className="flex items-center gap-4 px-4 py-1.5 flex-shrink-0" style={{ background: langMeta[lang].color, minHeight: 28 }}>
        <span className="text-xs font-black" style={{ color: lang === 'js' ? '#1E2140' : 'white' }}>
          {langMeta[lang].emoji} {langMeta[lang].label}
        </span>
        <span className="text-xs font-semibold opacity-70" style={{ color: lang === 'js' ? '#1E2140' : 'white' }}>
          {code[lang].split('\n').length} lines · {code[lang].length} chars
        </span>
        <span className="ml-auto text-xs font-black" style={{ color: lang === 'js' ? '#1E2140' : 'white', opacity: 0.8 }}>
          DREAM. CODE. ACHIEVE.
        </span>
      </div>
    </div>
  )
}
