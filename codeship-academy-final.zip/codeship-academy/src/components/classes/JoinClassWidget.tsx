'use client'
import { useState } from 'react'
import { Hash, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function JoinClassWidget({ onSuccess }: { onSuccess?: (className: string) => void }) {
  const router = useRouter()
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const handleJoin = async () => {
    if (code.trim().length < 4) return
    setLoading(true); setResult(null)
    try {
      const res = await fetch('/api/classes/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code.toUpperCase().trim() }),
      })
      const data = await res.json()
      if (data.success) {
        setResult({ success: true, message: data.message || `Joined ${data.className}!` })
        onSuccess?.(data.className)
        setTimeout(() => router.refresh(), 1500)
      } else {
        setResult({ success: false, message: data.error || 'Could not join class.' })
      }
    } catch {
      setResult({ success: false, message: 'Something went wrong. Please try again.' })
    }
    setLoading(false)
  }

  return (
    <div className="card-flat space-y-3">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#F5C51820' }}>
          <Hash size={16} style={{ color: '#F5C518' }} />
        </div>
        <div>
          <div className="text-sm font-black" style={{ color: '#2B2D42' }}>Join a Class</div>
          <div className="text-xs" style={{ color: '#8B90B0' }}>Enter the code your teacher gave you</div>
        </div>
      </div>

      <div className="flex gap-2">
        <input
          value={code}
          onChange={e => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8))}
          onKeyDown={e => e.key === 'Enter' && handleJoin()}
          placeholder="e.g. ABC123"
          className="input flex-1 text-center font-black tracking-widest text-lg"
          style={{ letterSpacing: '0.2em' }}
          maxLength={8}
        />
        <button
          onClick={handleJoin}
          disabled={loading || code.trim().length < 4}
          className="btn-navy px-4 py-2.5 text-sm flex-shrink-0 disabled:opacity-50"
        >
          {loading ? <RefreshCw size={15} className="animate-spin" /> : 'Join'}
        </button>
      </div>

      {result && (
        <div className="flex items-center gap-2 p-3 rounded-xl text-sm font-semibold"
          style={{
            background: result.success ? '#22C55E10' : '#FEF2F2',
            border: `1px solid ${result.success ? '#22C55E30' : '#FECACA'}`,
            color: result.success ? '#166534' : '#991B1B',
          }}>
          {result.success
            ? <CheckCircle size={15} style={{ color: '#22C55E', flexShrink: 0 }} />
            : <AlertCircle size={15} style={{ color: '#EF4444', flexShrink: 0 }} />}
          {result.message}
        </div>
      )}
    </div>
  )
}
