import Anthropic from '@anthropic-ai/sdk'
import type { AssessmentData, LearningProfile, PlannerConfig, AIGeneratedPlan } from '@/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function generateLearningProfile(assessment: AssessmentData): Promise<Partial<LearningProfile>> {
  const message = await anthropic.messages.create({
    model: 'claude-opus-4-5',
    max_tokens: 1024,
    messages: [{
      role: 'user',
      content: `You are CODEship Academy's AI education specialist. Generate a personalized learning profile for a child based on their assessment. Return ONLY valid JSON.

Child: ${assessment.name}, Age: ${assessment.age}, Grade: ${assessment.grade}
Experience: ${assessment.experience}
Skills (1-5): ${JSON.stringify(assessment.skills)}
Interests: ${assessment.interests.join(', ')}
Challenges: ${assessment.challenges.join(', ')}
Challenge notes: ${assessment.challenge_notes || 'None'}
Goals: ${assessment.goals.join(', ')}
Learning style: ${assessment.learning_style}

CODEship Levels:
- Explorers: Ages 6-7, Grades K-1 (no prior coding needed)
- Builders: Ages 8-9, Grades 2-3 (basic concepts)
- Developers: Ages 10-12, Grades 4-6 (intermediate)
- Engineers: Ages 13-16, Grades 7-8 (advanced)

Return this exact JSON structure:
{
  "recommended_level": "Explorers|Builders|Developers|Engineers",
  "strengths": ["string", "string", "string"],
  "challenges": ["string", "string"],
  "goals": ["string", "string", "string"],
  "recommended_mix": {"lessons": 50, "projects": 30, "quizzes": 20},
  "engagement_tips": ["string", "string"],
  "weekly_pace": "X sessions per week",
  "summary": "2-3 sentence warm, encouraging summary for parents"
}`
    }]
  })

  const text = (message.content[0] as { text: string }).text.replace(/```json|```/g, '').trim()
  return JSON.parse(text)
}

export async function generateWeeklyPlan(config: PlannerConfig, profile: Partial<LearningProfile>): Promise<AIGeneratedPlan> {
  const message = await anthropic.messages.create({
    model: 'claude-opus-4-5',
    max_tokens: 2048,
    messages: [{
      role: 'user',
      content: `You are CODEship Academy's AI lesson planner. Create a personalized weekly learning plan. Return ONLY valid JSON.

Child: ${config.childName}
Level: ${config.level}
Interests: ${config.interests.join(', ')}
Challenges: ${config.challenges.join(', ')}
Sessions per week: ${config.sessionsPerWeek}
Duration per session: ${config.sessionDuration} minutes
Focus: ${config.focusPreference}
Start date: ${config.startDate}
Goals: ${profile.goals?.join(', ') || 'general progress'}
Weekly pace recommended: ${profile.weekly_pace || `${config.sessionsPerWeek} sessions/week`}

Rules:
- Do NOT overload sessions
- Include at least 1 "quick win" (easy, confidence-building)
- Include 1 "challenge task" per week
- If focus issues: keep tasks under 25 minutes, prefer projects over reading
- If reading difficulty: minimize text-heavy lessons
- Use interests to pick themes (e.g. games, art)
- Place quizzes after concept clusters, not at the start
- Each session should feel achievable and fun

Return this exact JSON:
{
  "planTitle": "string",
  "weeklyGoal": "string",
  "sessions": [
    {
      "day": "Monday",
      "date": "Apr 7",
      "time": "4:00 PM",
      "title": "string",
      "type": "lesson|project|quiz",
      "duration": 30,
      "description": "string (encouraging, child-friendly)",
      "xp": 50,
      "tags": ["string"],
      "isQuickWin": false,
      "isChallenge": false
    }
  ],
  "tips": ["string", "string"],
  "estimatedXP": 250
}`
    }]
  })

  const text = (message.content[0] as { text: string }).text.replace(/```json|```/g, '').trim()
  return JSON.parse(text)
}

export async function generateQuizFeedback(
  studentName: string,
  quizTitle: string,
  score: number,
  wrongQuestions: { question: string; studentAnswer: string; correct: string; explanation: string }[]
): Promise<string> {
  const message = await anthropic.messages.create({
    model: 'claude-opus-4-5',
    max_tokens: 512,
    messages: [{
      role: 'user',
      content: `Write encouraging, age-appropriate feedback for a child who just completed a quiz.

Student: ${studentName}
Quiz: ${quizTitle}
Score: ${score}%
Questions to review: ${wrongQuestions.length}

Wrong questions:
${wrongQuestions.map(q => `- Q: ${q.question}\n  Their answer: ${q.studentAnswer}\n  Correct: ${q.correct}\n  Hint: ${q.explanation}`).join('\n')}

Write 2-3 sentences that:
1. Celebrate what they got right
2. Gently point out what to review (use "let's review" not "wrong")
3. Encourage them to try again
Never use the words "failed", "incorrect", "wrong", or "bad". Be warm, specific, and motivating.`
    }]
  })

  return (message.content[0] as { text: string }).text
}
