import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM = process.env.EMAIL_FROM || 'CODEship Academy <noreply@codeshipacademy.com>'
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://app.codeshipacademy.com'

// ─── Base HTML template ───────────────────────────────────────────────────────
function baseTemplate(content: string, preheader = '') {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CODEship Academy</title>
</head>
<body style="margin:0;padding:0;background:#F8F9FE;font-family:'Nunito',Helvetica,Arial,sans-serif;">
${preheader ? `<div style="display:none;max-height:0;overflow:hidden;">${preheader}</div>` : ''}
<table width="100%" cellpadding="0" cellspacing="0" style="background:#F8F9FE;padding:40px 20px;">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;">
      <!-- Header -->
      <tr><td style="background:#1E2140;border-radius:16px 16px 0 0;padding:28px 32px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <div style="display:inline-flex;align-items:center;gap:10px;">
                <div style="background:#F5C518;border-radius:10px;width:38px;height:38px;display:inline-flex;align-items:center;justify-content:center;font-size:20px;">🚀</div>
                <div>
                  <div style="color:white;font-weight:900;font-size:16px;line-height:1;">CODEship</div>
                  <div style="color:#F5C518;font-weight:800;font-size:8px;letter-spacing:0.15em;">ACADEMY</div>
                </div>
              </div>
            </td>
            <td align="right" style="color:rgba(255,255,255,0.4);font-size:11px;font-weight:600;">DREAM. CODE. ACHIEVE.</td>
          </tr>
        </table>
      </td></tr>
      <!-- Body -->
      <tr><td style="background:white;padding:32px;border-left:1px solid #E8EAF6;border-right:1px solid #E8EAF6;">
        ${content}
      </td></tr>
      <!-- Footer -->
      <tr><td style="background:#F8F9FE;border-radius:0 0 16px 16px;padding:20px 32px;border:1px solid #E8EAF6;border-top:none;text-align:center;">
        <p style="color:#8B90B0;font-size:12px;margin:0 0 6px;">
          CODEship Academy · 21 Simcoe St S, Oshawa ON · <a href="${APP_URL}" style="color:#F5C518;">codeshipacademy.com</a>
        </p>
        <p style="color:#B0B4D0;font-size:11px;margin:0;">
          <a href="${APP_URL}/dashboard/settings" style="color:#B0B4D0;">Manage email preferences</a>
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`
}

// ─── Welcome email ────────────────────────────────────────────────────────────
export async function sendWelcomeEmail(to: string, firstName: string, role: string) {
  const isParent = role === 'parent'
  const html = baseTemplate(`
    <h1 style="color:#1E2140;font-size:26px;font-weight:900;margin:0 0 8px;">Welcome to CODEship! 🎉</h1>
    <p style="color:#8B90B0;font-size:15px;margin:0 0 24px;">Hi ${firstName}! Your ${isParent ? "family's" : "classroom"} coding journey starts now.</p>

    <div style="background:#FFFBEB;border:1px solid #F5C51840;border-radius:12px;padding:20px;margin-bottom:24px;">
      <p style="color:#2B2D42;font-weight:800;margin:0 0 12px;font-size:15px;">🚀 Get started in 3 steps:</p>
      <div style="display:flex;flex-direction:column;gap:10px;">
        ${isParent ? `
          <div style="color:#2B2D42;font-size:14px;">1️⃣ <strong>Add your child</strong> — set up their profile and level</div>
          <div style="color:#2B2D42;font-size:14px;">2️⃣ <strong>Run the AI Assessment</strong> — personalize their learning path</div>
          <div style="color:#2B2D42;font-size:14px;">3️⃣ <strong>Generate a lesson plan</strong> — AI builds their first week instantly</div>
        ` : `
          <div style="color:#2B2D42;font-size:14px;">1️⃣ <strong>Create your first class</strong> — get a shareable class code</div>
          <div style="color:#2B2D42;font-size:14px;">2️⃣ <strong>Share with students</strong> — they join with the code</div>
          <div style="color:#2B2D42;font-size:14px;">3️⃣ <strong>Generate lesson plans</strong> — AI plans sessions for each student</div>
        `}
      </div>
    </div>

    <table width="100%" cellpadding="0" cellspacing="0">
      <tr><td>
        <a href="${APP_URL}/dashboard" style="display:inline-block;background:#F5C518;color:#1E2140;font-weight:900;font-size:15px;padding:14px 32px;border-radius:12px;text-decoration:none;">
          Go to My Dashboard →
        </a>
      </td></tr>
    </table>

    <p style="color:#B0B4D0;font-size:13px;margin:24px 0 0;">Your 14-day free trial is active. No credit card needed.</p>
  `, `Welcome to CODEship Academy, ${firstName}!`)

  return resend.emails.send({
    from: FROM,
    to,
    subject: `🚀 Welcome to CODEship Academy, ${firstName}!`,
    html,
  })
}

// ─── Weekly progress digest ───────────────────────────────────────────────────
interface WeeklyDigestData {
  parentName: string
  children: {
    name: string
    level: string
    xpEarned: number
    totalXP: number
    lessonsCompleted: number
    quizzesTaken: number
    avgQuizScore: number
    streakDays: number
    achievements: string[]
  }[]
}

export async function sendWeeklyDigest(to: string, data: WeeklyDigestData) {
  const childrenHtml = data.children.map(child => `
    <div style="border:1px solid #E8EAF6;border-radius:12px;padding:18px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
        <div>
          <div style="color:#1E2140;font-weight:900;font-size:16px;">${child.name}</div>
          <div style="color:#8B90B0;font-size:13px;">${child.level} Level</div>
        </div>
        <div style="text-align:right;">
          <div style="color:#F5C518;font-weight:900;font-size:18px;">⚡+${child.xpEarned} XP</div>
          <div style="color:#8B90B0;font-size:11px;">this week</div>
        </div>
      </div>
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td width="25%" style="text-align:center;padding:10px;background:#F8F9FE;border-radius:8px;">
            <div style="color:#0EA5E9;font-weight:900;font-size:18px;">${child.lessonsCompleted}</div>
            <div style="color:#8B90B0;font-size:11px;font-weight:700;">Lessons</div>
          </td>
          <td width="4%"></td>
          <td width="25%" style="text-align:center;padding:10px;background:#F8F9FE;border-radius:8px;">
            <div style="color:#7C3AED;font-weight:900;font-size:18px;">${child.quizzesTaken}</div>
            <div style="color:#8B90B0;font-size:11px;font-weight:700;">Quizzes</div>
          </td>
          <td width="4%"></td>
          <td width="25%" style="text-align:center;padding:10px;background:#F8F9FE;border-radius:8px;">
            <div style="color:#22C55E;font-weight:900;font-size:18px;">${child.avgQuizScore > 0 ? child.avgQuizScore + '%' : '—'}</div>
            <div style="color:#8B90B0;font-size:11px;font-weight:700;">Avg Score</div>
          </td>
          <td width="4%"></td>
          <td width="18%" style="text-align:center;padding:10px;background:#F8F9FE;border-radius:8px;">
            <div style="color:#EF4444;font-weight:900;font-size:18px;">🔥${child.streakDays}</div>
            <div style="color:#8B90B0;font-size:11px;font-weight:700;">Streak</div>
          </td>
        </tr>
      </table>
      ${child.achievements.length > 0 ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #E8EAF6;">
          <div style="color:#F5C518;font-weight:800;font-size:13px;">🏆 New Achievements: ${child.achievements.join(', ')}</div>
        </div>
      ` : ''}
    </div>
  `).join('')

  const html = baseTemplate(`
    <h1 style="color:#1E2140;font-size:24px;font-weight:900;margin:0 0 6px;">📊 Weekly Progress Report</h1>
    <p style="color:#8B90B0;font-size:14px;margin:0 0 24px;">Hi ${data.parentName}! Here's what your ${data.children.length === 1 ? 'child' : 'children'} accomplished this week.</p>
    ${childrenHtml}
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:8px;">
      <tr><td>
        <a href="${APP_URL}/dashboard/progress" style="display:inline-block;background:#1E2140;color:white;font-weight:900;font-size:14px;padding:12px 28px;border-radius:12px;text-decoration:none;">
          View Full Progress Report →
        </a>
      </td></tr>
    </table>
  `, `Your children's CODEship progress this week`)

  return resend.emails.send({
    from: FROM,
    to,
    subject: `📊 This week at CODEship — ${data.children.map(c => c.name).join(' & ')}`,
    html,
  })
}

// ─── Milestone alert ──────────────────────────────────────────────────────────
export async function sendMilestoneEmail(
  to: string,
  parentName: string,
  childName: string,
  milestone: 'level_up' | 'streak_7' | 'streak_30' | 'first_lesson' | 'first_project' | 'first_quiz' | 'xp_500' | 'xp_1000',
) {
  const MILESTONES = {
    level_up:       { emoji: '🚀', title: `${childName} levelled up!`, desc: `${childName} has completed their current level and moved up. They are growing as a coder!` },
    streak_7:       { emoji: '🔥', title: `7-day streak!`, desc: `${childName} has coded 7 days in a row. That is incredible dedication!` },
    streak_30:      { emoji: '💎', title: `30-day streak!`, desc: `${childName} has maintained a 30-day coding streak. They are a CODEship legend!` },
    first_lesson:   { emoji: '📚', title: `First lesson complete!`, desc: `${childName} completed their very first CODEship lesson today. Their coding journey has begun!` },
    first_project:  { emoji: '💻', title: `First project submitted!`, desc: `${childName} built and submitted their first coding project. They are a real developer now!` },
    first_quiz:     { emoji: '🎯', title: `First quiz passed!`, desc: `${childName} passed their first quiz. Knowledge is power!` },
    xp_500:         { emoji: '⚡', title: `500 XP milestone!`, desc: `${childName} has earned 500 XP. They are making real progress at CODEship!` },
    xp_1000:        { emoji: '🌟', title: `1,000 XP milestone!`, desc: `${childName} hit 1,000 XP. They are one of our top learners!` },
  }

  const m = MILESTONES[milestone]
  const html = baseTemplate(`
    <div style="text-align:center;padding:16px 0 24px;">
      <div style="font-size:56px;margin-bottom:12px;">${m.emoji}</div>
      <h1 style="color:#1E2140;font-size:24px;font-weight:900;margin:0 0 8px;">${m.title}</h1>
      <p style="color:#2B2D42;font-size:15px;margin:0 0 24px;">${m.desc}</p>
      <a href="${APP_URL}/dashboard/progress" style="display:inline-block;background:#F5C518;color:#1E2140;font-weight:900;font-size:15px;padding:14px 32px;border-radius:12px;text-decoration:none;">
        See ${childName}'s Progress →
      </a>
    </div>
    <p style="color:#B0B4D0;font-size:12px;text-align:center;margin:16px 0 0;">
      Hi ${parentName} — we just wanted to share this exciting milestone!
    </p>
  `, m.desc)

  return resend.emails.send({
    from: FROM,
    to,
    subject: `${m.emoji} ${childName} — ${m.title} — CODEship Academy`,
    html,
  })
}

// ─── Class invite email ───────────────────────────────────────────────────────
export async function sendClassInviteEmail(
  to: string,
  teacherName: string,
  className: string,
  inviteUrl: string,
  classCode: string,
) {
  const html = baseTemplate(`
    <h1 style="color:#1E2140;font-size:24px;font-weight:900;margin:0 0 8px;">You've been invited to join a class! 🎉</h1>
    <p style="color:#8B90B0;font-size:14px;margin:0 0 20px;">${teacherName} has invited you to join <strong>${className}</strong> on CODEship Academy.</p>

    <div style="background:#1E2140;border-radius:12px;padding:20px;text-align:center;margin-bottom:20px;">
      <div style="color:rgba(255,255,255,0.5);font-size:11px;font-weight:700;letter-spacing:0.1em;margin-bottom:6px;">CLASS CODE</div>
      <div style="color:#F5C518;font-size:32px;font-weight:900;letter-spacing:0.2em;">${classCode}</div>
    </div>

    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
      <tr><td align="center">
        <a href="${inviteUrl}" style="display:inline-block;background:#F5C518;color:#1E2140;font-weight:900;font-size:15px;padding:14px 32px;border-radius:12px;text-decoration:none;">
          Join ${className} →
        </a>
      </td></tr>
    </table>

    <p style="color:#8B90B0;font-size:13px;text-align:center;">Or go to <a href="${APP_URL}/auth/signup" style="color:#F5C518;">codeshipacademy.com</a> and enter the class code above.</p>
  `, `${teacherName} invited you to ${className}`)

  return resend.emails.send({
    from: FROM,
    to,
    subject: `🎓 ${teacherName} invited you to "${className}" on CODEship`,
    html,
  })
}
