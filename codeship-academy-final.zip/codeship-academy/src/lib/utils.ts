import { type ClassValue, clsx } from 'clsx'
import { format, formatDistanceToNow, isToday, isYesterday } from 'date-fns'
import type { LevelName, Difficulty, SessionStatus, SubscriptionStatus } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return inputs.filter(Boolean).join(' ')
}

// ─── LEVEL HELPERS ────────────────────────────────────────────────────────────

export const LEVEL_CONFIG: Record<LevelName, { color: string; bg: string; ages: string; grades: string; icon: string; order: number }> = {
  Explorers: { color: '#22C55E', bg: '#F0FDF4', ages: 'Ages 6–7', grades: 'K–1', icon: '🚀', order: 1 },
  Builders: { color: '#0EA5E9', bg: '#F0F9FF', ages: 'Ages 8–9', grades: '2–3', icon: '🔧', order: 2 },
  Developers: { color: '#7C3AED', bg: '#F5F3FF', ages: 'Ages 10–12', grades: '4–6', icon: '💻', order: 3 },
  Engineers: { color: '#F5C518', bg: '#FFFBEB', ages: 'Ages 13–16', grades: '7–8', icon: '⚙️', order: 4 },
}

export function getLevelConfig(level: LevelName) {
  return LEVEL_CONFIG[level] || LEVEL_CONFIG.Explorers
}

// ─── STATUS HELPERS ───────────────────────────────────────────────────────────

export const STATUS_CONFIG: Record<SessionStatus, { label: string; color: string; bg: string }> = {
  not_started: { label: 'Not Started', color: '#8B90B0', bg: '#F0F2FA' },
  in_progress: { label: 'In Progress', color: '#F59E0B', bg: '#FFFBEB' },
  completed: { label: 'Completed', color: '#22C55E', bg: '#F0FDF4' },
  skipped: { label: 'Skipped', color: '#8B90B0', bg: '#F0F2FA' },
  needs_review: { label: 'Review', color: '#EF4444', bg: '#FEF2F2' },
}

export const SUBSCRIPTION_CONFIG: Record<SubscriptionStatus, { label: string; color: string }> = {
  trialing: { label: 'Free Trial', color: '#0EA5E9' },
  active: { label: 'Active', color: '#22C55E' },
  past_due: { label: 'Past Due', color: '#F59E0B' },
  canceled: { label: 'Canceled', color: '#8B90B0' },
  unpaid: { label: 'Unpaid', color: '#EF4444' },
}

export const DIFFICULTY_CONFIG: Record<Difficulty, { label: string; color: string }> = {
  beginner: { label: 'Beginner', color: '#22C55E' },
  intermediate: { label: 'Intermediate', color: '#F59E0B' },
  advanced: { label: 'Advanced', color: '#EF4444' },
}

// ─── DATE HELPERS ─────────────────────────────────────────────────────────────

export function formatDate(date: string | Date, fmt = 'MMM d, yyyy') {
  return format(new Date(date), fmt)
}

export function formatRelative(date: string | Date) {
  const d = new Date(date)
  if (isToday(d)) return 'Today'
  if (isYesterday(d)) return 'Yesterday'
  return formatDistanceToNow(d, { addSuffix: true })
}

// ─── NUMBER HELPERS ───────────────────────────────────────────────────────────

export function formatCurrency(cents: number, currency = 'CAD') {
  return new Intl.NumberFormat('en-CA', { style: 'currency', currency }).format(cents / 100)
}

export function formatXP(xp: number) {
  if (xp >= 1000) return `${(xp / 1000).toFixed(1)}k`
  return xp.toString()
}

// ─── ICS CALENDAR EXPORT ─────────────────────────────────────────────────────

export function generateICSContent(sessions: {
  title: string
  date: string
  time?: string
  duration?: number
  description?: string
}[]) {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//CODEship Academy//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
  ]

  for (const session of sessions) {
    const startDate = new Date(`${session.date}T${session.time || '16:00'}:00`)
    const endDate = new Date(startDate.getTime() + (session.duration || 30) * 60 * 1000)

    const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'

    lines.push(
      'BEGIN:VEVENT',
      `UID:${Date.now()}-${Math.random()}@codeshipacademy.com`,
      `DTSTART:${fmt(startDate)}`,
      `DTEND:${fmt(endDate)}`,
      `SUMMARY:📚 ${session.title} — CODEship`,
      `DESCRIPTION:${session.description || 'CODEship Academy learning session'}`,
      `URL:https://app.codeshipacademy.com`,
      'END:VEVENT'
    )
  }

  lines.push('END:VCALENDAR')
  return lines.join('\r\n')
}
