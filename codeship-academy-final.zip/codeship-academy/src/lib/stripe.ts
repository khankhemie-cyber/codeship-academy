import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
  typescript: true,
})

export const PLAN_PRICES: Record<string, string> = {
  monthly:        process.env.STRIPE_PRICE_MONTHLY!,
  annual:         process.env.STRIPE_PRICE_ANNUAL!,
  family:         process.env.STRIPE_PRICE_FAMILY!,
  teacher:        process.env.STRIPE_PRICE_TEACHER!,
  sessions_5:     process.env.STRIPE_PRICE_SESSIONS_5!,
  sessions_10:    process.env.STRIPE_PRICE_SESSIONS_10!,
  sessions_20:    process.env.STRIPE_PRICE_SESSIONS_20!,
  school_monthly: process.env.STRIPE_PRICE_SCHOOL_MONTHLY!,
  school_annual:  process.env.STRIPE_PRICE_SCHOOL_ANNUAL!,
}

export const PLAN_FEATURES = {
  trial:          { max_children: 1, max_students: 0,  ai_planner: true,  calendar_sync: false, reports: false, session_packs: false, school_portal: false },
  monthly:        { max_children: 2, max_students: 0,  ai_planner: true,  calendar_sync: true,  reports: false, session_packs: false, school_portal: false },
  annual:         { max_children: 2, max_students: 0,  ai_planner: true,  calendar_sync: true,  reports: true,  session_packs: false, school_portal: false },
  family:         { max_children: 5, max_students: 0,  ai_planner: true,  calendar_sync: true,  reports: true,  session_packs: false, school_portal: false },
  teacher:        { max_children: 0, max_students: 35, ai_planner: true,  calendar_sync: true,  reports: true,  session_packs: false, school_portal: true  },
  school_monthly: { max_children: 0, max_students: 200,ai_planner: true,  calendar_sync: true,  reports: true,  session_packs: true,  school_portal: true  },
  school_annual:  { max_children: 0, max_students: 200,ai_planner: true,  calendar_sync: true,  reports: true,  session_packs: true,  school_portal: true  },
}

export const PLAN_DISPLAY = [
  {
    id: 'monthly',
    name: 'Monthly',
    price: 19,
    period: '/month',
    billedAs: '$19/month',
    maxChildren: 2,
    color: '#0EA5E9',
    popular: false,
    features: ['2 children', 'Full K–8 curriculum', 'AI lesson planner', 'Calendar sync', 'Code Lab access'],
  },
  {
    id: 'annual',
    name: 'Annual',
    price: 149,
    period: '/year',
    billedAs: '$149/year — save 35%',
    maxChildren: 2,
    color: '#F5C518',
    popular: true,
    features: ['2 children', 'Full K–8 curriculum', 'AI lesson planner', 'Calendar sync', 'Progress reports', 'PDF certificates'],
  },
  {
    id: 'family',
    name: 'Family',
    price: 29,
    period: '/month',
    billedAs: '$29/month',
    maxChildren: 5,
    color: '#7C3AED',
    popular: false,
    features: ['Up to 5 children', 'Full K–8 curriculum', 'AI planner', 'Calendar sync', 'Progress reports', 'Family insights dashboard'],
  },
  {
    id: 'teacher',
    name: 'Classroom',
    price: 49,
    period: '/month',
    billedAs: '$49/month',
    maxChildren: 0,
    maxStudents: 35,
    color: '#22C55E',
    popular: false,
    features: ['35 students', 'Class management + codes', 'AI lesson planner', 'Collective quiz review', 'Export reports', 'School portal access'],
  },
]

export const SESSION_PACKS = [
  { id: 'sessions_5',  name: '5 Sessions',  price: 495,  perSession: 99,  color: '#0EA5E9' },
  { id: 'sessions_10', name: '10 Sessions', price: 890,  perSession: 89,  color: '#7C3AED' },
  { id: 'sessions_20', name: '20 Sessions', price: 1580, perSession: 79,  color: '#F5C518' },
]

export const SCHOOL_PLANS = [
  {
    id: 'school_monthly',
    name: 'School Monthly',
    price: 299,
    period: '/month',
    students: 200,
    sessions: 20,
    color: '#22C55E',
    features: ['200 student accounts', '20 workshop sessions/year', 'Impact report dashboard', 'Dedicated support', 'Board-ready reports'],
  },
  {
    id: 'school_annual',
    name: 'School Annual',
    price: 2499,
    period: '/year',
    students: 200,
    sessions: 30,
    color: '#F5C518',
    features: ['200 student accounts', '30 workshop sessions/year', 'Impact report dashboard', 'Dedicated account manager', 'Custom curriculum alignment', 'Priority booking'],
  },
]
