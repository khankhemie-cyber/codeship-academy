/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-nunito)', 'Nunito', 'sans-serif'],
      },
      colors: {
        navy: {
          DEFAULT: '#1E2140',
          mid: '#2B2D42',
          light: '#3A3D5C',
        },
        gold: {
          DEFAULT: '#F5C518',
          dark: '#D4A800',
          light: '#FFF0A0',
        },
        brand: {
          teal: '#0EA5E9',
          purple: '#7C3AED',
          green: '#22C55E',
        },
      },
      backgroundImage: {
        'gradient-navy': 'linear-gradient(135deg, #1E2140 0%, #2B2D42 100%)',
        'gradient-gold': 'linear-gradient(135deg, #F5C518 0%, #D4A800 100%)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'spin-slow': 'spin 3s linear infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        slideUp: { '0%': { transform: 'translateY(12px)', opacity: 0 }, '100%': { transform: 'translateY(0)', opacity: 1 } },
      },
    },
  },
  plugins: [],
}
